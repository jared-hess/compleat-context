# 9-1308-1645-3581

**Cards:**

- Kykar, Wind's Fury
- Anointed Procession
- Crown of Flames
- Grapeshot

**Produces:** Infinite storm count, Near-infinite damage to any target, Infinite LTB, Infinite ETB, Infinite sacrifice triggers, Infinite death triggers

**Mana: {R}, MV: 1, Colors: URW, Popularity: 19**

**Steps:**

Cast Crown of Flames on Kykar, Wind's Fury.
Kykar Wind's Fury triggers creating 2 spirits with Anointed Procession.
Sacrifice both spirits adding {R}{R} to your mana pool with Kykar, Wind's Fury.
Return Crown of Flames to your hand with its ability.
Repeat for an arbitrarily large storm count.
Cast Grapeshot instead of Crown of Flames.

---

# 913-1385-1864-2034

**Cards:**

- Prossh, Skyraider of Kher
- Signpost Scarecrow
- Ashnod's Altar
- Zulaport Cutthroat

**Produces:** Infinite colored mana, Infinite kobold tokens, Infinite lifeloss

**Mana: , MV: 0, Colors: BRG, Popularity: 8**

**Steps:**

Cast Prossh, creating 6 kobold tokens.Sacrifice6 tokens to Altar to produce {12}.
Use {6} to produce {B}{R}{G} with Scarecrow.SacrificeProssh to Altar to put him back into the command zone.
(also producing {2})
Floating {8}{B}{R}{G}, recast Prossh for {5}{B}{R}{G}, producing 8 tokens.Sacrifice them all to Altar producing {20}, filter again, and repeat.
For eachsacrificeed creature, Cutthroat drains an opponent for 1 life.

---

# 913-1864-2034

**Cards:**

- Prossh, Skyraider of Kher
- Signpost Scarecrow
- Ashnod's Altar

**Produces:** Infinite colored mana, Infinite kobold tokens

**Mana: , MV: 0, Colors: BRG, Popularity: 8**

**Steps:**

Cast Prossh, creating 6 kobold tokens.Sacrifice6 tokens to Altar to produce {12}.
Use {6} to produce {B}{R}{G} with Scarecrow.SacrificeProssh to Altar to put him back into the command zone.
(also producing {2})
Floating {8}{B}{R}{G}, recast Prossh for {5}{B}{R}{G}, producing 8 tokens.Sacrifice them all to Altar producing {20}, filter again, and repeat.

---

# 913-1864-2034-2842

**Cards:**

- Prossh, Skyraider of Kher
- Signpost Scarecrow
- Ashnod's Altar
- Blood Artist

**Produces:** Infinite colored mana, Infinite kobold tokens, Infinite lifeloss

**Mana: , MV: 0, Colors: BRG, Popularity: 6**

**Steps:**

Cast Prossh, creating 6 kobold tokens.Sacrifice6 tokens to Altar to produce {12}.
Use {6} to produce {B}{R}{G} with Scarecrow.SacrificeProssh to Altar to put him back into the command zone.
(also producing {2})
Floating {8}{B}{R}{G}, recast Prossh for {5}{B}{R}{G}, producing 8 tokens.Sacrifice them all to Altar producing {20}, filter again, and repeat.
For eachsacrificeed creature, Artist drains an opponent for 1 life.

---

# 913-2440-2714-5105

**Cards:**

- Sigil of the New Dawn
- Mana Echoes
- Siege-Gang Commander
- Signpost Scarecrow

**Produces:** Infinite colored mana, Infinite colorless mana, Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {3}{R}{R}, MV: 5, Colors: RW, Popularity: 0**

**Steps:**

Cast Siege-Gang Commander by paying {3}{R}{R}.
When Siege-Gang Commander enters the battlefield, it and Mana Echoes trigger.
Resolve the Siege-Gang Commander trigger, creating three 1/1 Goblin creature tokens.
When the Goblin tokens enter the battlefield, Mana Echoes triggers three times.
Resolve all four Mana Echoes triggers, adding at least {16}.
Activate Signpost Scarecrow four times by paying {8}, adding {W}{R}{R}{R}.
Activate Siege-Gang Commander by paying {C}{R} and sacrificing itself.
Sigil of the New Dawn triggers, causing you to pay {C}{W} to return Siege-Gang Commander from your graveyard to your hand.
Resolve the Siege-Gang Commander activated ability, dealing 2 damage to any target.
Repeat.

---

# 914-1099-1799-2048

**Cards:**

- Grenzo, Dungeon Warden
- Epitaph Golem
- Dockside Extortionist
- Sling-Gang Lieutenant

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite Treasure tokens

**Mana: {1}{R}, MV: 2, Colors: BR, Popularity: 120**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least five Treasure tokens.
Activate four Treasure tokens by tapping and sacrificing them, adding {4}.
Activate Sling-Gang Lieutenant by sacrificing Dockside Extortionist, causing an opponent to lose 1 life and you to gain 1 life.
Activate Epitaph Golem by paying {2}, putting Dockside Extortionist on the bottom of your library from your graveyard.
Activate Grenzo by paying {2}, putting Dockside Extortionist into your graveyard from the bottom of your library, and then putting it onto the battlefield.
Repeat from step 2.

---

# 914-1214-3198

**Cards:**

- Dockside Extortionist
- Silent Departure
- Lore Drakkis

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {1}{R}, MV: 2, Colors: UR, Popularity: 1**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Cast Lore Drakkis for its mutate cost by paying {U/R}{U/R}, targeting Dockside Extortionist.
Lore Drakkis's mutate ability triggers, returning Silent Departure from your graveyard to hand.
Cast Silent Departure by paying {U}, returning Dockside Extortionist and Lore Drakkis to your hand.
Activate five Treasure tokens by tapping and sacrificing those, adding {1}{U}{U/R}{U/R}{R}.
Repeat.

---

# 914-1409

**Cards:**

- Dockside Extortionist
- Deadeye Navigator

**Produces:** Infinite blinking, Infinite colored mana, Infinite ETB, Infinite LTB, Infinite Treasure tokens

**Mana: {1}{U}, MV: 2, Colors: UR, Popularity: 1899**

**Steps:**

Activate Dockside Extortionist by paying {1}{U}, blinking it.
When Dockside Extortionist enters the battlefield, it and Deadeye Navigator's soulbond ability trigger.
Resolve the Dockside Extortionist trigger, creating at least two Treasure artifact tokens.
Resolve the Deadeye Navigator trigger, repairing it and Dockside Extortionist.
Activate two Treasures by tapping and sacrificing them, adding {1}{U}.
Repeat.

---

# 914-1458-2617

**Cards:**

- Midnight Guard
- Banishing Knack
- Dockside Extortionist

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite storm count, Infinite Treasure tokens

**Mana: {1}{R}, MV: 2, Colors: URW, Popularity: 0**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, triggering itself and Midnight Guard.
Resolve the Dockside Extortionist trigger, creating at least 3 Treasure tokens.
Resolve the Midnight Guard trigger, untapping it.
Activate a Treasure token by tapping and sacrificing it, adding {U}.
Cast Banishing Knack by paying {U} targeting Midnight Guard.
Activate Midnight Guard by tapping it, returning Dockside Extortionist from the battlefield to your hand.
Activate two Treasure tokens by tapping and sacrificing them, adding {1}{R}.
Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, triggering itself and Midnight Guard.
Resolve the Dockside Extortionist trigger, creating at least 3 Treasure tokens.
Resolve the Midnight Guard trigger, untapping it.
Repeat from step 7.

---

# 914-1639-2649

**Cards:**

- Vadrok, Apex of Thunder
- Dockside Extortionist
- Winds of Rebuke

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite mill, Infinite self-mill, Infinite storm count, Infinite Treasure tokens

**Mana: {1}{R} plus enough mana to pay for commander tax, if applicable, MV: 2, Colors: URW, Popularity: 74**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Activate six Treasure tokens by tapping and sacrificing them, adding {2}{W/U}{R}{R}{R}.
Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R} plus commander tax if applicable, putting it on top of Dockside Extortionist.
The Vadrok mutated creature triggers, allowing you to cast Winds of Rebuke from your graveyard without paying its mana cost.
Resolve Winds of Rebuke, returning Vadrok and Dockside Extortionist from the battlefield to your hand and causing each player to mill two cards.
Repeat.
If your opponents control at least seven artifacts and/or enchantments, this combo produces infinite Treasure tokens.

---

# 914-1792-2617

**Cards:**

- Midnight Guard
- Retraction Helix
- Dockside Extortionist

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite storm count, Infinite Treasure tokens

**Mana: {1}{R}, MV: 2, Colors: URW, Popularity: 0**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, triggering itself and Midnight Guard.
Resolve the Dockside Extortionist trigger, creating at least three Treasure tokens.
Resolve the Midnight Guard trigger, untapping it.
Activate three Treasure tokens by tapping and sacrificing them, adding {1}{U}{R}.
Cast Retraction Helix by paying {U}, targeting Midnight Guard.
Activate Midnight Guard by tapping it, returning Dockside Extortionist from the battlefield to your hand.
Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, triggering itself and Midnight Guard.
Resolve the Dockside Extortionist trigger, creating at least three Treasure tokens.
Resolve the Midnight Guard trigger, untapping it.
Activate two Treasure tokens by tapping and sacrificing them, adding {1}{R}.
Repeat from step 7.

---

# 914-1801-3198

**Cards:**

- Dockside Extortionist
- String of Disappearances
- Lore Drakkis

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {1}{R}, MV: 2, Colors: UR, Popularity: 6**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Cast Lore Drakkis for its mutate cost by paying {U/R}{U/R}, targeting Dockside Extortionist.
Lore Drakkis's mutate ability triggers, returning String of Disappearances from your graveyard to hand.
Cast String of Disappearances by paying {U}, returning Dockside Extortionist and Lore Drakkis to your hand.
Activate five Treasure tokens by tapping and sacrificing those, adding {1}{U}{U/R}{U/R}{R}.
Repeat.

---

# 914-2034-5003

**Cards:**

- Dockside Extortionist
- Nim Deathmantle
- Ashnod's Altar

**Produces:** Infinite colored mana, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite Treasure tokens

**Mana: {2}, MV: 2, Colors: R, Popularity: 949**

**Steps:**

Activate Ashnod's Altar by sacrificing Dockside Extortionist, adding {C}{C}.
Dockside Extortionist dies, triggering Nim Deathmantle, causing you to pay {4} to return Dockside Extortionist from your graveyard to the battlefield, and attach Nim Deathmantle to it.
Dockside Extortionist enters the battlefield, creating at least two Treasure tokens.
Activate two Treasure tokens by tapping and sacrificing them, adding two mana of any color.
Repeat.

---

# 914-2232

**Cards:**

- Dockside Extortionist
- Cloudstone Curio

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count, Infinite Treasure tokens

**Mana: {1}{R}, MV: 2, Colors: R, Popularity: 11831**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, triggering itself and Cloudstone Curio.
Resolve the Dockside Extortionist trigger, creating a number of Treasure tokens equal to the number of artifacts and/or enchantments your opponent control.
Resolve the Cloudstone Curio trigger, returning the additional nontoken nonartifact creature from the battlefield to your hand.
Activate a Treasure token by tapping and sacrificing it, adding one mana of any color.
Repeat step 5 until you have enough mana to cast the additional creature card.
Cast the additional creature by paying its mana cost.
The creature enters the battlefield, triggering Cloudstone Curio, returning Dockside Extortionist from the battlefield to your hand.
Activate two Treasure tokens by tapping and sacrificing them, adding {1}{R}.
Repeat.

---

# 914-2451-3069-5256

**Cards:**

- Sedris, the Traitor King
- Void Maw
- Altar of Dementia
- Dockside Extortionist

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinitely large Void Maw until end of turn, Infinite mill, Infinite sacrifice triggers, Infinite self-mill, Infinite Treasure tokens

**Mana: {2}{B}, MV: 3, Colors: UBR, Popularity: 1**

**Steps:**

Activate Altar of Dementia by sacrificing Dockside Extortionist, causing target player to mill cards equal to Dockside Extortionist's power.
Activate Dockside Extortionist's unearth ability by paying {2}{B}, returning it from your graveyard to the battlefield, giving it haste and exiling it at end of turn or when it leaves the battlefield.
Dockside Extortionist enters the battlefield, creating at least four Treasure tokens.
Activate three of the Treasure tokens by tapping and sacrificing them, adding {2}{B}.
Activate Altar of Dementia by sacrificing Dockside Extortionist.
Both Dockside Extortionist's undying ability and Void Maw attempt to exile Dockside Extortionist when it would be put into your graveyard.
Choose to apply the Void Maw replacement effect, exiling Dockside Extortionist.
Resolve the Altar of Dementia ability, causing target player to mill cards equal to Dockside Extortionist's power.
Activate Void Maw by putting Dockside Extortionist from exile into your graveyard, giving Void Maw +2/+2 until end of turn.
Repeat from step 2.

---

# 914-2461-3198

**Cards:**

- Dockside Extortionist
- Saving Grasp
- Lore Drakkis

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {1}{R}, MV: 2, Colors: URW, Popularity: 1**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Cast Lore Drakkis for its mutate cost by paying {U/R}{U/R}, targeting Dockside Extortionist.
Lore Drakkis's mutate ability triggers, returning Saving Grasp from your graveyard to hand.
Cast Saving Grasp by paying {U}, returning Dockside Extortionist and Lore Drakkis to your hand.
Activate five Treasure tokens by tapping and sacrificing those, adding {1}{U}{U/R}{U/R}{R}.
Repeat.

---

# 914-2504-2649

**Cards:**

- Vadrok, Apex of Thunder
- Dockside Extortionist
- Unexplained Disappearance

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite self-mill, Infinite storm count, Infinite surveil, Infinite Treasure tokens

**Mana: {1}{R} plus enough mana to pay for commander tax, if applicable, MV: 2, Colors: URW, Popularity: 1**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Activate six Treasure tokens by tapping and sacrificing them, adding {2}{W/U}{R}{R}{R}.
Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R} plus commander tax if applicable, putting it on top of Dockside Extortionist.
The Vadrok mutated creature triggers, allowing you to cast Unexplained Disappearance from your graveyard without paying its mana cost.
Resolve Unexplained Disappearance, returning Vadrok and Dockside Extortionist from the battlefield to your hand and causing you to surveil 1.
Repeat.
If your opponents control at least seven artifacts and/or enchantments, this combo produces infinite Treasure tokens.

---

# 914-2807-3198

**Cards:**

- Dockside Extortionist
- Clutch of Currents
- Lore Drakkis

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {1}{R}, MV: 2, Colors: UR, Popularity: 1**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Cast Lore Drakkis for its mutate cost by paying {U/R}{U/R}, targeting Dockside Extortionist.
Lore Drakkis's mutate ability triggers, returning Clutch of Currents from your graveyard to hand.
Cast Clutch of Currents by paying {U}, returning Dockside Extortionist and Lore Drakkis to your hand.
Activate five Treasure tokens by tapping and sacrificing those, adding {1}{U}{U/R}{U/R}{R}.
Repeat.

---

# 914-3089

**Cards:**

- Dockside Extortionist
- Barrin, Master Wizard

**Produces:** Infinite colored mana, Infinite ETB, Infinite sacrifice triggers, Infinite storm count, Infinite Treasure tokens

**Mana: {1}{R}, MV: 2, Colors: UR, Popularity: 2055**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Activate four Treasure tokens by tapping and sacrificing those, adding {R} and three mana of any color.
Activate Barrin by paying {2} and sacrificing a Treasure token, returning Dockside Extortionist to hand.
Repeat.

---

# 914-3198-3636

**Cards:**

- Dockside Extortionist
- Rescue
- Lore Drakkis

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {1}{R}, MV: 2, Colors: UR, Popularity: 4**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Cast Lore Drakkis for its mutate cost by paying {U/R}{U/R}, targeting Dockside Extortionist.
Lore Drakkis's mutate ability triggers, returning Rescue from your graveyard to hand.
Cast Rescue by paying {U}, returning Dockside Extortionist and Lore Drakkis to your hand.
Activate five Treasure tokens by tapping and sacrificing those, adding {1}{U}{U/R}{U/R}{R}.
Repeat.

---

# 914-3198-3648

**Cards:**

- Dockside Extortionist
- Word of Undoing
- Lore Drakkis

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {1}{R}, MV: 2, Colors: UR, Popularity: 1**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Cast Lore Drakkis for its mutate cost by paying {U/R}{U/R}, targeting Dockside Extortionist.
Lore Drakkis's mutate ability triggers, returning Word of Undoing from your graveyard to hand.
Cast Word of Undoing by paying {U}, returning Dockside Extortionist and Lore Drakkis to your hand.
Activate five Treasure tokens by tapping and sacrificing those, adding {1}{U}{U/R}{U/R}{R}.
Repeat.

---

# 914-3198-4263

**Cards:**

- Dockside Extortionist
- Unsummon
- Lore Drakkis

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {1}{R}, MV: 2, Colors: UR, Popularity: 4**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Cast Lore Drakkis for its mutate cost by paying {U/R}{U/R}, targeting Dockside Extortionist.
Lore Drakkis's mutate ability triggers, returning Unsummon from your graveyard to hand.
Cast Unsummon by paying {U}, returning Dockside Extortionist and Lore Drakkis to your hand.
Activate five Treasure tokens by tapping and sacrificing those, adding {1}{U}{U/R}{U/R}{R}.
Repeat.

---

# 914-3198-4643

**Cards:**

- Dockside Extortionist
- Void Snare
- Lore Drakkis

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {1}{R}, MV: 2, Colors: UR, Popularity: 7**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Cast Lore Drakkis for its mutate cost by paying {U/R}{U/R}, targeting Dockside Extortionist.
Lore Drakkis's mutate ability triggers, returning Void Snare from your graveyard to hand.
Cast Void Snare by paying {U}, returning Dockside Extortionist and Lore Drakkis to your hand.
Activate five Treasure tokens by tapping and sacrificing those, adding {1}{U}{U/R}{U/R}{R}.
Repeat.

---

# 914-3198-4953

**Cards:**

- Dockside Extortionist
- Chain of Vapor
- Lore Drakkis

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Infinite Treasure tokens

**Mana: {1}{R}, MV: 2, Colors: UR, Popularity: 227**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Activate five Treasure tokens by tapping and sacrificing them, adding {1}{U/R}{U/R}{U}{R}.
Cast Lore Drakkis for its mutate cost by paying {U/R}{U/R}, mutating it on top of Dockside Extortionist.
Lore Drakkis triggers, returning Chain of Vapor from your graveyard to your hand.
Cast Chain of Vapor by paying {U}, returning Lore Drakkis and Dockside Extortionist to your hand and choosing not to copy Chain of Vapor.
Repeat.

---

# 914-3423

**Cards:**

- Aegis Automaton
- Dockside Extortionist

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite storm count, Infinite Treasure tokens

**Mana: {1}{R}, MV: 2, Colors: RW, Popularity: 8**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least eight Treasure tokens.
Activate seven of the Treasure tokens by tapping and sacrificing them, adding {5}{W}{R}.
Activate Aegis Automaton by paying {4}{W}, returning Dockside Extortionist from the battlefield to your hand.
Repeat.

---

# 914-3593-4359-5147

**Cards:**

- Garna, the Bloodflame
- Sneak Attack
- Dockside Extortionist
- Goblin Bombardment

**Produces:** Infinite colored mana, Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite Treasure tokens

**Mana: {R}, MV: 1, Colors: BR, Popularity: 17**

**Steps:**

Activate Sneak Attack by paying {R}, putting Dockside Extortionist onto the battlefield.
Dockside Extortionist triggers, creating at least three Treasure tokens.
Activate two Treasure tokens by tapping and sacrificing those, adding {R}{R}.
Activate Goblin Bombardment by sacrificing Dockside Extortionist, dealing 1 damage to any target.
Activate Sneak Attack by paying {R}, putting Garna onto the battlefield.
Garna's enter the battlefield ability triggers.
Holding priority, activate Goblin Bombardment by sacrificing Garna, dealing 1 damage to any target.
Resolve the Garna ability, returning all creature cards put in your graveyard this turn to your hand.
Repeat.

---

# 914-4013-4659

**Cards:**

- Dockside Extortionist
- Eldrazi Displacer
- Krark-Clan Ironworks

**Produces:** Infinite blinking, Infinite colored mana, Infinite colorless mana, Infinite ETB, Infinite LTB, Infinite Treasure tokens, Infinite blinking of creatures you control except Eldrazi Displacer

**Mana: {2}{C}, MV: 3, Colors: RW, Popularity: 284**

**Steps:**

Activate Eldrazi Displacer by paying {2}{C}, blinking Dockside Extortionist.
Dockside Extortionsit enters the battlefield, creating at least three Treasure tokens.
Activate Krark-Clan Ironworks by sacrificing two Treasure tokens, adding {C}{C}{C}{C}.
Repeat.

---

# 914-5105-5147

**Cards:**

- Sigil of the New Dawn
- Dockside Extortionist
- Goblin Bombardment

**Produces:** Infinite colored mana, Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count, Infinite Treasure tokens

**Mana: {1}{R}, MV: 2, Colors: RW, Popularity: 10**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least five Treasure tokens.
Activate four of the Treasure tokens by tapping and sacrificing them, adding {2}{W}{R}.
Activate Goblin Bombardment by sacrificing Dockside Extortionist.
Sigil of the New Dawn triggers, causing you to pay {1}{W} to return Dockside Extortionist from your graveyard to your hand.
Resolve the Goblin Bombardment ability, dealing 1 damage to any target.
Repeat.

---

# 914-5105-5256

**Cards:**

- Sigil of the New Dawn
- Dockside Extortionist
- Altar of Dementia

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill, Infinite storm count, Infinite Treasure tokens

**Mana: {1}{R}, MV: 2, Colors: RW, Popularity: 7**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least five Treasure tokens.
Activate four of the Treasure tokens by tapping and sacrificing them, adding {2}{W}{R}.
Activate Altar of Dementia by sacrificing Dockside Extortionist.
Sigil of the New Dawn triggers, causing you to pay {1}{W} to return Dockside Extortionist from your graveyard to your hand.
Resolve the Altar of Dementia ability, causing target player to mill cards equal to Dockside Extortionist's power.
Repeat.

---

# 914-990-1678

**Cards:**

- Dockside Extortionist
- Recurring Nightmare
- Mayhem Devil

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite storm count, Infinite Treasure tokens

**Mana: {1}{R}, MV: 2, Colors: BR, Popularity: 0**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Activate Recurring Nightmare by sacrificing Dockside Extortionist and returning itself to hand, return Mayhem Devil to the battlefield.
Activate five Treasure tokens by tapping and sacrificing those, adding {4}{B}{B}.
Mayhem Devil triggers six times each.
Resolve the first Mayhem Devil trigger, dealing 1 damage to any target.
Repeat step 6 for each remaining Mayhem Devil trigger.
Cast Recurring Nightmare by paying {2}{B}.
Activate Recurring Nightmare by sacrificing Mayhem Devil.
Mayhem Devil trigger, dealing 1 damage to any target.
Resolve the Recurring Nightmare by returning itself to hand, return Dockside Extortionist to the battlefield.
Repeat from step 2.

---

# 92-1839-2298

**Cards:**

- Kuro, Pitlord
- Vizkopa Guildmage
- Oketra's Last Mercy

**Produces:** Each opponent loses the game

**Mana: {2}{W}{W}{W}{B}, MV: 6, Colors: WB, Popularity: 3**

**Steps:**

Activate Vizkopa Guildmage by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Activate Kuro by paying 1 life, targeting any creature.
Repeat step 2 until you have one life.
Resolve all Kuro abilities, giving the creature -1/-1 for each ability.
Cast Oketra's Last Mercy by paying {1}{W}{W}, causing your life total to become forty.
Vizkopa Guildmage triggers, causing each opponent to lose thirty-nine life.
Each opponent loses the game due to having zero or less life.

---

# 92-2063-2298

**Cards:**

- Mischievous Poltergeist
- Vizkopa Guildmage
- Oketra's Last Mercy

**Produces:** Each opponent loses the game

**Mana: {2}{W}{W}{W}{B}, MV: 6, Colors: WB, Popularity: 75**

**Steps:**

Activate Vizkopa Guildmage by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Activate Mischievous Poltergeist by paying 1 life, regenerating it.
Repeat step 2 until you have one life.
Cast Oketra's Last Mercy by paying {1}{W}{W}, causing your life total to become forty.
Vizkopa Guildmage triggers, causing each opponent to lose thirty-nine life.
Each opponent loses the game due to having zero or less life.

---

# 922-1656-3121-3866-4283

**Cards:**

- Necrotic Ooze
- Whisper, Blood Liturgist
- Altar Golem
- Abhorrent Overlord
- Marionette Master

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite tapped creature tokens

**Mana: , MV: 0, Colors: B, Popularity: 4**

**Steps:**

Tap Necrotic Ooze using Whisper, Blood Liturgist's ability to sacrifice two creatures and return Abhorrent Overlord to battlefield.
Abhorrent Overlord's ETB triggers, creating at least 5 creature tokens.
Using Altar Golem's ability, tap Abhorrent Overlord and 4 tokens to untap Necrotic Ooze.
Tap Necrotic Ooze and sacrifice Abhorrent Overlord and a tapped token to Whisper's ability to return Marionetter Master to the battlefield, creating 3 Servo tokens.
Tap Marionette Master and the 4 untapped tokens to untap Necrotic Ooze.
Sacrifice Marionetter Master and a Servo token, causing target opponent to lose 1 life and reanimating Abhorrent Overlord.
Repeat from step 2 for infinite life loss.

---

# 92-2298-2358

**Cards:**

- Blood Celebrant
- Vizkopa Guildmage
- Oketra's Last Mercy

**Produces:** Each opponent loses the game

**Mana: {2}{W}{W}{W}{B}, MV: 6, Colors: WB, Popularity: 174**

**Steps:**

Activate Blood Celebrant by paying {B} and one life, adding {B}.
Repeat step 1 until you have one life.
Activate Vizkopa Guildmage by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Cast Oketra's Last Mercy by paying {1}{W}{W}, causing your life total to become forty.
Vizkopa Guildmage triggers, causing each opponent to lose thirty-nine life.
Each opponent loses the game due to having zero or less life.

---

# 92-2298-2749

**Cards:**

- Wall of Blood
- Vizkopa Guildmage
- Oketra's Last Mercy

**Produces:** Each opponent loses the game

**Mana: {2}{W}{W}{W}{B}, MV: 6, Colors: WB, Popularity: 365**

**Steps:**

Activate Vizkopa Guildmage by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Activate Wall of Blood by paying 1 life, giving it +1/+1 until end of turn.
Repeat step 2 until you have one life.
Cast Oketra's Last Mercy by paying {1}{W}{W}, causing your life total to become forty.
Vizkopa Guildmage triggers, causing each opponent to lose thirty-nine life.
Each opponent loses the game due to having zero or less life.

---

# 92-2298-2935

**Cards:**

- Ethereal Champion
- Vizkopa Guildmage
- Oketra's Last Mercy

**Produces:** Each opponent loses the game

**Mana: {2}{W}{W}{W}{B}, MV: 6, Colors: WB, Popularity: 8**

**Steps:**

Activate Vizkopa Guildmage by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Activate Ethereal Champion by paying 1 life, preventing the next one damage dealt to it this turn.
Repeat step 2 until you have one life.
Cast Oketra's Last Mercy by paying {1}{W}{W}, causing your life total to become forty.
Vizkopa Guildmage triggers, causing each opponent to lose thirty-nine life.
Each opponent loses the game due to having zero or less life.

---

# 92-2298-3527

**Cards:**

- Spatial Binding
- Vizkopa Guildmage
- Oketra's Last Mercy

**Produces:** Each opponent loses the game

**Mana: {2}{W}{W}{W}{B}, MV: 6, Colors: WUB, Popularity: 1**

**Steps:**

Activate Vizkopa Guildmage by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Activate Spatial Binding by paying 1 life, preventing it from phasing out during your next upkeep.
Repeat step 2 until you have one life.
Cast Oketra's Last Mercy by paying {1}{W}{W}, causing your life total to become forty.
Vizkopa Guildmage triggers, causing each opponent to lose thirty-nine life.
Each opponent loses the game due to having zero or less life.

---

# 92-2298-3591

**Cards:**

- Necropotence
- Vizkopa Guildmage
- Oketra's Last Mercy

**Produces:** Each opponent loses the game

**Mana: {2}{W}{W}{W}{B}, MV: 6, Colors: WB, Popularity: 241**

**Steps:**

Activate Vizkopa Guildmage by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Activate Necropotence by paying 1 life, exiling the top card of your library.
Repeat step 2 until you have one life.
Cast Oketra's Last Mercy by paying {1}{W}{W}, causing your life total to become forty.
Vizkopa Guildmage triggers, causing each opponent to lose thirty-nine life.
Each opponent loses the game due to having zero or less life.

---

# 92-2298-3859

**Cards:**

- Cavern Harpy
- Vizkopa Guildmage
- Oketra's Last Mercy

**Produces:** Each opponent loses the game

**Mana: {2}{W}{W}{W}{B}, MV: 6, Colors: WUB, Popularity: 3**

**Steps:**

Activate Vizkopa Guildmage by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Activate Cavern Harpy by paying 1 life, targeting any creature.
Repeat step 2 until you have one life.
Resolve all Cavern Harpy abilities, returning it from the battlefield to your hand.
Cast Oketra's Last Mercy by paying {1}{W}{W}, causing your life total to become forty.
Vizkopa Guildmage triggers, causing each opponent to lose thirty-nine life.
Each opponent loses the game due to having zero or less life.

---

# 92-2749-3779

**Cards:**

- Wall of Blood
- Vizkopa Guildmage
- Swords to Plowshares

**Produces:** Infinite lifeloss, Near-infinite lifegain

**Mana: {1}{W}{W}{B}, MV: 4, Colors: WB, Popularity: 1458**

**Steps:**

Activate Vizkopa Guildmage's second ability by paying {1}{W}{B}, creating a delayed triggered ability.
Activate Wall of Blood's ability multiple times by paying 1 life each time until you are at 1 life, giving Wall of Blood +1/+1 until end of turn for each activation.
Cast Swords to Plowshares by paying {W}, exiling Wall of Blood and gaining life equal to its power.
The delayed triggered ability from Vizkopa Guildmage triggers, causing each opponent to lose that much life.

---

# 92-2927-3392

**Cards:**

- Children of Korlis
- Vizkopa Guildmage
- Plunge into Darkness

**Produces:** Each opponent loses the game, Near-infinite lifeloss

**Mana: {2}{W}{B}{B}, MV: 5, Colors: WB, Popularity: 198**

**Steps:**

Activate Vizkopa Guildmage's second ability by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Cast Plunge into Darkness by paying {1}{B}, choosing to pay an amount of life equal to the greatest lifetotal among opponent, then look at that many cards from the top of your library, putting one into your hand and exiling the rest.
Activate Children of Korils by sacrificing it, causing you to gain life equal to the amount of life you've lost this turn.
Vizkopa Guildmage triggers, causing each opponent to lose life equal to the amount of life you gained.
Each opponent loses the game due to having zero or less life.

---

# 923-2615-5112

**Cards:**

- Mairsil, the Pretender
- Spikeshot Elder
- Tree of Perdition

**Produces:** Target opponent loses the game

**Mana: {1}{R}{R}, MV: 3, Colors: UBR, Popularity: 250**

**Steps:**

Activate Mairsil using Tree of Perdition's ability by tapping it, exchanging target opponent's life total with Mairsil's toughness.
Activate Mairsil using Spikeshot Elder's ability by paying {1}{R}{R}, dealing damage equal to Mairsil's power to the opponent.
The opponent loses the game due to having zero or less life.

---

# 92-3966

**Cards:**

- Exquisite Blood
- Vizkopa Guildmage

**Produces:** Infinite lifegain triggers, Infinite lifeloss, Infinite lifegain

**Mana: {1}{W}{B}, MV: 3, Colors: WB, Popularity: 11839**

**Steps:**

Activate Vizkopa Guildmage's second ability by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Gain life.
Vizkopa Guildmage triggers, causing each opponent to lose 1 life.
Exquisite Blood triggers for each opponent that lost life.
Resolve a Exquisite Blood trigger, gaining 1 life.
Repeat from step 3.

---

# 924-2452-2577

**Cards:**

- Gravecrawler
- Rooftop Storm
- Phyrexian Ghoul

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinitely large Phyrexian Ghoul until end of turn, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: UB, Popularity: 820**

**Steps:**

Activate Phyrexian Ghoul's ability by sacrificing Gravecrawler, giving Phyrexian Ghoul +2/+2 until end of turn.
Cast Gravecrawler from your graveyard by paying {0}.
Repeat.

---

# 92-4624

**Cards:**

- Vizkopa Guildmage
- Revival // Revenge

**Produces:** Near-infinite lifeloss

**Mana: {5}{W}{W}{B}{B}, MV: 9, Colors: WB, Popularity: 6096**

**Steps:**

Activate Vizkopa Guildmage's second ability by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Cast Revenge by paying {4}{W}{B}, doubling your life total and causing target opponent to lose half their life, rounded up.
Vizkopa Guildmage triggers, causing each opponent to lose life equal to the life you gained.
Each opponent loses the game due to having zero or less life.

---

# 92-4996

**Cards:**

- Vizkopa Guildmage
- Beacon of Immortality

**Produces:** Near-infinite lifeloss

**Mana: {6}{W}{W}{B}, MV: 9, Colors: WB, Popularity: 5600**

**Steps:**

Activate Vizkopa Guildmage's second ability by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Cast Beacon of Immortality by paying {5}{W}, doubling your life total.
Vizkopa Guildmage triggers, causing each opponent to lose life equal to the life you gained.
Each opponent loses the game due to having zero or less life.

---

# 92-558-2298

**Cards:**

- Carrion Howler
- Vizkopa Guildmage
- Oketra's Last Mercy

**Produces:** Each opponent loses the game

**Mana: {2}{W}{W}{W}{B}, MV: 6, Colors: WB, Popularity: 11**

**Steps:**

Activate Vizkopa Guildmage by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Activate Carrion Howler by paying 1 life.
Repeat step 2 until you have one life.
Resolve all Carrion Howler abilities, giving itself +2/-1 for each ability.
Cast Oketra's Last Mercy by paying {1}{W}{W}, causing your life total to become forty.
Vizkopa Guildmage triggers, causing each opponent to lose thirty-nine life.
Each opponent loses the game due to having zero or less life.

---

# 926-1462

**Cards:**

- Enchanted Evening
- Aura Thief

**Produces:** Gain control of all permanents

**Mana: , MV: 0, Colors: WU, Popularity: 3304**

**Steps:**

Kill Aura Thief.
Aura Thief triggers, causing you to gain control of all permanents.

---

# 933-1061-1869

**Cards:**

- Inalla, Archmage Ritualist
- Timestream Navigator
- Conjurer's Closet

**Produces:** Infinite turns

**Mana: {3}{U}{U} each turn, MV: 5, Colors: UBR, Popularity: 1103**

**Steps:**

At the beginning of your end step, Conjurer's Closet triggers, blinking Timestream Navigator.
If you don't have the city's blessing, Timestream Navigator's Ascend ability gives you the city's blessing.
When Timestream Navigator enters the battlefield, triggering Inalla, causing you to pay {1} to create a token copy of Timestream Navigator with haste.
Activate the Timestream Navigator token by paying {2}{U}{U}, tapping it, and putting it on the bottom of your library, causing you to take an extra turn after this one.
Repeat each turn.

---

# 933-1061-2506

**Cards:**

- Molten Echoes
- Timestream Navigator
- Conjurer's Closet

**Produces:** Infinite turns

**Mana: {2}{U}{U} each turn, MV: 4, Colors: UR, Popularity: 737**

**Steps:**

At the beginning of your end step, Conjurer's Closet triggers, blinking Timestream Navigator.
Timestream Navigator enters the battlefield, triggering Molten Echoes, creating a token copy of Timestream Navigator with haste.
Activate the token Timestream Navigator by paying {2}{U}{U}, tapping it and putting it on the bottom of your library, causing you to take an extra turn after this one.
Repeat each turn.

---

# 933-2103-2493

**Cards:**

- Conjurer's Closet
- Archaeomancer
- Capture of Jingzhou

**Produces:** Infinite ETB, Infinite LTB, Infinite turns

**Mana: {3}{U}{U}, MV: 5, Colors: U, Popularity: 315**

**Steps:**

Cast Capture of Jingzhou by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Archaeomancer.
Archaeomancer enters the battlefield, returning Capture of Jingzhou from your graveyard to your hand.
Repeat.

---

# 933-2103-2556

**Cards:**

- Conjurer's Closet
- Mnemonic Wall
- Capture of Jingzhou

**Produces:** Infinite ETB, Infinite LTB, Infinite turns

**Mana: {3}{U}{U}, MV: 5, Colors: U, Popularity: 66**

**Steps:**

Cast Capture of Jingzhou by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Mnemonic Wall.
Mnemonic Wall enters the battlefield, returning Capture of Jingzhou from your graveyard to your hand.
Repeat.

---

# 933-2104-2493

**Cards:**

- Conjurer's Closet
- Archaeomancer
- Temporal Manipulation

**Produces:** Infinite ETB, Infinite LTB, Infinite turns

**Mana: {3}{U}{U}, MV: 5, Colors: U, Popularity: 782**

**Steps:**

Cast Temporal Manipulation by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Archaeomancer.
Archaeomancer enters the battlefield, returning Temporal Manipulation from your graveyard to your hand.
Repeat.

---

# 933-2104-2556

**Cards:**

- Conjurer's Closet
- Mnemonic Wall
- Temporal Manipulation

**Produces:** Infinite ETB, Infinite LTB, Infinite turns

**Mana: {3}{U}{U}, MV: 5, Colors: U, Popularity: 133**

**Steps:**

Cast Temporal Manipulation by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Mnemonic Wall.
Mnemonic Wall enters the battlefield, returning Temporal Manipulation from your graveyard to your hand.
Repeat.

---

# 933-2493-3617

**Cards:**

- Conjurer's Closet
- Archaeomancer
- Time Walk

**Produces:** Infinite ETB, Infinite LTB, Infinite turns

**Mana: {1}{U}, MV: 2, Colors: U, Popularity: 0**

**Steps:**

Cast Time Walk by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Archaeomancer.
Archaeomancer enters the battlefield, returning Time Walk from your graveyard to your hand.
Repeat.

---

# 933-2493-4377

**Cards:**

- Conjurer's Closet
- Archaeomancer
- Walk the Aeons

**Produces:** Infinite ETB, Infinite LTB, Infinite turns

**Mana: {4}{U}{U}, MV: 6, Colors: U, Popularity: 269**

**Steps:**

Cast Walk the Aeons by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Archaeomancer.
Archaeomancer enters the battlefield, returning Walk the Aeons from your graveyard to your hand.
Repeat.

---

# 933-2493-4872

**Cards:**

- Conjurer's Closet
- Archaeomancer
- Time Warp

**Produces:** Infinite ETB, Infinite LTB, Infinite turns

**Mana: {3}{U}{U}, MV: 5, Colors: U, Popularity: 1433**

**Steps:**

Cast Time Warp by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Archaeomancer.
Archaeomancer enters the battlefield, returning Time Warp from your graveyard to your hand.
Repeat.

---

# 933-2556-3617

**Cards:**

- Conjurer's Closet
- Mnemonic Wall
- Time Walk

**Produces:** Infinite ETB, Infinite LTB, Infinite turns

**Mana: {1}{U}, MV: 2, Colors: U, Popularity: 0**

**Steps:**

Cast Time Walk by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Mnemonic Wall.
Mnemonic Wall enters the battlefield, returning Time Walk from your graveyard to your hand.
Repeat.

---

# 933-2556-4377

**Cards:**

- Conjurer's Closet
- Mnemonic Wall
- Walk the Aeons

**Produces:** Infinite ETB, Infinite LTB, Infinite turns

**Mana: {4}{U}{U}, MV: 6, Colors: U, Popularity: 86**

**Steps:**

Cast Walk the Aeons by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Mnemonic Wall.
Mnemonic Wall enters the battlefield, returning Walk the Aeons from your graveyard to your hand.
Repeat.

---

# 933-2556-4872

**Cards:**

- Conjurer's Closet
- Mnemonic Wall
- Time Warp

**Produces:** Infinite ETB, Infinite LTB, Infinite turns

**Mana: {3}{U}{U}, MV: 5, Colors: U, Popularity: 208**

**Steps:**

Cast Time Warp by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Mnemonic Wall.
Mnemonic Wall enters the battlefield, returning Time Warp from your graveyard to your hand.
Repeat.

---

# 933-2724-3194

**Cards:**

- Wormfang Manta
- Hushwing Gryff
- Conjurer's Closet

**Produces:** Infinite turns

**Mana: , MV: 0, Colors: WU, Popularity: 37**

**Steps:**

At the beginning of your end step Conjurer's Closet triggers, exiling Wormfang Manta and returns it to the battlefield.
On LTB Wormfang Manta triggers, giving you an extra turn.
On ETB Hushwing Gryff prevents Wormfang Manta's trigger, so you do not skip your next turn.
Take your extra turn.

---

# 933-2724-3987

**Cards:**

- Wormfang Manta
- Torpor Orb
- Conjurer's Closet

**Produces:** Infinite turns

**Mana: , MV: 0, Colors: U, Popularity: 25**

**Steps:**

At the beginning of your end step Conjurer's Closet triggers, exiling Wormfang Manta and returns it to the battlefield.
On LTB Wormfang Manta triggers, giving you an extra turn.
On ETB Torpor Orb prevents Wormfang Manta's trigger, so you do not skip your next turn.
Take your extra turn.

---

# 933-2724-4006

**Cards:**

- Wormfang Manta
- Hushbringer
- Conjurer's Closet

**Produces:** Infinite turns

**Mana: , MV: 0, Colors: WU, Popularity: 14**

**Steps:**

At the beginning of your end step Conjurer's Closet triggers, exiling Wormfang Manta and returns it to the battlefield.
On LTB Wormfang Manta triggers, giving you an extra turn.
On ETB Hushbringer prevents Wormfang Manta's trigger, so you do not skip your next turn.
Take your extra turn.

---

# 933-957-2493

**Cards:**

- Conjurer's Closet
- Archaeomancer
- Time Stretch

**Produces:** Infinite ETB, Infinite LTB, Infinite turns

**Mana: {8}{U}{U}, MV: 10, Colors: U, Popularity: 363**

**Steps:**

Cast Time Stretch by paying {8}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Archaeomancer.
Archaeomancer enters the battlefield, returning Time Stretch from your graveyard to your hand.
Repeat.

---

# 933-957-2556

**Cards:**

- Conjurer's Closet
- Mnemonic Wall
- Time Stretch

**Produces:** Infinite ETB, Infinite LTB, Infinite turns

**Mana: {8}{U}{U}, MV: 10, Colors: U, Popularity: 37**

**Steps:**

Cast Time Stretch by paying {8}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Mnemonic Wall.
Mnemonic Wall enters the battlefield, returning Time Stretch from your graveyard to your hand.
Repeat.

---

# 936-1290

**Cards:**

- Bloodchief Ascension
- Mindcrank

**Produces:** Infinite mill, Near-infinite lifegain, Near-infinite lifegain triggers, Near-infinite lifeloss

**Mana: , MV: 0, Colors: B, Popularity: 47668**

**Steps:**

Cause one or more opponents to lose life.
Mindcrank triggers once for each life loss event, causing that player to mill cards equal to the amount of life lost.
Bloodchief Ascension triggers once for each card milled, causing that player to lose 2 life and you to gain 2 life for each trigger.
Repeat from step 2.

---

# 936-5069

**Cards:**

- Duskmantle Guildmage
- Mindcrank

**Produces:** Each opponent loses the game, Infinite mill, Near-infinite lifeloss

**Mana: {1}{U}{B} plus an additional {2}{U}{B} for each opponent you have, MV: 3, Colors: UB, Popularity: 16286**

**Steps:**

Activate Duskmantle Guildmage's first ability by paying {1}{U}{B}, causing your opponent to lose life whenever a card is put into their graveyard this turn.
Activate Duskmantle Guildmage's second ability by paying {2}{U}{B}, causing an opponent to mill two cards.
Duskmantle Guildmage triggers twice.
Resolve the first trigger, causing the opponent to lose 1 life.
Mindcrank triggers, causing the opponent to mill a card.
Duskmantle Guildmage triggers, causing the opponent to lose 1 life.
Repeat from step 5 until the opponent has a life total of zero, causing them to lose the game.
Repeat from step 2 for each other opponent.

---

# 937-2358-4551

**Cards:**

- Phyrexian Unlife
- Magus of the Mirror
- Blood Celebrant

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WB, Popularity: 283**

**Steps:**

During your upkeep, activate Blood Celebrant by paying {B} and one life, adding {B}.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-2358-4591

**Cards:**

- Platinum Angel
- Magus of the Mirror
- Blood Celebrant

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: B, Popularity: 319**

**Steps:**

During your upkeep, activate Blood Celebrant by paying {B} and one life, adding {B}.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-2358-4695

**Cards:**

- Soul Echo
- Magus of the Mirror
- Blood Celebrant

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WB, Popularity: 51**

**Steps:**

During your upkeep, activate Blood Celebrant by paying {B} and one life, adding {B}.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-2749-4551

**Cards:**

- Phyrexian Unlife
- Magus of the Mirror
- Wall of Blood

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WB, Popularity: 616**

**Steps:**

During your upkeep, activate Wall of Blood by paying 1 life, giving Wall of Blood +1/+1 until end of turn.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-2749-4591

**Cards:**

- Platinum Angel
- Magus of the Mirror
- Wall of Blood

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: B, Popularity: 922**

**Steps:**

During your upkeep, activate Wall of Blood by paying 1 life, giving Wall of Blood +1/+1 until end of turn.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-2749-4695

**Cards:**

- Soul Echo
- Magus of the Mirror
- Wall of Blood

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WB, Popularity: 72**

**Steps:**

During your upkeep, activate Wall of Blood by paying 1 life, giving Wall of Blood +1/+1 until end of turn.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-2935-4551

**Cards:**

- Phyrexian Unlife
- Magus of the Mirror
- Ethereal Champion

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WB, Popularity: 14**

**Steps:**

During your upkeep, activate Ethereal Champion by paying 1 life, preventing the next one damage that will be dealt to Ethereal Champion this turn.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-2935-4591

**Cards:**

- Platinum Angel
- Magus of the Mirror
- Ethereal Champion

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WB, Popularity: 17**

**Steps:**

During your upkeep, activate Ethereal Champion by paying 1 life, preventing the next one damage that will be dealt to Ethereal Champion this turn.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-2935-4695

**Cards:**

- Soul Echo
- Magus of the Mirror
- Ethereal Champion

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WB, Popularity: 6**

**Steps:**

During your upkeep, activate Ethereal Champion by paying 1 life, preventing the next one damage that will be dealt to Ethereal Champion this turn.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-3591-4551

**Cards:**

- Phyrexian Unlife
- Magus of the Mirror
- Necropotence

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WB, Popularity: 360**

**Steps:**

During your upkeep, activate Necropotence by paying 1 life, exiling the top card of your library face down.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-3591-4591

**Cards:**

- Platinum Angel
- Magus of the Mirror
- Necropotence

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: B, Popularity: 510**

**Steps:**

During your upkeep, activate Necropotence by paying 1 life, exiling the top card of your library face down.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-3591-4695

**Cards:**

- Soul Echo
- Magus of the Mirror
- Necropotence

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WB, Popularity: 48**

**Steps:**

During your upkeep, activate Necropotence by paying 1 life, exiling the top card of your library face down.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-3859-4551

**Cards:**

- Phyrexian Unlife
- Magus of the Mirror
- Cavern Harpy

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WUB, Popularity: 3**

**Steps:**

During your upkeep, activate Cavern Harpy by paying 1 life.
Repeat step 1 until you have zero life.
Resolve the last Cavern Harpy trigger, returning it to your hand.
The remaining Cavern Harpy triggers fizzle.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-3859-4591

**Cards:**

- Platinum Angel
- Magus of the Mirror
- Cavern Harpy

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: UB, Popularity: 6**

**Steps:**

During your upkeep, activate Cavern Harpy by paying 1 life.
Repeat step 1 until you have zero life.
Resolve the last Cavern Harpy trigger, returning it to your hand.
The remaining Cavern Harpy triggers fizzle.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-3859-4695

**Cards:**

- Soul Echo
- Magus of the Mirror
- Cavern Harpy

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WUB, Popularity: 1**

**Steps:**

During your upkeep, activate Cavern Harpy by paying 1 life.
Repeat step 1 until you have zero life.
Resolve the last Cavern Harpy trigger, returning it to your hand.
The remaining Cavern Harpy triggers fizzle.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 940-2178-3500

**Cards:**

- Thornbite Staff
- Arcane Teachings
- Basilisk Collar

**Produces:** Destroy all creatures opponents control, Destroy all creatures opponents control whenever a creature enters the battlefield

**Mana: , MV: 0, Colors: R, Popularity: 41**

**Steps:**

Activate the creature by tapping it, dealing 1 damage to any opponent's creature and causing you to gain 1 life.
The opponent's creature dies due to deathtouch, triggering Thornbite Staff, untapping your creature.
Repeat.

---

# 9-411-1283-2500-4600

**Cards:**

- Chromatic Orrery
- Grinning Ignus
- Mirage Mirror
- Grapeshot
- Mirror Gallery

**Produces:** Infinite damage, Infinite storm count

**Mana: , MV: 0, Colors: R, Popularity: 3**

**Steps:**

Tap Orrery for 5 mana.
Tap 2 mana to activate mirror, targeting grinning ignus.
In response, activate mirror again targeting orrery.
tap mirror for 5 mana before letting it become an ignus.
Use one mana to return mirror to your hand using ignus's ability.
this adds 3 to your mana pool.
8 floating.
cast mirror from your hand, 5 floating.
Repeat.
Cast grapeshot for Infinite damage.

---

# 9-411-2500-2604-5116

**Cards:**

- Ugin, the Ineffable
- Grinning Ignus
- Mirage Mirror
- Gilded Lotus
- Grapeshot

**Produces:** Infinite damage, Infinite magecraft triggers, Infinite storm count

**Mana: {1}, MV: 1, Colors: R, Popularity: 7**

**Steps:**

Activate Gilded Lotus by tapping it, adding {3}.
Activate Mirage Mirror twice by paying {4}, targeting Grinning Ignus and Gilded Lotus.
Resolve the first Mirage Mirror ability, causing it to become a copy of Gilded Lotus until end of turn.
Activate Mirage Mirror by tapping it, adding {R}{R}{R}.
Resolve the second Mirage Mirror ability, causing it to become a copy of Grinning Ignus until end of turn.
Activate Mirage Mirror by paying {R} and returning it to your hand, adding {C}{C}{R}.
Cast Mirage Mirror by paying {1}.
Repeat from step 2 until you have a very large storm count.
Cast Grapeshot by paying {1}{R}.
Grapeshot's storm ability triggers, creating a copy of Grapeshot for each spell you've cast this turn.
Resolve all Grapeshots, dealing infinite damage to any target(s).

---

# 943-1556-4235

**Cards:**

- Rings of Brighthearth
- Deserted Temple
- Scorched Ruins

**Produces:** Infinite colorless mana, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: , MV: 0, Colors: C, Popularity: 2525**

**Steps:**

Activate Scorched Ruins by tapping it, adding {C}{C}{C}{C}.
Activate Deserted Temple's second ability by paying {1} and tapping it, targeting Scorched Ruins.
Rings of Brighthearth triggers, causing you to pay {2} to copy Deserted Temple's ability, targeting Deserted Temple.
Resolve both Deserted Temple abilities, untapping Deserted Temple and Scorched Ruins.
Repeat an arbitrarily large number of times.
Once you have a large amount of {C}, you may untap any other lands you control in place of Scorched Ruins.

---

# 944-4050-4242-5105

**Cards:**

- Sigil of the New Dawn
- Phyrexian Altar
- Su-Chi
- Planar Gate

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: W, Popularity: 2**

**Steps:**

Activate Phyrexian Altar by sacrificing Su-Chi, adding {W}.
Su-Chi dies, triggering itself and Sigil of New Dawn.
Resolve the Su-Chi trigger, adding {C}{C}{C}{C}.
Resolve the Sigil of New Dawn trigger, causing you to pay {1}{W} to return Su-Chi from your graveyard to your hand.
Cast Su-Chi by paying {1}.
Repeat.

---

# 944-4050-5004-5105

**Cards:**

- Sigil of the New Dawn
- Phyrexian Altar
- Cathodion
- Planar Gate

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: W, Popularity: 0**

**Steps:**

Activate Phyrexian Altar by sacrificing Cathodion, adding {W}.
Cathodion dies, triggering itself and Sigil of New Dawn.
Resolve the Cathodion trigger, adding {C}{C}{C}.
Resolve the Sigil of New Dawn trigger, causing you to pay {1}{W} to return Cathodion from your graveyard to your hand.
Cast Cathodion by paying {1}.
Repeat.

---

# 949-1343-2686

**Cards:**

- Kaervek's Spite
- Academy Rector
- Barren Glory

**Produces:** Win the game

**Mana: {B}{B}{B}, MV: 3, Colors: WB, Popularity: 248**

**Steps:**

During the end step before your turn, cast Kaervek's Spite by paying {B}{B}{B}, discarding your hand, and sacrificing all permanents.
Academy Rector triggers, exiling itself and searching your library for Barren Glory, putting it onto the battlefield, and shuffling your library.
Resolve Kaervek's Spite, causing target player to lose five life.
At the beginning of your upkeep, Barren Glory triggers, causing you to win the game.

---

# 950-1584-3525

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Teferi's Isle

**Produces:** Infinite blue mana, Infinite mana permanents you control can produce, Infinite untap of permanents you control

**Mana: , MV: 0, Colors: U, Popularity: 34**

**Steps:**

Activate Teferi's Isle by tapping it, adding {U}{U}.
Activate Fatestitcher by tapping it, untapping Teferi's Isle.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-1584-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Teferi's Isle

**Produces:** Infinite blue mana, Infinite mana permanents you control can produce, Infinite untap of permanents you control

**Mana: , MV: 0, Colors: U, Popularity: 38**

**Steps:**

Activate Teferi's Isle by tapping it, adding {U}{U}.
Activate Fatestitcher by tapping it, untapping Teferi's Isle.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-1671-3525

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Simic Growth Chamber

**Produces:** Infinite green mana, Infinite mana permanents you control can produce, Infinite untap of permanents you control

**Mana: , MV: 0, Colors: GU, Popularity: 370**

**Steps:**

Activate Simic Growth Chamber by tapping it, adding {U}{G}.
Activate Fatestitcher by tapping it, untapping Simic Growth Chamber.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-1671-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Simic Growth Chamber

**Produces:** Infinite green mana, Infinite mana permanents you control can produce, Infinite untap of permanents you control

**Mana: , MV: 0, Colors: GU, Popularity: 579**

**Steps:**

Activate Simic Growth Chamber by tapping it, adding {U}{G}.
Activate Fatestitcher by tapping it, untapping Simic Growth Chamber.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-2605-3525

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Lotus Vale

**Produces:** Infinite colored mana

**Mana: , MV: 0, Colors: U, Popularity: 204**

**Steps:**

Activate Lotus Vale by tapping it, adding {U}{U}{U}.
Activate Fatestitcher by tapping it, untapping Lotus Vale.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.
Repeat steps with a different color for infinite mana of any color.

---

# 950-2605-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Lotus Vale

**Produces:** Infinite colored mana

**Mana: , MV: 0, Colors: U, Popularity: 211**

**Steps:**

Activate Lotus Vale by tapping it, adding {U}{U}{U}.
Activate Fatestitcher by tapping it, untapping Lotus Vale.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.
Repeat steps with a different color for infinite mana of any color.

---

# 950-3078-3525

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Soldevi Excavations

**Produces:** Infinite colorless mana

**Mana: , MV: 0, Colors: U, Popularity: 101**

**Steps:**

Activate Soldevi Excavations by tapping it, adding {C}{U}.
Activate Fatestitcher by tapping it, untapping Soldevi Excavations.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3078-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Soldevi Excavations

**Produces:** Infinite colorless mana

**Mana: , MV: 0, Colors: U, Popularity: 105**

**Steps:**

Activate Soldevi Excavations by tapping it, adding {C}{U}.
Activate Fatestitcher by tapping it, untapping Soldevi Excavations.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3147-3525

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Azorius Chancery

**Produces:** Infinite white mana, Infinite mana permanents you control can produce, Infinite untap of permanents you control

**Mana: , MV: 0, Colors: WU, Popularity: 551**

**Steps:**

Activate Azorius Chancery by tapping it, adding {W}{U}.
Activate Fatestitcher by tapping it, untapping Azorius Chancery.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3147-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Azorius Chancery

**Produces:** Infinite white mana, Infinite mana permanents you control can produce, Infinite untap of permanents you control

**Mana: , MV: 0, Colors: WU, Popularity: 798**

**Steps:**

Activate Azorius Chancery by tapping it, adding {W}{U}.
Activate Fatestitcher by tapping it, untapping Azorius Chancery.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3201-3525

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Arixmethes, Slumbering Isle

**Produces:** Infinite green mana

**Mana: , MV: 0, Colors: GU, Popularity: 88**

**Steps:**

Activate Arixmethes by tapping it, adding {U}{G}.
Activate Fatestitcher by tapping it, untapping Arixmethes.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3201-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Arixmethes, Slumbering Isle

**Produces:** Infinite green mana

**Mana: , MV: 0, Colors: GU, Popularity: 125**

**Steps:**

Activate Arixmethes by tapping it, adding {U}{G}.
Activate Fatestitcher by tapping it, untapping Arixmethes.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3230-3525

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Coral Atoll

**Produces:** Infinite colorless mana, Infinite mana permanents you control can produce, Infinite untap of permanents you control

**Mana: , MV: 0, Colors: U, Popularity: 262**

**Steps:**

Activate Coral Atoll by tapping it, adding {C}{U}.
Activate Fatestitcher by tapping it, untapping Coral Atoll.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3230-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Coral Atoll

**Produces:** Infinite colorless mana, Infinite mana permanents you control can produce, Infinite untap of permanents you control

**Mana: , MV: 0, Colors: U, Popularity: 324**

**Steps:**

Activate Coral Atoll by tapping it, adding {C}{U}.
Activate Fatestitcher by tapping it, untapping Coral Atoll.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3478-3525

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Dimir Aqueduct

**Produces:** Infinite black mana, Infinite mana permanents you control can produce, Infinite untap of permanents you control

**Mana: , MV: 0, Colors: UB, Popularity: 684**

**Steps:**

Activate Dimir Aqueduct by tapping it, adding {U}{B}.
Activate Fatestitcher by tapping it, untapping Dimir Aqueduct.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3478-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Dimir Aqueduct

**Produces:** Infinite black mana, Infinite mana permanents you control can produce, Infinite untap of permanents you control

**Mana: , MV: 0, Colors: UB, Popularity: 895**

**Steps:**

Activate Dimir Aqueduct by tapping it, adding {U}{B}.
Activate Fatestitcher by tapping it, untapping Dimir Aqueduct.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3525-3573

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Tolarian Academy

**Produces:** Infinite mana permanents you control can produce, Infinite untap of permanents you control

**Mana: , MV: 0, Colors: U, Popularity: 0**

**Steps:**

Activate Tolarian Academy by tapping it, adding at least {U}{U}.
Activate Fatestitcher by tapping it, untapping Tolarian Academy.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3525-3664

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Lotus Field

**Produces:** Infinite colored mana, Infinite mana permanents you control can produce, Infinite untap of permanents you control

**Mana: , MV: 0, Colors: U, Popularity: 554**

**Steps:**

Activate Lotus Field by tapping it, adding {U}{U}{U}.
Activate Fatestitcher by tapping it, untapping Lotus Field.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.
Repeat steps with a different color for infinite mana of any color.

---

# 950-3525-3756

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Izzet Boilerworks

**Produces:** Infinite red mana, Infinite mana permanents you control can produce, Infinite untap of permanents you control

**Mana: , MV: 0, Colors: UR, Popularity: 313**

**Steps:**

Activate Izzet Boilerworks by tapping it, adding {U}{R}.
Activate Fatestitcher by tapping it, untapping Izzet Boilerworks.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3573-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Tolarian Academy

**Produces:** Infinite mana permanents you control can produce, Infinite untap of permanents you control

**Mana: , MV: 0, Colors: U, Popularity: 0**

**Steps:**

Activate Tolarian Academy by tapping it, adding at least {U}{U}.
Activate Fatestitcher by tapping it, untapping Tolarian Academy.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3664-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Lotus Field

**Produces:** Infinite colored mana, Infinite mana permanents you control can produce, Infinite untap of permanents you control

**Mana: , MV: 0, Colors: U, Popularity: 663**

**Steps:**

Activate Lotus Field by tapping it, adding {U}{U}{U}.
Activate Fatestitcher by tapping it, untapping Lotus Field.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.
Repeat steps with a different color for infinite mana of any color.

---

# 950-3756-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Izzet Boilerworks

**Produces:** Infinite red mana, Infinite mana permanents you control can produce, Infinite untap of permanents you control

**Mana: , MV: 0, Colors: UR, Popularity: 574**

**Steps:**

Activate Izzet Boilerworks by tapping it, adding {U}{R}.
Activate Fatestitcher by tapping it, untapping Izzet Boilerworks.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 95-1848

**Cards:**

- Fleet Swallower
- Bruvac the Grandiloquent

**Produces:** Infinite mill for target opponent

**Mana: , MV: 0, Colors: U, Popularity: 13129**

**Steps:**

Declare Fleet Swallower as an attacker, attacking any opponent with an even library size.
Fleet Swallower triggers, causing the opponent to mill their entire library.

---

# 953-1139-1371

**Cards:**

- Hive Mind
- Enter the Infinite
- Howling Mine

**Produces:** Each opponent loses the game, Infinite draw, Infinite draw for opponents, Infinite draw triggers, Infinite draw triggers for opponents

**Mana: {8}{U}{U}{U}{U}, MV: 12, Colors: U, Popularity: 306**

**Steps:**

Cast Enter the Infinite by paying {8}{U}{U}{U}{U}.
Hive Mind triggers, causing each opponent to create a copy of Enter the Infinite.
Resolve each Enter the Infinite, causing each player to draw their entire library, put a card from their hand on top of their library, and have no maximum hand size until their next turn.
At the beginning of each opponent's draw step, Howling Mine triggers, causing them to draw an additional card and lose the game due to drawing from an empty library.

---

# 953-1371-2065

**Cards:**

- Hive Mind
- Enter the Infinite
- Dictate of Kruphix

**Produces:** Each opponent loses the game, Infinite draw, Infinite draw for opponents, Infinite draw triggers, Infinite draw triggers for opponents

**Mana: {8}{U}{U}{U}{U}, MV: 12, Colors: U, Popularity: 252**

**Steps:**

Cast Enter the Infinite by paying {8}{U}{U}{U}{U}.
Hive Mind triggers, causing each opponent to create a copy of Enter the Infinite.
Resolve each Enter the Infinite, causing each player to draw their entire library, put a card from their hand on top of their library, and have no maximum hand size until their next turn.
At the beginning of each opponent's draw step, Dictate of Kruphix triggers, causing them to draw an additional card and lose the game due to drawing from an empty library.

---

# 953-1371-2870

**Cards:**

- Hive Mind
- Enter the Infinite
- Anvil of Bogardan

**Produces:** Each opponent loses the game, Infinite draw, Infinite draw for opponents, Infinite draw triggers, Infinite draw triggers for opponents

**Mana: {8}{U}{U}{U}{U}, MV: 12, Colors: U, Popularity: 68**

**Steps:**

Cast Enter the Infinite by paying {8}{U}{U}{U}{U}.
Hive Mind triggers, causing each opponent to create a copy of Enter the Infinite.
Resolve each Enter the Infinite, causing each player to draw their entire library, put a card from their hand on top of their library, and have no maximum hand size until their next turn.
At the beginning of each opponent's draw step, Anvil of Bogardan triggers, causing them to draw an additional card, discard a card and lose the game due to drawing from an empty library.

---

# 953-1371-3032

**Cards:**

- Hive Mind
- Enter the Infinite
- Kami of the Crescent Moon

**Produces:** Each opponent loses the game, Infinite draw, Infinite draw for opponents, Infinite draw triggers, Infinite draw triggers for opponents

**Mana: {8}{U}{U}{U}{U}, MV: 12, Colors: U, Popularity: 289**

**Steps:**

Cast Enter the Infinite by paying {8}{U}{U}{U}{U}.
Hive Mind triggers, causing each opponent to create a copy of Enter the Infinite.
Resolve each Enter the Infinite, causing each player to draw their entire library, put a card from their hand on top of their library, and have no maximum hand size until their next turn.
At the beginning of each opponent's draw step, Kami triggers, causing them to draw an additional card and lose the game due to drawing from an empty library.

---

# 954-2034-2302-4215

**Cards:**

- Verdant Succession
- Angel of Fury
- Ashnod's Altar
- Painter's Servant

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: GW, Popularity: 1**

**Steps:**

Activate Ashnod's Altar by sacrificing Angel of Fury, adding {C}{C}.
Angel of Fury and Verdant Succession trigger.
Resolve the Angel of Fury trigger, shuffling it into your library.
Resolve the Verdant Succession trigger, searching your library for Angel of Fury, putting it onto the battlefield and shuffling your library.
Repeat.

---

# 954-2302-4050-4215

**Cards:**

- Verdant Succession
- Angel of Fury
- Phyrexian Altar
- Painter's Servant

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: GW, Popularity: 1**

**Steps:**

Activate Phyrexian Altar by sacrificing Angel of Fury, adding one mana of any color.
Angel of Fury and Verdant Succession trigger.
Resolve the Angel of Fury trigger, shuffling it into your library.
Resolve the Verdant Succession trigger, searching your library for Angel of Fury, putting it onto the battlefield and shuffling your library.
Repeat.

---

# 954-2302-4215-5256

**Cards:**

- Verdant Succession
- Angel of Fury
- Altar of Dementia
- Painter's Servant

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: GW, Popularity: 0**

**Steps:**

Activate Altar of Dementia by sacrificing Angel of Fury.
Angel of Fury and Verdant Succession trigger.
Resolve the Angel of Fury trigger, shuffling it into your library.
Resolve the Verdant Succession trigger, searching your library for Angel of Fury, putting it onto the battlefield and shuffling your library.
Resolve the Altar of Dementia ability from step 1, causing target player to mill cards equal to Angel of Fury's power.
Repeat.

---

# 95-5080

**Cards:**

- Maddening Cacophony
- Bruvac the Grandiloquent

**Produces:** Infinite mill

**Mana: {U}, MV: 1, Colors: U, Popularity: 41579**

**Steps:**

Cast Maddening Cacophony with kicker by paying {4}{U}{U}, causing each opponent to mill their entire library.

---

# 957-1271-3212

**Cards:**

- God-Eternal Kefnet
- Scroll Rack
- Time Stretch

**Produces:** Infinite turns

**Mana: {7}{U}{U} each turn, MV: 9, Colors: U, Popularity: 195**

**Steps:**

Tap Scroll Rack and pay {1} to activate it, putting Time Stretch on top of your library.
Pass the turn.
On your next draw step, when you draw Time Stretch, reveal it due to Kefnet's ability, making a copy that costs {2} less to cast.
Cast the copy for {6}{U}{U}, granting you two extra turns.

---

# 957-1702-3212

**Cards:**

- God-Eternal Kefnet
- Jace, the Mind Sculptor
- Time Stretch

**Produces:** Infinite turns

**Mana: {6}{U}{U} each turn, MV: 8, Colors: U, Popularity: 127**

**Steps:**

Activate Jace's zero loyalty ability, putting Time Stretch on top of your library.
Move to your next turn.
On your next draw step, when you draw Time Stretch, reveal it due to Kefnet's ability, making a copy that costs {2} less to cast.
Cast the copy for {6}{U}{U}, granting you two extra turns.

---

# 957-2334-2493

**Cards:**

- Soulherder
- Archaeomancer
- Time Stretch

**Produces:** Infinite turns

**Mana: {8}{U}{U} every other turn, MV: 10, Colors: WU, Popularity: 113**

**Steps:**

With Soulherder and a creature based spell recursion effect on the battlefield, cast the extra turn spell.
Move to end step and target the creature with Soulherder's ability.
When creature re-enters the battlefield, target the extra turn spell in your graveyard and return it to your hand, then pass to yourself.
Repeat

---

# 957-2334-2556

**Cards:**

- Soulherder
- Mnemonic Wall
- Time Stretch

**Produces:** Infinite turns

**Mana: {8}{U}{U} every other turn, MV: 10, Colors: WU, Popularity: 18**

**Steps:**

With Soulherder and a creature based spell recursion effect on the battlefield, cast the extra turn spell.
Move to end step and target the creature with Soulherder's ability.
When creature re-enters the battlefield, target the extra turn spell in your graveyard and return it to your hand, then pass to yourself.
Repeat

---

# 957-2493-4428

**Cards:**

- Thassa, Deep-Dwelling
- Archaeomancer
- Time Stretch

**Produces:** Infinite turns

**Mana: {8}{U}{U} every other turn, MV: 10, Colors: U, Popularity: 656**

**Steps:**

Cast Time Stretch by paying {8}{U}{U}, getting two extra turns after this one.
At the beginning of your end step, Thassa triggers, blinking Archaeomancer.
Archaeomancer enters the battlefield, returning Time Stretch from your graveyard to your hand.
Repeat every other turn.

---

# 957-2556-4305

**Cards:**

- Mnemonic Wall
- Followed Footsteps
- Time Stretch

**Produces:** Infinite turns

**Mana: {8}{U}{U} each turn, MV: 10, Colors: U, Popularity: 7**

**Steps:**

Cast Time Stretch by paying {8}{U}{U}, taking two extra turns after this one.
At the beginning of your upkeep on your next extra turn, Followed Footsteps triggers, creating a token copy of Mnemonic Wall.
Mnemonic Wall enters the battlefield, returning Time Stretch from your graveyard to your hand.
Repeat each turn.

---

# 957-2556-4428

**Cards:**

- Thassa, Deep-Dwelling
- Mnemonic Wall
- Time Stretch

**Produces:** Infinite turns

**Mana: {8}{U}{U} every other turn, MV: 10, Colors: U, Popularity: 48**

**Steps:**

Cast Time Stretch by paying {8}{U}{U}, getting two extra turns after this one.
At the beginning of your end step, Thassa triggers, blinking Mnemonic Wall.
Mnemonic Wall enters the battlefield, returning Time Stretch from your graveyard to your hand.
Repeat every other turn.

---

# 958-1750-2365-5261

**Cards:**

- Isochron Scepter
- Pull from Eternity
- Dralnu, Lich Lord
- Expropriate

**Produces:** Infinite turns

**Mana: {9}{U}{U} each turn, MV: 11, Colors: WUB, Popularity: 0**

**Steps:**

Cast Expropriate by paying {7}{U}{U}, causing you to take at least one extra turn after this one and exile Expropriate.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Pull from Eternity without paying its mana cost.
Resolve Pull from Eternity, putting Expropriate into your graveyard from exile.
Move to your next turn.
Activate Dralnu by tapping it, giving Expropriate flashback until end of turn.
Cast Expropriate from your graveyard by paying {7}{U}{U}, causing you to take an extra turn after this one and exile Expropriate.
Repeat from step 2.

---

# 958-1750-2575-5261

**Cards:**

- Isochron Scepter
- Pull from Eternity
- Dralnu, Lich Lord
- Temporal Mastery

**Produces:** Infinite turns

**Mana: {7}{U}{U} each turn, MV: 9, Colors: WUB, Popularity: 0**

**Steps:**

Cast Temporal Mastery by paying {5}{U}{U}, causing you to take an extra turn after this one and exile Temporal Mastery.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Pull from Eternity without paying its mana cost.
Resolve Pull from Eternity, putting Temporal Mastery into your graveyard from exile.
Move to your next turn.
Activate Dralnu by tapping it, giving Temporal Mastery flashback until end of turn.
Cast Temporal Mastery from your graveyard by paying {5}{U}{U}, causing you to take an extra turn after this one and exile Temporal Mastery.
Repeat from step 2.

---

# 958-1750-4084-5261

**Cards:**

- Isochron Scepter
- Pull from Eternity
- Dralnu, Lich Lord
- Part the Waterveil

**Produces:** Infinite turns

**Mana: {6}{U}{U} each turn, MV: 8, Colors: WUB, Popularity: 0**

**Steps:**

Cast Part the Waterveil by paying {4}{U}{U}, causing you to take an extra turn after this one and exile Part the Waterveil.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Pull from Eternity without paying its mana cost.
Resolve Pull from Eternity, putting Part the Waterveil into your graveyard from exile.
Move to your next turn.
Activate Dralnu by tapping it, giving Part the Waterveil flashback until end of turn.
Cast Part the Waterveil from your graveyard by paying {4}{U}{U}, causing you to take an extra turn after this one and exile Part the Waterveil.
Repeat from step 2.

---

# 968-2660-4772

**Cards:**

- Jace, Architect of Thought
- Wheel of Sun and Moon
- Doubling Season

**Produces:** Exile all nonland cards from all opponents' libraries and cast any of them without paying their mana costs, Infinite storm count

**Mana: {2}{U}{U}, MV: 4, Colors: GWU, Popularity: 67**

**Steps:**

Cast Jace, Architect of Thought for {2}{U}{U} which enters with 8 loyalty counters due to Doubling Season.
Activate Jace's -8, putting it on the bottom of your library.
Search you library for Jace and exile it, and exile a nonland card of your choice.
Cast Jace along with any of the nonland cards you wish to cast.
Repeat from step 2.

---

# 969-1991-3259

**Cards:**

- Tana, the Bloodsower
- Breath of Fury
- Fervor

**Produces:** Infinite combat damage, Infinite combat phases, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mana creatures you control can produce, Infinite sacrifice triggers, Infinite untap of creatures you control, Infinite creature tokens with haste

**Mana: , MV: 0, Colors: RG, Popularity: 20**

**Steps:**

Deal combat damage with Tana and the creature that has Breath of Fury attached.
Tana and Breath of Fury triggers.
Resolve the Tana trigger, creating a number of 1/1 Saproling creature tokens equal to the damage Tana dealt.
Resolve the Breath of Fury trigger, causing you to sacrifice the creature it is attached to, attach Breath of Fury to a Saproling token, untap all creatures you control and get an additional combat phase after this one.
Repeat.

---

# 971-2034-3048-5003

**Cards:**

- Roalesk, Apex Hybrid
- Ashnod's Altar
- Nim Deathmantle
- Pentad Prism

**Produces:** Infinite ETB, Infinite LTB, Infinite proliferate

**Mana: , MV: 0, Colors: GU, Popularity: 1**

**Steps:**

Sacrifice Roalesk to Ashnod's Altar generating two colorless, with Roalesk's death you proliferate twice, putting two more counters on Pentad Prism.
Remove those counters for two mana, use the other two mana from Ashnod's to return Roalesk to the battlefield using Nim Deathmantle.
Repeat.

---

# 972-1061-1953

**Cards:**

- Brudiclad, Telchor Engineer
- Timestream Navigator
- Saheeli's Artistry

**Produces:** Infinite turns

**Mana: {6}{U}{U}{U}{U} on your first turn, with {2}{U}{U} available on each extra turn, MV: 10, Colors: UR, Popularity: 180**

**Steps:**

Cast Saheeli's Artistry by paying {4}{U}{U}, creating a token copy of Timestream Navigator.
At the beginning of your combat phase, Brudiclad triggers, creating a 2/1 Phyrexian Myr creature token, then choosing to have all tokens you control become copies of the Timestream Navigator token.
Activate Timestream Navigator by paying {2}{U}{U} and tapping it and putting it onto the bottom of your library, causing you to take an extra turn after this one.
Move to your next turn.
Repeat from step 2.

---

# 972-1953-2105

**Cards:**

- Brudiclad, Telchor Engineer
- Combat Celebrant
- Saheeli's Artistry

**Produces:** Infinite combat phases, Infinite damage

**Mana: {4}{U}{U}, MV: 6, Colors: UR, Popularity: 475**

**Steps:**

Cast Saheeli's Artistry by paying {4}{U}{U}, creating a token copy of Combat Celebrant.
At the beginning of your combat phase, Brudiclad triggers, creating a 2/1 Phyrexian Myr creature token, then choosing to have all tokens you control become copies of the Combat Celebrant token.
Declare one of the Combat Celebrant copy as an attacker, choosing to exert it as it attacks.
The Combat Celebrant copy triggers, untapping all other creatures you control and causing you to get an additional combat phase after this one.
Repeat from step 2.

---

# 976-1029-2428-3990-4435

**Cards:**

- Greed
- Horizon Chimera
- Alhammarret's Archive
- Incubation Druid
- Tolarian Kraken

**Produces:** Infinite card draw, Infinite draw triggers, Near-infinite colored mana, Near-infinite lifegain, Near-infinite lifegain triggers

**Mana: , MV: 0, Colors: BGU, Popularity: 0**

**Steps:**

Activate Incubation Druid by tapping it, adding {B}{B}{B}.
Activate Greed by paying {B} and two life, causing you to draw two cards.
Horizon Chimera and Tolarian Kraken each trigger twice.
Resolve both Horizon Chimera triggers, causing you to gain four life.
Resolve the first Tolarian Kraken trigger, choosing not to pay.
Resolve the second Tolarian Kraken trigger, causing you to pay {1} to untap Incubation Druid.
Repeat.

---

# 976-1029-2428-3990-5042

**Cards:**

- Greed
- Horizon Chimera
- Teferi's Ageless Insight
- Incubation Druid
- Tolarian Kraken

**Produces:** Infinite card draw, Infinite draw triggers, Near-infinite colored mana

**Mana: , MV: 0, Colors: BGU, Popularity: 0**

**Steps:**

Activate Incubation Druid by tapping it, adding {B}{B}{B}.
Activate Greed by paying {B} and two life, causing you to draw two cards.
Horizon Chimera and Tolarian Kraken each trigger twice.
Resolve both Horizon Chimera triggers, causing you to gain two life.
Resolve the first Tolarian Kraken trigger, choosing not to pay.
Resolve the second Tolarian Kraken trigger, causing you to pay {1} to untap Incubation Druid.
Repeat.

---

# 978-1429-2034

**Cards:**

- Vizier of Remedies
- Lesser Masticore
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: W, Popularity: 284**

**Steps:**

Activate Ashnod's Altar by sacrificing Lesser Manticore, adding {C}{C}.
Lesser Manticore's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Repeat.

---

# 978-1429-4050

**Cards:**

- Vizier of Remedies
- Lesser Masticore
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: W, Popularity: 196**

**Steps:**

Activate Phyrexian Altar by sacrificing Lesser Manticore, adding one mana of any color.
Lesser Manticore's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Repeat.

---

# 978-1429-5256

**Cards:**

- Vizier of Remedies
- Lesser Masticore
- Altar of Dementia

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: W, Popularity: 331**

**Steps:**

Activate Altar of Dementia by sacrificing Lesser Manticore.
Lesser Manticore's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Resolve the Altar of Dementia ability, causing target player to mill cards equal to Lesser Manticore's power.
Repeat.

---

# 978-2034-2086

**Cards:**

- Vizier of Remedies
- Kitchen Finks
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: GW, Popularity: 594**

**Steps:**

Activate Ashnod's Altar by sacrificing Kitchen Finks, adding {C}{C}.
Kitchen Finks' persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Kitchen Finks enters the battlefield, causing you to gain two life.
Repeat.

---

# 978-2034-2111

**Cards:**

- Vizier of Remedies
- Wingrattle Scarecrow
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: W, Popularity: 61**

**Steps:**

Activate Ashnod's Altar by sacrificing Wingrattle Scarecrow, adding {C}{C}.
Wingrattle Scarecrow's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Repeat.

---

# 978-2034-2620

**Cards:**

- Vizier of Remedies
- Safehold Elite
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: GW, Popularity: 337**

**Steps:**

Activate Ashnod's Altar by sacrificing Safehold Elite, adding {C}{C}.
Safehold Elite's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Repeat.

---

# 978-2034-3607

**Cards:**

- River Kelpie
- Vizier of Remedies
- Ashnod's Altar

**Produces:** Infinite card draw, Near-infinite colorless mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers

**Mana: , MV: 0, Colors: WU, Popularity: 33**

**Steps:**

Activate Ashnod's Altar by sacrificing River Kelpie, adding {C}{C}.
River Kelpie's persist triggers, returning it from your graveyard to the battlefield.
River Kelpie enters the battlefield, causing you to draw.
Repeat.

---

# 978-2086-4050

**Cards:**

- Vizier of Remedies
- Kitchen Finks
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: GW, Popularity: 355**

**Steps:**

Activate Phyrexian Altar by sacrificing Kitchen Finks, adding one mana of any color.
Kitchen Finks' persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Kitchen Finks enters the battlefield, causing you to gain two life.
Repeat.

---

# 978-2086-5256

**Cards:**

- Vizier of Remedies
- Kitchen Finks
- Altar of Dementia

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: GW, Popularity: 452**

**Steps:**

Activate Altar of Dementia by sacrificing Kitchen Finks.
Kitchen Finks' persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Kitchen Finks enters the battlefield, causing you to gain two life.
Resolve the Altar of Dementia ability, causing target player to mill cards equal to Kitchen Finks' power.
Repeat.

---

# 978-2111-4050

**Cards:**

- Vizier of Remedies
- Wingrattle Scarecrow
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: W, Popularity: 40**

**Steps:**

Activate Phyrexian Altar by sacrificing Wingrattle Scarecrow, adding one mana of any color.
Wingrattle Scarecrow's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Repeat.

---

# 978-2111-5256

**Cards:**

- Vizier of Remedies
- Wingrattle Scarecrow
- Altar of Dementia

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: W, Popularity: 59**

**Steps:**

Activate Altar of Dementia by sacrificing Wingrattle Scarecrow.
Wingrattle Scarecrow's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Resolve the Altar of Dementia ability, causing target player to mill cards equal to Wingrattle Scarecrow's power.
Repeat.

---

# 978-2292-3607

**Cards:**

- River Kelpie
- Vizier of Remedies
- Viscera Seer

**Produces:** Infinite card draw, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers

**Mana: , MV: 0, Colors: WUB, Popularity: 15**

**Steps:**

Activate Viscera Seer by sacrificing River Kelpie.
River Kelpie's persist triggers, returning it from your graveyard to the battlefield.
River Kelpie enters the battlefield, causing you to draw.
Resolve the Viscera Seer trigger, scrying 1.
Repeat.

---

# 978-2438-3607

**Cards:**

- River Kelpie
- Vizier of Remedies
- Carrion Feeder

**Produces:** Infinite card draw, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinitely large Carrion Feeder, Near-infinite sacrifice triggers

**Mana: , MV: 0, Colors: WUB, Popularity: 7**

**Steps:**

Activate Carrion Feeder by sacrificing River Kelpie.
River Kelpie's persist triggers, returning it from your graveyard to the battlefield.
River Kelpie enters the battlefield, causing you to draw.
Resolve the Carrion Feeder trigger, putting a +1/+1 counter on it.
Repeat.

---

# 978-2620-4050

**Cards:**

- Vizier of Remedies
- Safehold Elite
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: GW, Popularity: 207**

**Steps:**

Activate Phyrexian Altar by sacrificing Safehold Elite, adding one mana of any color.
Safehold Elite's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Repeat.

---

# 978-2620-5256

**Cards:**

- Vizier of Remedies
- Safehold Elite
- Altar of Dementia

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: GW, Popularity: 267**

**Steps:**

Activate Altar of Dementia by sacrificing Safehold Elite.
Safehold Elite's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Resolve the Altar of Dementia ability, causing target player to mill cards equal to Safehold Elite's power.
Repeat.

---

# 978-3607-3899

**Cards:**

- River Kelpie
- Vizier of Remedies
- Spawning Pit

**Produces:** Infinite card draw, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers

**Mana: , MV: 0, Colors: WU, Popularity: 8**

**Steps:**

Activate Spawning Pit by sacrificing River Kelpie.
River Kelpie's persist triggers, returning it from your graveyard to the battlefield.
River Kelpie enters the battlefield, causing you to draw.
Resolve the Spawning Pit trigger, putting a charge counter on it.
Repeat.

---

# 978-3607-4050

**Cards:**

- River Kelpie
- Vizier of Remedies
- Phyrexian Altar

**Produces:** Infinite card draw, Near-infinite colored mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers

**Mana: , MV: 0, Colors: WU, Popularity: 21**

**Steps:**

Activate Phyrexian Altar by sacrificing River Kelpie, adding {1}.
River Kelpie's persist triggers, returning it from your graveyard to the battlefield.
River Kelpie enters the battlefield, causing you to draw.
Repeat.

---

# 978-3607-5256

**Cards:**

- River Kelpie
- Vizier of Remedies
- Altar of Dementia

**Produces:** Infinite card draw, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite mill, Near-infinite sacrifice triggers

**Mana: , MV: 0, Colors: WU, Popularity: 18**

**Steps:**

Activate Altar of Dementia by sacrificing River Kelpie.
River Kelpie's persist triggers, returning it from your graveyard to the battlefield.
River Kelpie enters the battlefield, causing you to draw.
Resolve the Altar of Dementia trigger, causing target player to mill three cards.
Repeat.

---

# 978-4762

**Cards:**

- Devoted Druid
- Vizier of Remedies

**Produces:** Infinite green mana

**Mana: , MV: 0, Colors: GW, Popularity: 4226**

**Steps:**

Activate Devoted Druid by tapping it, adding {G}.
Activate Devoted Druid by putting a zero -1/-1 counter on it due to Vizier of Remedies, untapping it.
Repeat.

---

# 981-1517-1532-2104

**Cards:**

- The Mirari Conjecture
- Faith's Reward
- Temporal Manipulation
- Cursecatcher

**Produces:** Infinite turns

**Mana: {6}{W}{U}{U} every other turn, MV: 9, Colors: WU, Popularity: 0**

**Steps:**

At the beginning of your precombat main phase, The Mirari Conjecture triggers, putting a lore counter on itself, sacrificing itself and copying all instant and sorcery spells you cast this turn.
Cast Temporal Manipulation by paying {3}{U}{U}.
The Mirari Conjecture triggers, creating a copy of Temporal Manipulation.
Resolve both Temporal Manipulations, getting two extra turns after this one.
Cast Faith's Reward by paying {3}{W}.
The Mirari Conjecture triggers, copying Faith's Reward.
Holding priority, activate Cursecatcher by sacrificing it, countering the original Faith's Reward.
Resolve the Faith's Reward copy, returning The Mirari Conjecture and Cursecatcher from your graveyard to the battlefield.
The Mirari Conjecture triggers, putting a lore counter on itself and returning Faith's Reward from your graveyard to your hand.
Proceed to your next turn.
At the beginning of your precombat main phase, The Mirari Conjecture triggers, putting a lore counter on itself and returning Temporal Manipulation from your graveyard to your hand.
Proceed to your next turn.
Repeat.

---

# 981-1517-1532-4377

**Cards:**

- The Mirari Conjecture
- Faith's Reward
- Walk the Aeons
- Cursecatcher

**Produces:** Infinite turns

**Mana: {7}{W}{U}{U} every other turn, MV: 10, Colors: WU, Popularity: 0**

**Steps:**

At the beginning of your precombat main phase, The Mirari Conjecture triggers, putting a lore counter on itself, sacrificing itself and copying all instant and sorcery spells you cast this turn.
Cast Walk the Aeons by paying {4}{U}{U}.
The Mirari Conjecture triggers, creating a copy of Walk the Aeons.
Resolve both Walk the Aeonss, getting two extra turns after this one.
Cast Faith's Reward by paying {3}{W}.
The Mirari Conjecture triggers, copying Faith's Reward.
Holding priority, activate Cursecatcher by sacrificing it, countering the original Faith's Reward.
Resolve the Faith's Reward copy, returning The Mirari Conjecture and Cursecatcher from your graveyard to the battlefield.
The Mirari Conjecture triggers, putting a lore counter on itself and returning Faith's Reward from your graveyard to your hand.
Proceed to your next turn.
At the beginning of your precombat main phase, The Mirari Conjecture triggers, putting a lore counter on itself and returning Walk the Aeons from your graveyard to your hand.
Proceed to your next turn.
Repeat.

---

# 981-1517-2104-3505

**Cards:**

- The Mirari Conjecture
- Second Sunrise
- Temporal Manipulation
- Cursecatcher

**Produces:** Infinite turns

**Mana: {4}{W}{W}{U}{U} every other turn, MV: 8, Colors: WU, Popularity: 0**

**Steps:**

At the beginning of your precombat main phase, The Mirari Conjecture triggers, putting a lore counter on itself, sacrificing itself and copying all instant and sorcery spells you cast this turn.
Cast Temporal Manipulation by paying {3}{U}{U}.
The Mirari Conjecture triggers, creating a copy of Temporal Manipulation.
Resolve both Temporal Manipulations, getting two extra turns after this one.
Cast Second Sunrise by paying {1}{W}{W}.
The Mirari Conjecture triggers, copying Second Sunrise.
Holding priority, activate Cursecatcher by sacrificing it, countering the original Second Sunrise.
Resolve the Second Sunrise copy, returning The Mirari Conjecture and Cursecatcher from your graveyard to the battlefield.
The Mirari Conjecture triggers, putting a lore counter on itself and returning Second Sunrise from your graveyard to your hand.
Proceed to your next turn.
At the beginning of your precombat main phase, The Mirari Conjecture triggers, putting a lore counter on itself and returning Temporal Manipulation from your graveyard to your hand.
Proceed to your next turn.
Repeat.

---

# 981-1517-3505-4377

**Cards:**

- The Mirari Conjecture
- Second Sunrise
- Walk the Aeons
- Cursecatcher

**Produces:** Infinite turns

**Mana: {5}{W}{W}{U}{U} every other turn, MV: 9, Colors: WU, Popularity: 0**

**Steps:**

At the beginning of your precombat main phase, The Mirari Conjecture triggers, putting a lore counter on itself, sacrificing itself and copying all instant and sorcery spells you cast this turn.
Cast Walk the Aeons by paying {4}{U}{U}.
The Mirari Conjecture triggers, creating a copy of Walk the Aeons.
Resolve both Walk the Aeonss, getting two extra turns after this one.
Cast Second Sunrise by paying {1}{W}{W}.
The Mirari Conjecture triggers, copying Second Sunrise.
Holding priority, activate Cursecatcher by sacrificing it, countering the original Second Sunrise.
Resolve the Second Sunrise copy, returning The Mirari Conjecture and Cursecatcher from your graveyard to the battlefield.
The Mirari Conjecture triggers, putting a lore counter on itself and returning Second Sunrise from your graveyard to your hand.
Proceed to your next turn.
At the beginning of your precombat main phase, The Mirari Conjecture triggers, putting a lore counter on itself and returning Walk the Aeons from your graveyard to your hand.
Proceed to your next turn.
Repeat.

---

# 985-1594-5078

**Cards:**

- Sensei's Divining Top
- Helm of Awakening
- Mystic Forge

**Produces:** Infinite card draw, Near-infinite storm count, Infinite draw triggers

**Mana: , MV: 0, Colors: C, Popularity: 7157**

**Steps:**

Activate Sensei's Divining Top by tapping it, causing you to draw a card and put Sensei's Divining Top on top of your library.
Cast Sensei's Divining Top from the top of your library by paying {0}.
Repeat

---

# 985-1976-5078

**Cards:**

- Sensei's Divining Top
- Etherium Sculptor
- Mystic Forge

**Produces:** Infinite card draw, Near-infinite storm count, Infinite draw triggers

**Mana: , MV: 0, Colors: U, Popularity: 27737**

**Steps:**

Activate Sensei's Divining Top by tapping it, causing you to draw a card and put Sensei's Divining Top on top of your library.
Cast Sensei's Divining Top from the top of your library by paying {0}.
Repeat

---

# 985-2146-5078

**Cards:**

- Sensei's Divining Top
- Cloud Key
- Mystic Forge

**Produces:** Infinite card draw, Near-infinite storm count, Infinite draw triggers

**Mana: , MV: 0, Colors: C, Popularity: 24426**

**Steps:**

Activate Sensei's Divining Top by tapping it, causing you to draw a card and put Sensei's Divining Top on top of your library.
Cast Sensei's Divining Top from the top of your library by paying {0}.
Repeat

---

# 985-4985-5078

**Cards:**

- Sensei's Divining Top
- Jhoira's Familiar
- Mystic Forge

**Produces:** Infinite card draw, Near-infinite storm count, Infinite draw triggers

**Mana: , MV: 0, Colors: C, Popularity: 17812**

**Steps:**

Activate Sensei's Divining Top by tapping it, causing you to draw a card and put Sensei's Divining Top on top of your library.
Cast Sensei's Divining Top from the top of your library by paying {0}.
Repeat

---

# 989-5125-5218

**Cards:**

- Dream Halls
- Verdant Eidolon
- Sparkcaster

**Produces:** Infinite damage, Infinite ETB, Infinite LTB, Infinite self-discard triggers, Infinite storm count

**Mana: , MV: 0, Colors: GUR, Popularity: 1**

**Steps:**

Cast Sparkcaster by discarding Verdant Eidolon.
Verdant Eidolon triggers from your graveyard, returning from your graveyard to your hand.
Sparkcaster enters the battlefield, triggering twice.
Resolve the first Sparkcaster trigger, dealing 1 damage to target player or planeswalker.
Resolve the second Sparkcaster trigger, returning Sparkcaster from the battlefield to your hand.
Repeat.

---

# 992-2702

**Cards:**

- Archetype of Imagination
- Moat

**Produces:** Opponents can't attack

**Mana: , MV: 0, Colors: WU, Popularity: 205**

**Steps:**

All creatures your opponent control lose flying.
Moat prevents things without flying from attacking.
Creatures your opponent can not fulfill the conditions necessary to attack.

---

# 992-4468

**Cards:**

- Moat
- Mystic Decree

**Produces:** Lock in which no creatures can attack

**Mana: , MV: 0, Colors: WU, Popularity: 28**

**Steps:**

All creatures lose flying and Islandwalk.
Moat prevents things without flying from attacking.
Creatures can not fulfill the conditions nessasary to attack.

---

# 998-1080-1494-5261

**Cards:**

- Scute Mob
- Bioshift
- Sage of Hours
- Isochron Scepter

**Produces:** Infinite turns

**Mana: {2}, MV: 2, Colors: GU, Popularity: 1**

**Steps:**

Activate Isochron Scepter by tapping it and paying {2}, casting a copy of Bioshift without paying its mana cost, targeting Scute Mob and Sage of Hours.
Sage of Hours triggers, putting a +1/+1 counter on itself.
Resolve the Bioshift copy, moving four +1/+1 counters from Scute Mob onto Sage of Hours.
Activate Sage of Hours by removing all +1/+1 counters from it, generating an extra turn after this one.
At the beginning of your extra turn's upkeep, Scute Mob triggers, putting four +1/+1 counters on itself.
Repeat.

---


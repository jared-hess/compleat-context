# 953-1139-1371

**Cards:**

- Hive Mind
- Enter the Infinite
- Howling Mine

**Produces:** Each opponent loses the game, Infinite card draw, Infinite card draw for each opponent, Infinite draw triggers, Infinite draw triggers for each opponent

**Mana: {8}{U}{U}{U}{U}, MV: 12, Colors: U, Popularity: 330**

**Steps:**

Cast Enter the Infinite by paying {8}{U}{U}{U}{U}.
Hive Mind triggers, causing each opponent to create a copy of Enter the Infinite.
Resolve each Enter the Infinite, causing each player to draw their entire library, put a card from their hand on top of their library, and have no maximum hand size until their next turn.
At the beginning of each opponent's draw step, Howling Mine triggers, causing them to draw an additional card and lose the game due to drawing from an empty library.

---

# 953-1371-2065

**Cards:**

- Hive Mind
- Enter the Infinite
- Dictate of Kruphix

**Produces:** Each opponent loses the game, Infinite card draw, Infinite card draw for each opponent, Infinite draw triggers, Infinite draw triggers for each opponent

**Mana: {8}{U}{U}{U}{U}, MV: 12, Colors: U, Popularity: 267**

**Steps:**

Cast Enter the Infinite by paying {8}{U}{U}{U}{U}.
Hive Mind triggers, causing each opponent to create a copy of Enter the Infinite.
Resolve each Enter the Infinite, causing each player to draw their entire library, put a card from their hand on top of their library, and have no maximum hand size until their next turn.
At the beginning of each opponent's draw step, Dictate of Kruphix triggers, causing them to draw an additional card and lose the game due to drawing from an empty library.

---

# 953-1371-2870

**Cards:**

- Hive Mind
- Enter the Infinite
- Anvil of Bogardan

**Produces:** Each opponent loses the game, Infinite card draw, Infinite card draw for each opponent, Infinite draw triggers, Infinite draw triggers for each opponent

**Mana: {8}{U}{U}{U}{U}, MV: 12, Colors: U, Popularity: 74**

**Steps:**

Cast Enter the Infinite by paying {8}{U}{U}{U}{U}.
Hive Mind triggers, causing each opponent to create a copy of Enter the Infinite.
Resolve each Enter the Infinite, causing each player to draw their entire library, put a card from their hand on top of their library, and have no maximum hand size until their next turn.
At the beginning of each opponent's draw step, Anvil of Bogardan triggers, causing them to draw an additional card, discard a card and lose the game due to drawing from an empty library.

---

# 953-1371-3032

**Cards:**

- Hive Mind
- Enter the Infinite
- Kami of the Crescent Moon

**Produces:** Each opponent loses the game, Infinite card draw, Infinite card draw for each opponent, Infinite draw triggers, Infinite draw triggers for each opponent

**Mana: {8}{U}{U}{U}{U}, MV: 12, Colors: U, Popularity: 292**

**Steps:**

Cast Enter the Infinite by paying {8}{U}{U}{U}{U}.
Hive Mind triggers, causing each opponent to create a copy of Enter the Infinite.
Resolve each Enter the Infinite, causing each player to draw their entire library, put a card from their hand on top of their library, and have no maximum hand size until their next turn.
At the beginning of each opponent's draw step, Kami triggers, causing them to draw an additional card and lose the game due to drawing from an empty library.

---

# 954-2034-2302-4215

**Cards:**

- Verdant Succession
- Angel of Fury
- Ashnod's Altar
- Painter's Servant

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: GW, Popularity: 1**

**Steps:**

Activate Ashnod's Altar by sacrificing Angel of Fury, adding {C}{C}.
Angel of Fury and Verdant Succession trigger.
Resolve the Angel of Fury trigger, shuffling it into your library.
Resolve the Verdant Succession trigger, searching your library for Angel of Fury, putting it onto the battlefield and shuffling your library.
Repeat.

---

# 954-2302-4050-4215

**Cards:**

- Verdant Succession
- Angel of Fury
- Phyrexian Altar
- Painter's Servant

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: GW, Popularity: 1**

**Steps:**

Activate Phyrexian Altar by sacrificing Angel of Fury, adding one mana of any color.
Angel of Fury and Verdant Succession trigger.
Resolve the Angel of Fury trigger, shuffling it into your library.
Resolve the Verdant Succession trigger, searching your library for Angel of Fury, putting it onto the battlefield and shuffling your library.
Repeat.

---

# 954-2302-4215-5256

**Cards:**

- Verdant Succession
- Angel of Fury
- Altar of Dementia
- Painter's Servant

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: GW, Popularity: 0**

**Steps:**

Activate Altar of Dementia by sacrificing Angel of Fury.
Angel of Fury and Verdant Succession trigger.
Resolve the Angel of Fury trigger, shuffling it into your library.
Resolve the Verdant Succession trigger, searching your library for Angel of Fury, putting it onto the battlefield and shuffling your library.
Resolve the Altar of Dementia ability from step 1, causing target player to mill cards equal to Angel of Fury's power.
Repeat.

---

# 95-5080

**Cards:**

- Bruvac the Grandiloquent
- Maddening Cacophony

**Produces:** Infinite mill

**Mana: {4}{U}{U}, MV: 6, Colors: U, Popularity: 45876**

**Steps:**

Cast Maddening Cacophony with kicker by paying {4}{U}{U}, causing each opponent to mill their library due to Bruvac.

---

# 957-1271-3212

**Cards:**

- God-Eternal Kefnet
- Scroll Rack
- Time Stretch

**Produces:** Infinite turns, Lock

**Mana: {7}{U}{U} each turn, MV: 9, Colors: U, Popularity: 197**

**Steps:**

Tap Scroll Rack and pay {1} to activate it, putting Time Stretch on top of your library.
Pass the turn.
On your next draw step, when you draw Time Stretch, reveal it due to Kefnet's ability, making a copy that costs {2} less to cast.
Cast the copy for {6}{U}{U}, granting you two extra turns.

---

# 957-1702-3212

**Cards:**

- God-Eternal Kefnet
- Jace, the Mind Sculptor
- Time Stretch

**Produces:** Infinite turns, Lock

**Mana: {6}{U}{U} each turn, MV: 8, Colors: U, Popularity: 129**

**Steps:**

Activate Jace's zero loyalty ability, putting Time Stretch on top of your library.
Move to your next turn.
On your next draw step, when you draw Time Stretch, reveal it due to Kefnet's ability, making a copy that costs {2} less to cast.
Cast the copy for {6}{U}{U}, granting you two extra turns.

---

# 957-2334-2493

**Cards:**

- Soulherder
- Archaeomancer
- Time Stretch

**Produces:** Infinite turns, Lock

**Mana: {8}{U}{U} every other turn, MV: 10, Colors: WU, Popularity: 111**

**Steps:**

With Soulherder and a creature based spell recursion effect on the battlefield, cast the extra turn spell.
Move to end step and target the creature with Soulherder's ability.
When creature re-enters the battlefield, target the extra turn spell in your graveyard and return it to your hand, then pass to yourself.
Repeat

---

# 957-2334-2556

**Cards:**

- Soulherder
- Mnemonic Wall
- Time Stretch

**Produces:** Infinite turns, Lock

**Mana: {8}{U}{U} every other turn, MV: 10, Colors: WU, Popularity: 15**

**Steps:**

With Soulherder and a creature based spell recursion effect on the battlefield, cast the extra turn spell.
Move to end step and target the creature with Soulherder's ability.
When creature re-enters the battlefield, target the extra turn spell in your graveyard and return it to your hand, then pass to yourself.
Repeat

---

# 957-2493-4428

**Cards:**

- Thassa, Deep-Dwelling
- Archaeomancer
- Time Stretch

**Produces:** Infinite turns, Lock

**Mana: {8}{U}{U} every other turn, MV: 10, Colors: U, Popularity: 708**

**Steps:**

Cast Time Stretch by paying {8}{U}{U}, getting two extra turns after this one.
At the beginning of your end step, Thassa triggers, blinking Archaeomancer.
Archaeomancer enters the battlefield, returning Time Stretch from your graveyard to your hand.
Repeat every other turn.

---

# 957-2556-4305

**Cards:**

- Mnemonic Wall
- Followed Footsteps
- Time Stretch

**Produces:** Infinite turns, Lock

**Mana: {8}{U}{U} each turn, MV: 10, Colors: U, Popularity: 4**

**Steps:**

Cast Time Stretch by paying {8}{U}{U}, taking two extra turns after this one.
At the beginning of your upkeep on your next extra turn, Followed Footsteps triggers, creating a token copy of Mnemonic Wall.
Mnemonic Wall enters the battlefield, returning Time Stretch from your graveyard to your hand.
Repeat each turn.

---

# 957-2556-4428

**Cards:**

- Thassa, Deep-Dwelling
- Mnemonic Wall
- Time Stretch

**Produces:** Infinite turns, Lock

**Mana: {8}{U}{U} every other turn, MV: 10, Colors: U, Popularity: 52**

**Steps:**

Cast Time Stretch by paying {8}{U}{U}, getting two extra turns after this one.
At the beginning of your end step, Thassa triggers, blinking Mnemonic Wall.
Mnemonic Wall enters the battlefield, returning Time Stretch from your graveyard to your hand.
Repeat every other turn.

---

# 958-1750-2365-5261

**Cards:**

- Isochron Scepter
- Pull from Eternity
- Dralnu, Lich Lord
- Expropriate

**Produces:** Infinite turns, Lock

**Mana: {9}{U}{U} each turn, MV: 11, Colors: WUB, Popularity: 0**

**Steps:**

Cast Expropriate by paying {7}{U}{U}, causing you to take at least one extra turn after this one and exile Expropriate.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Pull from Eternity without paying its mana cost.
Resolve Pull from Eternity, putting Expropriate into your graveyard from exile.
Move to your next turn.
Activate Dralnu by tapping it, giving Expropriate flashback until end of turn.
Cast Expropriate from your graveyard by paying {7}{U}{U}, causing you to take an extra turn after this one and exile Expropriate.
Repeat from step 2.

---

# 958-1750-2575-5261

**Cards:**

- Isochron Scepter
- Pull from Eternity
- Dralnu, Lich Lord
- Temporal Mastery

**Produces:** Infinite turns, Lock

**Mana: {7}{U}{U} each turn, MV: 9, Colors: WUB, Popularity: 0**

**Steps:**

Cast Temporal Mastery by paying {5}{U}{U}, causing you to take an extra turn after this one and exile Temporal Mastery.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Pull from Eternity without paying its mana cost.
Resolve Pull from Eternity, putting Temporal Mastery into your graveyard from exile.
Move to your next turn.
Activate Dralnu by tapping it, giving Temporal Mastery flashback until end of turn.
Cast Temporal Mastery from your graveyard by paying {5}{U}{U}, causing you to take an extra turn after this one and exile Temporal Mastery.
Repeat from step 2.

---

# 958-1750-4084-5261

**Cards:**

- Isochron Scepter
- Pull from Eternity
- Dralnu, Lich Lord
- Part the Waterveil

**Produces:** Lock, Infinite turns

**Mana: {6}{U}{U} each turn, MV: 8, Colors: WUB, Popularity: 0**

**Steps:**

Cast Part the Waterveil by paying {4}{U}{U}, causing you to take an extra turn after this one and exile Part the Waterveil.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Pull from Eternity without paying its mana cost.
Resolve Pull from Eternity, putting Part the Waterveil into your graveyard from exile.
Move to your next turn.
Activate Dralnu by tapping it, giving Part the Waterveil flashback until end of turn.
Cast Part the Waterveil from your graveyard by paying {4}{U}{U}, causing you to take an extra turn after this one and exile Part the Waterveil.
Repeat from step 2.

---

# 968-2660-4772

**Cards:**

- Jace, Architect of Thought
- Wheel of Sun and Moon
- Doubling Season

**Produces:** Cast any number of spells from opponents' libraries, Infinite storm count

**Mana: {2}{U}{U}, MV: 4, Colors: GWU, Popularity: 62**

**Steps:**

Cast Jace, Architect of Thought for {2}{U}{U} which enters with 8 loyalty counters due to Doubling Season.
Activate Jace's -8, putting it on the bottom of your library.
Search you library for Jace and exile it, and exile a nonland card of your choice.
Cast Jace along with any of the nonland cards you wish to cast.
Repeat from step 2.

---

# 969-1991-3259

**Cards:**

- Tana, the Bloodsower
- Breath of Fury
- Fervor

**Produces:** Infinite combat damage, Infinite combat phases, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mana creatures you control can produce, Infinite sacrifice triggers, Infinite untap of creatures you control, Infinite creature tokens with haste

**Mana: , MV: 0, Colors: RG, Popularity: 21**

**Steps:**

Deal combat damage with Tana and the creature that has Breath of Fury attached.
Tana and Breath of Fury triggers.
Resolve the Tana trigger, creating a number of 1/1 Saproling creature tokens equal to the damage Tana dealt.
Resolve the Breath of Fury trigger, causing you to sacrifice the creature it is attached to, attach Breath of Fury to a Saproling token, untap all creatures you control and get an additional combat phase after this one.
Repeat.

---

# 971-2034-3048-5003

**Cards:**

- Roalesk, Apex Hybrid
- Ashnod's Altar
- Nim Deathmantle
- Pentad Prism

**Produces:** Infinite ETB, Infinite LTB, Infinite proliferate

**Mana: , MV: 0, Colors: GU, Popularity: 1**

**Steps:**

Sacrifice Roalesk to Ashnod's Altar generating two colorless, with Roalesk's death you proliferate twice, putting two more counters on Pentad Prism.
Remove those counters for two mana, use the other two mana from Ashnod's to return Roalesk to the battlefield using Nim Deathmantle.
Repeat.

---

# 972-1061-1953

**Cards:**

- Brudiclad, Telchor Engineer
- Timestream Navigator
- Saheeli's Artistry

**Produces:** Lock, Infinite turns

**Mana: {6}{U}{U}{U}{U} on your first turn, with {2}{U}{U} available on each extra turn, MV: 10, Colors: UR, Popularity: 164**

**Steps:**

Cast Saheeli's Artistry by paying {4}{U}{U}, creating a token copy of Timestream Navigator.
At the beginning of your combat phase, Brudiclad triggers, creating a 2/1 Phyrexian Myr creature token, then choosing to have all tokens you control become copies of the Timestream Navigator token.
Activate Timestream Navigator by paying {2}{U}{U} and tapping it and putting it onto the bottom of your library, causing you to take an extra turn after this one.
Move to your next turn.
Repeat from step 2.

---

# 972-1953-2105

**Cards:**

- Brudiclad, Telchor Engineer
- Combat Celebrant
- Saheeli's Artistry

**Produces:** Infinite combat phases, Infinite damage

**Mana: {4}{U}{U}, MV: 6, Colors: UR, Popularity: 472**

**Steps:**

Cast Saheeli's Artistry by paying {4}{U}{U}, creating a token copy of Combat Celebrant.
At the beginning of your combat phase, Brudiclad triggers, creating a 2/1 Phyrexian Myr creature token, then choosing to have all tokens you control become copies of the Combat Celebrant token.
Declare one of the Combat Celebrant copy as an attacker, choosing to exert it as it attacks.
The Combat Celebrant copy triggers, untapping all other creatures you control and causing you to get an additional combat phase after this one.
Repeat from step 2.

---

# 976-1029-2428-3990-4435

**Cards:**

- Greed
- Horizon Chimera
- Alhammarret's Archive
- Incubation Druid
- Tolarian Kraken

**Produces:** Infinite card draw, Infinite draw triggers, Near-infinite colored mana, Near-infinite lifegain, Near-infinite lifegain triggers

**Mana: , MV: 0, Colors: BGU, Popularity: 0**

**Steps:**

Activate Incubation Druid by tapping it, adding {B}{B}{B}.
Activate Greed by paying {B} and two life, causing you to draw two cards.
Horizon Chimera and Tolarian Kraken each trigger twice.
Resolve both Horizon Chimera triggers, causing you to gain four life.
Resolve the first Tolarian Kraken trigger, choosing not to pay.
Resolve the second Tolarian Kraken trigger, causing you to pay {1} to untap Incubation Druid.
Repeat.

---

# 976-1029-2428-3990-5042

**Cards:**

- Greed
- Horizon Chimera
- Teferi's Ageless Insight
- Incubation Druid
- Tolarian Kraken

**Produces:** Infinite card draw, Infinite draw triggers, Near-infinite colored mana

**Mana: , MV: 0, Colors: BGU, Popularity: 0**

**Steps:**

Activate Incubation Druid by tapping it, adding {B}{B}{B}.
Activate Greed by paying {B} and two life, causing you to draw two cards.
Horizon Chimera and Tolarian Kraken each trigger twice.
Resolve both Horizon Chimera triggers, causing you to gain two life.
Resolve the first Tolarian Kraken trigger, choosing not to pay.
Resolve the second Tolarian Kraken trigger, causing you to pay {1} to untap Incubation Druid.
Repeat.

---

# 978-1429-2034

**Cards:**

- Vizier of Remedies
- Lesser Masticore
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: W, Popularity: 316**

**Steps:**

Activate Ashnod's Altar by sacrificing Lesser Manticore, adding {C}{C}.
Lesser Manticore's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Repeat.

---

# 978-1429-4050

**Cards:**

- Vizier of Remedies
- Lesser Masticore
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: W, Popularity: 235**

**Steps:**

Activate Phyrexian Altar by sacrificing Lesser Manticore, adding one mana of any color.
Lesser Manticore's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Repeat.

---

# 978-1429-5256

**Cards:**

- Vizier of Remedies
- Lesser Masticore
- Altar of Dementia

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: W, Popularity: 379**

**Steps:**

Activate Altar of Dementia by sacrificing Lesser Manticore.
Lesser Manticore's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Resolve the Altar of Dementia ability, causing target player to mill cards equal to Lesser Manticore's power.
Repeat.

---

# 978-2034-2086

**Cards:**

- Vizier of Remedies
- Kitchen Finks
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: GW, Popularity: 579**

**Steps:**

Activate Ashnod's Altar by sacrificing Kitchen Finks, adding {C}{C}.
Kitchen Finks' persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Kitchen Finks enters the battlefield, causing you to gain two life.
Repeat.

---

# 978-2034-2111

**Cards:**

- Vizier of Remedies
- Wingrattle Scarecrow
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: W, Popularity: 74**

**Steps:**

Activate Ashnod's Altar by sacrificing Wingrattle Scarecrow, adding {C}{C}.
Wingrattle Scarecrow's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Repeat.

---

# 978-2034-2620

**Cards:**

- Vizier of Remedies
- Safehold Elite
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: GW, Popularity: 330**

**Steps:**

Activate Ashnod's Altar by sacrificing Safehold Elite, adding {C}{C}.
Safehold Elite's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Repeat.

---

# 978-2034-3607

**Cards:**

- River Kelpie
- Vizier of Remedies
- Ashnod's Altar

**Produces:** Infinite card draw, Near-infinite colorless mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers

**Mana: , MV: 0, Colors: WU, Popularity: 37**

**Steps:**

Activate Ashnod's Altar by sacrificing River Kelpie, adding {C}{C}.
River Kelpie's persist triggers, returning it from your graveyard to the battlefield.
River Kelpie enters the battlefield, causing you to draw.
Repeat.

---

# 978-2086-4050

**Cards:**

- Vizier of Remedies
- Kitchen Finks
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: GW, Popularity: 344**

**Steps:**

Activate Phyrexian Altar by sacrificing Kitchen Finks, adding one mana of any color.
Kitchen Finks' persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Kitchen Finks enters the battlefield, causing you to gain two life.
Repeat.

---

# 978-2086-5256

**Cards:**

- Vizier of Remedies
- Kitchen Finks
- Altar of Dementia

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: GW, Popularity: 438**

**Steps:**

Activate Altar of Dementia by sacrificing Kitchen Finks.
Kitchen Finks' persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Kitchen Finks enters the battlefield, causing you to gain two life.
Resolve the Altar of Dementia ability, causing target player to mill cards equal to Kitchen Finks' power.
Repeat.

---

# 978-2111-4050

**Cards:**

- Vizier of Remedies
- Wingrattle Scarecrow
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: W, Popularity: 47**

**Steps:**

Activate Phyrexian Altar by sacrificing Wingrattle Scarecrow, adding one mana of any color.
Wingrattle Scarecrow's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Repeat.

---

# 978-2111-5256

**Cards:**

- Vizier of Remedies
- Wingrattle Scarecrow
- Altar of Dementia

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: W, Popularity: 77**

**Steps:**

Activate Altar of Dementia by sacrificing Wingrattle Scarecrow.
Wingrattle Scarecrow's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Resolve the Altar of Dementia ability, causing target player to mill cards equal to Wingrattle Scarecrow's power.
Repeat.

---

# 978-2292-3607

**Cards:**

- River Kelpie
- Vizier of Remedies
- Viscera Seer

**Produces:** Infinite card draw, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers

**Mana: , MV: 0, Colors: WUB, Popularity: 18**

**Steps:**

Activate Viscera Seer by sacrificing River Kelpie.
River Kelpie's persist triggers, returning it from your graveyard to the battlefield.
River Kelpie enters the battlefield, causing you to draw.
Resolve the Viscera Seer trigger, scrying 1.
Repeat.

---

# 978-2438-3607

**Cards:**

- River Kelpie
- Vizier of Remedies
- Carrion Feeder

**Produces:** Infinite card draw, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinitely large creature, Near-infinite sacrifice triggers

**Mana: , MV: 0, Colors: WUB, Popularity: 10**

**Steps:**

Activate Carrion Feeder by sacrificing River Kelpie.
River Kelpie's persist triggers, returning it from your graveyard to the battlefield.
River Kelpie enters the battlefield, causing you to draw.
Resolve the Carrion Feeder trigger, putting a +1/+1 counter on it.
Repeat.

---

# 978-2620-4050

**Cards:**

- Vizier of Remedies
- Safehold Elite
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: GW, Popularity: 199**

**Steps:**

Activate Phyrexian Altar by sacrificing Safehold Elite, adding one mana of any color.
Safehold Elite's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Repeat.

---

# 978-2620-5256

**Cards:**

- Vizier of Remedies
- Safehold Elite
- Altar of Dementia

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: GW, Popularity: 259**

**Steps:**

Activate Altar of Dementia by sacrificing Safehold Elite.
Safehold Elite's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Resolve the Altar of Dementia ability, causing target player to mill cards equal to Safehold Elite's power.
Repeat.

---

# 978-3607-3899

**Cards:**

- River Kelpie
- Vizier of Remedies
- Spawning Pit

**Produces:** Infinite card draw, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers

**Mana: , MV: 0, Colors: WU, Popularity: 7**

**Steps:**

Activate Spawning Pit by sacrificing River Kelpie.
River Kelpie's persist triggers, returning it from your graveyard to the battlefield.
River Kelpie enters the battlefield, causing you to draw.
Resolve the Spawning Pit trigger, putting a charge counter on it.
Repeat.

---

# 978-3607-4050

**Cards:**

- River Kelpie
- Vizier of Remedies
- Phyrexian Altar

**Produces:** Infinite card draw, Near-infinite colored mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers

**Mana: , MV: 0, Colors: WU, Popularity: 23**

**Steps:**

Activate Phyrexian Altar by sacrificing River Kelpie, adding {1}.
River Kelpie's persist triggers, returning it from your graveyard to the battlefield.
River Kelpie enters the battlefield, causing you to draw.
Repeat.

---

# 978-3607-5256

**Cards:**

- River Kelpie
- Vizier of Remedies
- Altar of Dementia

**Produces:** Infinite card draw, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite mill, Near-infinite sacrifice triggers

**Mana: , MV: 0, Colors: WU, Popularity: 19**

**Steps:**

Activate Altar of Dementia by sacrificing River Kelpie.
River Kelpie's persist triggers, returning it from your graveyard to the battlefield.
River Kelpie enters the battlefield, causing you to draw.
Resolve the Altar of Dementia trigger, causing target player to mill three cards.
Repeat.

---

# 978-4762

**Cards:**

- Devoted Druid
- Vizier of Remedies

**Produces:** Infinite green mana

**Mana: , MV: 0, Colors: GW, Popularity: 4357**

**Steps:**

Activate Devoted Druid by tapping it, adding {G}.
Activate Devoted Druid by putting a zero -1/-1 counter on it due to Vizier of Remedies, untapping it.
Repeat.

---

# 981-1517-1532-2104

**Cards:**

- The Mirari Conjecture
- Faith's Reward
- Temporal Manipulation
- Cursecatcher

**Produces:** Infinite turns, Lock

**Mana: {6}{W}{U}{U} every other turn, MV: 9, Colors: WU, Popularity: 0**

**Steps:**

At the beginning of your precombat main phase, The Mirari Conjecture triggers, putting a lore counter on itself, sacrificing itself and copying all instant and sorcery spells you cast this turn.
Cast Temporal Manipulation by paying {3}{U}{U}.
The Mirari Conjecture triggers, creating a copy of Temporal Manipulation.
Resolve both Temporal Manipulations, getting two extra turns after this one.
Cast Faith's Reward by paying {3}{W}.
The Mirari Conjecture triggers, copying Faith's Reward.
Holding priority, activate Cursecatcher by sacrificing it, countering the original Faith's Reward.
Resolve the Faith's Reward copy, returning The Mirari Conjecture and Cursecatcher from your graveyard to the battlefield.
The Mirari Conjecture triggers, putting a lore counter on itself and returning Faith's Reward from your graveyard to your hand.
Proceed to your next turn.
At the beginning of your precombat main phase, The Mirari Conjecture triggers, putting a lore counter on itself and returning Temporal Manipulation from your graveyard to your hand.
Proceed to your next turn.
Repeat.

---

# 981-1517-1532-4377

**Cards:**

- The Mirari Conjecture
- Faith's Reward
- Walk the Aeons
- Cursecatcher

**Produces:** Infinite turns, Lock

**Mana: {7}{W}{U}{U} every other turn, MV: 10, Colors: WU, Popularity: 0**

**Steps:**

At the beginning of your precombat main phase, The Mirari Conjecture triggers, putting a lore counter on itself, sacrificing itself and copying all instant and sorcery spells you cast this turn.
Cast Walk the Aeons by paying {4}{U}{U}.
The Mirari Conjecture triggers, creating a copy of Walk the Aeons.
Resolve both Walk the Aeonss, getting two extra turns after this one.
Cast Faith's Reward by paying {3}{W}.
The Mirari Conjecture triggers, copying Faith's Reward.
Holding priority, activate Cursecatcher by sacrificing it, countering the original Faith's Reward.
Resolve the Faith's Reward copy, returning The Mirari Conjecture and Cursecatcher from your graveyard to the battlefield.
The Mirari Conjecture triggers, putting a lore counter on itself and returning Faith's Reward from your graveyard to your hand.
Proceed to your next turn.
At the beginning of your precombat main phase, The Mirari Conjecture triggers, putting a lore counter on itself and returning Walk the Aeons from your graveyard to your hand.
Proceed to your next turn.
Repeat.

---

# 981-1517-2104-3505

**Cards:**

- The Mirari Conjecture
- Second Sunrise
- Temporal Manipulation
- Cursecatcher

**Produces:** Infinite turns, Lock

**Mana: {4}{W}{W}{U}{U} every other turn, MV: 8, Colors: WU, Popularity: 0**

**Steps:**

At the beginning of your precombat main phase, The Mirari Conjecture triggers, putting a lore counter on itself, sacrificing itself and copying all instant and sorcery spells you cast this turn.
Cast Temporal Manipulation by paying {3}{U}{U}.
The Mirari Conjecture triggers, creating a copy of Temporal Manipulation.
Resolve both Temporal Manipulations, getting two extra turns after this one.
Cast Second Sunrise by paying {1}{W}{W}.
The Mirari Conjecture triggers, copying Second Sunrise.
Holding priority, activate Cursecatcher by sacrificing it, countering the original Second Sunrise.
Resolve the Second Sunrise copy, returning The Mirari Conjecture and Cursecatcher from your graveyard to the battlefield.
The Mirari Conjecture triggers, putting a lore counter on itself and returning Second Sunrise from your graveyard to your hand.
Proceed to your next turn.
At the beginning of your precombat main phase, The Mirari Conjecture triggers, putting a lore counter on itself and returning Temporal Manipulation from your graveyard to your hand.
Proceed to your next turn.
Repeat.

---

# 981-1517-3505-4377

**Cards:**

- The Mirari Conjecture
- Second Sunrise
- Walk the Aeons
- Cursecatcher

**Produces:** Infinite turns, Lock

**Mana: {5}{W}{W}{U}{U} every other turn, MV: 9, Colors: WU, Popularity: 0**

**Steps:**

At the beginning of your precombat main phase, The Mirari Conjecture triggers, putting a lore counter on itself, sacrificing itself and copying all instant and sorcery spells you cast this turn.
Cast Walk the Aeons by paying {4}{U}{U}.
The Mirari Conjecture triggers, creating a copy of Walk the Aeons.
Resolve both Walk the Aeonss, getting two extra turns after this one.
Cast Second Sunrise by paying {1}{W}{W}.
The Mirari Conjecture triggers, copying Second Sunrise.
Holding priority, activate Cursecatcher by sacrificing it, countering the original Second Sunrise.
Resolve the Second Sunrise copy, returning The Mirari Conjecture and Cursecatcher from your graveyard to the battlefield.
The Mirari Conjecture triggers, putting a lore counter on itself and returning Second Sunrise from your graveyard to your hand.
Proceed to your next turn.
At the beginning of your precombat main phase, The Mirari Conjecture triggers, putting a lore counter on itself and returning Walk the Aeons from your graveyard to your hand.
Proceed to your next turn.
Repeat.

---

# 985-1594-5078

**Cards:**

- Sensei's Divining Top
- Helm of Awakening
- Mystic Forge

**Produces:** Infinite draw triggers, Infinite card draw, Near-infinite storm count

**Mana: , MV: 0, Colors: C, Popularity: 7749**

**Steps:**

Activate Sensei's Divining Top by tapping it, causing you to draw a card and put Sensei's Divining Top on top of your library.
Cast Sensei's Divining Top from the top of your library by paying {0}.
Repeat

---

# 985-1976-5078

**Cards:**

- Sensei's Divining Top
- Etherium Sculptor
- Mystic Forge

**Produces:** Infinite card draw, Near-infinite storm count, Infinite draw triggers

**Mana: , MV: 0, Colors: U, Popularity: 31353**

**Steps:**

Activate Sensei's Divining Top by tapping it, causing you to draw a card and put Sensei's Divining Top on top of your library.
Cast Sensei's Divining Top from the top of your library by paying {0}.
Repeat

---

# 985-2146-5078

**Cards:**

- Sensei's Divining Top
- Cloud Key
- Mystic Forge

**Produces:** Infinite card draw, Near-infinite storm count, Infinite draw triggers

**Mana: , MV: 0, Colors: C, Popularity: 27587**

**Steps:**

Activate Sensei's Divining Top by tapping it, causing you to draw a card and put Sensei's Divining Top on top of your library.
Cast Sensei's Divining Top from the top of your library by paying {0}.
Repeat

---

# 985-4985-5078

**Cards:**

- Sensei's Divining Top
- Jhoira's Familiar
- Mystic Forge

**Produces:** Infinite draw triggers, Infinite card draw, Near-infinite storm count

**Mana: , MV: 0, Colors: C, Popularity: 19433**

**Steps:**

Activate Sensei's Divining Top by tapping it, causing you to draw a card and put Sensei's Divining Top on top of your library.
Cast Sensei's Divining Top from the top of your library by paying {0}.
Repeat

---

# 989-5125-5218

**Cards:**

- Dream Halls
- Verdant Eidolon
- Sparkcaster

**Produces:** Infinite damage, Infinite ETB, Infinite LTB, Infinite self-discard triggers, Infinite storm count

**Mana: , MV: 0, Colors: GUR, Popularity: 2**

**Steps:**

Cast Sparkcaster by discarding Verdant Eidolon.
Verdant Eidolon triggers from your graveyard, returning from your graveyard to your hand.
Sparkcaster enters the battlefield, triggering twice.
Resolve the first Sparkcaster trigger, dealing 1 damage to target player or planeswalker.
Resolve the second Sparkcaster trigger, returning Sparkcaster from the battlefield to your hand.
Repeat.

---

# 992-2702

**Cards:**

- Archetype of Imagination
- Moat

**Produces:** Opponents can't attack, Lock

**Mana: , MV: 0, Colors: WU, Popularity: 257**

**Steps:**

All creatures your opponent control lose flying.
Moat prevents things without flying from attacking.
Creatures your opponent can not fulfill the conditions necessary to attack.

---

# 992-4468

**Cards:**

- Moat
- Mystic Decree

**Produces:** Creatures can't attack, Lock

**Mana: , MV: 0, Colors: WU, Popularity: 40**

**Steps:**

All creatures lose flying and Islandwalk.
Moat prevents things without flying from attacking.
Creatures can not fulfill the conditions nessasary to attack.

---

# 998-1080-1494-5261

**Cards:**

- Scute Mob
- Bioshift
- Sage of Hours
- Isochron Scepter

**Produces:** Infinite turns, Lock

**Mana: {2}, MV: 2, Colors: GU, Popularity: 2**

**Steps:**

Activate Isochron Scepter by tapping it and paying {2}, casting a copy of Bioshift without paying its mana cost, targeting Scute Mob and Sage of Hours.
Sage of Hours triggers, putting a +1/+1 counter on itself.
Resolve the Bioshift copy, moving four +1/+1 counters from Scute Mob onto Sage of Hours.
Activate Sage of Hours by removing all +1/+1 counters from it, generating an extra turn after this one.
At the beginning of your extra turn's upkeep, Scute Mob triggers, putting four +1/+1 counters on itself.
Repeat.

---


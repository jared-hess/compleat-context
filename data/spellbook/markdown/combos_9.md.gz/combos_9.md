# 3756-4222-4348

**Cards:**

- Freed from the Real
- Ley Druid
- Izzet Boilerworks

**Produces:** Infinite red mana, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: , MV: 0, Colors: GUR, Popularity: 10**

**Steps:**

Activate Izzet Boilerworks by tapping it, adding {U}{R}.
Activate Ley Druid by tapping it, untapping Izzet Boilerworks.
Activate Freed from the Real's last ability by paying {U}, untapping Ley Druid.
Repeat any number of times.

---

# 3756-4222-4644

**Cards:**

- Freed from the Real
- Tidewater Minion
- Izzet Boilerworks

**Produces:** Infinite red mana, Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: UR, Popularity: 37**

**Steps:**

Activate Izzet Boilerworks by tapping it, adding {U}{R}.
Activate Tidewater Minion's last ability by tapping it, untapping Izzet Boilerworks.
Activate Freed from the Real's last ability by paying {U}, untapping Tidewater Minion.
Repeat any number of times.

---

# 3762-4222

**Cards:**

- Oasis Ritualist
- Freed from the Real

**Produces:** Infinite colored mana

**Mana: , MV: 0, Colors: GU, Popularity: 92**

**Steps:**

Activate Oasis Ritualist's second ability by tapping and exerting it, adding {U}{U}.
Activate Freed from the Real's second ability by paying {U}, untapping Oasis Ritualist.
Repeat

---

# 3785-4762

**Cards:**

- Devoted Druid
- One with the Stars

**Produces:** Infinite green mana

**Mana: , MV: 0, Colors: GU, Popularity: 157**

**Steps:**

Activate Devoted Druid by tapping it, adding {G}.
Activate Devoted Druid by putting a -1/-1 counter on it, untapping it.
Repeat.

---

# 3795-4067

**Cards:**

- Mind Over Matter
- Sea Gate Loremaster

**Produces:** Infinite self-discard triggers, Infinite draw triggers, Infinite looting, Near-infinite card draw, Near-infinite untap of permanents you control, Near-infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: U, Popularity: 14**

**Steps:**

Activate Sea Gate Loremaster by tapping it, causing you to draw at least one card.
Activate Mind Over Matter by discarding a card, untapping Sea Gate Loremaster.
Repeat.

---

# 3799-4090

**Cards:**

- Stuffy Doll
- Pariah

**Produces:** Draw the game

**Mana: , MV: 0, Colors: W, Popularity: 10582**

**Steps:**

Deal damage to Stuffy Doll, either using its ability or another method.
Stuffy Doll triggers, attempting to deal damage to you, but dealing damage to Stuffy Doll instead due to Pariah.
Repeat step 2 in an infinite loop, causing the game to end in a draw.

---

# 3799-5166

**Cards:**

- Guilty Conscience
- Stuffy Doll

**Produces:** Infinite damage to one opponent

**Mana: , MV: 0, Colors: W, Popularity: 5652**

**Steps:**

Deal damage to Stuffy Doll.
Stuffy Doll triggers, dealing damage to the chosen player.
Guilty Conscience triggers, dealing damage to Stuffy Doll.
Repeat from step 2.

---

# 3814-4222

**Cards:**

- Freed from the Real
- Argothian Elder

**Produces:** Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: , MV: 0, Colors: GU, Popularity: 951**

**Steps:**

Activate Argothian Elder by tapping it, untapping two lands you control.
Activate those lands by tapping them, adding at least {1}{U}.
Activate Freed from the Real's last ability by paying {U}, untapping Argothian Elder.
Repeat.

---

# 38-2076-3101-3705

**Cards:**

- Squee, the Immortal
- Hazoret's Monument
- Runaway Steam-Kin
- Skirk Prospector

**Produces:** Infinite death triggers, Infinite draw triggers, Infinite ETB, Infinite looting, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {R}{R}{R}, MV: 3, Colors: R, Popularity: 581**

**Steps:**

Activate Skirk Prospector by sacrificing Squee, adding {R}.
Cast Squee from your graveyard by paying {R}{R}.
Runaway Steam-Kin and Hazoret's Monument trigger.
Resolve the Runaway Steam-Kin trigger, putting a +1/+1 counter on it.
Resolve the Hazoret's Monument trigger, allowing you to loot.
Repeat two additional times.
Activate Runaway Steam-Kin by removing three +1/+1 counters from it, adding {R}{R}{R}.
Repeat.

---

# 3821-4013

**Cards:**

- Peregrine Drake
- Eldrazi Displacer

**Produces:** Infinite ETB, Infinite LTB, Infinite mana lands you control can produce, Infinite blinking

**Mana: , MV: 0, Colors: WU, Popularity: 6421**

**Steps:**

Activate up to five lands by tapping them, adding at least {2}{C}.
Activate Eldrazi Displacer by paying {2}{C}, blinking Peregrine Drake.
When Peregrine Drake enters the battlefield, it triggers, untapping up to five lands.
Repeat.

---

# 3821-4766-5105-5256

**Cards:**

- Sigil of the New Dawn
- Deathrender
- Altar of Dementia
- Peregrine Drake

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mana lands you control can produce, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: {1}{W}, MV: 2, Colors: WU, Popularity: 0**

**Steps:**

Activate Altar of Dementia by sacrificing Peregrine Drake.
Sigil of the New Dawn and Deathrender trigger.
Resolve Sigil of the New Dawn's trigger, paying {1}{W} to return Peregrine Drake from your graveyard to your hand.
Resolve Deathrender's trigger, putting Peregrine Drake from your hand onto the battlefield and attaching Deathrender to it.
Peregrine Drake enters the battlefield, triggering itself, untapping up to five lands you control that can produce at least {2}{W}.
Resolve the Altar of Dementia ability from step 1, causing target player to mill four cards.
Repeat.

---

# 38-2440-2967

**Cards:**

- Skirk Prospector
- Pashalik Mons
- Mana Echoes

**Produces:** Infinite colorless mana, Infinite creature tokens, Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite red mana, Infinite sacrifice triggers

**Mana: {3}{R}, MV: 4, Colors: R, Popularity: 6390**

**Steps:**

Activate Pashalik Mons by paying {3}{R} and sacrificing the additional Goblin.
Pashalik Mons triggers, dealing 1 damage to any target.
Resolve Pashalik Mons's ability from step 1, creating two 1/1 Goblin creature tokens.
Mana Echoes triggers twice, adding a total of at least eight colorless mana.
Activate Skirk Prospector by sacrificing a Goblin token, adding {R}.
Pashalik Mons triggers, dealing 1 damage to any target.
Repeat, adding an increasing amount of mana in step 4 each time.

---

# 383-1371-3948-4398

**Cards:**

- Eye of the Storm
- Hive Mind
- Neverending Torment
- Stranglehold

**Produces:** Opponents can't cast spells, Lock

**Mana: {4}{B}{B}, MV: 6, Colors: UBR, Popularity: 5**

**Steps:**

Cast Neverending Torment.
Neverending Torment is exiled with Eye of the Storm.
Choose to not cast your copy of Neverending Torment with Eye of the Storm.
Hive Mind triggers, and all other players are forced to cast Neverending Torment.
All other players may not cast any other spells for the rest of the game because of Neverending Torment's Epic ability, and they can not use Enduring Ideal due to Stranglehold.

---

# 38-345-586-618-1657-1799-3189

**Cards:**

- Doomsday
- Grenzo, Dungeon Warden
- Metallic Mimic
- Murderous Redcap
- Kiki-Jiki, Mirror Breaker
- Priest of Gix
- Skirk Prospector

**Produces:** Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: {2}{B}{B}{B}, MV: 5, Colors: BR, Popularity: 233**

**Steps:**

Cast Doomsday by paying {B}{B}{B}, searching your library and graveyard for Metallic Mimic, Murderous Redcap, Skirk Prospector, Kiki-Jiki, and Priest of Gix, exiling all other cards from your graveyard and library, and then placing the remaining cards on top of your library in the order previously listed and losing half your life, rounded up.
Activate Grenzo by paying {2}, putting Priest of Gix into your graveyard and then onto the battlefield, adding {B}{B}{B}.
Activate Grenzo by paying {2}, putting Kiki-Jiki into your graveyard and then onto the battlefield.
Activate Kiki-Jiki by tapping, creating a token copy of Priest of Gix.
Token copy of Priest of Gix entering the battlefield, adding {B}{B}{B}.
Activate Grenzo by paying {2}, putting Skirk Prospector into your graveyard and then onto the battlefield.
Activate Grenzo by paying {2}, putting Murderous Redcap into your graveyard and then onto the battlefield, dealing damage equal to its power to any target.
Activate Skirk Prospector by sacrificing Kiki-Jiki and Murderous Redcap, adding {R}{R}.
Murderous Redcap persist ability triggers, holding priority, activate Grenzo by paying {2}, putting Metallic Mimic into your graveyard and then onto the battlefield, naming "Goblin".
Resolve the Murderous Redcap persist ability, returning it to the battlefield, dealing damage equal to its power to any target.
Activate Skirk Prospector by sacrificing Murderous Redcap, adding {R}.
Murderous Redcap persist ability triggers, returning it to the battlefield, dealing damage equal to its power to any target.
Repeat from step 11.

---

# 3857-3859-4191

**Cards:**

- Cavern Harpy
- Parasitic Strix
- Aluren

**Produces:** Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite lifeloss, Infinite LTB, Infinite storm count

**Mana: , MV: 0, Colors: BGU, Popularity: 75**

**Steps:**

Cast Parasitic Strix by paying {0}.
Parasitic Strix enters the battlefield, causing target player to lose 2 life and gaining you 2 life.
Cast Cavern Harpy by paying {0}.
Cavern Harpy enters the battlefield, returning Parasitic Strix to your hand.
Activate Cavern Harpy by paying 1 life, returning it to your hand.
Repeat.

---

# 386-1089-1525-4298

**Cards:**

- Abundance
- Borborygmos Enraged
- Curiosity
- Glistening Oil

**Produces:** Each opponent loses the game, Near-infinite self-discard triggers

**Mana: , MV: 0, Colors: UBRG, Popularity: 0**

**Steps:**

Activate Borborygmos by discarding a land, dealing three infect damage to an opponent.
Curiosity triggers, causing you to reveal cards from the top of your library until you reveal a land card, put it into your hand and put all other cards revealed this way on the bottom of your library.
Repeat.

---

# 386-1525-2396-4298

**Cards:**

- Abundance
- Borborygmos Enraged
- Ophidian Eye
- Glistening Oil

**Produces:** Each opponent loses the game, Near-infinite self-discard triggers

**Mana: , MV: 0, Colors: UBRG, Popularity: 0**

**Steps:**

Activate Borborygmos by discarding a land, dealing three infect damage to an opponent.
Ophidian Eye triggers, causing you to reveal cards from the top of your library until you reveal a land card, put it into your hand and put all other cards revealed this way on the bottom of your library.
Repeat.

---

# 38-618-3580

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Lightning Crafter
- Skirk Prospector

**Produces:** Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite red mana, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: R, Popularity: 4094**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of Lightning Crafter with haste.
The Lightning Crafter token enters the battlefield, championing Kiki-JIki.
Activate the Lightning Crafter token by tapping it, dealing 3 damage to any target.
Activate Skirk Prospector by sacrificing the Lightning Crafter token, adding {R}.
The Lightning Crafter token leaves the battlefield, returning Kiki-Jiki from exile to the battlefield.
Repeat.

---

# 386-406-1525-4298

**Cards:**

- Abundance
- Borborygmos Enraged
- Tandem Lookout
- Glistening Oil

**Produces:** Each opponent loses the game, Near-infinite self-discard triggers

**Mana: , MV: 0, Colors: UBRG, Popularity: 0**

**Steps:**

Activate Borborygmos by discarding a land, dealing three infect damage to an opponent.
Borborygmos triggers, causing you to reveal cards from the top of your library until you reveal a land card, put it into your hand and put all other cards revealed this way on the bottom of your library.
Repeat.

---

# 38-659-2178

**Cards:**

- Krenko, Mob Boss
- Thornbite Staff
- Skirk Prospector

**Produces:** Infinite creature tokens, Infinite damage, Infinite red mana

**Mana: , MV: 0, Colors: R, Popularity: 10633**

**Steps:**

Activate Krenko by tapping it, creating a number of Goblin tokens equal to the number of Goblins you control.
Activate Skirk Prosperctor by sacrificing a Goblin you control, adding {R}.
Thornbite Staff triggers, untapping Krenko.
Repeat.

---

# 38-659-2816

**Cards:**

- Skirk Prospector
- Krenko, Mob Boss
- Umbral Mantle

**Produces:** Infinite creature tokens, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite red mana, Infinite untap of creatures you control, Infinite mana creatures you control can produce, Infinitely large creature until end of turn

**Mana: , MV: 0, Colors: R, Popularity: 7757**

**Steps:**

Activate Krenko by tapping it, creating at least three 1/1 Goblin creature tokens.
Activate Skirk Prospector three times by sacrificing three Goblin tokens, adding {R}{R}{R}.
Activate Krenko by paying {3} and untapping it, giving it +2/+2 until end of turn.
Repeat.

---

# 38-659-3750

**Cards:**

- Skirk Prospector
- Krenko, Mob Boss
- Aggravated Assault

**Produces:** Infinite creature tokens, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite combat phases, Infinite red mana, Infinite untap of creatures you control, Infinite mana creatures you control can produce

**Mana: , MV: 0, Colors: R, Popularity: 5134**

**Steps:**

Activate Krenko by tapping it, creating at least X 1/1 Goblin creature tokens.
Activate Skirk Prospector three times by sacrificing three Goblin tokens, adding {R}{R}{R}.
Activate Aggravated Assault by paying {3}, untapping Krenko.
Repeat.

---

# 386-790-1972

**Cards:**

- Windfall
- Glistening Oil
- Nekusar, the Mindrazer

**Produces:** Each opponent loses the game

**Mana: {2}{U}, MV: 3, Colors: UBR, Popularity: 1076**

**Steps:**

Cast Windfall by paying {2}{U}, causing each player to discard their hand and then draw a number of cards equal to the greatest number of cards a player discarded this way.
Nekusar triggers for each card drawn this way, giving each opponent a poison counter for each card they drew.
Each opponent loses the game due to having ten or more poison counters

---

# 387-1531-2530-4050-4529

**Cards:**

- God-Eternal Bontu
- Endrek Sahr, Master Breeder
- Carnival of Souls
- Deathgreeter
- Phyrexian Altar

**Produces:** Infinite card draw, Infinite colored mana, Infinite death triggers, Infinite draw triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite sacrifice triggers

**Mana: {3}{B}{B} plus enough mana to pay for commander tax, if applicable, MV: 5, Colors: B, Popularity: 37**

**Steps:**

Cast God-Eternal Bontu either from your hand or from the command zone by paying {3}{B}{B} and commander tax, if applicable.
Endrek Sahr triggers, creating five 1/1 Thrull creature tokens.
The Thrull tokens enter the battlefield, triggering Carnival of Souls five times.
Activate Phyrexian Altar by sacrificing two Thrull tokens, adding {B}{B}.
Deathgreeter triggers twice, causing you to gain two life.
Resolve each Carnival of Souls, causing you to lose five life and add {B}{B}{B}{B}{B}.
Resolve God-Eternal Bontu from step 1.
God-Eternal Bontu enters the battlefield, triggering its first ability.
Holding priority, activate Phyrexian Altar by sacrificing God-Eternal Bontu, adding {B}.
God-Eternal Bontu's second ability and Deathgreeter trigger.
Resolve the God-Eternal Bontu trigger, causing you to put it into your library third from the top from your graveyard.
Resolve the Deathgreeter trigger, causing you to gain 1 life.
Resolve God-Eternal Bontu's first ability from step 8, sacrificing three Thrulls and drawing three cards.
Deathgreeter triggers three times, causing you to gain three life.
Repeat.
Once you have an empty library, you can continue the combo by only sacrificing one Thrull in step 13, and sacrificing the other two Thrulls to Phyrexian Altar.

---

# 387-411-5231

**Cards:**

- Endrek Sahr, Master Breeder
- Thermopod
- Grinning Ignus

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite red mana, Infinite sacrifice triggers, Infinite storm count

**Mana: {R}, MV: 1, Colors: BR, Popularity: 6**

**Steps:**

Activate Grinning Ignus by paying {R} and returning it from the battlefield to your hand, adding {C}{C}{R}.
Cast Grinning Ignus by paying {2}{R}.
Endrek Sahr triggers, creating three Thrull tokens.
Activate Thermopod's second ability by sacrificing the Thrull tokens, adding {R}{R}{R}.
Repeat.

---

# 389-4053

**Cards:**

- Solemnity
- Nine Lives

**Produces:** Prevent all damage that would be dealt to you, Lock

**Mana: , MV: 0, Colors: W, Popularity: 5154**

**Steps:**

If a source would deal damage to you, Nine Lives prevents that damage.
Solmenity prevents Nine Lives from putting an incarnation counter on itself.

---

# 3903-4469

**Cards:**

- Lavinia, Azorius Renegade
- Knowledge Pool

**Produces:** Counter all spells opponents cast that are created by Knowledge Pool, Exile all spells players cast from their hands, Lock

**Mana: , MV: 0, Colors: WU, Popularity: 4634**

**Steps:**

Whenever a player casts a spell from their hand, Knowledge Pool triggers, exiling that spell and allowing them to cast a spell exiled by it without paying its mana cost.
When an opponent casts a spell this way, Lavinia triggers, countering that spell.

---

# 3903-4761

**Cards:**

- Teferi, Time Raveler
- Knowledge Pool

**Produces:** Exile all spells opponents cast from their hands, Lock

**Mana: , MV: 0, Colors: WU, Popularity: 3111**

**Steps:**

Because of Teferi, opponent can only cast spells whenever they could cast a sorcery.
Whenever they cast a spell from their hand, Knowledge Pool triggers, exiling that spell.
The opponent cannot cast the spell as permitted by Knowledge Pool due to Teferi.

---

# 3910-4013-4659

**Cards:**

- Breya, Etherium Shaper
- Eldrazi Displacer
- Krark-Clan Ironworks

**Produces:** Infinite colorless mana, Infinite damage, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite blinking of most creatures

**Mana: {W}{U}{B}{R}, MV: 4, Colors: WUBR, Popularity: 2823**

**Steps:**

Cast Breya by paying {W}{U}{B}{R}.
Breya enters the battlefield, creating two 1/1 blue Thopter artifact creature tokens.
Activate Krark-Clan Ironworks by sacrificing those two creature tokens, adding {C}{C}.
Activate Eldrazi Displacer by paying {2}{C}, blinking Breya.
Repeat from step 2.
Once you have infinite colorless mana, you may use it to activate Breya's other abilities.

---

# 3910-4659-5003

**Cards:**

- Nim Deathmantle
- Krark-Clan Ironworks
- Breya, Etherium Shaper

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite creature tokens

**Mana: {2}, MV: 2, Colors: WUBR, Popularity: 4069**

**Steps:**

Activate Krark-Clan Ironworks by sacrificing Breya, adding {C}{C}.
When Breya dies, Nim Deathmantle triggers, causing you to pay {4} to return Breya from your graveyard to the battlefield and attach Nim Deathmantle to it.
When Breya enters, it triggers, creating two artifact creature tokens.
Activate Krark-Clan Ironworks by sacrificing a creature token, adding {C}{C}.
Repeat.

---

# 391-1584-3525

**Cards:**

- Pemmin's Aura
- Blossom Dryad
- Teferi's Isle

**Produces:** Infinite blue mana, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: , MV: 0, Colors: GU, Popularity: 4**

**Steps:**

Activate Teferi's Isle by tapping it, adding {U}{U}.
Activate Blossom Dryad by tapping it, untapping Teferi's Isle.
Activate Pemmin's Aura's first ability by paying {U}, untapping Blossom Dryad.
Repeat any number of times.

---

# 391-1584-4222

**Cards:**

- Freed from the Real
- Blossom Dryad
- Teferi's Isle

**Produces:** Infinite blue mana, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: , MV: 0, Colors: GU, Popularity: 4**

**Steps:**

Activate Teferi's Isle by tapping it, adding {U}{U}.
Activate Blossom Dryad by tapping it, untapping Teferi's Isle.
Activate Freed from the Real's last ability by paying {U}, untapping Blossom Dryad.
Repeat any number of times.

---

# 391-1671-3525

**Cards:**

- Pemmin's Aura
- Blossom Dryad
- Simic Growth Chamber

**Produces:** Infinite green mana, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: , MV: 0, Colors: GU, Popularity: 75**

**Steps:**

Activate Simic Growth Chamber by tapping it, adding {U}{G}.
Activate Blossom Dryad by tapping it, untapping Simic Growth Chamber.
Activate Pemmin's Aura's first ability by paying {U}, untapping Blossom Dryad.
Repeat any number of times.

---

# 391-1671-4222

**Cards:**

- Freed from the Real
- Blossom Dryad
- Simic Growth Chamber

**Produces:** Infinite green mana, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: , MV: 0, Colors: GU, Popularity: 170**

**Steps:**

Activate Simic Growth Chamber by tapping it, adding {U}{G}.
Activate Blossom Dryad by tapping it, untapping Simic Growth Chamber.
Activate Freed from the Real's last ability by paying {U}, untapping Blossom Dryad.
Repeat any number of times.

---

# 391-2605-3525

**Cards:**

- Pemmin's Aura
- Blossom Dryad
- Lotus Vale

**Produces:** Infinite colored mana

**Mana: , MV: 0, Colors: GU, Popularity: 10**

**Steps:**

Activate Lotus Vale by tapping it, adding {U}{U}{U}.
Activate Blossom Dryad by tapping it, untapping Lotus Vale.
Activate Pemmin's Aura's first ability by paying {U}, untapping Blossom Dryad.
Repeat any number of times.
Repeat steps with a different color for infinite mana of any color.

---

# 391-2605-4222

**Cards:**

- Freed from the Real
- Blossom Dryad
- Lotus Vale

**Produces:** Infinite colored mana

**Mana: , MV: 0, Colors: GU, Popularity: 11**

**Steps:**

Activate Lotus Vale by tapping it, adding {U}{U}{U}.
Activate Blossom Dryad by tapping it, untapping Lotus Vale.
Activate Freed from the Real's last ability by paying {U}, untapping Blossom Dryad.
Repeat any number of times.
Repeat steps with a different color for infinite mana of any color.

---

# 391-3078-3525

**Cards:**

- Pemmin's Aura
- Blossom Dryad
- Soldevi Excavations

**Produces:** Infinite colorless mana

**Mana: , MV: 0, Colors: GU, Popularity: 4**

**Steps:**

Activate Soldevi Excavations by tapping it, adding {C}{U}.
Activate Blossom Dryad by tapping it, untapping Soldevi Excavations.
Activate Pemmin's Aura's first ability by paying {U}, untapping Blossom Dryad.
Repeat any number of times.

---

# 391-3078-4222

**Cards:**

- Freed from the Real
- Blossom Dryad
- Soldevi Excavations

**Produces:** Infinite colorless mana

**Mana: , MV: 0, Colors: GU, Popularity: 4**

**Steps:**

Activate Soldevi Excavations by tapping it, adding {C}{U}.
Activate Blossom Dryad by tapping it, untapping Soldevi Excavations.
Activate Freed from the Real's last ability by paying {U}, untapping Blossom Dryad.
Repeat any number of times.

---

# 391-3147-3525

**Cards:**

- Pemmin's Aura
- Blossom Dryad
- Azorius Chancery

**Produces:** Infinite white mana, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: , MV: 0, Colors: GWU, Popularity: 13**

**Steps:**

Activate Azorius Chancery by tapping it, adding {W}{U}.
Activate Blossom Dryad by tapping it, untapping Azorius Chancery.
Activate Pemmin's Aura's first ability by paying {U}, untapping Blossom Dryad.
Repeat any number of times.

---

# 391-3147-4222

**Cards:**

- Freed from the Real
- Blossom Dryad
- Azorius Chancery

**Produces:** Infinite white mana, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: , MV: 0, Colors: GWU, Popularity: 19**

**Steps:**

Activate Azorius Chancery by tapping it, adding {W}{U}.
Activate Blossom Dryad by tapping it, untapping Azorius Chancery.
Activate Freed from the Real's last ability by paying {U}, untapping Blossom Dryad.
Repeat any number of times.

---

# 391-3201-3525

**Cards:**

- Pemmin's Aura
- Blossom Dryad
- Arixmethes, Slumbering Isle

**Produces:** Infinite green mana

**Mana: , MV: 0, Colors: GU, Popularity: 16**

**Steps:**

Activate Arixmethes by tapping it, adding {U}{G}.
Activate Blossom Dryad by tapping it, untapping Arixmethes.
Activate Pemmin's Aura's first ability by paying {U}, untapping Blossom Dryad.
Repeat any number of times.

---

# 391-3201-4222

**Cards:**

- Freed from the Real
- Blossom Dryad
- Arixmethes, Slumbering Isle

**Produces:** Infinite green mana

**Mana: , MV: 0, Colors: GU, Popularity: 24**

**Steps:**

Activate Arixmethes by tapping it, adding {U}{G}.
Activate Blossom Dryad by tapping it, untapping Arixmethes.
Activate Freed from the Real's last ability by paying {U}, untapping Blossom Dryad.
Repeat any number of times.

---

# 391-3230-3525

**Cards:**

- Pemmin's Aura
- Blossom Dryad
- Coral Atoll

**Produces:** Infinite colorless mana, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: , MV: 0, Colors: GU, Popularity: 9**

**Steps:**

Activate Coral Atoll by tapping it, adding {C}{U}.
Activate Blossom Dryad by tapping it, untapping Coral Atoll.
Activate Pemmin's Aura's first ability by paying {U}, untapping Blossom Dryad.
Repeat any number of times.

---

# 391-3230-4222

**Cards:**

- Freed from the Real
- Blossom Dryad
- Coral Atoll

**Produces:** Infinite colorless mana, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: , MV: 0, Colors: GU, Popularity: 12**

**Steps:**

Activate Coral Atoll by tapping it, adding {C}{U}.
Activate Blossom Dryad by tapping it, untapping Coral Atoll.
Activate Freed from the Real's last ability by paying {U}, untapping Blossom Dryad.
Repeat any number of times.

---

# 391-3478-3525

**Cards:**

- Pemmin's Aura
- Blossom Dryad
- Dimir Aqueduct

**Produces:** Infinite black mana, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: , MV: 0, Colors: BGU, Popularity: 11**

**Steps:**

Activate Dimir Aqueduct by tapping it, adding {U}{B}.
Activate Blossom Dryad by tapping it, untapping Dimir Aqueduct.
Activate Pemmin's Aura's first ability by paying {U}, untapping Blossom Dryad.
Repeat any number of times.

---

# 391-3478-4222

**Cards:**

- Freed from the Real
- Blossom Dryad
- Dimir Aqueduct

**Produces:** Infinite black mana, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: , MV: 0, Colors: BGU, Popularity: 12**

**Steps:**

Activate Dimir Aqueduct by tapping it, adding {U}{B}.
Activate Blossom Dryad by tapping it, untapping Dimir Aqueduct.
Activate Freed from the Real's last ability by paying {U}, untapping Blossom Dryad.
Repeat any number of times.

---

# 391-3525-3573

**Cards:**

- Pemmin's Aura
- Blossom Dryad
- Tolarian Academy

**Produces:** Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: , MV: 0, Colors: GU, Popularity: 0**

**Steps:**

Activate Tolarian Academy by tapping it, adding at least {U}{U}.
Activate Blossom Dryad by tapping it, untapping Tolarian Academy.
Activate Pemmin's Aura's first ability by paying {U}, untapping Blossom Dryad.
Repeat any number of times.

---

# 391-3525-3664

**Cards:**

- Pemmin's Aura
- Blossom Dryad
- Lotus Field

**Produces:** Infinite colored mana, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: , MV: 0, Colors: GU, Popularity: 27**

**Steps:**

Activate Lotus Field by tapping it, adding {U}{U}{U}.
Activate Blossom Dryad by tapping it, untapping Lotus Field.
Activate Pemmin's Aura's first ability by paying {U}, untapping Blossom Dryad.
Repeat any number of times.
Repeat steps with a different color for infinite mana of any color.

---

# 391-3525-3756

**Cards:**

- Pemmin's Aura
- Blossom Dryad
- Izzet Boilerworks

**Produces:** Infinite red mana, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: , MV: 0, Colors: GUR, Popularity: 11**

**Steps:**

Activate Izzet Boilerworks by tapping it, adding {U}{R}.
Activate Blossom Dryad by tapping it, untapping Izzet Boilerworks.
Activate Pemmin's Aura's first ability by paying {U}, untapping Blossom Dryad.
Repeat any number of times.

---

# 391-3573-4222

**Cards:**

- Freed from the Real
- Blossom Dryad
- Tolarian Academy

**Produces:** Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: , MV: 0, Colors: GU, Popularity: 0**

**Steps:**

Activate Tolarian Academy by tapping it, adding at least {U}{U}.
Activate Blossom Dryad by tapping it, untapping Tolarian Academy.
Activate Freed from the Real's last ability by paying {U}, untapping Blossom Dryad.
Repeat any number of times.

---

# 391-3664-4222

**Cards:**

- Freed from the Real
- Blossom Dryad
- Lotus Field

**Produces:** Infinite colored mana, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: , MV: 0, Colors: GU, Popularity: 34**

**Steps:**

Activate Lotus Field by tapping it, adding {U}{U}{U}.
Activate Blossom Dryad by tapping it, untapping Lotus Field.
Activate Freed from the Real's last ability by paying {U}, untapping Blossom Dryad.
Repeat any number of times.
Repeat steps with a different color for infinite mana of any color.

---

# 391-3756-4222

**Cards:**

- Freed from the Real
- Blossom Dryad
- Izzet Boilerworks

**Produces:** Infinite red mana, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: , MV: 0, Colors: GUR, Popularity: 12**

**Steps:**

Activate Izzet Boilerworks by tapping it, adding {U}{R}.
Activate Blossom Dryad by tapping it, untapping Izzet Boilerworks.
Activate Freed from the Real's last ability by paying {U}, untapping Blossom Dryad.
Repeat any number of times.

---

# 39-2034-2302-4215

**Cards:**

- Verdant Succession
- Alabaster Dragon
- Ashnod's Altar
- Painter's Servant

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: GW, Popularity: 0**

**Steps:**

Activate Ashnod's Altar by sacrificing Alabaster Dragon, adding {C}{C}.
Alabaster Dragon and Verdant Succession trigger.
Resolve the Alabaster Dragon trigger, shuffling it into your library.
Resolve the Verdant Succession trigger, searching your library for Alabaster Dragon, putting it onto the battlefield and shuffling your library.
Repeat.

---

# 3921-4929-5189

**Cards:**

- Ghave, Guru of Spores
- Cryptic Trilobite
- Winding Constrictor

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: WBG, Popularity: 1402**

**Steps:**

Activate Cryptic Trilobite's first ability by removing a +1/+1 counter from it, adding {C}{C}.
Activate Ghave's first ability by paying {1} and removing a +1/+1 counter from Cryptic Trilobite, creating a 1/1 Saproling creature token.
Activate Ghave's second ability by paying {1} and sacrificing the Saproling token, putting two +1/+1 counters on Cryptic Trilobite.
Repeat.

---

# 39-2302-4050-4215

**Cards:**

- Verdant Succession
- Alabaster Dragon
- Phyrexian Altar
- Painter's Servant

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: GW, Popularity: 0**

**Steps:**

Activate Phyrexian Altar by sacrificing Alabaster Dragon, adding one mana of any color.
Alabaster Dragon and Verdant Succession trigger.
Resolve the Alabaster Dragon trigger, shuffling it into your library.
Resolve the Verdant Succession trigger, searching your library for Alabaster Dragon, putting it onto the battlefield and shuffling your library.
Repeat.

---

# 39-2302-4215-5256

**Cards:**

- Verdant Succession
- Alabaster Dragon
- Altar of Dementia
- Painter's Servant

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: GW, Popularity: 0**

**Steps:**

Activate Altar of Dementia by sacrificing Alabaster Dragon.
Alabaster Dragon and Verdant Succession trigger.
Resolve the Alabaster Dragon trigger, shuffling it into your library.
Resolve the Verdant Succession trigger, searching your library for Alabaster Dragon, putting it onto the battlefield and shuffling your library.
Resolve the Altar of Dementia ability from step 1, causing target player to mill cards equal to Alabaster Dragon's power.
Repeat.

---

# 394-1385-2178-4283

**Cards:**

- Whisper, Blood Liturgist
- Thornbite Staff
- Desecrated Tomb
- Zulaport Cutthroat

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: B, Popularity: 51**

**Steps:**

Activate Whisper by tapping it and sacrificing two other nontoken creatures.
Zulaport Cutthroat and Whisper trigger twice.
Resolve both Zulaport Cutthroat triggers, causing each opponent to lose 2 life and you to gain two life.
Resolve both Whisper triggers, untapping it.
Resolve the Whisper ability from step 1, returning target creature card from your graveyard to the battlefield.
Desecrated Tomb triggers, creating a 1/1 Bat creature token.
Activate Whisper by tapping it and sacrificing the Bat token and any other nontoken creature.
Repeat from step 2.

---

# 3941-4222-5089

**Cards:**

- Karn, the Great Creator
- Freed from the Real
- Coveted Jewel

**Produces:** Infinite colored mana

**Mana: {2}{U}, MV: 3, Colors: U, Popularity: 28**

**Steps:**

Activate Karn's first loyalty ability, causing Coveted Jewel to become an artifact creature until end of turn.
Cast Freed from the Real by paying {2}{U}, enchanting Coveted Jewel.
Activate Coveted Jewel by tapping it, adding {U}{U}{U}.
Activate Freed from the Real by paying {U}, untapping Coveted Jewel.
Repeat from step 2.

---

# 394-2178-2842-4283

**Cards:**

- Whisper, Blood Liturgist
- Thornbite Staff
- Desecrated Tomb
- Blood Artist

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: B, Popularity: 50**

**Steps:**

Activate Whisper by tapping it and sacrificing two other nontoken creatures.
Blood Artist and Whisper trigger twice.
Resolve both Blood Artist triggers, causing target player to lose 2 life and you to gain two life.
Resolve both Whisper triggers, untapping it.
Resolve the Whisper ability from step 1, returning target creature card from your graveyard to the battlefield.
Desecrated Tomb triggers, creating a 1/1 Bat creature token.
Activate Whisper by tapping it and sacrificing the Bat token and any other nontoken creature.
Repeat from step 2.

---

# 394-3101-3705-4050

**Cards:**

- Squee, the Immortal
- Desecrated Tomb
- Runaway Steam-Kin
- Phyrexian Altar

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {3}{R}, MV: 4, Colors: R, Popularity: 229**

**Steps:**

Activate Phyrexian Altar by sacrificing Squee, adding {R}.
Cast Squee from your graveyard by paying {1}{R}{R}.
Runaway Steam-Kin and Desecrated Tomb trigger.
Resolve the Runaway Steam-Kin trigger, putting a +1/+1 counter on it.
Resolve the Desecrated Tomb trigger, creating a 1/1 Bat creature token.
Activate Phyrexian Altar by sacrificing Squee and the Bat token, adding {R}{R}.
Repeat from step 2 two additional times.
Activate Runaway Steam-Kin by removing three +1/+1 counters from it, adding {R}{R}{R}.
Repeat from step 2.

---

# 3946-4053

**Cards:**

- Glacial Chasm
- Solemnity

**Produces:** Prevent all damage that would be dealt to you, Lock

**Mana: , MV: 0, Colors: W, Popularity: 2107**

**Steps:**

While you have Glacial Chasm on the battlefield, no damage can be dealt to you.
Solemnity prevents you from putting age counter on Glacial Chasm.


---

# 3948-4603

**Cards:**

- Maralen of the Mornsong
- Stranglehold

**Produces:** Opponents can't search libraries, Lock, Players can't draw cards

**Mana: , MV: 0, Colors: BR, Popularity: 380**

**Steps:**

Maralen prevents players from drawing cards. The ability to search libraries will be rendered moot for opponents due to Stranglehold.

---

# 3965-4691

**Cards:**

- Vilis, Broker of Blood
- Curse of Fool's Wisdom

**Produces:** Infinite card draw, Infinite draw triggers, Near-infinite lifegain triggers

**Mana: {B}, MV: 1, Colors: B, Popularity: 858**

**Steps:**

Activate Vilis by paying {B} and 2 life, targeting any creature.
Vilis triggers, causing you to draw two cards.
Curse of Fool's Wisdom triggers twice.
Resolve a Curse of Fool's Wisdom trigger, causing you to gain 2 life and lose 2 life.
Repeat from step 2.

---

# 3966-4740

**Cards:**

- Aetherflux Reservoir
- Exquisite Blood

**Produces:** Infinite damage, Infinite lifegain triggers

**Mana: , MV: 0, Colors: B, Popularity: 48457**

**Steps:**

Activate Aetherflux Reservoir by paying 50 life, dealing 50 damage to target opponent.
Exquisite Blood triggers, causing you to gain you 50 life.
Repeat.

---

# 3966-4789

**Cards:**

- Exquisite Blood
- Cliffhaven Vampire

**Produces:** Infinite lifegain triggers, Infinite lifeloss, Infinite lifegain

**Mana: , MV: 0, Colors: WB, Popularity: 13463**

**Steps:**

Gain life.
Cliffhaven Vampire triggers, causing each opponent to lose 1 life.
Exquisite Blood triggers for each opponent that lost life.
Resolve a Exquisite Blood trigger, gaining 1 life.
Repeat from step 2.

---

# 3966-4912

**Cards:**

- Exquisite Blood
- Epicure of Blood

**Produces:** Infinite lifegain triggers, Infinite lifeloss, Infinite lifegain

**Mana: , MV: 0, Colors: B, Popularity: 7724**

**Steps:**

Gain life.
Epicure of Blood triggers, causing each opponent to lose 1 life.
Exquisite Blood triggers for each opponent that lost life.
Resolve a Exquisite Blood trigger, gaining 1 life.
Repeat from step 2.

---

# 3972-4221

**Cards:**

- Living Plane
- Ethereal Absolution

**Produces:** Destroy all lands opponents control, Mass Land Denial

**Mana: , MV: 0, Colors: WBG, Popularity: 65**

**Steps:**

Living Plane makes all lands 1/1 creatures, and Ethereal Absolution gives opponent creatures -1/-1.

---

# 4013-4659-4840

**Cards:**

- Myr Battlesphere
- Eldrazi Displacer
- Krark-Clan Ironworks

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite blinking of most creatures

**Mana: {C}, MV: 1, Colors: W, Popularity: 1366**

**Steps:**

Spend {2}{C} to activate Eldrazi Displacer's ability targeting Myr Battlesphere.
Myr Battlesphere ETBs, creating 4 Myr tokens.
Sacrifice two tokens to Krark-Clan Ironworks for 4 {C}.
Use the mana to activate Eldrazi Displacer's ability, targeting the Battlesphere.
Repeat for infinite Myr tokens and colorless mana.

---

# 4017-4631-4929

**Cards:**

- Essence Depleter
- Sunbond
- Cryptic Trilobite

**Produces:** Infinite lifegain, Infinite lifegain triggers, Infinite lifeloss

**Mana: {1}{C}, MV: 2, Colors: WB, Popularity: 4**

**Steps:**

Activate Essence Depleter by paying {1}{C}, causing target opponent to lose 1 life and gaining you 1 life.
Sunbond triggers, putting a +1/+1 counter on Trilobite.
Activate Cryptic Trilobite's first ability by removing a +1/+1 counters, adding {C}{C}.
Repeat.

---

# 402-539-1606

**Cards:**

- Ashaya, Soul of the Wild
- Ley Weaver
- Prodigal Pyromancer

**Produces:** Infinite damage, Infinite mana lands you control can produce, Infinite untap of creatures you control, Infinite mana creatures you control can produce, Infinite untap of nontoken creatures you control, Infinite mana nontoken creatures you control can produce, Infinite untap of lands you control

**Mana: , MV: 0, Colors: RG, Popularity: 2**

**Steps:**

Activate Prodigal Pyromancer by tapping it, dealing 1 damage to any target.
Activate Ley Weaver by tapping it, untapping itself and Prodigal Pyromancer.
Repeat.

---

# 402-539-3814

**Cards:**

- Ashaya, Soul of the Wild
- Argothian Elder
- Prodigal Pyromancer

**Produces:** Infinite damage, Infinite mana lands you control can produce, Infinite untap of creatures you control, Infinite mana creatures you control can produce, Infinite untap of nontoken creatures you control, Infinite mana nontoken creatures you control can produce, Infinite untap of lands you control

**Mana: , MV: 0, Colors: RG, Popularity: 4**

**Steps:**

Activate Prodigal Pyromancer by tapping it, dealing 1 damage to any target.
Activate Argothian Elder by tapping it, untapping itself and Prodigal Pyromancer.
Repeat.

---

# 4031-4499

**Cards:**

- Ardent Electromancer
- Emiel the Blessed

**Produces:** Infinite blinking, Infinite ETB, Infinite LTB, Infinite red mana

**Mana: , MV: 0, Colors: RGW, Popularity: 5**

**Steps:**

Activate Emiel by paying {3}, blinking Ardent Electromancer.
Ardent Electromancer enters the battlefield, adding {R}{R}{R}{R}.
Repeat

---

# 404-1849-2096-2105

**Cards:**

- Ghired, Conclave Exile
- Combat Celebrant
- God-Pharaoh's Gift
- Mass Hysteria

**Produces:** Infinite combat phases, Infinite creature tokens with haste

**Mana: , MV: 0, Colors: RGW, Popularity: 1**

**Steps:**

Move to your combat phase, God-Pharaoh's Gift trigger.
Resolve God-Pharaoh's Gift by exiling Combat Celebrant from your graveyard and creating a token copy of Combat Celebrant.
Attack with Ghired and token copy of Combat Celebrant.
Ghired triggers, creating a copy of Combat Celebrant token.
Exert Combat Celebrant, untapping all other creatures you control, gaining additional combat phase after this one.
Repeat from step 4.

---

# 404-1849-2105-2506

**Cards:**

- Ghired, Conclave Exile
- Combat Celebrant
- Molten Echoes
- Mass Hysteria

**Produces:** Infinite combat phases, Infinite creature tokens with haste

**Mana: {2}{R}, MV: 3, Colors: RGW, Popularity: 2**

**Steps:**

Cast Combat Celebrant by paying {2}{R}.
Combat Celebrant enters the battlefield, triggering Molten Echoes, creating a token copy of Combat Celebrant.
Move to your combat phase, attack with Ghired and Combat Celebrant.
Ghired triggers, creating a copy of Combat Celebrant token.
Exert Combat Celebrant, untapping all other creatures you control, gaining additional combat phase after this one.
Repeat from step 4.

---

# 404-1849-2105-4313

**Cards:**

- Ghired, Conclave Exile
- Combat Celebrant
- Flameshadow Conjuring
- Mass Hysteria

**Produces:** Infinite combat phases, Infinite creature tokens with haste

**Mana: {2}{R}{R}, MV: 4, Colors: RGW, Popularity: 6**

**Steps:**

Cast Combat Celebrant by paying {2}{R}.
Combat Celebrant enters the battlefield, triggering Flameshadow Conjuring, causing you to pay {R}, creating a token copy of Combat Celebrant.
Proceed to your combat phase, and declare Ghired and Combat Celebrant.
Ghired triggers, creating a copy of Combat Celebrant token.
Exert Combat Celebrant, untapping all other creatures you control, gaining additional combat phase after this one.
Repeat from step 4.

---

# 404-1849-2105-4663

**Cards:**

- Ghired, Conclave Exile
- Combat Celebrant
- Bramble Sovereign
- Mass Hysteria

**Produces:** Infinite combat phases, Infinite creature tokens with haste, Infinite ETB

**Mana: {3}{R}{G}, MV: 5, Colors: RGW, Popularity: 5**

**Steps:**

Cast Combat Celebrant by paying {2}{R}.
Combat Celebrant enters the battlefield, triggering Bramble Sovereign, causing you to pay {1}{G} to create a token copy of Combat Celebrant.
Proceed to your combat phase, and declare Ghired and Combat Celebrant as attackers.
Ghired triggers, creating a copy of the Combat Celebrant token.
Exert Combat Celebrant, untapping all other creatures you control and gaining an additional combat phase after this one.
Repeat from step 4.

---

# 4050-4120-4215

**Cards:**

- Verdant Succession
- Vigor
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: G, Popularity: 32**

**Steps:**

Activate Phyrexian Altar by sacrificing Vigor, adding one mana of any color.
Vigor dies, triggering itself and Verdant Succession.
Resolve the Vigor trigger, shuffling it into your library.
Resolve the Verdant Succession trigger, searching your library for Vigor, putting it onto the battlefield and shuffling your library.
Repeat.

---

# 4050-4215-5209

**Cards:**

- Verdant Succession
- Worldspine Wurm
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: G, Popularity: 53**

**Steps:**

Activate Phyrexian Altar by sacrificing Worldspire Wurm, adding one mana of any color.
Worldspire Wurm dies, triggering itself and Verdant Succession.
Resolve the Worldspire Wurm trigger, shuffling it into your library.
Resolve the Verdant Succession trigger, searching your library for Worldspire Wurm, putting it onto the battlefield and shuffling your library.
Repeat.

---

# 4050-4242-5003

**Cards:**

- Nim Deathmantle
- Su-Chi
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: C, Popularity: 151**

**Steps:**

Activate Phyrexian Altar by sacrificing Su-Chi, adding {1}.
Su-Chi and Nim Deathmantle trigger.
Resolve the Su-Chi trigger, adding {C}{C}{C}{C}.
Resolve the Nim Deathmantle trigger, causing you to pay {4} to return Su-Chi from your graveyard to the battlefield, and then attach Nim Deathmantle to it.
Repeat.

---

# 4050-4419-5189

**Cards:**

- Ghave, Guru of Spores
- Renata, Called to the Hunt
- Phyrexian Altar

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: {2}, MV: 2, Colors: WBG, Popularity: 332**

**Steps:**

Activate Ghave's first ability by paying {1} and removing a +1/+1 counter from Ghave, creating a 1/1 Saproling creature token with a +1/+1 counter on it.
Activate Ghave's first ability by paying {1} and removing a +1/+1 counter from a Saproling token, creating a 1/1 Saproling creature token with a +1/+1 counter on it.
Activate Phyrexian Altar by sacrificing a Saproling token without a +1/+1 counter on it, adding one mana of any color.
Repeat from step 2.

---

# 4050-4535-5189

**Cards:**

- Ghave, Guru of Spores
- Good-Fortune Unicorn
- Phyrexian Altar

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: {2}, MV: 2, Colors: WBG, Popularity: 1134**

**Steps:**

Activate Ghave's first ability by paying {1} and removing a +1/+1 counter from a creature you control, creating a 1/1 Saproling creature token.
The Saproling enters the battlefield, triggering Good-Fortune Unicorn, putting a +1/+1 counter on the Saproling.
Activate Ghave's first ability by paying {1} and removing a +1/+1 counter from the Saproling.
Holding priority, activate Phyrexian Altar by sacrificing the Saproling, adding {1}.
Resolve the Ghave ability, creating a 1/1 Saproling creature token.
Repeat from step 2.

---

# 4050-4840-5003

**Cards:**

- Myr Battlesphere
- Nim Deathmantle
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite creature tokens, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: {3}, MV: 3, Colors: C, Popularity: 395**

**Steps:**

Activate Phyrexian Altar by sacrificing Myr Battlesphere, adding {1}.
Nim Deathmantle triggers, causing you to pay {4} to return Myr Battlesphere from your graveyard to the battlefield, and attach Nim Deathmantle to it.
Myr Battlesphere enters the battlefield, creating four 1/1 Myr creature tokens.
Activate Phyrexian Altar by sacrificing three Myr tokens, adding {3}.
Repeat.

---

# 4050-5003-5004

**Cards:**

- Nim Deathmantle
- Cathodion
- Phyrexian Altar

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: C, Popularity: 249**

**Steps:**

Activate Phyrexian Altar by sacrificing Cathodion, adding one mana of any color.
Cathodion and Nim Deathmantle trigger.
Resolve the Cathodion trigger, adding {C}{C}{C}.
Resolve the Nim Deathmantle trigger, causing you to pay {4} to return Cathodion from your graveyard to the battlefield, and then attach Nim Deathmantle to it.
Repeat.

---

# 4050-5003-5296

**Cards:**

- Workhorse
- Nim Deathmantle
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: C, Popularity: 114**

**Steps:**

Activate Workhorse by removing four +1/+1 counters, adding {C}{C}{C}{C}.
Activate Phyrexian Altar by sacrificing Workhorse, adding one mana of any color.
Workhorse dies, triggering Nim Deathmantle, causing you to pay {4} to return Workhorse from your graveyard to the battlefield, and attach Nim Deathmantle to it.
Workhorse enters the battlefield with four +1/+1 counters on it.
Repeat.

---

# 4050-5189-5319

**Cards:**

- Ghave, Guru of Spores
- Geralf's Messenger
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite creature tokens, Infinite death triggers, Infinite ETB, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite +1/+1 counters on creatures you control

**Mana: , MV: 0, Colors: WBG, Popularity: 681**

**Steps:**

Activate Phyrexian Altar by sacrificing Geralf's Messenger, adding {1}.
Geralf's Messenger undying ability triggers, returning it to the battlefield with al +1/+1 counter on it.
Geralf's Messnger's ETB ability triggers, causing target opponent to lose 2 life.
Activate Ghave's first ability by paying {1} and removing a +1/+1 counter from Geralf's Messenger, creating a 1/1 Saproling creature token.
Repeat.

---

# 4053-4551

**Cards:**

- Solemnity
- Phyrexian Unlife

**Produces:** You can't lose the game due to having 0 or less life, Lock

**Mana: , MV: 0, Colors: W, Popularity: 8958**

**Steps:**

While you have zero or less life, Phyrexian Unlife causes all damage to be dealt to you to become infect damage.
Solemnity prevents you from getting poison counters due to infect damage.

---

# 406-1218-1525-4298

**Cards:**

- Abundance
- Borborygmos Enraged
- Tandem Lookout
- Tainted Strike

**Produces:** Each opponent loses the game, Near-infinite self-discard triggers

**Mana: {B}, MV: 1, Colors: UBRG, Popularity: 0**

**Steps:**

Cast Tainted Strike by paying {B}, giving Borborygmos +1/+0 and infect until end of turn.
Activate Borborygmos by discarding a land, dealing three infect damage to an opponent.
Borborygmos triggers, causing you to reveal cards from the top of your library until you reveal a land card, put it into your hand and put all other cards revealed this way on the bottom of your library.
Repeat from step 2.

---

# 406-1525-3681-4298

**Cards:**

- Abundance
- Borborygmos Enraged
- Tandem Lookout
- Grafted Exoskeleton

**Produces:** Each opponent loses the game, Near-infinite self-discard triggers

**Mana: , MV: 0, Colors: GUR, Popularity: 0**

**Steps:**

Activate Borborygmos by discarding a land, dealing three infect damage to an opponent.
Borborygmos triggers, causing you to reveal cards from the top of your library until you reveal a land card, put it into your hand and put all other cards revealed this way on the bottom of your library.
Repeat.

---

# 406-1525-4179-4298

**Cards:**

- Abundance
- Borborygmos Enraged
- Tandem Lookout
- Triumph of the Hordes

**Produces:** Each opponent loses the game, Near-infinite self-discard triggers

**Mana: {2}{G}{G}, MV: 4, Colors: GUR, Popularity: 0**

**Steps:**

Cast Triumph of the Hordes by paying {2}{G}{G}, giving all creature you control +1/+1, trample, and infect untile end of turn.
Activate Borborygmos by discarding a land, dealing three infect damage to an opponent.
Borborygmos triggers, causing you to reveal cards from the top of your library until you reveal a land card, put it into your hand and put all other cards revealed this way on the bottom of your library.
Repeat from step 2.

---

# 406-1525-4298-4651

**Cards:**

- Abundance
- Borborygmos Enraged
- Tandem Lookout
- Phyresis

**Produces:** Each opponent loses the game, Near-infinite self-discard triggers

**Mana: , MV: 0, Colors: UBRG, Popularity: 0**

**Steps:**

Activate Borborygmos by discarding a land, dealing three infect damage to an opponent.
Borborygmos triggers, causing you to reveal cards from the top of your library until you reveal a land card, put it into your hand and put all other cards revealed this way on the bottom of your library.
Repeat.

---

# 406-2353

**Cards:**

- Niv-Mizzet, Parun
- Tandem Lookout

**Produces:** Infinite card draw, Infinite draw triggers, Near-infinite damage

**Mana: , MV: 0, Colors: UR, Popularity: 30694**

**Steps:**

Draw a card.
Niv-Mizzet triggers, dealing 1 damage to any target.
Niv-Mizzet's soulbond ability triggers, drawing you a card.
Repeat from step 2.

---

# 406-4703

**Cards:**

- Brallin, Skyshark Rider
- Tandem Lookout

**Produces:** Infinite card draw, Infinite draw triggers, Near-infinite +1/+1 counters on a creature, Near-infinite damage, Near-infinite self-discard triggers

**Mana: , MV: 0, Colors: UR, Popularity: 1805**

**Steps:**

During your cleanup step, discard to your maximum hand size.
Brallin triggers for each card discarded, getting a +1/+1 counter and dealing 1 damage to each opponent.
Brallin's ability from Tandem Lookout triggers, causing you to draw a card for each damages done to each opponent.
Pass priority, moving to an additional cleanup step.
Repeat.

---

# 406-4869

**Cards:**

- Glint-Horn Buccaneer
- Tandem Lookout

**Produces:** Infinite draw triggers, Infinite rummaging, Infinite self-discard triggers, Near-infinite damage

**Mana: , MV: 0, Colors: UR, Popularity: 7900**

**Steps:**

Proceed to your cleanup step, causing you to discard down to your maximum hand size.
Glint-Horn Buccaneer triggers for each card discarded this way.
Resolve the first trigger, dealing 1 damage to each opponent.
Glint-Horn Buccaneer triggers, causing you to draw a card.
Repeat from step 3 for each remaining trigger.
After all players pass priority, another cleanup step occurs, causing you to discard down to your maximum hand size.
Repeat from step 2.

---

# 406-4971

**Cards:**

- Niv-Mizzet, the Firemind
- Tandem Lookout

**Produces:** Infinite card draw, Infinite draw triggers, Near-infinite damage

**Mana: , MV: 0, Colors: UR, Popularity: 11541**

**Steps:**

Activate Niv-Mizzet's ability to draw a card.
Niv-Mizzet triggers, dealing 1 damage to target opponent.
When Niv-Mizzet deals damage, its ability from Tandem Lookout triggers, causing you to draw a card.
Repeat from step 2.
To end the loop and stop yourself drawing from an empty library, choose any target besides an opponent in step 2.

---

# 406-731-1525-4298

**Cards:**

- Abundance
- Borborygmos Enraged
- Tandem Lookout
- Corrupted Conscience

**Produces:** Each opponent loses the game, Near-infinite self-discard triggers

**Mana: , MV: 0, Colors: GUR, Popularity: 0**

**Steps:**

Activate Borborygmos by discarding a land, dealing three infect damage to an opponent.
Borborygmos triggers, causing you to reveal cards from the top of your library until you reveal a land card, put it into your hand and put all other cards revealed this way on the bottom of your library.
Repeat.

---

# 4067-4857

**Cards:**

- Mind Over Matter
- Temple Bell

**Produces:** Infinite looting, Infinite self-discard triggers, Infinite draw triggers, Near-infinite card draw for each opponent, Near-infinite draw triggers for each opponent

**Mana: , MV: 0, Colors: U, Popularity: 2111**

**Steps:**

Activate Temple Bell by tapping it, causing each player to draw a card.
Activate Mind Over Matter by discarding a card, untapping Temple Bell.
Repeat.

---

# 4067-4971

**Cards:**

- Mind Over Matter
- Niv-Mizzet, the Firemind

**Produces:** Infinite draw triggers, Infinite looting, Infinite self-discard triggers, Near-infinite damage

**Mana: , MV: 0, Colors: UR, Popularity: 395**

**Steps:**

Activate Niv-Mizzet by tapping it, causing you to draw a card.
Niv-Mizzet triggers, dealing 1 damage to any target.
Activate Mind Over Matter by discarding a card, untapping Niv-Mizzet.
Repeat.

---

# 4067-5028

**Cards:**

- Mind Over Matter
- Arcanis the Omnipotent

**Produces:** Infinite draw triggers, Infinite self-discard triggers, Infinite looting, Near-infinite card draw, Near-infinite untap of permanents you control, Near-infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: U, Popularity: 1910**

**Steps:**

Activate Arcanis by tapping it, causing you to draw three cards.
Activate Mind Over Matter by discarding a card, untapping Arcanis.
Repeat.

---

# 4091-4235-5116

**Cards:**

- Rings of Brighthearth
- Aphetto Alchemist
- Gilded Lotus

**Produces:** Infinite colored mana, Infinite untap of artifacts and creatures

**Mana: , MV: 0, Colors: U, Popularity: 619**

**Steps:**

Activate Gilded Lotus by tapping it, adding three mana of any color.
Activate Aphetto Alchemist by tapping it.
Rings of Brighthearth triggers, allowing you to pay {2} to copy Aphetto Alchemist's ability and choose a new target for the copy.
Resolve both copies of Aphetto Alchemist's ability, untapping Aphetto Alchemist and Gilded Lotus.
Repeat.
Once you have infinite mana, you may untap any artifact or creature instead of Gilded Lotus in step 4.

---

# 4091-4684

**Cards:**

- Mesmeric Orb
- Aphetto Alchemist

**Produces:** Infinite self-mill

**Mana: , MV: 0, Colors: U, Popularity: 1568**

**Steps:**

Activate Aphetto Alchemist by tapping it, untapping itself.
When Aphetto Alchemist becomes untapped, Mesmeric Orb triggers, causing you to mill a card.
Repeat.

---

# 4096-4404-4407

**Cards:**

- Goblin Welder
- Corridor Monitor
- Unbender Tine

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: URW, Popularity: 7**

**Steps:**

Activate Goblin Welder by tapping it, sacrificing Corridor Monitor and returning Unbender Tine from your graveyard to the battlefield.
Activate Unbender Tine by tapping it, untapping Goblin Welder.
Activate Goblin Welder by tapping it, sacrificing Unbender Tine and returning Corridor Monitor from your graveyard to the battlefield.
Corridor Monitor enters the battlefield, untapping Goblin Welder.
Repeat.

---

# 4096-4404-5167

**Cards:**

- Goblin Welder
- Corridor Monitor
- Esper Sojourners

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: WUBR, Popularity: 1**

**Steps:**

Activate Goblin Welder by tapping it, sacrificing Esper Sojourners and returning Corridor Monitor from your graveyard to the battlefield.
Esper Sojourners and Corridor Monitor trigger.
Resolve the Esper Sojourners trigger, untapping Goblin Welder.
Holding priority, activate Goblin Welder by tapping it, sacrificing Corridor Monitor and returning Esper Sojourners from your graveyard to the battlefield.
Resolve the Corridor Monitor trigger from step 2, untapping Goblin Welder.
Repeat.

---

# 4096-4407-5167

**Cards:**

- Goblin Welder
- Unbender Tine
- Esper Sojourners

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: WUBR, Popularity: 1**

**Steps:**

Activate Goblin Welder by tapping it, sacrificing Esper Sojourners and returning Unbender Tine from your graveyard to the battlefield.
Esper Sojourners triggers, untapping Goblin Welder.
Activate Unbender Tine by tapping it.
Holding priority, activate Goblin Welder by tapping it, sacrificing Unbender Tine and returning Esper Sojourners from your graveyard to the battlefield.
Resolve the Unbender Tine trigger from step 3, untapping Goblin Welder.
Repeat.

---

# 4104-5107-5261

**Cards:**

- Isochron Scepter
- Rally of Wings
- Tezzeret, Agent of Bolas

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: , MV: 0, Colors: WUB, Popularity: 1**

**Steps:**

Activate Tezzeret's second loyalty ability by removing a loyalty counter on it, causing Isochron Scepter to become an artifact creature until end of turn.
Activate creatures you control by tapping those, adding at least {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Rally of Wings without paying its mana cost, untapping all creatures.
Repeat from step 2.


---

# 411-1812-2146-4893

**Cards:**

- Grinning Ignus
- Cloud Key
- Prismite
- Training Grounds

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count

**Mana: {R}, MV: 1, Colors: UR, Popularity: 0**

**Steps:**

Activate Grinning Ignus by paying {R} and returning it to your hand, adding {C}{C}{R}.
Cast Grinning Ignus by paying {1}{R}.
Activate Prismite by paying {1}, adding {R}.
Repeat.

---

# 411-1812-2510-4893

**Cards:**

- Grinning Ignus
- Semblance Anvil
- Prismite
- Training Grounds

**Produces:** Infinite colored mana, Infinite colorless mana, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: {R}, MV: 1, Colors: UR, Popularity: 0**

**Steps:**

Pay {R} to return Grinning Ignus to your hand, adding {R}{C}{C}.
Cast Grinning Ignus for {R}.
Activate Prismite for {C} to add {R} leaving you where you started with with an additional {1}.
Repeat for infinite mana.

---

# 411-1812-3168-4893

**Cards:**

- Grinning Ignus
- Urza's Incubator
- Prismite
- Training Grounds

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count

**Mana: {R}, MV: 1, Colors: UR, Popularity: 0**

**Steps:**

Activate Grinning Ignus by paying {R} and returning it to your hand, adding {C}{C}{R}.
Cast Grinning Ignus by paying {R}.
Activate Prismite by paying {1}, adding {R}.
Repeat.

---

# 411-2146-2520

**Cards:**

- Grinning Ignus
- Cloud Key
- Skyshroud Elf

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count

**Mana: {R}, MV: 1, Colors: RGW, Popularity: 0**

**Steps:**

Activate Grinning Ignus by paying {R} and returning it to your hand, adding {C}{C}{R}.
Cast Grinning Ignus by paying {1}{R}.
Activate Skyshroud Elf by paying {1}, adding {R}.
Repeat.

---

# 411-2146-4720-4893

**Cards:**

- Grinning Ignus
- Cloud Key
- Stonework Packbeast
- Training Grounds

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count

**Mana: {R}, MV: 1, Colors: UR, Popularity: 1**

**Steps:**

Activate Grinning Ignus by paying {R} and returning it to your hand, adding {C}{C}{R}.
Cast Grinning Ignus by paying {1}{R}.
Activate Stonework Packbeast by paying {1}, adding {R}.
Repeat.

---

# 411-2510-4720-4893

**Cards:**

- Grinning Ignus
- Semblance Anvil
- Stonework Packbeast
- Training Grounds

**Produces:** Infinite colored mana, Infinite colorless mana, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: {R}, MV: 1, Colors: UR, Popularity: 0**

**Steps:**

Pay {R} to return Grinning Ignus to your hand, adding {R}{C}{C}.
Cast Grinning Ignus for {R}.
Activate Stonework Packbeast for {C} to add {R} leaving you where you started with with an additional {1}.
Repeat for infinite mana.

---

# 411-2520-3168

**Cards:**

- Grinning Ignus
- Urza's Incubator
- Skyshroud Elf

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count

**Mana: {R}, MV: 1, Colors: RGW, Popularity: 1**

**Steps:**

Activate Grinning Ignus by paying {R} and returning it to your hand, adding {C}{C}{R}.
Cast Grinning Ignus by paying {R}.
Activate Skyshroud Elf by paying {1}, adding {R}.
Repeat.

---

# 411-3101

**Cards:**

- Grinning Ignus
- Runaway Steam-Kin

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count

**Mana: {2}{R} plus an additional amount of {R} available equal to three minus the number of +1/+1 counters on Runaway Steam-Kin, MV: 3, Colors: R, Popularity: 5101**

**Steps:**

If Runaway Steam-Kin has three or more +1/+1 counters on it, activate it by removing three +1/+1 counters from it, adding {R}{R}{R}.
Cast Grinning Ignus by paying {2}{R}.
Runaway Steam-Kin triggers, putting a +1/+1 counter on it.
Activate Grinning Ignus by paying {R} and returning it from the battlefield to your hand, adding {C}{C}{R}.
Repeat.

---

# 411-3168-4720-4893

**Cards:**

- Grinning Ignus
- Urza's Incubator
- Stonework Packbeast
- Training Grounds

**Produces:** Infinite colored mana, Infinite colorless mana, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: {R}, MV: 1, Colors: UR, Popularity: 0**

**Steps:**

Pay {R} to return Grinning Ignus to your hand, adding {R}{C}{C}.
Cast Grinning Ignus for {R}.
Activate Stonework Packbeast for {C} to add {R} leaving you where you started with with an additional {1}.
Repeat for infinite mana.

---

# 411-4191

**Cards:**

- Aluren
- Grinning Ignus

**Produces:** Infinite colorless mana, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite lifeloss, Infinite LTB, Infinite storm count

**Mana: {R}, MV: 1, Colors: RG, Popularity: 165**

**Steps:**

Cast Grinning Ignus without paying its mana cost.
Activate Grinning Ignus by paying {R}, returning it to your hand and adding {C}{C}{R}.
Repeat.

---

# 411-913-2146-4893

**Cards:**

- Grinning Ignus
- Cloud Key
- Signpost Scarecrow
- Training Grounds

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count

**Mana: {R}, MV: 1, Colors: UR, Popularity: 1**

**Steps:**

Activate Grinning Ignus by paying {R} and returning it to your hand, adding {C}{C}{R}.
Cast Grinning Ignus by paying {1}{R}.
Activate Signpost Scarecrow by paying {1}, adding {R}.
Repeat.

---

# 411-913-2510-4893

**Cards:**

- Grinning Ignus
- Semblance Anvil
- Signpost Scarecrow
- Training Grounds

**Produces:** Infinite colored mana, Infinite colorless mana, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: {R}, MV: 1, Colors: UR, Popularity: 0**

**Steps:**

Pay {R} to return Grinning Ignus to your hand, adding {R}{C}{C}.
Cast Grinning Ignus for {R}.
Activate Signpost Scarecrow for {C} to add {R} leaving you where you started with with an additional {1}.
Repeat for infinite mana.

---

# 411-913-3168-4893

**Cards:**

- Grinning Ignus
- Urza's Incubator
- Signpost Scarecrow
- Training Grounds

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count

**Mana: {R}, MV: 1, Colors: UR, Popularity: 0**

**Steps:**

Activate Grinning Ignus by paying {R} and returning it to your hand, adding {C}{C}{R}.
Cast Grinning Ignus by paying {R}.
Activate Signpost Scarecrow by paying {1}, adding {R}.
Repeat.

---

# 411-913-944-4893

**Cards:**

- Grinning Ignus
- Planar Gate
- Signpost Scarecrow
- Training Grounds

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count

**Mana: {R}, MV: 1, Colors: UR, Popularity: 0**

**Steps:**

Activate Grinning Ignus by paying {R} and returning it to your hand, adding {C}{C}{R}.
Cast Grinning Ignus by paying {R}.
Activate Signpost Scarecrow by paying {1}, adding {R}.
Repeat.

---

# 411-944-1812-4893

**Cards:**

- Grinning Ignus
- Planar Gate
- Prismite
- Training Grounds

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count

**Mana: {R}, MV: 1, Colors: UR, Popularity: 0**

**Steps:**

Activate Grinning Ignus by paying {R} and returning it to your hand, adding {C}{C}{R}.
Cast Grinning Ignus by paying {R}.
Activate Prismite by paying {1}, adding {R}.
Repeat.

---

# 411-944-2520

**Cards:**

- Grinning Ignus
- Planar Gate
- Skyshroud Elf

**Produces:** Infinite ETB, Infinite storm count, Infinite LTB

**Mana: {R}, MV: 1, Colors: RGW, Popularity: 0**

**Steps:**

Activate Grinning Ignus by paying {R} and returning it to your hand, adding {C}{C}{R}.
Cast Grinning Ignus by paying {R}.
Activate Skyshroud Elf by paying {1}, adding {R}.
Repeat.

---

# 411-944-4720-4893

**Cards:**

- Grinning Ignus
- Planar Gate
- Stonework Packbeast
- Training Grounds

**Produces:** Infinite colored mana, Infinite colorless mana, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: {R}, MV: 1, Colors: UR, Popularity: 0**

**Steps:**

Pay {R} to return Grinning Ignus to your hand, adding {R}{C}{C}.
Cast Grinning Ignus for {R}.
Activate Stonework Packbeast for {C} to add {R} leaving you where you started with with an additional {1}.
Repeat for infinite mana.

---

# 4120-4215-5256

**Cards:**

- Verdant Succession
- Vigor
- Altar of Dementia

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: G, Popularity: 79**

**Steps:**

Activate Altar of Dementia by sacrificing Vigor.
Vigor dies, triggering itself and Verdant Succession.
Resolve the Vigor trigger, shuffling it into your library.
Resolve the Verdant Succession trigger, searching your library for Vigor, putting it onto the battlefield and shuffling your library.
Resolve the Altar of Dementia ability, causing target player to mill cards equal to Vigor's power.
Repeat.

---

# 4125-4305-4377

**Cards:**

- Shipwreck Dowser
- Followed Footsteps
- Walk the Aeons

**Produces:** Infinite turns, Lock

**Mana: {4}{U}{U} each turn, MV: 6, Colors: U, Popularity: 8**

**Steps:**

Cast Walk the Aeons by paying {4}{U}{U}, causing you to take an extra turn after this one.
Move to your next turn.
At the beginning of your upkeep, Followed Footsteps triggers, creating a token copy of Shipwreck Dowser.
The Shipwreck Dowser token enters the battlefield, returning Walk the Aeons from your graveyard to your hand.
Repeat.

---

# 4125-4305-4872

**Cards:**

- Shipwreck Dowser
- Followed Footsteps
- Time Warp

**Produces:** Infinite turns, Lock

**Mana: {3}{U}{U} each turn, MV: 5, Colors: U, Popularity: 11**

**Steps:**

Cast Time Warp by paying {3}{U}{U}, causing you to take an extra turn after this one.
Move to your next turn.
At the beginning of your upkeep, Followed Footsteps triggers, creating a token copy of Shipwreck Dowser.
The Shipwreck Dowser token enters the battlefield, returning Time Warp from your graveyard to your hand.
Repeat.

---

# 413-1020-1414-4986

**Cards:**

- Teshar, Ancestor's Apostle
- Myr Retriever
- Blasting Station
- Lotus Petal

**Produces:** Infinite colored mana, Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: W, Popularity: 921**

**Steps:**

Activate Lotus Petal by tapping and sacrificing it, adding one mana of any color.
Activate Blasting Station by tapping it and sacrificing Myr Retriever.
Myr Retriever triggers, returning Lotus Petal from your graveyard to your hand.
Resolve the Blasting Station ability, dealing 1 damage to any target.
Cast Lotus Petal by paying {0}.
Teshar triggers, returning Myr Retriever from your graveyard to the battlefield.
Blasting Station triggers, untapping itself.
Repeat.

---

# 413-1020-1492-4986

**Cards:**

- Teshar, Ancestor's Apostle
- Myr Retriever
- Blasting Station
- Welding Jar

**Produces:** Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: W, Popularity: 546**

**Steps:**

Activate Welding Jar by sacrificing it.
Activate Blasting Station by tapping it and sacrificing Myr Retriever.
Myr Retriever triggers, returning Welding Jar from your graveyard to your hand.
Resolve the Blasting Station ability, dealing 1 damage to any target.
Cast Welding Jar by paying {0}.
Teshar triggers, returning Myr Retriever from your graveyard to the battlefield.
Blasting Station triggers, untapping itself.
Repeat.

---

# 413-1020-2478-4986

**Cards:**

- Teshar, Ancestor's Apostle
- Myr Retriever
- Blasting Station
- Mishra's Bauble

**Produces:** Infinite card draw at the beginning of the next upkeep, Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: W, Popularity: 1127**

**Steps:**

Activate Mishra's Bauble by tapping and sacrificing it, looking at the top card of a player's library and drawing a card at the beginning of the next turn's upkeep.
Activate Blasting Station by tapping it and sacrificing Myr Retriever.
Myr Retriever triggers, returning Mishra's Bauble from your graveyard to your hand.
Resolve the Blasting Station ability, dealing 1 damage to any target.
Cast Mishra's Bauble by paying {0}.
Teshar triggers, returning Myr Retriever from your graveyard to the battlefield.
Blasting Station triggers, untapping itself.
Repeat.

---

# 413-1020-3200-4986

**Cards:**

- Teshar, Ancestor's Apostle
- Myr Retriever
- Blasting Station
- Urza's Bauble

**Produces:** Infinite card draw at the beginning of the next upkeep, Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: W, Popularity: 561**

**Steps:**

Activate Urza's Bauble by tapping and sacrificing it, looking at a random card in target player's hand and drawing a card at the beginning of the next turn's upkeep.
Activate Blasting Station by tapping it and sacrificing Myr Retriever.
Myr Retriever triggers, returning Urza's Bauble from your graveyard to your hand.
Resolve the Blasting Station ability, dealing 1 damage to any target.
Cast Urza's Bauble by paying {0}.
Teshar triggers, returning Myr Retriever from your graveyard to the battlefield.
Blasting Station triggers, untapping itself.
Repeat.

---

# 413-1117-2478-4986

**Cards:**

- Teshar, Ancestor's Apostle
- Junk Diver
- Blasting Station
- Mishra's Bauble

**Produces:** Infinite card draw at the beginning of the next upkeep, Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: W, Popularity: 982**

**Steps:**

Activate Mishra's Bauble by tapping and sacrificing it, looking at the top card of a player's library and drawing a card at the beginning of the next turn's upkeep.
Activate Blasting Station by tapping it and sacrificing Junk Diver.
Junk Diver triggers, returning Mishra's Bauble from your graveyard to your hand.
Resolve the Blasting Station ability, dealing 1 damage to any target.
Cast Mishra's Bauble by paying {0}.
Teshar triggers, returning Junk Diver from your graveyard to the battlefield.
Blasting Station triggers, untapping itself.
Repeat.

---

# 4131-4235

**Cards:**

- Rings of Brighthearth
- Basalt Monolith

**Produces:** Infinite colorless mana

**Mana: {2}, MV: 2, Colors: C, Popularity: 45254**

**Steps:**

Activate Basalt Monolith's first ability by tapping it, adding {C}{C}{C}.
Activate Basalt Monolith's last ability by paying {3}.
Rings of Brighthearth triggers, causing you to pay {2} to copy Basalt Monolith's last ability.
Resolve the copy of Basalt Monolith's last ability, untapping it.
Activate Basalt Monolith's first ability by tapping it, adding {C}{C}{C}.
Resolve the Basalt Monolith ability from step 2, untapping it.
Repeat.

---

# 4131-4241-4893

**Cards:**

- Basalt Monolith
- Training Grounds
- Karn, Silver Golem

**Produces:** Infinite colorless mana

**Mana: , MV: 0, Colors: U, Popularity: 93**

**Steps:**

Activate Basalt Monolith's first ability by tapping it, adding {C}{C}{C}.
Activate Karn by paying {1}, causing Basalt Monolith to become an artifact creature until end of turn.
Activate Basalt Monolith's second ability by paying {1}, untapping it.
Activate Basalt Monolith's first ability by tapping it, adding {C}{C}{C}.
 Repeat from step 3.

---

# 4131-4547

**Cards:**

- Basalt Monolith
- Forsaken Monument

**Produces:** Infinite colorless mana

**Mana: , MV: 0, Colors: C, Popularity: 52077**

**Steps:**

Activate Basalt Monolith's first ability by tapping it, adding {C}{C}{C}{C}.
Activate Basalt Monolith's last ability by paying {3}, untapping it.
Repeat.

---

# 4131-4684

**Cards:**

- Basalt Monolith
- Mesmeric Orb

**Produces:** Infinite self-mill

**Mana: , MV: 0, Colors: C, Popularity: 8713**

**Steps:**

Activate Basalt Monolith's first ability by tapping it, adding {3}.
Activate Basalt Monolith's last ability by paying {3}, untapping it.
Mesmeric Orb triggers, causing you to mill a card.
Repeat.

---

# 4131-4893-5089

**Cards:**

- Basalt Monolith
- Training Grounds
- Karn, the Great Creator

**Produces:** Infinite colorless mana

**Mana: , MV: 0, Colors: U, Popularity: 1274**

**Steps:**

Activate Karn's first loyalty ability by putting a loyalty counter on it, causing Basalt Monolith to become an artifact creature until end of turn.
Activate Basalt Monolith's first ability by tapping it, adding {C}{C}{C}.
Activate Basalt Monolith's second ability by paying {1}, untapping it.
Repeat.

---

# 4131-4944

**Cards:**

- Crackdown Construct
- Basalt Monolith

**Produces:** Infinitely large creature until end of turn

**Mana: , MV: 0, Colors: C, Popularity: 1125**

**Steps:**

Activate Basalt Monolith's first ability by tapping it, adding {C}{C}{C}.
Activate Basalt Monolith's last ability by paying {3}, untapping it.
Crackdown Construct triggers, gaining +1/+1 until end of turn.
Repeat.

---

# 413-1741-4766-5105

**Cards:**

- Sigil of the New Dawn
- Deathrender
- Blasting Station
- Cloud of Faeries

**Produces:** Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: {1}{W}, MV: 2, Colors: WU, Popularity: 1**

**Steps:**

Activate Blasting Station by tapping it and sacrificing Cloud of Faeries.
Sigil of the New Dawn and Deathrender trigger.
Resolve the Sigil of the New Dawn trigger, paying {1}{W} to return Cloud of Faeries from your graveyard to your hand.
Resolve the Deathrender trigger, putting Cloud of Faeries from your hand onto the battlefield and attaching Deathrender to it.
Cloud of Faeries and Blasting Station trigger.
Resolve the Cloud of Faeries trigger, untapping two lands you control that can produce {1}{W}.
Resolve the Blasting Station trigger, untapping it.
Resolve the Blasting Station ability from step 1, dealing 1 damage to any target.
Repeat.

---

# 413-1818-1981

**Cards:**

- Darien, King of Kjeldor
- Blasting Station
- Healer of the Pride

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: W, Popularity: 729**

**Steps:**

Activate Blasting Station by tapping it and sacrificng any other creature you control, dealing 1 damage to yourself.
Darien triggers, creating a 1/1 Soldier creature token.
The Soldier enters the battlefield, triggering Blasting Station and Healer of the Pride.
Resolve the Blasting Station trigger, untapping it.
Resolve the Healer of the Pride trigger, causing you to gain two life.
Repeat.

---

# 413-1874-1981

**Cards:**

- Darien, King of Kjeldor
- Blasting Station
- Ajani's Welcome

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifegain triggers, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: W, Popularity: 1351**

**Steps:**

Activate Blasting Station by tapping it and sacrificng any other creature you control, dealing 1 damage to yourself.
Darien triggers, creating a 1/1 Soldier creature token.
The Soldier enters the battlefield, triggering Blasting Station and Ajani's Welcome.
Resolve the Blasting Station trigger, untapping it.
Resolve the Ajani's Welcome trigger, causing you to gain 1 life.
Repeat.

---

# 413-1992-2744

**Cards:**

- Basri's Lieutenant
- Cathars' Crusade
- Blasting Station

**Produces:** Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite +1/+1 counters on creatures you control

**Mana: , MV: 0, Colors: W, Popularity: 88**

**Steps:**

Activate Blasting Station by tapping and sacrificing a creature with at least one +1/+1 counter.
Basri's Lieutenant trigger, creating a 2/2 Knight token.
When Knight token enters the battlefield, Blasting Station and Cathars' Crusade triggers.
Resolve the Blasting Station trigger, untapping itself.
Resolve the Cathars' Crusade trigger, putting a +1/+1 counter on each creature you control.
Resolve the Blasting Station ability by dealing 1 damage to any target.
Repeat.

---

# 413-1992-4381

**Cards:**

- Basri's Lieutenant
- Grumgully, the Generous
- Blasting Station

**Produces:** Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: RGW, Popularity: 1**

**Steps:**

Activate Blasting Station by tapping and sacrificing a creature with at least one +1/+1 counter.
Basri's Lieutenant trigger, creating a 2/2 Knight token.
When Knight token enters the battlefield, Blasting Station and Grumgully triggers.
Resolve the Blasting Station trigger, untapping itself.
Resolve Grumgully's trigger, putting a +1/+1 counter on each creature you control.
Resolve the Blasting Station ability by dealing 1 damage to any target.
Repeat.

---

# 413-1992-4419

**Cards:**

- Basri's Lieutenant
- Renata, Called to the Hunt
- Blasting Station

**Produces:** Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: GW, Popularity: 20**

**Steps:**

Activate Blasting Station by tapping and sacrificing a creature with at least one +1/+1 counter.
Basri's Lieutenant trigger, creating a 2/2 Knight token.
When Knight token enters the battlefield, Blasting Station and Renata triggers.
Resolve the Blasting Station trigger, untapping itself.
Resolve Renata's trigger, putting a +1/+1 counter on each creature you control.
Resolve the Blasting Station ability by dealing 1 damage to any target.
Repeat.

---

# 413-2018-3216

**Cards:**

- Suncleanser
- Luminous Broodmoth
- Blasting Station

**Produces:** Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: W, Popularity: 18**

**Steps:**

Activate Blasting Station by tapping it and sacrificing Suncleanser.
When Suncleanser dies, Luminous Broodmoth triggers, returning Suncleanser from your graveyard to the battlefield with a flying counter on it.
When Suncleanser enters the battlefield, it and Blasting Station trigger.
Resolve the Suncleanser trigger, removing the flying counter from Suncleanser.
Resolve the Blasting Station trigger, untapping it.
Resolve the Blasting Station ability from step 1.
Repeat.

---

# 413-2018-3826

**Cards:**

- Medicine Runner
- Luminous Broodmoth
- Blasting Station

**Produces:** Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: GW, Popularity: 8**

**Steps:**

Activate Blasting Station by tapping it and sacrificing Medicine Runner.
When Medicine Runner dies, Luminous Broodmoth triggers, returning Medicine Runner from your graveyard to the battlefield with a flying counter on it.
When Medicine Runner enters the battlefield, it and Blasting Station trigger.
Resolve the Blasting Station trigger, untapping it.
Resolve the Medicine Runner trigger, removing the flying counter from Medicine Runner.
Resolve the Blasting Station ability from step 1.
Repeat.

---

# 413-2018-4053

**Cards:**

- Luminous Broodmoth
- Solemnity
- Blasting Station

**Produces:** Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: W, Popularity: 546**

**Steps:**

Activate Blasting Station by tapping it and sacrificing a creature without flying.
When the creature dies, Luminous Broodmoth triggers, returning the creature from your graveyard to the battlefield without a flying counter on it due to Solemnity.
When the creature enters the battlefield, Blasting Station triggers, untapping Blasting Station.
Resolve the Blasting Station ability from step 1.
Repeat.

---

# 413-2058-2073-4659

**Cards:**

- Flayer Husk
- Blasting Station
- Salvaging Station
- Krark-Clan Ironworks

**Produces:** Infinite colorless mana, Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: C, Popularity: 197**

**Steps:**

Activate Blasting Station by tapping it and sacrificing any creature.
Salvaging Station triggers, untapping itself.
Activate Krark-Clan Ironworks by sacrificing Flayer Husk, adding {C}{C}.
Activate Salvaging Station by tapping it, returning Flayer Husk from your graveyard to the battlefield.
When Flayer Husk enters the battlefield, it triggers itself and Blasting Station.
Resolve Blasting Station's trigger, untapping it.
Resolve Flayer Husk's trigger, creating a 0/0 Germ creature token and attaching Flayer Husk to it.
When the Germ enters the battlefield, Blasting Station triggers.
In response, repeat from step 1.

---

# 413-2060-2265-3062-5105

**Cards:**

- Sigil of the New Dawn
- Crystalline Crawler
- Hardened Scales
- Blasting Station
- Pir, Imaginative Rascal

**Produces:** Infinite colored mana, Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {4} in at least three different colors, MV: 4, Colors: GW, Popularity: 0**

**Steps:**

Cast Crystalline Crawler giving it 5 +1/+1 counters because of Pir, Imaginative Rascal and harden scales.
Remove all five counters getting {W} {U} {B} {R} {G}.
Sacrifice Crawler to Blasting Station tapping it to deal 1 damage.
Pay Sigil's cost of {1}{W} returning Crawler to hand.
Recast Crystalline Crawler for all of the remaining floating mana giving it six +1/+1 counters and untapping Blasting Station.
Remove all six counters netting {6} of assorted colors containing {W} {W} {U} {B} {R} {G}.
Repeat steps 4-7 adding mana along the way.

---

# 413-2060-4772-5105

**Cards:**

- Sigil of the New Dawn
- Crystalline Crawler
- Doubling Season
- Blasting Station

**Produces:** Infinite colored mana, Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {4} in at least three different colors, MV: 4, Colors: GW, Popularity: 0**

**Steps:**

Cast Crystalline Crawler giving it six +1/+1 counters because of Doubling Season.
Remove all six counters getting {W} {W} {U} {B} {R} {G}.
Sacrifice Crawler to Blasting Station tapping it to deal 1 damage.
Pay Sigil's cost of {1}{W} returning Crawler to hand.
Recast Crystalline Crawler for all but one of the remaining floating mana giving it eight +1/+1 counters and untapping Blasting Station.
Remove all eight counters netting {8} of assorted colors containing at least {W} {W} {U} {B} {R} {G}.
Repeat steps 4-7.

---

# 413-2281-5237

**Cards:**

- Saffi Eriksdotter
- Renegade Rallier
- Blasting Station

**Produces:** Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: GW, Popularity: 920**

**Steps:**

Activate Saffi by sacrificing it, targeting Renegade Rallier.
Activate Blasting Station by tapping it and sacrificing Renegade Rallier.
When Renegade Rallier dies, Saffi triggers, returning Renegade Rallier from your graveyard to the battlefield.
When Renegade Rallier enters the battlefield, it and Blasting Station triggers.
Resolve the Blasting Station trigger, untapping it.
Resolve the Renegade Rallier trigger, returning Saffi from your graveyard to the battlefield.
When Saffi enters the battlefield, Blasting Station triggers, untapping Blasting Station.
Resolve the Blasting Station ability from step 2, dealing 1 damage to any target.
Repeat.

---

# 413-2478-2866-4986

**Cards:**

- Teshar, Ancestor's Apostle
- Scrap Trawler
- Mishra's Bauble
- Blasting Station

**Produces:** Infinite card draw at the beginning of the next upkeep, Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count, Infinite draw triggers at the beginning of the next upkeep

**Mana: , MV: 0, Colors: W, Popularity: 1061**

**Steps:**

Cast Mishra's Bauble by paying its mana cost.
Teshar triggers, returning Scrap Trawler from your graveyard to the battlefield.
When Scrap Trawler enters, Blasting Station triggers, untapping Blasting Station.
Activate Mishra's Bauble by tapping and sacrificing it.
Activate Blasting Station by tapping it and sacrificing Scrap Trawler.
When Scrap Trawler dies, it triggers, returning Mishra's Bauble from your graveyard to your hand.
Resolve the Blasting Station ability.
Repeat.

---

# 413-2478-3689-4986

**Cards:**

- Teshar, Ancestor's Apostle
- Workshop Assistant
- Blasting Station
- Mishra's Bauble

**Produces:** Infinite card draw at the beginning of the next upkeep, Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: W, Popularity: 934**

**Steps:**

Activate Mishra's Bauble by tapping and sacrificing it, looking at the top card of a player's library and drawing a card at the beginning of the next turn's upkeep.
Activate Blasting Station by tapping it and sacrificing Workshop Assistant.
Workshop Assistant triggers, returning Mishra's Bauble from your graveyard to your hand.
Resolve the Blasting Station ability, dealing 1 damage to any target.
Cast Mishra's Bauble by paying {0}.
Teshar triggers, returning Workshop Assistant from your graveyard to the battlefield.
Blasting Station triggers, untapping itself.
Repeat.

---

# 413-2730-3175

**Cards:**

- Kaya's Ghostform
- Sun Titan
- Blasting Station

**Produces:** Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: WB, Popularity: 154**

**Steps:**

Activate Blasting Station by tapping it and sacrificing Sun Titan.
When Sun Titan dies, Kaya's Ghostform triggers, returning Sun Titan from your graveyard to the battlefield.
When Sun Titan enters, it and Blasting Station trigger.
Resolve the Sun Titan trigger, returning Kaya's Ghostform from your graveyard to the battlefield attached to Sun Titan
Resolve the Blasting Station trigger, untapping it
Resolve the Blasting Station ability from step 1.
Repeat.

---

# 413-2730-5145

**Cards:**

- Kaya's Ghostform
- Archon of Falling Stars
- Blasting Station

**Produces:** Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: WB, Popularity: 8**

**Steps:**

Activate Blasting Station by tapping and sacrificing Archon of Falling Stars.
Kaya's Ghostform and Archon of Falling Stars triggers.
Resolve the Kaya's Ghostform trigger, returning Archon of Falling Stars to the battlefield.
Resolve the Archon of Falling Stars' trigger, returning Kaya's Ghostform to the battlefield and attached to Archon of Falling Stars.
Resolve the Blasting Station's ability, dealing 1 damage to any target.
Repeat.

---

# 413-3055-5145

**Cards:**

- Archon of Falling Stars
- Gift of Immortality
- Blasting Station

**Produces:** Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: W, Popularity: 14**

**Steps:**

Activate Blasting Station by tapping it and sacrificing Archon of Falling Stars.
Archon of Falling Stars dies, triggering itself and Gift of Immortality.
Resolve the Gift of Immortality trigger, returning Archon of Falling Stars from your graveyard to the battlefield.
Archon of Falling Stars enters the battlefield, triggering Blasting Station, untapping Blasting Station.
Resolve the Archon of Falling Stars trigger from step 2, returning Gift of Immortality from your graveyard to the battlefield attached to Archon of Falling Stars.
Resolve the Blasting Station ability from step 1, dealing 1 damage to any target.
Repeat.

---

# 413-3821-4766-5105

**Cards:**

- Sigil of the New Dawn
- Deathrender
- Blasting Station
- Peregrine Drake

**Produces:** Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mana lands you control can produce, Infinite sacrifice triggers

**Mana: {1}{W}, MV: 2, Colors: WU, Popularity: 0**

**Steps:**

Activate Blasting Station by tapping it and sacrificing Peregrine Drake.
Sigil of the New Dawn and Deathrender trigger.
Resolve the Sigil of the New Dawn trigger, paying {1}{W} to return Peregrine Drake from your graveyard to your hand.
Resolve the Deathrender trigger, putting Peregrine Drake from your hand onto the battlefield and attaching Deathrender to it.
Peregrine Drake and Blasting Station trigger.
Resolve the Peregrine Drake trigger, untapping up to five lands you control that can produce at least {2}{W}.
Resolve the Blasting Station trigger, untapping it.
Resolve the Blasting Station ability from step 1, dealing 1 damage to any target.
Repeat.

---

# 413-567-1981

**Cards:**

- Darien, King of Kjeldor
- Soul's Attendant
- Blasting Station

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifegain triggers, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: W, Popularity: 1605**

**Steps:**

Activate Blasting Station by tapping it and by sacrificing a creature you control other than Darien, dealing 1 damage to yourself.
Darien triggers, causing you to create a 1/1 Soldier creature token.
The Soldier token enters the battlefield, triggering Soul's Attendant and Blasting Station.
Resolve the Soul's Attendant trigger, causing you to gain 1 life.
Resolve the Blasting Station trigger, untapping it.
Repeat.

---

# 413-628-4053

**Cards:**

- Mikaeus, the Unhallowed
- Blasting Station
- Solemnity

**Produces:** Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: WB, Popularity: 422**

**Steps:**

Activate Blasting Station by tapping it and sacrificing the additional creature.
When the creature dies, its undying ability triggers, returning it to the battlefield from your graveyard with zero +1/+1 counters due to Solemnity.
When the creature enters the battlefield, Blasting Station triggers, untapping Blasting Station.
Resolve the Blasting Station ability from step 1, dealing 1 damage to any target.
Repeat.

---

# 413-628-4907

**Cards:**

- Mikaeus, the Unhallowed
- Blasting Station
- Tatterkite

**Produces:** Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: B, Popularity: 382**

**Steps:**

Activate Blasting Station by tapping it and sacrificing Tatterkite.
When Tatterkite dies, its undying ability triggers, returning it to the battlefield from your graveyard with zero +1/+1 counters due to its ability.
When Tatterkite enters the battlefield, Blasting Station triggers, untapping Blasting Station.
Resolve the Blasting Station ability from step 1, dealing 1 damage to any target.
Repeat.

---

# 413-628-5296

**Cards:**

- Workhorse
- Mikaeus, the Unhallowed
- Blasting Station

**Produces:** Infinite colorless mana, Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: B, Popularity: 121**

**Steps:**

Activate Workhorse by removing all +1/+1 counters, adding that many {C}.
Activate Blasting Station by tapping it and sacrificing Workhorse.
Workhorse undying ability triggers, returning it to the battlefield with an additional +1/+1 counter on it.
Blasting Station triggers, untapping it.
Resolve the Blasting Station's ability, dealing 1 damage to any target.
Repeat.

---

# 413-631-914-5220

**Cards:**

- Dockside Extortionist
- Mortuary
- Grim Haruspex
- Blasting Station

**Produces:** Infinite colored mana, Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite Treasure tokens

**Mana: {1}{R}, MV: 2, Colors: BR, Popularity: 1**

**Steps:**

Activate Blasting Station by tapping and sacrificing Dockside Extortionist.
Dockside Extortionist dies, triggering Mortuary and Grim Haruspex.
Resolve the Mortuary trigger, putting Dockside Extortionist on top of your library.
Resolve the Grim Haruspex trigger, drawing you a card.
Resolve the Blasting Station's ability, dealing 1 damage to any target.
Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least three Treasure tokens.
Activate two Treasure tokens by tapping and sacrificing those, adding {1}{R}.
Repeat.

---

# 413-671-1981

**Cards:**

- Darien, King of Kjeldor
- Blasting Station
- Daxos, Blessed by the Sun

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: W, Popularity: 1464**

**Steps:**

Activate Blasting Station by tapping it and sacrificng any other creature you control.
Daxos triggers, causing you to gain 1 life.
Resolve the Blasting Station trigger, dealing 1 damage to yourself.
Darien triggers, creating a 1/1 Soldier creature token.
The Soldier enters the battlefield, triggering Blasting Station and Daxos.
Resolve the Blasting Station trigger, untapping it.
Resolve the Daxos trigger, causing you to gain 1 life.
Repeat.

---

# 413-864-3518-3637

**Cards:**

- Lion's Eye Diamond
- Brought Back
- Eternal Witness
- Blasting Station

**Produces:** Infinite colored mana, Infinite damage, Return some permanent cards from your graveyard to the battlefield tapped

**Mana: {1}{G}{G}, MV: 3, Colors: GW, Popularity: 0**

**Steps:**

Cast Eternal Witness by paying {1}{G}{G}.
When Eternal Witness enters the battlefield, it triggers itself and Blasting Station.
In response, activate Lion's Eye Diamond by sacrificing it and discarding your hand, adding {W}{W}{W}.
Activate Blasting Station by tapping it and sacrificing Eternal Witness, dealing 1 damage to any target.
Resolve the Blasting Station trigger, untapping it.
Resolve the Eternal Witness trigger, returning Brought Back from your graveyard to your hand.
Cast Brought Back by paying {W}{W}, returning Eternal Witness and Lion's Eye Diamond from your graveyard to the battlefield tapped.
Repeat from step 2, adding mana of any color in step 3 once you have an arbitrary amount of white mana.
Once you have infinite mana, you may choose any other valid target for Brought Back in place of Lion's Eye Diamond in step 7.

---

# 413-893-4853

**Cards:**

- Dross Scorpion
- Myr Turbine
- Blasting Station

**Produces:** Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: C, Popularity: 418**

**Steps:**

Activate Myr Turbine by tapping it, creating a 1/1 Myr artifact creature token.
When the Myr enters, Blasting Station triggers, untapping Blasting Station.
Activate Blasting Station by tapping it and sacrificing the Myr.
When the Myr dies, Dross Scorpion triggers, untapping Myr Turbine.
Resolve the Blasting Station ability.
Repeat.

---

# 4148-4398

**Cards:**

- Eye of the Storm
- Spellshift

**Produces:** Near-infinite casts of all instant and sorcery spells in your library and exiled by Eye of the Storm, Near-infinite magecraft triggers, Near-infinite storm count

**Mana: {3}{U} plus enough mana to cast the additional instant or sorcery, MV: 4, Colors: U, Popularity: 94**

**Steps:**

Cast the additional instant or sorcery by paying its mana cost, triggering Eye of the Storm.
Holding priority, cast Spellshift by paying {3}{U} targeting the instant or sorcery spell.
Eye of the Storm triggers, exiling Spellshift and casting copies of Spellshift and any other instants and/or sorceries exiled by Eye of the Storm of your choosing without paying their mana costs.
Choose to have Spellshift target any instant or sorcery spell on the stack of your choosing.
Resolve Spellshift, countering the chosen instant or sorcery spell and then revealing an instant or sorcery card from your library, cast it without paying its mana cost, and shuffle your library.
Eye of the Storm triggers, exiling the instant or sorcery and casting copies of Spellshift and any other instants and/or sorceries exiled by Eye of the Storm of your choosing without paying their mana costs.
Repeat from step 4.

---

# 420-1041

**Cards:**

- Worms of the Earth
- Aegis Angel

**Produces:** Lands can't enter the battlefield, Lock, Mass Land Denial

**Mana: {6}{W}{W}{B}{B}{B}, MV: 11, Colors: WB, Popularity: 7**

**Steps:**

Cast Worms of the Earth.
Cast Aegis Angel, and when Aegis Angel ETBs, target Worms of the Earth.
Player's can not play lands or have lands enter the battlefield, and paying the cost to remove Worms of the Earth does not destroy it due to Aegis Angel.

---

# 4215-5209-5256

**Cards:**

- Verdant Succession
- Worldspine Wurm
- Altar of Dementia

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: G, Popularity: 150**

**Steps:**

Activate Altar of Dementia by sacrificing Worldspire Wurm.
Worldspire Wurm dies, triggering itself and Verdant Succession.
Resolve the Worldspire Wurm trigger, shuffling it into your library.
Resolve the Verdant Succession trigger, searching your library for Worldspire Wurm, putting it onto the battlefield and shuffling your library.
Resolve the Altar of Dementia ability, causing target player to mill cards equal to Worldspire Wurm's power.
Repeat.

---

# 421-618

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Huntmaster Liger

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite tapped creature tokens

**Mana: , MV: 0, Colors: RW, Popularity: 60**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of mutated Huntmaster Liger.
Activate the token copy by tapping it, creating a token copy of mutated Huntmaster Liger.
Repeat from step 2.

---

# 4217-5067

**Cards:**

- Release to the Wind
- Lutri, the Spellchaser

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count, Infinite magecraft triggers

**Mana: {3}{U}{U/R}{U/R} plus commander tax if applicable, MV: 6, Colors: UR, Popularity: 217**

**Steps:**

Cast Release to the Wind by paying {2}{U}
Holding priority, cast Lutri either from your hand or from the command zone by paying its mana cost plus commander tax if applicable.
When Lutri enters, it triggers, copying Release to the Wind, targeting Lutri.
Resolve the Release to the Wind copy, exiling Lutri
Cast Lutri from exile without paying its mana cost.
Repeat from step 3.

---

# 422-1050-2636-3263

**Cards:**

- Nevinyrral's Disk
- Darksteel Forge
- Mycosynth Lattice
- Unwinding Clock

**Produces:** Destroy all permanents opponents control each turn, Lock, Mass Land Denial

**Mana: , MV: 0, Colors: C, Popularity: 3329**

**Steps:**

Mycosynth Lattice makes eveything an atrifact, Darksteel Forge makes all of your artifacts indestructible.
Nevinyrrall's Disk destroyes all artifacts except yours because yours are indestructable.
Unwinding Clock allows this to happen every untap step.

---

# 4221-5158

**Cards:**

- Living Plane
- Elesh Norn, Grand Cenobite

**Produces:** Destroy all lands opponents control, Mass Land Denial

**Mana: , MV: 0, Colors: GW, Popularity: 1123**

**Steps:**

Living Plane makes all lands 1/1 creatures, and Elesh Norn gives opponent creatures -2/-2.

---

# 4222-4289-4723

**Cards:**

- Night Market Lookout
- Cryptolith Rite
- Freed from the Real

**Produces:** Infinite lifegain, Infinite lifegain triggers, Infinite lifeloss

**Mana: , MV: 0, Colors: BGU, Popularity: 28**

**Steps:**

Activate Night Market Lookout by tapping it, adding {U}.
Night Market Lookout triggers, causing each opponent to lose 1 life and you to gain 1 life.
Activate Freed from the Real's second ability by paying {U}, untapping Night Market Lookout.
Repeat.


---

# 4222-4306-5089

**Cards:**

- Karn, the Great Creator
- Freed from the Real
- Nyx Lotus

**Produces:** Infinite colored mana

**Mana: {2}{U}, MV: 3, Colors: U, Popularity: 14**

**Steps:**

Activate Karn's first loyalty ability, causing Nyx Lotus to become an artifact creature until end of turn.
Cast Freed from the Real by paying {2}{U}, enchanting Nyx Lotus.
Activate Nyx Lotus by tapping it, adding mana of that color equal to your devotion of that color.
Activate Freed from the Real by paying {U}, untapping Nyx Lotus.
Repeat from step 2.

---

# 4222-4418

**Cards:**

- Freed from the Real
- Mul Daya Channelers

**Produces:** Infinite colored mana

**Mana: , MV: 0, Colors: GU, Popularity: 30**

**Steps:**

Activate Mul Daya Channelers by tapping, adding {U}{U}.
Activate Freed from the Real's second ability by paying {U}, untap Mul Daya Channelers.
Repeat.
Once you have infinite blue mana, you may activate Mul Daya Channelers for infinite mana of any colors.

---

# 4222-5089-5116

**Cards:**

- Karn, the Great Creator
- Freed from the Real
- Gilded Lotus

**Produces:** Infinite colored mana

**Mana: {2}{U}, MV: 3, Colors: U, Popularity: 119**

**Steps:**

Activate Karn's first loyalty ability, causing Gilded Lotus to become an artifact creature until end of turn.
Cast Freed from the Real by paying {2}{U}, enchanting Gilded Lotus.
Activate Gilded Lotus by tapping it, adding {U}{U}{U}.
Activate Freed from the Real by paying {U}, untapping Gilded Lotus.
Repeat from step 2.

---

# 4222-5168

**Cards:**

- Bloom Tender
- Freed from the Real

**Produces:** Infinite non-blue mana of colors among permanents you control, Infinite mana of colors among permanents you control

**Mana: , MV: 0, Colors: GU, Popularity: 17369**

**Steps:**

Activate Bloom Tender by tapping it, adding at least {G}{U}.
Activate Freed from the Real's second ability by paying {U}, untapping Bloom Tender.
Repeat.

---

# 423-2309-3293

**Cards:**

- Emeria Shepherd
- Evolution Sage
- Fall of the Thran

**Produces:** Infinite landfall triggers, Infinite mana lands you control can produce, Infinite proliferate, Return all nonland permanents from your graveyard to the battlefield

**Mana: , MV: 0, Colors: GW, Popularity: 27**

**Steps:**

Play any land from your hand.
The land enters the battlefield, triggering Emeria Shepherd and Evolution Sage.
Resolve the Emeria Shepherd trigger, choosing not to return a permanent.
Resolve the Evolution Sage trigger, putting a lore counter on Fall of the Thran.
Fall of the Thran triggers, causing each player to return two land cards from their graveyard to the battlefield.
The two lands enter the battlefield, triggering Emeria Shepherd twice and Evolution Sage twice.
Resolve both Emeria Shepherd triggers,  choosing not to return a permanent.
Resolve the first Evolution Sage trigger, choosing not to proliferate.
Resolve the second Evolution Sage trigger, putting a lore counter on Fall of the Thran.
Fall of the Thran triggers, causing each player to return two land cards from their graveyard to the battlefield, in which one of your returned lands must be a Plains, and sacrificing Fall of the Thran.
The two lands enter the battlefield, triggering Emeria Shepherd twice and Evolution Sage twice.
Holding priority, activate all available lands you control by tapping them, adding at least {W}.
Resolve the first Emeria Shepherd trigger,  choosing not to return a permanent.
Resolve the first Evolution Sage trigger, choosing not to proliferate.
Resolve the second Emeria Shepherd trigger, returning Fall of the Thran from your graveyard to the battlefield.
Fall of the Thran enters the battlefield with a lore counter, destroying all lands.
Resolve the second Evolution Sage trigger, putting a lore counter on Fall of the Thran.
Repeat from step 5.

---

# 423-757-2402

**Cards:**

- Magosi, the Waterveil
- Nesting Grounds
- Evolution Sage

**Produces:** Infinite turns, Lock

**Mana: {1} each turn, MV: 1, Colors: GU, Popularity: 410**

**Steps:**

Activate Nesting Grounds's last ability by paying {1} and tapping it, moving an eon counter from Magosi to Nesting Grounds.
Activate Magosi's last ability by tapping it, removing an eon counter from it, and returning it from the battlefield to your hand, taking an extra turn after this one.
Play Magosi.
Evolution Sage triggers, causing you to proliferate, putting an additional eon counter on Nesting Grounds.
On your next extra turn, activate Nesting Grounds's last ability by paying {1} and tapping it, moving an eon counter from Nesting Grounds to Magosi.
Repeat from step 2.

---

# 4241-5107-5261

**Cards:**

- Isochron Scepter
- Rally of Wings
- Karn, Silver Golem

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: {1}, MV: 1, Colors: W, Popularity: 4**

**Steps:**

Activate Karn by paying {1}, causing Isochron Scepter to become an artifact creature until end of turn.
Activate creatures you control by tapping those, adding {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Rally of Wings without paying its mana cost, untapping all creatures.
Repeat from step 2.


---

# 4242-4479-5003

**Cards:**

- Nim Deathmantle
- Su-Chi
- Life Chisel

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: C, Popularity: 1**

**Steps:**

Activate Life Chisel by sacrificing Su-Chi.
Su-Chi and Nim Deathmantle triggers.
Resolve the Su-Chi trigger, adding {C}{C}{C}{C}.
Resolve the Nim Deathmantle trigger, causing you to pay {4} to return Su-Chi from your graveyard to the battlefield, and then attach Nim Deathmantle to it.
Resolve the Life Chisel trigger, gaining 4 life.
Repeat.

---

# 4242-5003-5256

**Cards:**

- Nim Deathmantle
- Su-Chi
- Altar of Dementia

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: C, Popularity: 86**

**Steps:**

Activate Altar of Dementia by sacrificing Su-Chi.
Su-Chi and Nim Deathmantle triggers.
Resolve the Su-Chi trigger, adding {C}{C}{C}{C}.
Resolve the Nim Deathmantle trigger, causing you to pay {4} to return Su-Chi from your graveyard to the battlefield, and then attach Nim Deathmantle to it.
Resolve the Altar of Dementia ability, causing target player to mill cards equal to Su-Chi's power.
Repeat.

---

# 4270-4377-4423

**Cards:**

- Mystic Sanctuary
- Trade Routes
- Walk the Aeons

**Produces:** Infinite turns, Skip your draw steps, Lock

**Mana: {5}{U}{U}, MV: 7, Colors: U, Popularity: 1697**

**Steps:**

Cast Walk the Aeons by paying {4}{U}{U}, getting an extra turn after this one.
Play Mystic Sanctuary to put Walk the Aeons on top of your library.
Activate Trade Routes' first ability by paying {1}, returning Mystic Sanctuary to your hand.
Move to your next turn.
Repeat.

---

# 4270-4423-4872

**Cards:**

- Mystic Sanctuary
- Trade Routes
- Time Warp

**Produces:** Skip your draw steps, Lock, Infinite turns

**Mana: {4}{U}{U}, MV: 6, Colors: U, Popularity: 990**

**Steps:**

Cast Time Warp by paying {3}{U}{U}, getting an extra turn after this one.
Play Mystic Sanctuary to put Time Warp on top of your library.
Activate Trade Routes' first ability by paying {1}, returning Mystic Sanctuary to your hand.
Move to your next turn.
Repeat.

---

# 427-5200

**Cards:**

- Kydele, Chosen of Kruphix
- Sword of the Paruns

**Produces:** Infinite colorless mana, Infinite untap of creatures you control, Infinite mana creatures you control can produce

**Mana: , MV: 0, Colors: GU, Popularity: 312**

**Steps:**

Activate Kydele by tapping it, adding at least {C}{C}{C}{C}.
Activate Sword of the Paruns by paying {3}, untapping Kydele.
Repeat.

---

# 4289-4449-4893

**Cards:**

- Hateflayer
- Training Grounds
- Cryptolith Rite

**Produces:** Infinite damage

**Mana: , MV: 0, Colors: GUR, Popularity: 36**

**Steps:**

Activate Hateflayer by tapping it, adding {R}.
Activate Hateflayer by paying {R} and untapping it, causing it to deal damage equal to its power to any target.
Repeat.

---

# 4300-4423-4872

**Cards:**

- Meloku the Clouded Mirror
- Mystic Sanctuary
- Time Warp

**Produces:** Infinite turns, Skip your draw steps, Lock

**Mana: {4}{U}{U} each turn, MV: 6, Colors: U, Popularity: 789**

**Steps:**

Cast Time Warp by paying {3}{U}{U}, causing you to take an extra turn after this one.
Play Mystic Sanctuary.
When Mystic Sanctuary enters the battlefield untapped, it triggers, putting Time Warp on top of your library from your graveyard.
Activate Meloku by paying {1} and returning Mystic Sanctuary from the battlefield to your hand, creating a 1/1 Illusion creature token.
Move to your next turn, drawing Time Warp during your draw step.
Repeat.

---

# 4305-4377-4477

**Cards:**

- Greenwarden of Murasa
- Followed Footsteps
- Walk the Aeons

**Produces:** Infinite creature tokens, Infinite turns, Lock

**Mana: {4}{U}{U} each turn, MV: 6, Colors: GU, Popularity: 3**

**Steps:**

Cast Walk the Aeons by paying {6}{U}{U}, taking an extra turn after this one.
Move to your next turn.
At the beginning of your upkeep, Followed Footsteps triggers, creating a copy of Greenwarden of Murasa.
Greenwarden of Murasa enters the battlefield, returning Walk the Aeons to your hand.
Repeat.

---

# 4305-4477-4872

**Cards:**

- Greenwarden of Murasa
- Followed Footsteps
- Time Warp

**Produces:** Infinite creature tokens, Infinite turns, Lock

**Mana: {3}{U}{U} each turn, MV: 5, Colors: GU, Popularity: 0**

**Steps:**

Cast Time Warp by paying {3}{U}{U}, taking an extra turn after this one.
Move to your next turn.
At the beginning of your upkeep, Followed Footsteps triggers, creating a copy of Greenwarden of Murasa.
Greenwarden of Murasa enters the battlefield, returning Time Warp to your hand.
Repeat.

---

# 4311-4985-5078

**Cards:**

- Sensei's Divining Top
- Jhoira's Familiar
- Future Sight

**Produces:** Infinite draw triggers, Infinite card draw, Near-infinite storm count

**Mana: , MV: 0, Colors: U, Popularity: 379**

**Steps:**

Activate Sensei's Divining Top by tapping it, causing you to draw a card and put Sensei's Divining Top on top of your library.
Cast Sensei's Divining Top from the top of your library by paying {0}.
Repeat

---

# 43-1329-2478-5034

**Cards:**

- Paradox Engine
- Mishra's Bauble
- Emry, Lurker of the Loch
- Sol Ring

**Produces:** Infinite colorless mana, Infinite ETB, Infinite storm count

**Mana: , MV: 0, Colors: U, Popularity: 0**

**Steps:**

Sacrifice Mishra's Bauble targeting any player.
Use Emry's ability targeting Mishra's Bauble in graveyard.
Cast Mishra's Bauble.
On ETB Paradox Engine triggers, untapping Emry and Sol Ring.
Tap Sol Ring for {C} {C}.

---

# 43-1329-3200-5034

**Cards:**

- Paradox Engine
- Urza's Bauble
- Emry, Lurker of the Loch
- Sol Ring

**Produces:** Infinite colorless mana, Infinite ETB, Infinite storm count

**Mana: , MV: 0, Colors: U, Popularity: 0**

**Steps:**

Sacrifice Urza's Bauble targeting any player.
Use Emry's ability targeting Urza's Bauble in graveyard.
Cast Urza's Bauble.
On ETB Paradox Engine triggers, untapping Emry and Sol Ring.
Tap Sol Ring for {C} {C}.

---

# 43-1458-1778-5034

**Cards:**

- Paradox Engine
- Memnite
- Banishing Knack
- Sol Ring

**Produces:** Infinite colorless mana, Infinite ETB, Infinite storm count

**Mana: {U}, MV: 1, Colors: U, Popularity: 0**

**Steps:**

Cast Banishing Knack targeting Memnite Tap Sol Ring for {C} {C} Use Memnite's new ability to bounce Sol Ring to hand.
Cast Sol Ring triggering Paradox Engine untapping all nonland permanents.

---

# 43-1599-3685

**Cards:**

- Spine of Ish Sah
- Priest of Yawgmoth
- Paradox Engine

**Produces:** Destroy any number of target permanents opponents control, Near-infinite storm count, Mass Land Denial

**Mana: , MV: 0, Colors: B, Popularity: 0**

**Steps:**

Activate Priest of Yawgmoth by tapping and sacrificing Spine of Ish Sah, adding seven {B}.
Spine of Ish Sah triggers, returning itself from your graveyard to your hand.
Cast Spine of Ish Sah by paying {7}.
Paradox Engine triggers, untapping all nonland permanents you control.
Spine of Ish Sah enters the battlefield, destroying target permanent.
Repeat.

---

# 43-1778-1792-5034

**Cards:**

- Paradox Engine
- Memnite
- Retraction Helix
- Sol Ring

**Produces:** Infinite colorless mana, Infinite ETB, Infinite storm count

**Mana: {U}, MV: 1, Colors: U, Popularity: 0**

**Steps:**

Cast Retraction Helix targeting Memnite Tap Sol Ring for {C} {C} Use Memnite's new ability to bounce Sol Ring to hand.
Cast Sol Ring triggering Paradox Engine untapping all nonland permanents.

---

# 432-1687

**Cards:**

- Siona, Captain of the Pyleas
- Shielded by Faith

**Produces:** Infinite creature tokens, Infinite ETB

**Mana: {1}{W}{W}, MV: 3, Colors: GW, Popularity: 4933**

**Steps:**

Cast Shielded by faith by paying {1}{W}{W}, targeting Siona.
Siona triggers, creating a 1/1 Human Soldier token.
Shielded by Faith triggers, causing you to attach it to the new token.
Repeat from step 2.

---

# 432-3587

**Cards:**

- Boros Reckoner
- Shielded by Faith

**Produces:** Infinite lifegain, Infinite lifegain triggers

**Mana: , MV: 0, Colors: RW, Popularity: 1546**

**Steps:**

Give Boros Reckoner lifelink.
Deal damage to Boros Reckoner.
Boros Reckoner triggers, dealing that much damage to itself and causing you to gain that much life.
Repeat step 4 any number of times.

---

# 43-4415

**Cards:**

- Paradox Engine
- Stonecloaker

**Produces:** Infinite ETB, Infinite untap of nonland permanents you control, Infinite mana nonland permanents you control can produce

**Mana: , MV: 0, Colors: W, Popularity: 0**

**Steps:**

Cast Stonecloaker.
Paradox engine triggers untapping all our non-lands.
On resolution, Stonecloaker's ETB effects trigger, to preserve your own graveyard stack them as bounce, then exile, but to just exile all yards, order doesn't matter.
Tap all non-land mana sources for mana.
Responding to the exile trigger by casting Stonecloaker again allows you to repeat this process ad nauseum while only selecting a finite number of targets before letting the exile effects resolve.

---

# 43-5261

**Cards:**

- Paradox Engine
- Isochron Scepter

**Produces:** Infinite copies of cards exiled with Isochron Scepter, Infinite magecraft triggers, Infinite mana nonland permanents you control can produce, Infinite storm count, Infinite untap of nonland permanents you control

**Mana: , MV: 0, Colors: C, Popularity: 0**

**Steps:**

Activate all mana-producing nonland permanents you control by tapping them, adding at least {2}.
Activate Isochron Scepter by paying {2} and tapping it, causing you to cast a copy of the exiled instant.
Paradox Engine triggers, untapping all nonland permanents you control.
Resolve the copy of the instant.
Repeat.
If nonland permanents you control can tap to produce at least {3}, this combo nets infinite mana.

---

# 4377-4560

**Cards:**

- Soulfire Grand Master
- Walk the Aeons

**Produces:** Infinite turns, Lock

**Mana: {U/R} each turn, MV: 1, Colors: URW, Popularity: 76**

**Steps:**

Pay {2}{U/R} {U/R} to activate Soulfire Grand Master's ability.
Pay {4}{U}{U} to cast Walk the Aeons.
Soulfire Grand Master's ability triggers, returning Walk the Aeons to your hand.
Pass to extra turn.
Repeat for infinite turns.

---

# 4377-5021-5261

**Cards:**

- Isochron Scepter
- Noxious Revival
- Walk the Aeons

**Produces:** Infinite turns, Lock

**Mana: {6}{U}{U} each turn, MV: 8, Colors: GU, Popularity: 65**

**Steps:**

Cast Walk the Aeons by paying {4}{U}{U}, taking an extra turn after this one.
Activate Isochron Scepter by paying {2}, casting a copy of Noxious Revival without paying its mana cost.
Resolve the Noxious Revival, returning Walk the Aeons from your graveyard to your hand.
Move to your next turn.
Repeat.

---

# 439-2034-4215

**Cards:**

- Verdant Succession
- Arashin Sovereign
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: GW, Popularity: 12**

**Steps:**

Activate Ashnod's Altar by sacrificing Arashin Sovereign, adding {C}{C}.
Arashin Sovereign dies, triggering itself and Verdant Succession.
Resolve the Arashin Sovereign trigger, putting it on top of your library.
Resolve the Verdant Succession trigger, searching your library for Arashin Sovereign, putting it onto the battlefield and shuffling your library.
Repeat.

---

# 439-4050-4215

**Cards:**

- Verdant Succession
- Arashin Sovereign
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: GW, Popularity: 3**

**Steps:**

Activate Phyrexian Altar by sacrificing Arashin Sovereign, adding one mana of any color.
Arashin Sovereign dies, triggering itself and Verdant Succession.
Resolve the Arashin Sovereign trigger, putting it on top of your library.
Resolve the Verdant Succession trigger, searching your library for Arashin Sovereign, putting it onto the battlefield and shuffling your library.
Repeat.

---

# 439-4215-5256

**Cards:**

- Verdant Succession
- Arashin Sovereign
- Altar of Dementia

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: GW, Popularity: 10**

**Steps:**

Activate Altar of Dementia by sacrificing Arashin Sovereign.
Arashin Sovereign dies, triggering itself and Verdant Succession.
Resolve the Arashin Sovereign trigger, putting it on top of your library.
Resolve the Verdant Succession trigger, searching your library for Arashin Sovereign, putting it onto the battlefield and shuffling your library.
Resolve the Altar of Dementia ability, causing target player to mill cards equal to Arashin Sovereign's power.
Repeat.

---

# 4398-4469

**Cards:**

- Eye of the Storm
- Lavinia, Azorius Renegade

**Produces:** Opponents can't cast instants or sorceries, Lock

**Mana: , MV: 0, Colors: WU, Popularity: 370**

**Steps:**

Any time your opponent cast an instant or sorcery it gets exiled with Eye of the Storm.
Lavinia, Azorious Renegade prevents them from casting them from exile.

---

# 4413-4812

**Cards:**

- Kederekt Leviathan
- Animate Dead

**Produces:** Return all nonland permanents to owner's hand each turn, Lock

**Mana: {1}{B}, MV: 2, Colors: UB, Popularity: 1744**

**Steps:**

Cast Animate Dead by paying {1}{B}.
Animate Dead enters the battlefield, returning Kederekt Leviathan from your graveyard to the battlefield attached with Animate Dead.
Kederekt Leviathan triggers, returning all nonland permanents to their owner's hands.
Animate Dead triggers, causing you to sacrifice Kederekt Leviathan.
Repeat each turn.

---

# 4419-4929-5189

**Cards:**

- Ghave, Guru of Spores
- Cryptic Trilobite
- Renata, Called to the Hunt

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: WBG, Popularity: 553**

**Steps:**

Activate Cryptic Trilobite's first ability by removing two +1/+1 counters from it, adding {C}{C}{C}{C}.
Activate Ghave's first ability by paying {1} and removing a +1/+1 counter from Cryptic Trilobite, creating a 1/1 Saproling creature token that enters with a +1/+1 counter on it.
Activate Ghave's first ability by paying {1} and removing a +1/+1 counter from a Saproling, creating a 1/1 Saproling creature token that enters with a +1/+1 counter on it.
Activate Ghave's second ability by paying {1} and sacrificing a Saproling token with no counters on it, putting a +1/+1 counter on Cryptic Trilobite.
Activate Cryptic Trilobite's first ability by removing a +1/+1 counter from it, adding {C}{C}.
Repeat from step 3.

---

# 444-2275

**Cards:**

- Drogskol Reaver
- Shabraz, the Skyshark

**Produces:** Infinite card draw, Infinite draw triggers, Near-infinite +1/+1 counters on a creature, Near-infinite lifegain, Near-infinite lifegain triggers

**Mana: , MV: 0, Colors: WU, Popularity: 5785**

**Steps:**

Draw a card.
Shabraz triggers, putting a +1/+1 counter on itself and causing you to gain 1 life.
Drogskol Reaver triggers, causing you to draw a card.
Repeat from step 2 until your library is empty.
In response to the final Shabraz trigger, remove a combo piece or win the game to avoid losing by drawing from an empty library.

---

# 444-3965

**Cards:**

- Drogskol Reaver
- Curse of Fool's Wisdom

**Produces:** Infinite card draw, Infinite draw triggers, Near-infinite lifegain triggers

**Mana: , MV: 0, Colors: WUB, Popularity: 77**

**Steps:**

Draw a card.
Curse of Fool's Wisdom triggers, causing you to lose 2 life and gain 2 life.
Drogskol Reaver triggers, causing you to draw a card.
Repeat from step 2 until your library is empty.
Respond to the final Curse of Fool's Widsom trigger by removing a combo piece or winning the game to avoid losing due to drawing from an empty library.

---

# 4449-4474-4893

**Cards:**

- Hateflayer
- Training Grounds
- Paradise Mantle

**Produces:** Infinite damage

**Mana: , MV: 0, Colors: UR, Popularity: 19**

**Steps:**

Activate Hateflayer by tapping it, adding {R}.
Activate Hateflayer by paying {R} and untapping it, causing it to deal damage equal to its power to any target.
Repeat.

---

# 445-2836-3304

**Cards:**

- Ominous Seas
- Greater Good
- Laboratory Maniac

**Produces:** Win the game

**Mana: , MV: 0, Colors: GU, Popularity: 196**

**Steps:**

Activate Ominous Seas by removing eight foreshadow counters from it, creating a 8/8 Kraken creature token.
Activate Greater Good by sacrificing the Kraken token, drawing eight cards and discarding three cards.
Ominous Seas triggers eight times, putting eight foreshadow counters on itself.
Repeat until you draw from an empty library, winning the game.

---

# 445-3096-3304

**Cards:**

- Ominous Seas
- Greater Good
- Jace, Wielder of Mysteries

**Produces:** Win the game

**Mana: , MV: 0, Colors: GU, Popularity: 144**

**Steps:**

Activate Ominous Seas by removing eight foreshadow counters from it, creating a 8/8 Kraken creature token.
Activate Greater Good by sacrificing the Kraken token, drawing eight cards and discarding three cards.
Ominous Seas triggers eight times, putting eight foreshadow counters on itself.
Repeat until you draw from an empty library, winning the game.

---

# 4468-4992

**Cards:**

- Mystic Decree
- Stormtide Leviathan

**Produces:** Creatures can't attack, Lock

**Mana: , MV: 0, Colors: U, Popularity: 60**

**Steps:**

Mystic Decree causes all creatures to lose flying and islandwalk.
Because Stormtide Leviathan prohibits creatures without flying or islandwalk from attacking, no creatures can attack.

---

# 447-2882-4675-4694

**Cards:**

- Cavalier of Dawn
- Infinite Reflection
- March of the Machines
- Gustha's Scepter

**Produces:** Infinite creature tokens, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: , MV: 0, Colors: WU, Popularity: 0**

**Steps:**

Cast Gustha's Scepter by paying {0}.
Gustha's Scepter enters the battlefield as a copy of Cavalier of Dawn.
Copy of Cavalier of Dawn enter-the-battlefield ability triggers, destroying itself and creating you a 3/3 Golem token.
Copy of Cavalier of Dawn dies, triggering itself, returning Gustha's Scepter from your graveyard to your hand.
Repeat.

---

# 4475-4843

**Cards:**

- Virtus the Veiled
- Wound Reflection

**Produces:** Target opponent loses the game

**Mana: , MV: 0, Colors: B, Popularity: 2449**

**Steps:**

Attack the opponent with Virtus.
At end of turn, Reflection triggers.

---

# 448-4242-5003

**Cards:**

- Nim Deathmantle
- Su-Chi
- Jinxed Idol

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: C, Popularity: 0**

**Steps:**

Activate Jinxed Idol by sacrificing Su-Chi.
Su-Chi and Nim Deathmantle triggers.
Resolve the Su-Chi trigger, adding {C}{C}{C}{C}.
Resolve the Nim Deathmantle trigger, causing you to pay {4} to return Su-Chi from your graveyard to the battlefield, and then attach Nim Deathmantle to it.
Holding priority, repeat.

---

# 449-2024-5168

**Cards:**

- Seedcradle Witch
- Bloom Tender
- Prismatic Lace

**Produces:** Infinite black mana, Infinite blue mana, Infinitely large creature until end of turn, Infinite red mana, Infinite mana of colors among permanents you control

**Mana: {U}, MV: 1, Colors: GWU, Popularity: 0**

**Steps:**

Cast Prismatic Lace for {U}, making a permanent you control all colors.
Activate Bloom Tender by tapping it, adding {W}{U}{B}{R}{G}.
Activate Seedcradle Witch by paying {2}{W}{G}, giving Bloom Tender +3/+3 until end of turn and untapping it.
Repeat from step 2.

---

# 449-570-2024

**Cards:**

- Seedcradle Witch
- Faeburrow Elder
- Prismatic Lace

**Produces:** Infinite black mana, Infinite blue mana, Infinitely large creature until end of turn, Infinite red mana, Infinite mana of colors among permanents you control

**Mana: {U}, MV: 1, Colors: GWU, Popularity: 0**

**Steps:**

Cast Prismatic Lace for {U}, making a permanent you control all colors.
Activate Faeburrow Elder by tapping it, adding {W}{U}{B}{R}{G}.
Activate Seedcradle Witch by paying {2}{W}{G}, giving Faeburrow Elder +3/+3 until end of turn and untapping it.
Repeat from step 2.

---

# 45-1309-1518-1987

**Cards:**

- Ghostly Flicker
- Will Kenrith
- Salvager of Secrets
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: U, Popularity: 5**

**Steps:**

Activate Will Kenrith's -2 ability targeting yourself, reducing the cost of your instant, sorcery, and planeswalker spells by {2} until end of turn and drawing you 2 cards.
Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Salvager of Secrets, blinking them.
When Salvager of Secrets enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-1309-1987-2427

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Salvager of Secrets
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: U, Popularity: 4**

**Steps:**

Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Salvager of Secrets, blinking them.
When Salvager of Secrets enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-1309-1987-2510

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Salvager of Secrets
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: U, Popularity: 6**

**Steps:**

Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Salvager of Secrets, blinking them.
When Salvager of Secrets enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-1309-1987-3075

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Salvager of Secrets
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: UR, Popularity: 5**

**Steps:**

Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Salvager of Secrets, blinking them.
When Salvager of Secrets enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-1518-1987-2493

**Cards:**

- Ghostly Flicker
- Will Kenrith
- Archaeomancer
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: U, Popularity: 10**

**Steps:**

Activate Will Kenrith's -2 ability targeting yourself, reducing the cost of your instant, sorcery, and planeswalker spells by {2} until end of turn and drawing you 2 cards.
Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Archaeomancer, blinking them.
When Archaeomancer enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-1518-1987-2556

**Cards:**

- Ghostly Flicker
- Will Kenrith
- Mnemonic Wall
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: U, Popularity: 6**

**Steps:**

Activate Will Kenrith's -2 ability targeting yourself, reducing the cost of your instant, sorcery, and planeswalker spells by {2} until end of turn and drawing you 2 cards.
Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Mnemonic Wall, blinking them.
When Mnemonic Wall enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-1518-1987-3227

**Cards:**

- Ghostly Flicker
- Will Kenrith
- Scrivener
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: U, Popularity: 4**

**Steps:**

Activate Will Kenrith's -2 ability targeting yourself, reducing the cost of your instant, sorcery, and planeswalker spells by {2} until end of turn and drawing you 2 cards.
Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Scrivener, blinking them.
When Scrivener enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-1518-1987-3277

**Cards:**

- Ghostly Flicker
- Will Kenrith
- Izzet Chronarch
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: UR, Popularity: 2**

**Steps:**

Activate Will Kenrith's -2 ability targeting yourself, reducing the cost of your instant, sorcery, and planeswalker spells by {2} until end of turn and drawing you 2 cards.
Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Izzet Chronarch, blinking them.
When Izzet Chronarch enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-1518-1987-4125

**Cards:**

- Ghostly Flicker
- Will Kenrith
- Shipwreck Dowser
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: U, Popularity: 6**

**Steps:**

Activate Will Kenrith's -2 ability targeting yourself, reducing the cost of your instant, sorcery, and planeswalker spells until end of turn.
Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Shipwreck Dowser, blinking them.
When Shipwreck Dowser enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-1987-2427-2493

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Archaeomancer
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: U, Popularity: 5**

**Steps:**

Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Archaeomancer, blinking them.
When Archaeomancer enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-1987-2427-2556

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Mnemonic Wall
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: U, Popularity: 2**

**Steps:**

Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Mnemonic Wall, blinking them.
When Mnemonic Wall enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-1987-2427-3227

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Scrivener
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: U, Popularity: 3**

**Steps:**

Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Scrivener, blinking them.
When Scrivener enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-1987-2427-3277

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Izzet Chronarch
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: UR, Popularity: 1**

**Steps:**

Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Izzet Chronarch, blinking them.
When Izzet Chronarch enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-1987-2427-4125

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Shipwreck Dowser
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: U, Popularity: 4**

**Steps:**

Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Shipwreck Dowser, blinking them.
When Shipwreck Dowser enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-1987-2493-2510

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Archaeomancer
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: U, Popularity: 8**

**Steps:**

Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Archaeomancer, blinking them.
When Archaeomancer enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-1987-2493-3075

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Archaeomancer
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: UR, Popularity: 5**

**Steps:**

Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Archaeomancer, blinking them.
When Archaeomancer enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-1987-2510-2556

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Mnemonic Wall
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: U, Popularity: 5**

**Steps:**

Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Mnemonic Wall, blinking them.
When Mnemonic Wall enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-1987-2510-3227

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Scrivener
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: U, Popularity: 3**

**Steps:**

Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Scrivener, blinking them.
When Scrivener enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-1987-2510-3277

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Izzet Chronarch
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: UR, Popularity: 1**

**Steps:**

Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Izzet Chronarch, blinking them.
When Izzet Chronarch enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-1987-2510-4125

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Shipwreck Dowser
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: U, Popularity: 6**

**Steps:**

Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Shipwreck Dowser, blinking them.
When Shipwreck Dowser enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-1987-2556-3075

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Mnemonic Wall
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: UR, Popularity: 2**

**Steps:**

Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Mnemonic Wall, blinking them.
When Mnemonic Wall enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-1987-3075-3227

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Scrivener
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: UR, Popularity: 2**

**Steps:**

Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Scrivener, blinking them.
When Scrivener enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-1987-3075-3277

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Izzet Chronarch
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: UR, Popularity: 3**

**Steps:**

Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Izzet Chronarch, blinking them.
When Izzet Chronarch enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-1987-3075-4125

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Shipwreck Dowser
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: UR, Popularity: 4**

**Steps:**

Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Shipwreck Dowser, blinking them.
When Shipwreck Dowser enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 4535-4929-5189

**Cards:**

- Ghave, Guru of Spores
- Cryptic Trilobite
- Good-Fortune Unicorn

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: WBG, Popularity: 1760**

**Steps:**

Activate Cryptic Trilobite's first ability by removing two +1/+1 counters from it, adding {C}{C}{C}{C}.
Activate Ghave's first ability by paying {1} and removing a +1/+1 counter from Cryptic Trilobite, creating a 1/1 Saproling creature token.
The Saproling enters the battlefield, triggering Good-Fortune Unicorn, putting a +1/+1 counter on the Saproling.
Activate Ghave's first ability by paying {1} and removing a +1/+1 counter from a Saproling, creating a 1/1 Saproling creature token.
The Saproling enters the battlefield, triggering Good-Fortune Unicorn, putting a +1/+1 counter on the Saproling.
Activate Ghave's second ability by paying {1} and sacrificing a Saproling token with no counters on it, putting a +1/+1 counter on Cryptic Trilobite.
Activate Cryptic Trilobite's first ability by removing a +1/+1 counter from it, adding {C}{C}.
Repeat from step 4.

---

# 45-364-1309-1987

**Cards:**

- Ghostly Flicker
- Arcane Melee
- Salvager of Secrets
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: U, Popularity: 9**

**Steps:**

Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Salvager of Secrets, blinking them.
When Salvager of Secrets enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-364-1987-2493

**Cards:**

- Ghostly Flicker
- Arcane Melee
- Archaeomancer
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: U, Popularity: 17**

**Steps:**

Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Archaeomancer, blinking them.
When Archaeomancer enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-364-1987-2556

**Cards:**

- Ghostly Flicker
- Arcane Melee
- Mnemonic Wall
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: U, Popularity: 10**

**Steps:**

Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Mnemonic Wall, blinking them.
When Mnemonic Wall enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-364-1987-3227

**Cards:**

- Ghostly Flicker
- Arcane Melee
- Scrivener
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: U, Popularity: 5**

**Steps:**

Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Scrivener, blinking them.
When Scrivener enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-364-1987-3277

**Cards:**

- Ghostly Flicker
- Arcane Melee
- Izzet Chronarch
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: UR, Popularity: 4**

**Steps:**

Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Izzet Chronarch, blinking them.
When Izzet Chronarch enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-364-1987-4125

**Cards:**

- Ghostly Flicker
- Arcane Melee
- Shipwreck Dowser
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: U, Popularity: 8**

**Steps:**

Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Shipwreck Dowser, blinking them.
When Shipwreck Dowser enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-364-614-1987

**Cards:**

- Ghostly Flicker
- Arcane Melee
- Nucklavee
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: UR, Popularity: 3**

**Steps:**

Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-364-813-1987

**Cards:**

- Ghostly Flicker
- Arcane Melee
- Scholar of the Ages
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 11**

**Steps:**

Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 4560-4872

**Cards:**

- Soulfire Grand Master
- Time Warp

**Produces:** Infinite turns, Lock

**Mana: {U/R} each turn, MV: 1, Colors: URW, Popularity: 452**

**Steps:**

Pay {2}{U/R} {U/R} to activate Soulfire Grand Master's ability.
Pay {3}{U}{U} to cast Time Warp.
Soulfire Grand Master's ability triggers, returning Time Warp to your hand.
Pass to extra turn.

---

# 45-614-1518-1987

**Cards:**

- Ghostly Flicker
- Will Kenrith
- Nucklavee
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: UR, Popularity: 1**

**Steps:**

Activate Will Kenrith's -2 ability targeting yourself, reducing the cost of your instant, sorcery, and planeswalker spells by {2} until end of turn and drawing you 2 cards.
Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-614-1987-2427

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Nucklavee
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: UR, Popularity: 0**

**Steps:**

Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-614-1987-2510

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Nucklavee
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: UR, Popularity: 2**

**Steps:**

Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-614-1987-3075

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Nucklavee
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand

**Mana: , MV: 0, Colors: UR, Popularity: 2**

**Steps:**

Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 457-2034-5003

**Cards:**

- Nim Deathmantle
- Ashnod's Altar
- Urza, Lord High Artificer

**Produces:** Infinite blue mana, Infinite colorless mana, Infinite creature tokens, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Exile your library, Cast all spells in your library, Infinite creature tokens that are infinitely large

**Mana: {2}, MV: 2, Colors: U, Popularity: 3845**

**Steps:**

Activate Ashnod's Altar by sacrificing Urza, adding {C}{C}.
When Urza dies, Nim Deathmantle triggers, causing you to pay {4} to return Urza from your graveyard to the battlefield and attach Nim Deathmantle to it.
When Urza enters, it triggers, creating a creature token.
Activate Ashnod's Altar by sacrificing a creature token, adding {C}{C}.
Repeat.

---

# 457-2558-4139

**Cards:**

- Urza, Lord High Artificer
- Thopter Foundry
- Sword of the Meek

**Produces:** Cast all spells in your library, Infinite blue mana, Infinite creature tokens, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Exile your library

**Mana: , MV: 0, Colors: WUB, Popularity: 6128**

**Steps:**

Activate Urza's first ability by tapping Sword of the Meek, adding {U}.
Activate Thopter Foundry by paying {1} and sacrificing Sword of the Meek, creating a 1/1 Thopter creature token with flying and causing you to gain 1 life.
The Thopter enters the battlefield, triggering Sword of the Meek, causing you to return Sword of the Meek from your graveyard to the battlefield attached to the Thopter.
Repeat.
Once you have an infinite amount of Thopter tokens, you may tap them using Urza's first ability to get infinite {U}, and then use the mana to activate Urza's second ability infinite times.

---

# 45-813-1518-1987

**Cards:**

- Ghostly Flicker
- Will Kenrith
- Scholar of the Ages
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 8**

**Steps:**

Activate Will Kenrith's -2 ability targeting yourself, reducing the cost of your instant, sorcery, and planeswalker spells by {2} until end of turn and drawing you 2 cards.
Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-813-1987-2427

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Scholar of the Ages
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 2**

**Steps:**

Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-813-1987-2510

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Scholar of the Ages
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 5**

**Steps:**

Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 45-813-1987-3075

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Scholar of the Ages
- Khalni Gem

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all lands you control to your hand, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: UR, Popularity: 2**

**Steps:**

Activate Khalni Gem by tapping it, adding {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Khalni Gem and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Khalni Gem enters the battlefield, return two lands you control to your hand if able.
Repeat.

---

# 4620-4702

**Cards:**

- Captain of the Mists
- Splinter Twin

**Produces:** Infinite creature tokens with haste, Infinite ETB

**Mana: , MV: 0, Colors: UR, Popularity: 33**

**Steps:**

Activate Splinter twins ability, creating a copy of Captain.
Captain then triggers untapping.
Repeat.

---

# 4621-4821

**Cards:**

- Izzet Guildmage
- Dramatic Reversal

**Produces:** Infinite colored mana

**Mana: {3}{U}{U}, MV: 5, Colors: UR, Popularity: 230**

**Steps:**

Cast Dramatic Reversal by paying {1}{U}.
Holding priority, activate Izzet Guildmage's first ability by paying {2}{U}, copying Dramatic Reversal.
Resolve the Dramatic Reversal copy, untapping all nonland permanents you control.
Activate all nonland permanents by tapping those, adding at least {3}{U}.
Repeat from step 2.

---

# 462-3587

**Cards:**

- Boros Reckoner
- Break of Day

**Produces:** Infinite lifegain, Infinite lifegain triggers

**Mana: {1}{W}, MV: 2, Colors: RW, Popularity: 23**

**Steps:**

Give Boros Reckoner lifelink.
Cast Break of Day by paying {1}{W}, giving creatures you control indestructible and +1/+1 until end of turn.
Deal damage to Boros Reckoner.
Boros Reckoner triggers, dealing that much damage to itself and causing you to gain that much life.
Repeat step 4 any number of times.

---

# 4644-4684

**Cards:**

- Mesmeric Orb
- Tidewater Minion

**Produces:** Infinite self-mill

**Mana: , MV: 0, Colors: U, Popularity: 66**

**Steps:**

Activate Tidewater Minion's last ability by tapping it, untapping itself.
When Tidewater Minion becomes untapped, Mesmeric Orb triggers, causing you to mill a card.
Repeat.

---

# 464-5080

**Cards:**

- Maddening Cacophony
- Fraying Sanity

**Produces:** Infinite mill for target opponent, Near-infinite mill

**Mana: {4}{U}{U}, MV: 6, Colors: U, Popularity: 24969**

**Steps:**

Cast Maddening Cacophony with kicker by paying {4}{U}{U}, causing each opponent to mill cards equal to half their library size, rounded up.
At the beginning of your end step, Fraying Sanity triggers, causing the opponent enchanted by Fraying Sanity to mill cards equal to the number of cards put into their graveyard this turn.

---

# 464-781

**Cards:**

- Traumatize
- Fraying Sanity

**Produces:** Infinite mill for target opponent

**Mana: {3}{U}{U}, MV: 5, Colors: U, Popularity: 17472**

**Steps:**

Cast Traumatize by paying {3}{U}{U}, causing the opponent enchanted by Fraying Sanity to mill cards equal to half their library size, rounded down.
At the beginning of your end step, Fraying Sanity triggers, causing the opponent to mill cards equal to the number of cards put into their graveyard this turn.

---

# 4659-4702-4853

**Cards:**

- Splinter Twin
- Dross Scorpion
- Krark-Clan Ironworks

**Produces:** Infinite colorless mana, Infinite creature tokens with haste, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: R, Popularity: 25**

**Steps:**

Activate Dross Scorpion by tapping it, creating a copy of it with haste.
Activate Krark-Clan Ironworks by sacrificing the Dross Scorpion copy, adding {C}{C}.
The Dross Scorpion copy dies, triggering itself and every Dross Scorpion on the battlefield.
Resolve the first Dross Scorpion trigger, untapping the Dross Scorpion enchanted by Splinter Twin.
Activate the Dross Scorpion enchanted by Splinter Twin by tapping it, creating a copy of it with haste.
Repeat steps 4-5 for each remaining trigger.
Repeat from step 2.

---

# 4659-4840-5003

**Cards:**

- Nim Deathmantle
- Krark-Clan Ironworks
- Myr Battlesphere

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: {2}, MV: 2, Colors: C, Popularity: 3228**

**Steps:**

Activate Krark-Clan Ironworks by sacrificing Myr Battlesphere, adding {C}{C}.
When Myr Battlesphere dies, Nim Deathmantle triggers, causing you to pay {4} to return Myr Battlesphere from your graveyard to the battlefield and attach Nim Deathmantle to it.
When Myr Battlesphere enters, it triggers, creating four artifact creature tokens.
Activate Krark-Clan Ironworks by sacrificing a creature token, adding {C}{C}.
Repeat.

---

# 4694-4740

**Cards:**

- Aetherflux Reservoir
- March of the Machines

**Produces:** Infinite damage, Infinite lifegain triggers

**Mana: , MV: 0, Colors: U, Popularity: 351**

**Steps:**

Give Aetherflux Reservoir lifelink, if needed.
Activate Aetherflux Reservoir by paying 50 life, dealing 50 damage to any target and causing you to gain 50 life.
Repeat step 2.

---

# 4694-5107-5261

**Cards:**

- Isochron Scepter
- Rally of Wings
- March of the Machines

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: , MV: 0, Colors: WU, Popularity: 2**

**Steps:**

Activate creatures you control by tapping those, adding {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Rally of Wings without paying its mana cost, untapping all creatures.
Repeat

---

# 473-4067

**Cards:**

- Mind Over Matter
- Archivist

**Produces:** Infinite self-discard triggers, Infinite draw triggers, Infinite looting

**Mana: , MV: 0, Colors: U, Popularity: 226**

**Steps:**

Activate Archivist by tapping it, causing you to draw a card.
Activate Mind Over Matter by discarding a card, untapping Archivist.
Repeat.

---

# 4740-5089

**Cards:**

- Karn, the Great Creator
- Aetherflux Reservoir

**Produces:** Infinite damage, Infinite lifegain triggers

**Mana: , MV: 0, Colors: C, Popularity: 8846**

**Steps:**

Activate Karn's first loyalty ability by putting a loyalty counter on it, causing Aetherflux Reservoir to become an artifact creature until end of turn.
Give Aetherflux Reservoir lifelink.
Activate Aetherflux Reservoir by paying 50 life, dealing 50 damage to any target and causing you to gain 50 life.
Repeat step 3.

---

# 4772-4929-5189

**Cards:**

- Ghave, Guru of Spores
- Doubling Season
- Cryptic Trilobite

**Produces:** Infinite colorless mana that can only be spent to activate abilities, Infinite creature tokens, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite +1/+1 counters on creatures you control

**Mana: {1}, MV: 1, Colors: WBG, Popularity: 1481**

**Steps:**

Activate Cryptic Trilobite's first ability by removing a +1/+1 counter from it, adding {C}{C}.
Activate Ghave's first ability by paying {1} and removing a +1/+1 counter from Cryptic Trilobite, creating two 1/1 Saproling creature tokens.
Activate Ghave's second ability by paying {1} and sacrificing a Saproling, putting two +1/+1 counters on Cryptic Trilobite.
Repeat.
Once you have infinite +1/+1 counters on Cryptic Trilobite, you may alter this loop to produce infinite creature tokens, put infinite +1/+1 counters on all your creatures, and activate Cryptic Trilobite infinite times.

---

# 478-1846-3911-4235

**Cards:**

- Rings of Brighthearth
- Galvanic Key
- Candelabra of Tawnos
- High Tide

**Produces:** Infinite mana artifacts you control can produce, Infinite mana lands you control can produce, Infinite untap of artifacts you control, Infinite untap of lands you control

**Mana: {U}, MV: 1, Colors: U, Popularity: 0**

**Steps:**

Cast High Tide by paying {U}, causing all Islands to add an additional {U} when they are tapped for mana this turn.
Activate two Islands you control by tapping them, adding {U}{U}{U}{U}.
Activate Candelabra of Tawnos by paying {2} and tapping it.
Rings of Brighthearth triggers, causing you to pay {2} to copy Candelabra of Tawnos' ability.
Resolve the first Candelabra of Tawnos ability, untapping the two Islands.
Activate two Islands you control by tapping them, adding {U}{U}{U}{U}.
Resolve the second Candelabra of Tawnos ability, untapping the two Islands.
Activate Galvanic Key by paying {3} and tapping it.
Rings of Brighthearth triggers, causing you to pay {2} to copy Galvanic Key's ability.
Resolve both Galvanic Key abilities, untapping Galvanic Key and Candelabra of Tawnos.
Repeat from step 2.

---

# 478-617-1846-4235

**Cards:**

- Rings of Brighthearth
- Voltaic Key
- Candelabra of Tawnos
- High Tide

**Produces:** Infinite mana artifacts you control can produce, Infinite mana lands you control can produce, Infinite untap of artifacts you control, Infinite untap of lands you control

**Mana: {U}, MV: 1, Colors: U, Popularity: 19**

**Steps:**

Cast High Tide by paying {U}, causing all Islands to add an additional {U} when they are tapped for mana this turn.
Activate two Islands you control by tapping them, adding {U}{U}{U}{U}.
Activate Candelabra of Tawnos by paying {2} and tapping it.
Rings of Brighthearth triggers, causing you to pay {2} to copy Candelabra of Tawnos' ability.
Resolve the first Candelabra of Tawnos ability, untapping the two Islands.
Activate two Islands you control by tapping them, adding {U}{U}{U}{U}.
Resolve the second Candelabra of Tawnos ability, untapping the two Islands.
Activate Voltaic Key by paying {1} and tapping it.
Rings of Brighthearth triggers, causing you to pay {2} to copy Voltaic Key's ability.
Resolve both Voltaic Key abilities, untapping Voltaic Key and Candelabra of Tawnos.
Repeat from step 2.

---

# 4812-4846

**Cards:**

- Animate Dead
- Worldgorger Dragon

**Produces:** Infinite colored mana, Infinite colorless mana, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: {1}{B}, MV: 2, Colors: BR, Popularity: 14336**

**Steps:**

Cast Animate Dead by paying {1}{B}.
Animate Dead enters the battlefield, returning Worldgorger Dragon from your graveyard to the battlefield attached with Animate Dead.
Worldgorger Dragon enters the battlefield, exiling all other permanents you control.
Animate Dead triggers, sacrificing Worldgorger Dragon.
Worldgorger Dragon leaves the battlefield, returning all permanents exiled by it to the battlefield.
Animate Dead enters the battlefield, returning Worldgorger Dragon from your graveyard to the battlefield attached with Animate Dead.
Holding priority, activate all lands you control by tapping those, adding manas of any colors those lands can produce.
Repeat.

---

# 4812-5276

**Cards:**

- Leonin Relic-Warder
- Animate Dead

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: {1}{B}, MV: 2, Colors: WB, Popularity: 8494**

**Steps:**

Cast Animate Dead by paying {1}{B}, returning Leonin Relic-Warder from your graveyard to the battlefield, and attaching Animate Dead to it.
Leonin Relic-Warder enters the battlefield, exiling Animate Dead.
Animate Dead leaves the battlefield, causing you to sacrifice Leonin Relic-Warder.
Leonin Relic-Warder leaves the battlefield, returning Animate Dead from exile to the battlefield.
Animate Dead enters the battlefield, returning Leonin Relic-Warder from your graveyard to the battlefield, and attaching Animate Dead to it.
Repeat from step 3.

---

# 4821-5054

**Cards:**

- League Guildmage
- Dramatic Reversal

**Produces:** Infinite colored mana

**Mana: {3}{U}{R}, MV: 5, Colors: UR, Popularity: 243**

**Steps:**

Pay {1} {U} to cast Dramatic Reversal.
Pay {2}{R} to activate League Guildmage to make a copy of Dramatic Reversal.
Untap all of your nonland permanents.
Tap your nonland permanents to produce {3}{R}.

---

# 4821-5261

**Cards:**

- Dramatic Reversal
- Isochron Scepter

**Produces:** Infinite magecraft triggers, Infinite mana nonland permanents you control can produce, Infinite storm count, Infinite untap of nonland permanents you control

**Mana: , MV: 0, Colors: U, Popularity: 95526**

**Steps:**

Activate all mana-producing nonland permanents you control by tapping them, adding at least {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Dramatic Reversal without paying it's mana cost.
Resolve Dramatic Reversal, untapping all nonland permanents you control.
Repeat.

---

# 483-1580-2034-2530

**Cards:**

- Cruel Celebrant
- Reassembling Skeleton
- Carnival of Souls
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite lifegain triggers, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers

**Mana: {B}, MV: 1, Colors: WB, Popularity: 128**

**Steps:**

Activate Ashnod's Altar by sacrificing Reassembling Skeleton, adding {C}{C}.
Reassembling Skeleton dies, triggering Cruel Celebrant, causing each opponent to lose 1 life and gaining you 1 life.
Cast Reassembling Skeleton from your graveyard by paying {1}{B}.
Reassembling Skeleton enters the battlefield triggering Carnival of Souls, causing you to lose 1 life and adding {B}.
Repeat.

---

# 483-1580-2530-4050

**Cards:**

- Cruel Celebrant
- Reassembling Skeleton
- Carnival of Souls
- Phyrexian Altar

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifegain triggers, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers

**Mana: {1}, MV: 1, Colors: WB, Popularity: 128**

**Steps:**

Activate Ashnod's Altar by sacrificing Reassembling Skeleton, adding one mana of any color.
Reassembling Skeleton dies, triggering Cruel Celebrant, causing each opponent to lose 1 life and gaining you 1 life.
Cast Reassembling Skeleton from your graveyard by paying {1}{B}.
Reassembling Skeleton enters the battlefield triggering Carnival of Souls, causing you to lose 1 life and adding {B}.
Repeat.

---

# 483-2018-4050-5197

**Cards:**

- Luminous Broodmoth
- Cruel Celebrant
- Downdraft
- Phyrexian Altar

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers

**Mana: {G}, MV: 1, Colors: WBG, Popularity: 0**

**Steps:**

Activate Downdraft by paying {G}, causing Luminous Broodmoth to lose flying until end of turn.
Activate Phyrexian Altar by sacrificing Luminous Broodmoth, adding {G}.
Cruel Celebrant triggers, causing each opponent to lose 1 life and causing you to gain 1 life.
Luminous Broodmoth triggers, returning itself from your graveyard to the battlefield with a flying counter on it.
Repeat.

---

# 4832-5107-5261

**Cards:**

- Isochron Scepter
- Rally of Wings
- Ensoul Artifact

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: , MV: 0, Colors: WU, Popularity: 2**

**Steps:**

Activate creatures you control by tapping those, adding {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Rally of Wings without paying its mana cost, untapping all creatures.
Repeat

---

# 4872-5021-5261

**Cards:**

- Isochron Scepter
- Noxious Revival
- Time Warp

**Produces:** Infinite turns, Lock

**Mana: {5}{U}{U} each turn, MV: 7, Colors: GU, Popularity: 604**

**Steps:**

Cast Time Warp by paying {3}{U}{U}, taking an extra turn after this one.
Activate Isochron Scepter by paying {2}, casting a copy of Noxious Revival without paying its mana cost.
Resolve the Noxious Revival, returning Time Warp from your graveyard to your hand.
Move to your next turn.
Repeat.

---

# 4916-5107-5261

**Cards:**

- Isochron Scepter
- Rally of Wings
- Animate Artifact

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: , MV: 0, Colors: WU, Popularity: 0**

**Steps:**

Activate creatures you control by tapping those, adding {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Rally of Wings without paying its mana cost, untapping all creatures.
Repeat.

---

# 4929-5189-5319

**Cards:**

- Ghave, Guru of Spores
- Geralf's Messenger
- Cryptic Trilobite

**Produces:** Infinite colorless mana that can only be spent to activate abilities, Infinite creature tokens, Infinite ETB, Infinite lifeloss, Infinite LTB, Infinite +1/+1 counters on creatures you control

**Mana: {1}, MV: 1, Colors: WBG, Popularity: 817**

**Steps:**

Activate Ghave's second ability by paying {1} and sacrificing Geralf's Messenger.
Geralf's Messenger's undying ability triggers, returning Geralf's Messenger from your graveyard to the battlefield with a +1/+1 counter on it.
Geralf's Messenger enters the battlefield tapped, causing an opponent to lose 2 life.
Resolve the Ghave ability, putting a +1/+1 counter on Cryptic Trilobite.
Activate Cryptic Trilobite by removing a +1/+1 counter from it, adding {C}{C} that can only be spent to activate abilities.
Activate Ghave's first ability by paying {1} and removing a +1/+1 counter from Geralf's Messenger, creating a 1/1 Saproling creature token.
Repeat.

---

# 499-3179-3676-4518

**Cards:**

- Oketra's Monument
- Tangleroot
- Kor Skyfisher
- Farrelite Priest

**Produces:** Infinite creature tokens, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: {1}, MV: 1, Colors: GW, Popularity: 0**

**Steps:**

Cast Kor Skyfisher by paying {1}.
Oketra's Monument and Tangleroot triggers.
Resolve the Oketra's Monument trigger, creating a 1/1 Warrior token.
Resolve the Tangleroot trigger, adding {G}.
Kor Skyfisher enters the battlefield, returning it to your hand.
Activate Farrelite Priest by paying {G}, adding {W}.
Repeat.

---

# 499-3179-3676-4770

**Cards:**

- Oketra's Monument
- Tangleroot
- Whitemane Lion
- Farrelite Priest

**Produces:** Infinite creature tokens, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: {1}, MV: 1, Colors: GW, Popularity: 1**

**Steps:**

Cast Whitemane Lion by paying {1}.
Oketra's Monument and Tangleroot triggers.
Resolve the Oketra's Monument trigger, creating a 1/1 Warrior token.
Resolve the Tangleroot trigger, adding {G}.
Whitemane Lion enters the battlefield, returning it to your hand.
Activate Farrelite Priest by paying {G}, adding {W}.
Repeat.

---

# 503-1012-2908-3676

**Cards:**

- Kefnet's Monument
- Tangleroot
- Dream Stalker
- Vizier of the Menagerie

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count

**Mana: {1}, MV: 1, Colors: GU, Popularity: 1**

**Steps:**

Cast Dream Stalker by paying {1}.
Kefnet's Monument and Tangleroot triggers.
Resolve the Kefnet's Monument trigger, tapping target creature an opponent controls.
Resolve the Tangleroot trigger, adding {G}.
Dream Stalker enters the battlefield, returning it to your hand.
Repeat.

---

# 503-1283-2908-3676

**Cards:**

- Kefnet's Monument
- Tangleroot
- Dream Stalker
- Chromatic Orrery

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count

**Mana: {1}, MV: 1, Colors: GU, Popularity: 0**

**Steps:**

Cast Dream Stalker by paying {1}.
Kefnet's Monument and Tangleroot triggers.
Resolve the Kefnet's Monument trigger, tapping target creature an opponent controls.
Resolve the Tangleroot trigger, adding {G}.
Dream Stalker enters the battlefield, returning it to your hand.
Repeat.

---

# 503-1840-2908-3676

**Cards:**

- Kefnet's Monument
- Tangleroot
- Dream Stalker
- False Dawn

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count

**Mana: {2}{W}, MV: 3, Colors: GWU, Popularity: 0**

**Steps:**

Cast False Dawn by paying {1}{W}, drawing you a card.
Cast Dream Stalker by paying {W}.
Kefnet's Monument and Tangleroot triggers.
Resolve the Kefnet's Monument trigger, tapping target creature an opponent controls.
Resolve the Tangleroot trigger, adding {W}.
Dream Stalker enters the battlefield, returning it to your hand.
Repeat.

---

# 503-2908-3263-3676

**Cards:**

- Kefnet's Monument
- Tangleroot
- Dream Stalker
- Mycosynth Lattice

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count

**Mana: {1}, MV: 1, Colors: GU, Popularity: 1**

**Steps:**

Cast Dream Stalker by paying {1}.
Kefnet's Monument and Tangleroot triggers.
Resolve the Kefnet's Monument trigger, tapping target creature an opponent controls.
Resolve the Tangleroot trigger, adding {1}.
Dream Stalker enters the battlefield, returning it to your hand.
Repeat.

---

# 503-2908-3676-3917

**Cards:**

- Kefnet's Monument
- Tangleroot
- Dream Stalker
- Orochi Leafcaller

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count

**Mana: {1}, MV: 1, Colors: GU, Popularity: 0**

**Steps:**

Cast Dream Stalker by paying {1}.
Kefnet's Monument and Tangleroot triggers.
Resolve the Kefnet's Monument trigger, tapping target creature an opponent controls.
Resolve the Tangleroot trigger, adding {G}.
Dream Stalker enters the battlefield, returning it to your hand.
Activate Orochi Leafcaller by paying {G}, adding {U}.
Repeat.

---

# 507-3031

**Cards:**

- Possibility Storm
- Drannith Magistrate

**Produces:** Opponents can't cast spells, Lock

**Mana: , MV: 0, Colors: RW, Popularity: 1255**

**Steps:**

When an opponent casts a card from their hand, Possibility Storm will exile it.
They can not cast any cards from Possibility Storm because the exiled cards are not cast from their hand.

---

# 51-129-3525

**Cards:**

- Kinnan, Bonder Prodigy
- Lotus Guardian
- Pemmin's Aura

**Produces:** Infinite colored mana

**Mana: , MV: 0, Colors: GU, Popularity: 1**

**Steps:**

Activate Lotus Guardian by tapping it, adding two {U}{U}.
Activate Pemmin's Aura's first ability by paying {U}, untapping Lotus Guardian.
Repeat.
Once you have infinite blue mana, you may repeat for infinite colored mana.

---

# 51-129-4222

**Cards:**

- Kinnan, Bonder Prodigy
- Lotus Guardian
- Freed from the Real

**Produces:** Infinite colored mana

**Mana: , MV: 0, Colors: GU, Popularity: 1**

**Steps:**

Activate Lotus Guardian by tapping it, adding two {U}{U}.
Activate Freed from the Real's second ability by paying {U}, untapping Lotus Guardian.
Repeat.
Once you have infinite blue mana, you may repeat for infinite colored mana.

---

# 515-1636-2366

**Cards:**

- Squirrel Nest
- Intruder Alarm
- Dryad Arbor

**Produces:** Infinite creature tokens, Infinite ETB, Infinite mana creatures you control can produce, Infinite untap of creatures

**Mana: , MV: 0, Colors: GU, Popularity: 66**

**Steps:**

Activate Dryad Arbor's Squirrel Nest ability by tapping it, creating a 1/1 green Squirrel token.
Intruder Alarm triggers, untapping all creatures.
Repeat.

---

# 515-2757

**Cards:**

- Earthcraft
- Squirrel Nest

**Produces:** Infinite ETB, Infinite tapped creature tokens

**Mana: , MV: 0, Colors: G, Popularity: 6308**

**Steps:**

Activate the enchanted basic land by tapping it, creating a 1/1 green Squirrel creature token.
Activate Earthcraft by tapping an untapped creature you control, untapping the enchanted basic land.
Repeat.

---

# 518-1159-5109

**Cards:**

- Sustaining Spirit
- Arcbond
- Volcano Hellion

**Produces:** Infinite damage

**Mana: {4}{R}{R}{R}, MV: 7, Colors: RW, Popularity: 2**

**Steps:**

Cast Volcano Hellion by paying {2}{R}{R}.
Volcano Hellion enters the battlefield, triggering itself, targeting any creature.
In response, cast Arcbond by paying {2}{R}, targeting the same creature and creating a delayed triggered ability.
Resolve Volcano Hellion's trigger, dealing an arbitrarily large amount of damage to the targeted creature and to you, reducing your life total to 1 due to Sustaining Spirit.
Arcbond's delayed triggered ability triggers, dealing an equal amount of damage to all other creatures and all players, which again does not reduce your life total below 1.

---

# 518-1341-5109

**Cards:**

- Serra the Benevolent
- Arcbond
- Volcano Hellion

**Produces:** Infinite damage

**Mana: {4}{R}{R}{R}, MV: 7, Colors: RW, Popularity: 3**

**Steps:**

Cast Volcano Hellion by paying {2}{R}{R}.
Volcano Hellion enters the battlefield, triggering itself, targeting any other creature.
In response, cast Arcbond by paying {2}{R}, targeting the same creature and creating a delayed triggered ability.
Resolve Volcano Hellion's trigger, dealing an arbitrarily large amount of damage to the targeted creature and to you, reducing your life total to 1 due to Serra the Benevolent's emblem.
Arcbond's delayed triggered ability triggers, dealing an equal amount of damage to all other creatures and all players, which again does not reduce your life total below 1.

---

# 518-1691-1811-3733

**Cards:**

- Zada, Hedron Grinder
- Jeskai Charm
- Ephemeral Shields
- Arcbond

**Produces:** Each opponent loses the game, Infinite damage, Infinite lifegain, Infinite lifegain triggers

**Mana: {3}{U}{R}{R}{W}{W}, MV: 8, Colors: URW, Popularity: 1**

**Steps:**

Cast Ephemeral Shields by paying {1}{W}, targeting Zada.
Zada triggers, creating a copy of Ephemeral Shields for each creature you control.
Resolve all Ephemeral Shields, giving all creatures you control indestructible until end of turn.
 Cast Jeskai Charm by paying {U}{R}{W}, giving all creatures you control +1/+1 and lifelink until end of turn.
Cast Arcbond by paying {2}{R}, targeting Zada.
Zada triggers, copying Arcbond for each creature you control.
Resolve each Arcbond, causing each creature you control to deal damage to each other creature and player when they are dealt damage.
Deal damage to any creature you control, triggering their Arcbond ability, dealing that much damage to each other creature and player.
The creature's lifelink triggers, causing you to gain life equal to the damage dealt.
When damage is dealt to each of your creatures, their Arcbond abilities will trigger.
Repeat from step 6 with each creature's trigger.

---

# 518-1691-3509-3733

**Cards:**

- Mirrorwing Dragon
- Jeskai Charm
- Ephemeral Shields
- Arcbond

**Produces:** Infinite damage

**Mana: {3}{U}{R}{R}{W}{W}, MV: 8, Colors: URW, Popularity: 0**

**Steps:**

Before damage cast Ephemeral Shields, targeting any creature.
Mirrorwing Dragon's ability triggers, copying Shields to the other creatures and giving each indestructible until the end of turn.
Cast Jeskai Charm, choosing the mode to give your creatures lifelink until the end of turn.
Cast Arcbond, targeting one of the creatures.
Mirrorwing Dragon's ability triggers, copying Arcbond onto the other creatures.
Once a creature takes damage, the ability given by Arcbond triggers, reflecting the damage onto all players and all other creatures.
Because of lifelink, you gain life while all other players lose life.
As the ability deals damage to the other creatures you control, their Arcbond abilities trigger in response, doing the same.

---

# 518-1691-3733-3994

**Cards:**

- Precursor Golem
- Jeskai Charm
- Ephemeral Shields
- Arcbond

**Produces:** Infinite damage

**Mana: {3}{U}{R}{R}{W}{W}, MV: 8, Colors: URW, Popularity: 12**

**Steps:**

Before damage cast Ephemeral Shields, targeting any of the golems.
Precursor Golem's ability triggers, copying Shields to the other golems and giving each indestructible until the end of turn.
Cast Jeskai Charm, choosing the mode to give your creatures lifelink until the end of turn.
Cast Arcbond, targeting one of the golems.
Precursor Golem's ability triggers, copying Arcbond onto the other golems.
Once a Golem takes damage, the ability given by Arcbond triggers, reflecting the damage onto all players and all other creatures.
Because of lifelink, you gain life while all other players lose life.
As the ability deals damage to the other golems, their Arcbond abilities trigger in response, doing the same.

---

# 518-1984-5109

**Cards:**

- Angel's Grace
- Arcbond
- Volcano Hellion

**Produces:** Infinite damage

**Mana: {4}{R}{R}{R}{W}, MV: 8, Colors: RW, Popularity: 59**

**Steps:**

Cast Angel's Grace by paying {W}, making it impossible for you to lose the game or have your life total reduced below 1 this turn.
Cast Volcano Hellion by paying {2}{R}{R}.
Volcano Hellion enters the battlefield, triggering itself, targeting any creature.
In response, cast Arcbond by paying {2}{R}, targeting the same creature and creating a delayed triggered ability.
Resolve Volcano Hellion's trigger, dealing an arbitrarily large amount of damage to the targeted creature and to you, reducing your life total to 1 due to Angel's Grace.
Arcbond's delayed triggered ability triggers, dealing an equal amount of damage to all other creatures and all players, which does not change your life total due to Angel's Grace.

---

# 518-3640-5109

**Cards:**

- Fortune Thief
- Arcbond
- Volcano Hellion

**Produces:** Infinite damage

**Mana: {4}{R}{R}{R}, MV: 7, Colors: R, Popularity: 494**

**Steps:**

Cast Volcano Hellion by paying {2}{R}{R}.
Volcano Hellion enters the battlefield, triggering itself, targeting any creature.
In response, cast Arcbond by paying {2}{R}, targeting the same creature and creating a delayed triggered ability.
Resolve Volcano Hellion's trigger, dealing an arbitrarily large amount of damage to the targeted creature and to you, reducing your life total to 1 due to Fortune Thief.
Arcbond's delayed triggered ability triggers, dealing an equal amount of damage to all other creatures and all players, which again does not reduce your life total below 1.

---

# 518-519-5109

**Cards:**

- Worship
- Arcbond
- Volcano Hellion

**Produces:** Infinite damage

**Mana: {4}{R}{R}{R}, MV: 7, Colors: RW, Popularity: 13**

**Steps:**

Cast Volcano Hellion by paying {2}{R}{R}.
Volcano Hellion enters the battlefield, triggering itself, targeting any other creature.
In response, cast Arcbond by paying {2}{R}, targeting the same creature and creating a delayed triggered ability.
Resolve Volcano Hellion's trigger, dealing an arbitrarily large amount of damage to the targeted creature and to you, reducing your life total to 1 due to Worship.
Arcbond's delayed triggered ability triggers, dealing an equal amount of damage to all other creatures and all players, which again does not reduce your life total below 1.

---

# 518-739-5109

**Cards:**

- Gideon of the Trials
- Arcbond
- Volcano Hellion

**Produces:** Infinite damage

**Mana: {4}{R}{R}{R}, MV: 7, Colors: RW, Popularity: 2**

**Steps:**

Cast Volcano Hellion by paying {2}{R}{R}.
Volcano Hellion enters the battlefield, triggering itself, targeting any creature.
In response, cast Arcbond by paying {2}{R}, targeting the same creature and creating a delayed triggered ability.
Resolve Volcano Hellion's trigger, dealing an arbitrarily large amount of damage to the targeted creature and to you, which does not cause you to lose the game due to Gideon of the Trials's emblem.
Arcbond's delayed triggered ability triggers, dealing an equal amount of damage to all other creatures and all players, which again does not cause you to lose the game.

---

# 519-3041-5109

**Cards:**

- Worship
- Coalhauler Swine
- Volcano Hellion

**Produces:** Infinite damage

**Mana: {2}{R}{R}, MV: 4, Colors: RW, Popularity: 11**

**Steps:**

Cast Volcano Hellion by paying {2}{R}{R}.
Volcano Hellion enters the battlefield, triggering itself, dealing an arbitrarily large amount of damage to Coalhauler Swine and to you, which does not reduce your life total below 1 due to Worship.
Coalhauler Swine triggers, dealing an equal amount of damage to each player, which again does not reduce your life total below 1.

---

# 521-1494-1692-3048

**Cards:**

- Roalesk, Apex Hybrid
- Sage of Hours
- Mirror Mockery
- Helm of the Host

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: GU, Popularity: 1**

**Steps:**

At the beginning of combat, Helm of the Host will trigger, making a nonlegendary copy of Roalesk.
When the Roalesk token ETBs, put the 2 +1/+1 counters on Sage of Hours.
Attack with the nontoken Roalesk.
Mirror Mockery triggers, making a copy of Roalesk.
Place its ETB trigger onto the stack targeting Sage of hours, then sacrifice this token copy due to the legend rule, proliferating the +1/+1 counters on Sage of Hours up to 4.
Resolve the ETB trigger, increasing the total number of +1/+1 counters on Sage of Hours to 6.
Remove all +1/+1 counters from Sage of Hours to take an extra turn.
Repeat for infinite turns.

---

# 522-1189-3575

**Cards:**

- Aerie Ouphes
- Eldrazi Monument
- Melira, Sylvok Outcast

**Produces:** Infinite damage to some creatures, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: G, Popularity: 16**

**Steps:**

Activate Aerie Ouphes by sacrificing itself.
Aerie Ouphes' persist ability triggers, returning it from your graveyard to the battlefield.
Resolve the Aerie Ouphes ability, dealing damage equal to its power to Melira.
Repeat.

---

# 522-1657-2292-2890-4583

**Cards:**

- Protean Hulk
- Body Snatcher
- Viscera Seer
- Murderous Redcap
- Melira, Sylvok Outcast

**Produces:** Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite scry

**Mana: , MV: 0, Colors: BRG, Popularity: 167**

**Steps:**

Get Protean Hulk killed, triggering its ability.
Get Body Snatcher and Viscera Seer.
With Body Snatcher's ETB trigger on the stack, sacrifice it to Viscera Seer, getting back Protean Hulk for its death trigger.
Sacrifice Hulk to Viscera Seer, triggering its ability.
Get Murderous Redcap and Melira.
Murderous Redcap ETB ability triggers, dealing 2 damage to an opponent.
Sacrifice Murderous Redcap to Viscera Seer, bringing it back with persist.
Melira prevents a -1/-1 counter from being put on Murderous Redcap.
Repeat.

---

# 522-2111-2890-3653-4204

**Cards:**

- Varolz, the Scar-Striped
- Protean Hulk
- Disciple of the Vault
- Wingrattle Scarecrow
- Melira, Sylvok Outcast

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifeloss, Infinite LTB

**Mana: , MV: 0, Colors: BG, Popularity: 35**

**Steps:**

Sacrifice Protean Hulk to Varolz's regenerate ability.
Protean Hulk's ability activates, placing Melira, Wingrattle Scarecrow, and Disciple of the Vault on the battlefield.
Sacrifice Wingrattle Scarecrow to Varolz's regenerate ability, triggering Disciple of the Vault's ability and causing an opponent to lose 1 life.
Wingrattle Scarecrow's persist ability activates, bringing it back to the battlefield without a -1/-1 counter due to Melira's ability.
Repeat.

---

# 522-2918-3575

**Cards:**

- Aerie Ouphes
- Darksteel Gargoyle
- Melira, Sylvok Outcast

**Produces:** Infinite damage to some creatures, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: G, Popularity: 2**

**Steps:**

Activate Aerie Ouphes by sacrificing itself.
Aerie Ouphes' persist ability triggers, returning it from your graveyard to the battlefield.
Resolve the Aerie Ouphes ability, dealing damage equal to its power to Darksteel Gargoyle.
Repeat.

---

# 524-3149

**Cards:**

- Avacyn, Angel of Hope
- Aether Storm

**Produces:** Players can't cast creature spells, Lock

**Mana: , MV: 0, Colors: WU, Popularity: 30**

**Steps:**

Aether Storm prevents any player from casting creature spells.
Avacyn causes Aether Storm to become indestructible, and thus it cannot be destroyed by its ability.

---

# 524-4810

**Cards:**

- Angel of Jubilation
- Aether Storm

**Produces:** Players can't cast creature spells, Lock

**Mana: {3}{U}, MV: 4, Colors: WU, Popularity: 28**

**Steps:**

Cast Aether Storm.
Players can no longer cast creature spells, and Aether Storm can not be destroyed due to players being unable to pay life to activate its ability

---

# 527-1627-1909-2232

**Cards:**

- Selvala, Heart of the Wilds
- Cloudstone Curio
- Wirewood Symbiote
- Llanowar Elves

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: , MV: 0, Colors: G, Popularity: 632**

**Steps:**

Activate Llanowar Elves by tapping it, adding {G}.
Activate Selvala by paying {G} and tapping it, adding at least {1}{G}{G}{G}.
Activate Wirewood Symbiote by returning Llanowar Elves to your hand, untapping Selvala.
Cast Llanowar Elves by paying {G}.
Llanowar Elves enters the battlefield, triggering Cloudstone Curio, returning Wirewood Symbiote to your hand.
Cast Wirewood Symbiote by paying {G}.
Wirewood Symbiote enters the battlefield, triggering Cloudstone Curio, returning nothing to your hand.
Repeat from step 2.

---

# 527-1909-2232-2951

**Cards:**

- Selvala, Heart of the Wilds
- Cloudstone Curio
- Wirewood Symbiote
- Leaf Gilder

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: , MV: 0, Colors: G, Popularity: 5**

**Steps:**

Activate Leaf Gilder by tapping it, adding {G}.
Activate Selvala by paying {G} and tapping it, adding at least {2}{G}{G}{G}.
Activate Wirewood Symbiote by returning Leaf Gilder to your hand, untapping Selvala.
Cast Leaf Gilder by paying {1}{G}.
Leaf Gilder enters the battlefield, triggering Cloudstone Curio, returning Wirewood Symbiote to your hand.
Cast Wirewood Symbiote by paying {G}.
Wirewood Symbiote enters the battlefield, triggering Cloudstone Curio, returning nothing to your hand.
Repeat from step 2.

---

# 527-1909-2232-4852

**Cards:**

- Selvala, Heart of the Wilds
- Cloudstone Curio
- Wirewood Symbiote
- Elvish Mystic

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: , MV: 0, Colors: G, Popularity: 624**

**Steps:**

Activate Elvish Mystic by tapping it, adding {G}.
Activate Selvala by paying {G} and tapping it, adding at least {1}{G}{G}{G}.
Activate Wirewood Symbiote by returning Elvish Mystic to your hand, untapping Selvala.
Cast Elvish Mystic by paying {G}.
Elvish Mystic enters the battlefield, triggering Cloudstone Curio, returning Wirewood Symbiote to your hand.
Cast Wirewood Symbiote by paying {G}.
Wirewood Symbiote enters the battlefield, triggering Cloudstone Curio, returning nothing to your hand.
Repeat from step 2.

---

# 527-1909-2232-4977

**Cards:**

- Selvala, Heart of the Wilds
- Cloudstone Curio
- Wirewood Symbiote
- Fyndhorn Elves

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: , MV: 0, Colors: G, Popularity: 592**

**Steps:**

Activate Fyndhorn Elves by tapping it, adding {G}.
Activate Selvala by paying {G} and tapping it, adding at least {1}{G}{G}{G}.
Activate Wirewood Symbiote by returning Fyndhorn Elves to your hand, untapping Selvala.
Cast Fyndhorn Elves by paying {G}.
Fyndhorn Elves enters the battlefield, triggering Cloudstone Curio, returning Wirewood Symbiote to your hand.
Cast Wirewood Symbiote by paying {G}.
Wirewood Symbiote enters the battlefield, triggering Cloudstone Curio, returning nothing to your hand.
Repeat from step 2.

---

# 527-2024

**Cards:**

- Seedcradle Witch
- Selvala, Heart of the Wilds

**Produces:** Infinite colored mana, Infinitely large creatures you control until end of turn, Infinite mana creatures you control can produce, Infinite untap of creatures you control

**Mana: {G}, plus an additional {1} available if you do not control a creature with power 5 or greater, MV: 1, Colors: GW, Popularity: 357**

**Steps:**

Activate Selvala by paying {G} and tapping it, adding at least {1}{G}{G}{W}.
Activate Seedcradle Witch by paying {2}{G}{W}, untapping Selvala and giving it +3/+3 until end of turn.
Repeat.

---

# 527-2645

**Cards:**

- Staff of Domination
- Selvala, Heart of the Wilds

**Produces:** Infinite card draw, Infinite colored mana, Infinite draw triggers, Infinite lifegain, Infinite lifegain triggers, Infinite mana creatures you control can produce, Infinite untap of creatures you control

**Mana: {G}, MV: 1, Colors: G, Popularity: 17600**

**Steps:**

Activate Selvala by paying {G} and tapping it, adding at least {5}{G}.
Activate Staff of Domination's third ability by paying {3} and tapping it, untapping Selvala.
Activate Staff of Domination's first ability by paying {1}, untapping it.
Repeat.

---

# 527-3464-3657

**Cards:**

- Kogla, the Titan Ape
- Hyrax Tower Scout
- Selvala, Heart of the Wilds

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count, Infinite untap of creatures you control, Infinite mana creatures you control can produce, Infinite colored mana

**Mana: {G}, MV: 1, Colors: G, Popularity: 2977**

**Steps:**

Activate Selvala by paying {G} and tapping it, adding at least {3}{G}{G}{G}.
Cast Hyrax Tower Scout by paying {2}{G}.
When Hyrax Tower Scout enters the battlefield, it triggers, untapping Selvala.
Activate Kogla by paying {1}{G}, returning Hyrax Tower Scout from the battlefield to your hand.
Repeat.

---

# 527-539-4657

**Cards:**

- Ashaya, Soul of the Wild
- Magus of the Candelabra
- Selvala, Heart of the Wilds

**Produces:** Infinite colored mana, Infinite mana lands you control can produce, Infinite untap of nontoken creatures you control, Infinite mana nontoken creatures you control can produce, Infinite untap of lands you control

**Mana: {G}, MV: 1, Colors: G, Popularity: 1409**

**Steps:**

Activate Selvala by paying {G} and tapping it, adding at least {3}{G}.
Activate Magus of the Candelabra by paying {2} and tapping it, untapping it and Selvala.
Repeat.

---

# 528-2012-2034-5189

**Cards:**

- Ghave, Guru of Spores
- Ashnod's Altar
- Strangleroot Geist
- Corpse Knight

**Produces:** Infinite colorless mana, Infinite creature tokens, Infinite ETB, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite death triggers, Infinite +1/+1 counters on creatures you control

**Mana: , MV: 0, Colors: WBG, Popularity: 504**

**Steps:**

Activate Ashnod's Altar by sacrificing Strangleroot Geist, adding {C}{C}.
Strangleroot Geist's undying triggers, returning Strangleroot Geist from your graveyard to the battlefield with a +1/+1 counter on it.
Strangleroot Geist enters the battlefield triggering Corpse Knight, causing each opponent to lose 1 life.
Activate Ghave's second ability by paying {1} and removing a +1/+1 counter from Strangleroot Geist, creating a 1/1 Saproling creature token.
The Saproling token enters the battlefield triggering Corpse Knight, causing each opponent to lose 1 life.
Repeat.

---

# 528-2012-4050-5189

**Cards:**

- Ghave, Guru of Spores
- Phyrexian Altar
- Strangleroot Geist
- Corpse Knight

**Produces:** Infinite colored mana, Infinite creature tokens, Infinite ETB, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite death triggers, Infinite +1/+1 counters on creatures you control

**Mana: , MV: 0, Colors: WBG, Popularity: 337**

**Steps:**

Activate Phyrexian Altar by sacrificing Strangleroot Geist, adding {1}.
Strangleroot Geist's undying triggers, returning Strangleroot Geist from your graveyard to the battlefield with a +1/+1 counter on it.
Strangleroot Geist enters the battlefield triggering Corpse Knight, causing each opponent to lose 1 life.
Activate Ghave's second ability by paying {1} and removing a +1/+1 counter from Strangleroot Geist, creating a 1/1 Saproling creature token.
The Saproling token enters the battlefield triggering Corpse Knight, causing each opponent to lose 1 life.
Repeat.

---

# 528-2012-4929-5189

**Cards:**

- Ghave, Guru of Spores
- Cryptic Trilobite
- Strangleroot Geist
- Corpse Knight

**Produces:** Infinite colorless mana that can only be spent to activate abilities, Infinite creature tokens, Infinite ETB, Infinite lifeloss, Infinite LTB, Infinite +1/+1 counters on creatures you control

**Mana: {1}, MV: 1, Colors: WBG, Popularity: 438**

**Steps:**

Activate Ghave's second ability by paying {1} and sacrificing Strangleroot Geist.
Strangleroot Geist's undying ability triggers, returning Strangleroot Geist from your graveyard to the battlefield with a +1/+1 counter on it.
Strangleroot Geist enters the battlefield triggering Corpse Knight, causing each opponent to lose 1 life.
Resolve the Ghave ability, putting a +1/+1 counter on Cryptic Trilobite.
Activate Cryptic Trilobite by removing a +1/+1 counter from it, adding {C}{C} that can only be spent to activate abilities.
Activate Ghave's first ability by paying {1} and removing a +1/+1 counter from Strangleroot Geist, creating a 1/1 Saproling creature token.
The Saproling token enters the battlfield triggering Corpse Knight, causing each opponent to lose 1 life.
Repeat.

---

# 528-2018-4050-5197

**Cards:**

- Luminous Broodmoth
- Corpse Knight
- Downdraft
- Phyrexian Altar

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers

**Mana: {G}, MV: 1, Colors: WBG, Popularity: 1**

**Steps:**

Activate Downdraft by paying {G}, causing Luminous Broodmoth to lose flying until end of turn.
Activate Phyrexian Altar by sacrificing Luminous Broodmoth, adding {G}.
Luminous Broodmoth triggers, returning itself from your graveyard to the battlefield with a flying counter on it.
Luminous Broodmoth enters the battlefield triggering Corpse Knight, causing each opponent to lose 1 life.
Repeat.

---

# 528-2034-3644-5189

**Cards:**

- Ghave, Guru of Spores
- Ashnod's Altar
- Young Wolf
- Corpse Knight

**Produces:** Infinite colorless mana, Infinite creature tokens, Infinite ETB, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite death triggers, Infinite +1/+1 counters on creatures you control

**Mana: , MV: 0, Colors: WBG, Popularity: 855**

**Steps:**

Activate Ashnod's Altar by sacrificing Young Wolf, adding {C}{C}.
Young Wolf's undying triggers, returning Young Wolf from your graveyard to the battlefield with a +1/+1 counter on it.
Young Wolf enters the battlefield triggering Corpse Knight, causing each opponent to lose 1 life.
Activate Ghave's second ability by paying {1} and removing a +1/+1 counter from Young Wolf, creating a 1/1 Saproling creature token.
The Saproling token enters the battlefield triggering Corpse Knight, causing each opponent to lose 1 life.
Repeat.

---

# 528-2034-4350-5189

**Cards:**

- Ghave, Guru of Spores
- Ashnod's Altar
- Butcher Ghoul
- Corpse Knight

**Produces:** Infinite colorless mana, Infinite creature tokens, Infinite ETB, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite death triggers, Infinite +1/+1 counters on creatures you control

**Mana: , MV: 0, Colors: WBG, Popularity: 135**

**Steps:**

Activate Ashnod's Altar by sacrificing Butcher Ghoul, adding {C}{C}.
Butcher Ghoul's undying triggers, returning Butcher Ghoul from your graveyard to the battlefield with a +1/+1 counter on it.
Butcher Ghoul enters the battlefield triggering Corpse Knight, causing each opponent to lose 1 life.
Activate Ghave's second ability by paying {1} and removing a +1/+1 counter from Butcher Ghoul, creating a 1/1 Saproling creature token.
The Saproling token enters the battlefield triggering Corpse Knight, causing each opponent to lose 1 life.
Repeat.

---

# 528-3644-4050-5189

**Cards:**

- Ghave, Guru of Spores
- Phyrexian Altar
- Young Wolf
- Corpse Knight

**Produces:** Infinite colored mana, Infinite creature tokens, Infinite ETB, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite death triggers, Infinite +1/+1 counters on creatures you control

**Mana: , MV: 0, Colors: WBG, Popularity: 532**

**Steps:**

Activate Phyrexian Altar by sacrificing Young Wolf, adding {1}.
Young Wolf's undying triggers, returning Young Wolf from your graveyard to the battlefield with a +1/+1 counter on it.
Young Wolf enters the battlefield triggering Corpse Knight, causing each opponent to lose 1 life.
Activate Ghave's second ability by paying {1} and removing a +1/+1 counter from Young Wolf, creating a 1/1 Saproling creature token.
The Saproling token enters the battlefield triggering Corpse Knight, causing each opponent to lose 1 life.
Repeat.

---

# 528-3644-4929-5189

**Cards:**

- Ghave, Guru of Spores
- Cryptic Trilobite
- Young Wolf
- Corpse Knight

**Produces:** Infinite colorless mana that can only be spent to activate abilities, Infinite creature tokens, Infinite death triggers, Infinite ETB, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite +1/+1 counters on creatures you control

**Mana: {1}, MV: 1, Colors: WBG, Popularity: 737**

**Steps:**

Activate Ghave's second ability by paying {1} and sacrificing Young Wolf.
Young Wolf's undying ability triggers, returning Young Wolf from your graveyard to the battlefield with a +1/+1 counter on it.
Young Wolf enters the battlefield triggering Corpse Knight, causing each opponent to lose 1 life.
Resolve the Ghave ability, putting a +1/+1 counter on Cryptic Trilobite.
Activate Cryptic Trilobite by removing a +1/+1 counter from it, adding {C}{C} that can only be spent to activate abilities.
Activate Ghave's first ability by paying {1} and removing a +1/+1 counter from Young Wolf, creating a 1/1 Saproling creature token.
The Saproling token enters the battlfield triggering Corpse Knight, causing each opponent to lose 1 life.
Repeat.

---

# 528-4050-4350-5189

**Cards:**

- Ghave, Guru of Spores
- Phyrexian Altar
- Butcher Ghoul
- Corpse Knight

**Produces:** Infinite colored mana, Infinite creature tokens, Infinite ETB, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite death triggers, Infinite +1/+1 counters on creatures you control

**Mana: , MV: 0, Colors: WBG, Popularity: 86**

**Steps:**

Activate Phyrexian Altar by sacrificing Butcher Ghoul, adding {1}.
Butcher Ghoul's undying triggers, returning Butcher Ghoul from your graveyard to the battlefield with a +1/+1 counter on it.
Butcher Ghoul enters the battlefield triggering Corpse Knight, causing each opponent to lose 1 life.
Activate Ghave's second ability by paying {1} and removing a +1/+1 counter from Butcher Ghoul, creating a 1/1 Saproling creature token.
The Saproling token enters the battlefield triggering Corpse Knight, causing each opponent to lose 1 life.
Repeat.

---

# 528-4350-4929-5189

**Cards:**

- Ghave, Guru of Spores
- Cryptic Trilobite
- Butcher Ghoul
- Corpse Knight

**Produces:** Infinite colorless mana that can only be spent to activate abilities, Infinite creature tokens, Infinite ETB, Infinite lifeloss, Infinite LTB, Infinite +1/+1 counters on creatures you control

**Mana: {1}, MV: 1, Colors: WBG, Popularity: 109**

**Steps:**

Activate Ghave's second ability by paying {1} and sacrificing Butcher Ghoul.
Butcher Ghoul's undying ability triggers, returning Butcher Ghoul from your graveyard to the battlefield with a +1/+1 counter on it.
Butcher Ghoul enters the battlefield triggering Corpse Knight, causing each opponent to lose 1 life.
Resolve the Ghave ability, putting a +1/+1 counter on Cryptic Trilobite.
Activate Cryptic Trilobite by removing a +1/+1 counter from it, adding {C}{C} that can only be spent to activate abilities.
Activate Ghave's first ability by paying {1} and removing a +1/+1 counter from Butcher Ghoul, creating a 1/1 Saproling creature token.
The Saproling token enters the battlfield triggering Corpse Knight, causing each opponent to lose 1 life.
Repeat.

---

# 53-1491-2987

**Cards:**

- Channeler Initiate
- Sinking Feeling
- Obelisk Spider

**Produces:** Infinite lifegain, Infinite lifegain triggers, Infinite lifeloss

**Mana: , MV: 0, Colors: BGU, Popularity: 11**

**Steps:**

Activate Channeler Initiate by tapping and removing a -1/-1 counter from it, adding one mana of any color.
Activate Channeler Initiate by paying {1} and putting a -1/-1 counter on it, untapping it.
Obelisk Spider triggers, causing each opponent to lose 1 life and you to gain 1 life.
Repeat.

---

# 531-651-4046

**Cards:**

- Outrider en-Kor
- Task Force
- Severed Strands

**Produces:** Infinite lifegain

**Mana: {1}{B}, MV: 2, Colors: WB, Popularity: 10**

**Steps:**

Activate Outrider en-Kor by paying {0}, targeting Task Force.
Task Force triggers, giving itself +0/+3 until end of turn.
Resolve Outrider en-Kor's ability, causing the next one damage dealt to Outrider en-Kor this turn to be dealt to Task Force instead.
Repeat an arbitrarily large number of times.
Cast Severed Strands by paying {1}{B} and sacrificing Task Force, causing you to gain life equal to Task Force's toughness and destroy target creature an opponent controls.

---

# 536-1061-1869

**Cards:**

- Timestream Navigator
- Riptide Laboratory
- Inalla, Archmage Ritualist

**Produces:** Infinite turns, Lock

**Mana: {5}{U}{U}{U}{U} each turn, MV: 9, Colors: UBR, Popularity: 3453**

**Steps:**

Cast Timestream Navigator by paying {1}{U}.
Timestream Navigator enters the battlefield, triggering Inalla, causing you to pay {1} to create a token copy of Timestream Navigator with haste.
If you do not have the city's blessing, Timestream Navigator triggers, giving you the city's blessing for the rest of the game.
Activate Riptide Laboratory by paying {1}{U} and tapping it, returning the nontoken Timestream Navigator to your hand from the battlefield.
Activate the token Timestream Navigator by paying {2}{U}{U}, tapping it, and putting it on the bottom of your library, causing you to take an extra turn after this one.
Repeat each turn.

---

# 538-1183-1636-4061

**Cards:**

- Dalakos, Crafter of Wonders
- Pentavus
- Intruder Alarm
- Impact Tremors

**Produces:** Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite untap of creatures you control, Infinite mana creatures you control can produce, Infinite untap of creatures

**Mana: , MV: 0, Colors: UR, Popularity: 1**

**Steps:**

Activate Dalakos by tapping it, adding {C}{C} that can only be spent on artifacts or to activate abilities of artifacts.
Activate Pentavus's first ability by paying {1}, creating a 1/1 Pentavite creature token.
Creature tokens enters the battlefield, triggering Intruder Alarm, untapping all creatures.
Impact Tremors triggers, dealing 1 damage to each opponent.
Activate Pentavus's second ability by paying {1} and sacrificing a Pentavite, putting a +1/+1 counter on Pentavus.
Repeat.

---

# 538-1183-2178-4061

**Cards:**

- Dalakos, Crafter of Wonders
- Pentavus
- Thornbite Staff
- Impact Tremors

**Produces:** Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: UR, Popularity: 1**

**Steps:**

Activate Dalakos by tapping it, adding {C}{C} that can only be spent on artifacts or to activate abilities of artifacts.
Activate Pentavus's first ability by paying {1}, creating a 1/1 Pentavite creature token.
Impact Tremors triggers, dealing 1 damage to each opponent.
Activate Pentavus's second ability by paying {1} and sacrificing a Pentavite, putting a +1/+1 counter on Pentavus.
Dalakos triggers, untapping.
Repeat.

---

# 538-1621-2781

**Cards:**

- Felidar Guardian
- Wispweaver Angel
- Impact Tremors

**Produces:** Infinite damage, Infinite ETB, Infinite LTB

**Mana: {3}{W}, MV: 4, Colors: RW, Popularity: 193**

**Steps:**

Cast Wispweaver Angel.
When it ETBs, target Felidar Guardian with its ETB and trigger Impact Tremors.
When Felidar Guardian ETBs, target Wispweaver Angel and trigger Impact Tremors.
Repeat for Infinite damage.

---

# 538-2034-5003-5296

**Cards:**

- Workhorse
- Nim Deathmantle
- Ashnod's Altar
- Impact Tremors

**Produces:** Infinite colorless mana, Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: R, Popularity: 46**

**Steps:**

Activate Workhorse by removing four +1/+1 counters, adding {C}{C}{C}{C}.
Activate Ashnod's Altar by sacrificing Workhorse, adding {C}{C}.
Workhorse dies, triggering Nim Deathmantle, causing you to pay {4} to return Workhorse from your graveyard to the battlefield, and attach Nim Deathmantle to it.
Workhorse enters the battlefield with four +1/+1 counters on it.
Impact Tremors triggers, dealing 1 damages to each opponent.
Repeat.

---

# 538-4050-5003-5296

**Cards:**

- Workhorse
- Nim Deathmantle
- Impact Tremors
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite colorless mana, Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: R, Popularity: 20**

**Steps:**

Activate Workhorse by removing four +1/+1 counters, adding {C}{C}{C}{C}.
Activate Phyrexian Altar by sacrificing Workhorse, adding one mana of any color.
Workhorse dies, triggering Nim Deathmantle, causing you to pay {4} to return Workhorse from your graveyard to the battlefield, and attach Nim Deathmantle to it.
Workhorse enters the battlefield with four +1/+1 counters on it.
Impact Tremors triggers, dealing 1 damage to each opponent.
Repeat.

---

# 539-1247-1682

**Cards:**

- Ashaya, Soul of the Wild
- Pili-Pala
- Dictate of Karametra

**Produces:** Infinite colored mana

**Mana: , MV: 0, Colors: G, Popularity: 14**

**Steps:**

Activate Pili-Pala by tapping it, adding {G}{G}.
Activate Pili-Pala by paying {2} and untapping it, adding one mana of any color.
Repeat.

---

# 539-1247-2071

**Cards:**

- Ashaya, Soul of the Wild
- Pili-Pala
- Wolfwillow Haven

**Produces:** Infinite colored mana

**Mana: , MV: 0, Colors: G, Popularity: 6**

**Steps:**

Activate Pili-Pala by tapping it, adding {G}{G}.
Activate Pili-Pala by paying {2} and untapping it, adding one mana of any color.
Repeat.

---

# 539-1247-2203

**Cards:**

- Ashaya, Soul of the Wild
- Pili-Pala
- Vorinclex, Voice of Hunger

**Produces:** Infinite colored mana

**Mana: , MV: 0, Colors: G, Popularity: 29**

**Steps:**

Activate Pili-Pala by tapping it, adding {G}{G}.
Activate Pili-Pala by paying {2} and untapping it, adding one mana of any color.
Repeat.

---

# 539-1247-2597

**Cards:**

- Ashaya, Soul of the Wild
- Pili-Pala
- Wild Growth

**Produces:** Infinite colored mana

**Mana: , MV: 0, Colors: G, Popularity: 313**

**Steps:**

Activate Pili-Pala by tapping it, adding {G}{G}.
Activate Pili-Pala by paying {2} and untapping it, adding one mana of any color.
Repeat.

---

# 539-1247-3099

**Cards:**

- Ashaya, Soul of the Wild
- Leyline of Abundance
- Pili-Pala

**Produces:** Infinite colored mana, Infinite +1/+1 counters on creatures you control

**Mana: , MV: 0, Colors: G, Popularity: 154**

**Steps:**

Activate Pili-Pala's Forest ability by tapping it, adding {G}.
When you tap Pili-Pala for mana, Leyline of Abundance triggers, adding {G}.
Activate Pili-Pala's own ability by paying {2} and untapping it, adding one mana of any color.
Repeat.
Once you have infinite mana, you may activate Leyline of Abundance infinite times and activate Quirion Ranger targeting any creatures infinite times.

---

# 539-1247-3102

**Cards:**

- Ashaya, Soul of the Wild
- Pili-Pala
- Vernal Bloom

**Produces:** Infinite colored mana

**Mana: , MV: 0, Colors: G, Popularity: 14**

**Steps:**

Activate Pili-Pala by tapping it, adding {G}{G}.
Activate Pili-Pala by paying {2} and untapping it, adding one mana of any color.
Repeat.

---

# 539-1247-3430

**Cards:**

- Ashaya, Soul of the Wild
- Pili-Pala
- Nyxbloom Ancient

**Produces:** Infinite colored mana

**Mana: , MV: 0, Colors: G, Popularity: 82**

**Steps:**

Activate Pili-Pala by tapping it, adding {G}{G}{G}.
Activate Pili-Pala by paying {2} and untapping it, adding one mana of any color.
Repeat.

---

# 539-1247-4178

**Cards:**

- Ashaya, Soul of the Wild
- Pili-Pala
- Nissa, Who Shakes the World

**Produces:** Infinite colored mana

**Mana: , MV: 0, Colors: G, Popularity: 56**

**Steps:**

Activate Pili-Pala by tapping it, adding {G}{G}.
Activate Pili-Pala by paying {2} and untapping it, adding one mana of any color.
Repeat.

---

# 539-1247-4974

**Cards:**

- Ashaya, Soul of the Wild
- Pili-Pala
- Zendikar Resurgent

**Produces:** Infinite colored mana

**Mana: , MV: 0, Colors: G, Popularity: 30**

**Steps:**

Activate Pili-Pala by tapping it, adding {G}{G}.
Activate Pili-Pala by paying {2} and untapping it, adding one mana of any color.
Repeat.

---

# 539-1247-5175

**Cards:**

- Ashaya, Soul of the Wild
- Pili-Pala
- Caged Sun

**Produces:** Infinite colored mana

**Mana: , MV: 0, Colors: G, Popularity: 17**

**Steps:**

Activate Pili-Pala by tapping it, adding {G}{G}.
Activate Pili-Pala by paying {2} and untapping it, adding one mana of any color.
Repeat.

---

# 539-1247-5227

**Cards:**

- Ashaya, Soul of the Wild
- Utopia Sprawl
- Pili-Pala

**Produces:** Infinite colored mana

**Mana: , MV: 0, Colors: G, Popularity: 254**

**Steps:**

Activate Pili-Pala by tapping it, adding {1}{G}.
Activate Pili-Pala by paying {2} and untapping it, adding one mana of any color.
Repeat.

---

# 539-1247-5234

**Cards:**

- Ashaya, Soul of the Wild
- Pili-Pala
- Heartbeat of Spring

**Produces:** Infinite colored mana

**Mana: , MV: 0, Colors: G, Popularity: 27**

**Steps:**

Activate Pili-Pala by tapping it, adding {G}{G}.
Activate Pili-Pala by paying {2} and untapping it, adding one mana of any color.
Repeat.

---

# 539-1606

**Cards:**

- Ashaya, Soul of the Wild
- Ley Weaver

**Produces:** Infinite mana lands you control can produce, Infinite untap of creatures you control, Infinite mana creatures you control can produce, Infinite untap of nontoken creatures you control, Infinite mana nontoken creatures you control can produce, Infinite untap of lands you control

**Mana: , MV: 0, Colors: G, Popularity: 2582**

**Steps:**

Activate Ley Weaver by tapping it, untapping itself and any other land.
Activate the land by tapping it, adding one mana of any color that land can produce.
Repeat.

---

# 539-1606-4291

**Cards:**

- Ashaya, Soul of the Wild
- Ley Weaver
- Prodigal Sorcerer

**Produces:** Infinite damage, Infinite mana lands you control can produce, Infinite untap of creatures you control, Infinite mana creatures you control can produce, Infinite untap of nontoken creatures you control, Infinite mana nontoken creatures you control can produce, Infinite untap of lands you control

**Mana: , MV: 0, Colors: GU, Popularity: 21**

**Steps:**

Activate Prodigal Sorcerer by tapping it, dealing 1 damage to any target.
Activate Ley Weaver by tapping it, untapping itself and Prodigal Sorcerer.
Repeat.

---

# 539-1978-4878

**Cards:**

- Ashaya, Soul of the Wild
- Market Festival
- Voltaic Construct

**Produces:** Infinite colored mana, Infinite untap of artifact creatures you control

**Mana: , MV: 0, Colors: G, Popularity: 1**

**Steps:**

Activate Voltaic Construct by tapping it, adding {G}.
Market Festival triggers, adding two mana of any color(s).
Activate Voltaic Construct by paying {G}{G}, untapping it.
Repeat

---

# 539-2050-4684

**Cards:**

- Ashaya, Soul of the Wild
- Arbor Elf
- Mesmeric Orb

**Produces:** Infinite self-mill

**Mana: , MV: 0, Colors: G, Popularity: 51**

**Steps:**

Activate Arbor Elf by tapping it, untapping itself.
Mesmeric Orb triggers, causing you to mill a card.
Repeat.

---

# 539-3181

**Cards:**

- Krosan Restorer
- Ashaya, Soul of the Wild

**Produces:** Infinite colored mana, Infinite untap of creatures and lands you control

**Mana: , MV: 0, Colors: G, Popularity: 1504**

**Steps:**

Activate Krosan Restorer by tapping it, untapping itself at least one other nonsummoning sick land.
Activate the land, adding {1}.
Repeat.

---

# 539-3291-4657

**Cards:**

- Ashaya, Soul of the Wild
- Magus of the Candelabra
- Karametra's Acolyte

**Produces:** Infinite green mana, Infinite mana lands you control can produce, Infinite untap of nontoken creatures you control, Infinite mana nontoken creatures you control can produce, Infinite untap of lands you control

**Mana: , MV: 0, Colors: G, Popularity: 1013**

**Steps:**

Activate Karametra's Acolyte by tapping it, adding at least {G}{G}{G}{G}.
Activate Magus of the Candelabra by paying {2} and tapping it, untapping it and Karametra's Acolyte.
Repeat.

---

# 539-3814

**Cards:**

- Ashaya, Soul of the Wild
- Argothian Elder

**Produces:** Infinite mana lands you control can produce, Infinite untap of creatures you control, Infinite mana creatures you control can produce, Infinite untap of nontoken creatures you control, Infinite mana nontoken creatures you control can produce, Infinite untap of lands you control

**Mana: , MV: 0, Colors: G, Popularity: 5059**

**Steps:**

Activate Argothian Elder by tapping it, untapping itself and any other land.
Activate the land by tapping it, adding one mana of any color that land can produce.
Repeat.

---

# 539-3814-4291

**Cards:**

- Ashaya, Soul of the Wild
- Argothian Elder
- Prodigal Sorcerer

**Produces:** Infinite damage, Infinite mana lands you control can produce, Infinite untap of creatures you control, Infinite mana creatures you control can produce, Infinite untap of nontoken creatures you control, Infinite mana nontoken creatures you control can produce, Infinite untap of lands you control

**Mana: , MV: 0, Colors: GU, Popularity: 17**

**Steps:**

Activate Prodigal Sorcerer by tapping it, dealing 1 damage to any target.
Activate Argothian Elder by tapping it, untapping itself and Prodigal Sorcerer.
Repeat.

---

# 539-3995-5227

**Cards:**

- Ashaya, Soul of the Wild
- Horseshoe Crab
- Utopia Sprawl

**Produces:** Infinite green mana

**Mana: , MV: 0, Colors: GU, Popularity: 13**

**Steps:**

Activate Horseshoe Crab by tapping it, adding {U}{G}.
Activate Horseshoe Crab by paying {U}, untapping itself.
Repeat.

---

# 539-4241-5175

**Cards:**

- Ashaya, Soul of the Wild
- Caged Sun
- Karn, Silver Golem

**Produces:** Draw the game

**Mana: {1}, MV: 1, Colors: G, Popularity: 8**

**Steps:**

Activate Karn by paying {1}, causing Caged Sun to become an artifact creature until end of turn.
Activate Caged Sun by tapping it, adding {G}.
Caged Sun triggers, adding {G}.
Repeat step 2.
As Caged Sun's triggered ability is a mana ability, this combo creates a mandatory infinite loop that cannot be interacted with, thus ending the game in a draw.

---

# 539-579-1247

**Cards:**

- Ashaya, Soul of the Wild
- Pili-Pala
- Mana Reflection

**Produces:** Infinite colored mana

**Mana: , MV: 0, Colors: G, Popularity: 46**

**Steps:**

Activate Pili-Pala by tapping it, adding {G}{G}.
Activate Pili-Pala by paying {2} and untapping it, adding one mana of any color.
Repeat.

---

# 539-630-1247

**Cards:**

- Ashaya, Soul of the Wild
- Pili-Pala
- Keeper of Progenitus

**Produces:** Infinite colored mana

**Mana: , MV: 0, Colors: G, Popularity: 9**

**Steps:**

Activate Pili-Pala by tapping it, adding {G}{G}.
Activate Pili-Pala by paying {2} and untapping it, adding one mana of any color.
Repeat.

---

# 544-1176

**Cards:**

- Estrid, the Masked
- Sanctum of Eternity

**Produces:** Infinite colored mana, Infinite colorless mana, Infinite mana enchanted permanents you control can produce

**Mana: {5}{G}{W}{U}, MV: 8, Colors: GWU, Popularity: 367**

**Steps:**

Activate Estrid's second loyalty ability by removing one loyalty counter, creating a Mask Aura token and attaching it to Sanctum of Eternity.
Activate Sanctum of Eternity by paying {2} and tapping it, returning Estrid to your hand.
Activate all other enchanted permanents that can produce at least {4}{W}{U}{G}.
Cast Estrid by paying {1}{W}{U}{G}.
Activate Estrid's first loyalty ability by putting two loyalty counters on it, untapping all enchanted permanents you control.

---

# 544-2226

**Cards:**

- Zacama, Primal Calamity
- Sanctum of Eternity

**Produces:** Infinite damage to creatures, Infinite enchantment destruction, Infinite ETB, Infinite lifegain, Infinite LTB, Infinite lifegain triggers, Infinite mana lands you control can produce, Infinite storm count

**Mana: , MV: 0, Colors: RGW, Popularity: 1323**

**Steps:**

Activate all mana producing lands you control besides Sanctum of Eternity by tapping them, adding at least {9}{R}{G}{W}.
Activate Sanctum of Eternity by paying {2} and tapping it, returning Zacama from the battlefield to your hand.
Cast Zacama by paying {6}{R}{G}{W}.
Zacama triggers, untapping all lands you control.
Repeat.

---

# 557-3554-3617

**Cards:**

- Time Walk
- Seasons Past
- Diabolic Revelation

**Produces:** Lock, Infinite turns

**Mana: {9}{B}{B}{G}{G}{U} each turn, MV: 14, Colors: BGU, Popularity: 0**

**Steps:**

Cast Seasons Past by paying {4}{G}{G}, returning Diabolic Revelation, Time Walk, and any number of cards with different mana costs to your hand and putting Seasons Past on the bottom of your library.
Cast Diabolic Revelation by paying {4}{B}{B}, putting Seasons Past from your library into your hand.
Cast Time Walk by paying {1}{U}, granting you an extra turn.
Repeat each turn.

---

# 557-3554-4377

**Cards:**

- Walk the Aeons
- Seasons Past
- Diabolic Revelation

**Produces:** Infinite turns, Lock

**Mana: {12}{B}{B}{G}{G}{U}{U} each turn, MV: 18, Colors: BGU, Popularity: 1**

**Steps:**

Cast Seasons Past by paying {4}{G}{G}, returning Diabolic Revelation, Walk the Aeons, and any number of cards with different mana costs to your hand and putting Seasons Past on the bottom of your library.
Cast Diabolic Revelation by paying {4}{B}{B}, putting Seasons Past from your library into your hand.
Cast Walk the Aeons by paying {4}{U}{U}, granting you an extra turn.
Repeat each turn.

---

# 557-3846

**Cards:**

- Atemsis, All-Seeing
- Diabolic Revelation

**Produces:** Target opponent loses the game

**Mana: {9}{B}{B} (at most), MV: 11, Colors: UB, Popularity: 13**

**Steps:**

Cast Diabolic Revelation by paying at most {9}{B}{B}, searching your library for at most six cards with differing mana values and putting them into your hand.
Move to your combat phase, and deal combat damage to an opponent with Atemsis.
Atemsis triggers, revealing your hand and causing the opponent dealt combat damage to lose the game.

---

# 562-651-2603

**Cards:**

- Warrior en-Kor
- Task Force
- Worthy Cause

**Produces:** Infinite lifegain

**Mana: {W}, MV: 1, Colors: W, Popularity: 55**

**Steps:**

Activate Warrior en-Kor by paying {0}, targeting Task Force.
Task Force triggers, giving itself +0/+3 until end of turn.
Resolve Warrior en-Kor's ability, causing the next one damage dealt to Warrior en-Kor this turn to be dealt to Task Force instead.
Repeat an arbitrarily large number of times.
Cast Worthy Cause by paying {W} and sacrificing Task Force, causing you to gain life equal to Task Force's toughness.

---

# 56-3391-4050

**Cards:**

- Hogaak, Arisen Necropolis
- Korozda Guildmage
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite creature tokens, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {2}{B}{G}, MV: 4, Colors: BG, Popularity: 441**

**Steps:**

Activate Korozda Guildmage's second ability by paying {2}{B}{G} and sacrificing Hogaak.
If Hogaak is your commander, choose not to return it to the command zone from your graveyard.
Resolve the Korozda Guildmage trigger, creating eight 1/1 Saproling creature tokens.
Cast Hogaak from your graveyard by tapping seven Saprolings.
Activate Phyrexian Altar four times by sacrificing four Saprolings, adding {2}{B}{G}.
Repeat.

---

# 567-1734-4279-4681

**Cards:**

- Yawgmoth, Thran Physician
- Fiend Hunter
- Karmic Guide
- Soul's Attendant

**Produces:** Infinite card draw, Infinite draw triggers, Near-infinite -1/-1 counters, Near-infinite death triggers, Near-infinite ETB, Near-infinite lifegain triggers, Near-infinite LTB, Near-infinite sacrifice triggers

**Mana: {1}{W}{W}, MV: 3, Colors: WB, Popularity: 41**

**Steps:**

Cast Fiend Hunter by paying {1}{W}{W}.
Fiend Hunter enters the battlefield, triggering itself and Soul's Attendant.
Resolve the Fiend Hunter trigger, exiling Karmic Guide.
Resolve the Soul's Attendant trigger, causing you to gain 1 life.
Activate Yawgmoth by paying 1 life and sacrificing Fiend Hunter.
Fiend Hunter triggers, returning Karmic Guide from exile to the battlefield.
Karmic Guide enters the battlefield, triggering itself and Soul's Attendant.
Resolve the Karmic Guide trigger, returning Fiend Hunter from your graveyard to the battlefield.
Fiend Hunter enters the battlefield, triggering itself and Soul's Attendant.
Resolve the Fiend Hunter trigger, exiling Karmic Guide.
Resolve both remaining Soul's Attendant triggers, causing you to gain two life.
Resolve the Yawgmoth ability from step 5, putting a -1/-1 counter on up to one creature and drawing a card.
Repeat from step 5.

---

# 568-2103-4423

**Cards:**

- Mystic Sanctuary
- Capsize
- Capture of Jingzhou

**Produces:** Infinite turns, Skip your draw steps, Lock

**Mana: {7}{U}{U}{U}{U}, MV: 11, Colors: U, Popularity: 705**

**Steps:**

Cast Capture of Jingzhou by paying {3}{U}{U}, getting an extra turn after this one.
Play Mystic Sanctuary to put Capture of Jingzhou on top of your library.
Cast Capsize for its buyback cost by paying {4}{U}{U}, returning Mystic Sanctuary to your hand.
Move to your next turn.
Repeat.

---

# 568-2104-4423

**Cards:**

- Mystic Sanctuary
- Capsize
- Temporal Manipulation

**Produces:** Infinite turns, Skip your draw steps, Lock

**Mana: {7}{U}{U}{U}{U}, MV: 11, Colors: U, Popularity: 1038**

**Steps:**

Cast Temporal Manipulation by paying {3}{U}{U}, getting an extra turn after this one.
Play Mystic Sanctuary to put Temporal Manipulation on top of your library.
Cast Capsize for its buyback cost by paying {4}{U}{U}, returning Mystic Sanctuary to your hand.
Move to your next turn.
Repeat.

---

# 568-4377-4423

**Cards:**

- Mystic Sanctuary
- Capsize
- Walk the Aeons

**Produces:** Infinite turns, Skip your draw steps, Lock

**Mana: {8}{U}{U}{U}{U}, MV: 12, Colors: U, Popularity: 651**

**Steps:**

Cast Walk the Aeons by paying {4}{U}{U}, getting an extra turn after this one.
Play Mystic Sanctuary to put Walk the Aeons on top of your library.
Cast Capsize for its buyback cost by paying {4}{U}{U}, returning Mystic Sanctuary to your hand.
Move to your next turn.
Repeat.

---

# 568-4423-4872

**Cards:**

- Mystic Sanctuary
- Capsize
- Time Warp

**Produces:** Infinite turns, Skip your draw steps, Lock

**Mana: {7}{U}{U}{U}{U}, MV: 11, Colors: U, Popularity: 1595**

**Steps:**

Cast Time Warp by paying {3}{U}{U}, getting an extra turn after this one.
Play Mystic Sanctuary to put Time Warp on top of your library.
Cast Capsize for its buyback cost by paying {4}{U}{U}, returning Mystic Sanctuary to your hand.
Move to your next turn.
Repeat.

---

# 570-1764-2024

**Cards:**

- Seedcradle Witch
- Faeburrow Elder
- Scrapbasket

**Produces:** Infinite black mana, Infinite blue mana, Infinitely large creature until end of turn, Infinite red mana, Infinite mana of colors among permanents you control

**Mana: {1}, MV: 1, Colors: GW, Popularity: 0**

**Steps:**

Activate Scrapbasket by paying {1}, making it all colors until end of turn.
Activate Faeburrow Elder by tapping it, adding {W}{U}{B}{R}{G}.
Activate Seedcradle Witch by paying {2}{W}{G}, giving Faeburrow Elder +3/+3 until end of turn and untapping it.
Repeat from step 2.

---

# 570-2011

**Cards:**

- Najeela, the Blade-Blossom
- Faeburrow Elder

**Produces:** Infinite combat phases, Infinite creature tokens, Infinite ETB, Infinite lifegain, Infinite lifegain triggers

**Mana: , MV: 0, Colors: WUBRG, Popularity: 7410**

**Steps:**

Declare Najeela and Faeburrow Elder as attackers.
Najeela triggers, creating a 1/1 Warrior creature token that is tapped and attacking.
Activate Faeburrow Elder by tapping it, adding {W}{U}{B}{R}{G}.
Activate Najeela by paying {W}{U}{B}{R}{G}, untapping all attacking creatures, giving them trample, lifelink, and haste, and gaining an additional combat phase after this one.
Repeat each combat phase.

---

# 570-2024-2251

**Cards:**

- Seedcradle Witch
- Faeburrow Elder
- Quickchange

**Produces:** Infinite black mana, Infinite blue mana, Infinitely large creature until end of turn, Infinite red mana, Infinite mana of colors among permanents you control

**Mana: {1}{U}, MV: 2, Colors: GWU, Popularity: 0**

**Steps:**

Cast Quickchange by paying {1}{U}, making a creature you control all colors until end of turn.
Activate Faeburrow Elder by tapping it, adding {W}{U}{B}{R}{G}.
Activate Seedcradle Witch by paying {2}{W}{G}, giving Faeburrow Elder +3/+3 until end of turn and untapping it.
Repeat from step 2.

---

# 570-2024-2268

**Cards:**

- Seedcradle Witch
- Faeburrow Elder
- Dream Coat

**Produces:** Infinite black mana, Infinite blue mana, Infinitely large creature until end of turn, Infinite red mana, Infinite mana of colors among permanents you control

**Mana: , MV: 0, Colors: GWU, Popularity: 0**

**Steps:**

Activate Dream Coat by paying {0}, making the enchanted creature all colors.
Activate Faeburrow Elder by tapping it, adding {W}{U}{B}{R}{G}.
Activate Seedcradle Witch by paying {2}{W}{G}, giving Faeburrow Elder +3/+3 until end of turn and untapping it.
Repeat from step 2.

---

# 570-2024-2887

**Cards:**

- Seedcradle Witch
- Faeburrow Elder
- Scuttlemutt

**Produces:** Infinite black mana, Infinite blue mana, Infinitely large creature until end of turn, Infinite red mana, Infinite mana of colors among permanents you control

**Mana: , MV: 0, Colors: GW, Popularity: 1**

**Steps:**

Activate Scuttlemutt's second ability by tapping it, making any creature you control all colors until end of turn.
Activate Faeburrow Elder by tapping it, adding {W}{U}{B}{R}{G}.
Activate Seedcradle Witch by paying {2}{W}{G}, giving Faeburrow Elder +3/+3 until end of turn and untapping it.
Repeat from step 2.

---

# 570-2024-3295

**Cards:**

- Seedcradle Witch
- Faeburrow Elder
- Swirling Spriggan

**Produces:** Infinite black mana, Infinite blue mana, Infinitely large creature until end of turn, Infinite red mana, Infinite mana of colors among permanents you control

**Mana: {G/U}{G/U}, MV: 2, Colors: GWU, Popularity: 0**

**Steps:**

Activate Swirling Spriggan by paying {G/U}{G/U}, making a creature you control all colors until end of turn.
Activate Faeburrow Elder by tapping it, adding {W}{U}{B}{R}{G}.
Activate Seedcradle Witch by paying {2}{W}{G}, giving Faeburrow Elder +3/+3 until end of turn and untapping it.
Repeat from step 2.

---

# 570-2024-3842

**Cards:**

- Seedcradle Witch
- Faeburrow Elder
- Planewide Celebration

**Produces:** Infinite black mana, Infinite blue mana, Infinitely large creature until end of turn, Infinite red mana, Infinite mana of colors among permanents you control

**Mana: {5}{G}{G}, MV: 7, Colors: GW, Popularity: 0**

**Steps:**

Cast Planewide Celebration by paying {5}{G}{G}, creating at least one 2/2 Citizen creature token that's all colors.
Activate Faeburrow Elder by tapping it, adding {W}{U}{B}{R}{G}.
Activate Seedcradle Witch by paying {2}{W}{G}, giving Faeburrow Elder +3/+3 until end of turn and untapping it.
Repeat from step 2.

---

# 570-2024-4858

**Cards:**

- Seedcradle Witch
- Faeburrow Elder
- Prismwake Merrow

**Produces:** Infinite black mana, Infinite blue mana, Infinitely large creature until end of turn, Infinite red mana, Infinite mana of colors among permanents you control

**Mana: {2}{U}, MV: 3, Colors: GWU, Popularity: 0**

**Steps:**

Cast Prismwake Merrow by paying {2}{U}.
Prismwake Merrow enters the battlefield, triggering itself, making a permanent you control all colors until end of turn.
Activate Faeburrow Elder by tapping it, adding {W}{U}{B}{R}{G}.
Activate Seedcradle Witch by paying {2}{W}{G}, giving Faeburrow Elder +3/+3 until end of turn and untapping it.
Repeat from step 3.

---

# 570-3525

**Cards:**

- Faeburrow Elder
- Pemmin's Aura

**Produces:** Infinite non-blue mana of colors among permanents you control, Infinite mana of colors among permanents you control

**Mana: , MV: 0, Colors: GWU, Popularity: 4045**

**Steps:**

Activate Faeburrow Elder by tapping it, adding {W}{U}{G}.
Activate Pemmin's Aura's first ability by paying {U}, untapping Faeburrow Elder.
Repeat.

---

# 570-4222

**Cards:**

- Faeburrow Elder
- Freed from the Real

**Produces:** Infinite non-blue mana of colors among permanents you control, Infinite mana of colors among permanents you control

**Mana: , MV: 0, Colors: GWU, Popularity: 8226**

**Steps:**

Activate Faeburrow Elder by tapping it, adding {W}{U}{G}.
Activate Freed from the Real's second ability by paying {U}, untapping Faeburrow Elder.
Repeat.

---

# 570-751-1029-3314

**Cards:**

- Chulane, Teller of Tales
- Tolarian Kraken
- Shrieking Drake
- Faeburrow Elder

**Produces:** Infinite card draw, Infinite draw triggers, Near-infinite ETB, Near-infinite green mana, Near-infinite landfall triggers, Near-infinite LTB, Near-infinite storm count, Near-infinite white mana, Put all lands from your hand and library onto the battlefield

**Mana: , MV: 0, Colors: GWU, Popularity: 17**

**Steps:**

Activate Faeburrow Elder by tapping it, adding at least {W}{U}{G}.
Cast Shrieking Drake by paying {U}.
Chulane triggers, causing you to draw a card and allowing you to put a land card from your hand onto the battlefield.
Tolarian Kraken triggers, causing you to pay {1} to untap Faeburrow Elder.
Shrieking Drake enters the battlefield, returning itself from the battlefield to your hand.
Repeat.

---

# 570-901-2024

**Cards:**

- Seedcradle Witch
- Faeburrow Elder
- Govern the Guildless

**Produces:** Infinite black mana, Infinite blue mana, Infinitely large creature until end of turn, Infinite red mana, Infinite mana of colors among permanents you control

**Mana: {1}{U}, MV: 2, Colors: GWU, Popularity: 0**

**Steps:**

During your upkeep, activate Govern the Guildless by paying {1}{U} and revealing it from your hand, making a creature you control all colors until end of turn.
Activate Faeburrow Elder by tapping it, adding {W}{U}{B}{R}{G}.
Activate Seedcradle Witch by paying {2}{W}{G}, giving Faeburrow Elder +3/+3 until end of turn and untapping it.
Repeat from step 2.

---

# 57-232-1636

**Cards:**

- Priest of Urabrask
- Feldon of the Third Path
- Intruder Alarm

**Produces:** Infinite creature tokens with haste, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite untap of creatures, Infinite mana creatures you control can produce

**Mana: {2}{R}, MV: 3, Colors: UR, Popularity: 8**

**Steps:**

Activate Feldon by tapping it and paying {2}{R}, creating an artifact token copy of Priest of Urabrask with haste.
The token copy of Priest of Urabrask and Intruder Alarm trigger.
Resolve the Priest of Urabrask trigger, adding {R}{R}{R}.
Resolve the Intruder Alarm trigger, untapping all creatures.
Repeat.

---

# 572-5125-5218

**Cards:**

- Dream Halls
- Sandstorm Eidolon
- Sparkcaster

**Produces:** Infinite damage, Infinite ETB, Infinite LTB, Infinite self-discard triggers, Infinite storm count

**Mana: , MV: 0, Colors: GUR, Popularity: 2**

**Steps:**

Cast Sparkcaster by discarding Sandstorm Eidolon.
Sandstorm Eidolon triggers from your graveyard, returning from your graveyard to your hand.
Sparkcaster enters the battlefield, triggering twice.
Resolve the first Sparkcaster trigger, dealing 1 damage to target player or planeswalker.
Resolve the second Sparkcaster trigger, returning Sparkcaster from the battlefield to your hand.
Repeat.

---

# 574-628

**Cards:**

- Vish Kal, Blood Arbiter
- Mikaeus, the Unhallowed

**Produces:** Infinite -1/-1 to any number of target creatures, Infinite death triggers, Infinite ETB

**Mana: , MV: 0, Colors: WB, Popularity: 308**

**Steps:**

Sacrifice Vish Kal to his first ability, triggering Undying, which will return Vish Kal to the battlefield with a +1/+1 counter.
Remove the +1/+1 counter with Vish Kal's second ability, targeting any other creature or Vish Kal, if all the other creatures are dead.
Repeat steps 1-2.

---

# 578-2645

**Cards:**

- Staff of Domination
- Metalworker

**Produces:** Infinite card draw, Infinite colorless mana, Infinite draw triggers, Infinite lifegain, Infinite lifegain triggers, Infinite untap of creatures you control, Infinite mana creatures you control can produce

**Mana: , MV: 0, Colors: C, Popularity: 8698**

**Steps:**

Activate Metalworker by tapping it, adding at least six {C}.
Activate Staff of Domination's third ability by paying {3} and tapping it, untapping Metalworker.
Activate Staff of Domination's first ability by paying {1}, untapping it.
Repeat.

---

# 578-2816

**Cards:**

- Umbral Mantle
- Metalworker

**Produces:** Infinite colorless mana, Infinitely large creature until end of turn, Infinite untap of creatures you control, Infinite mana creatures you control can produce

**Mana: , MV: 0, Colors: C, Popularity: 1142**

**Steps:**

Activate Metalworker by tapping it, revealing at least two artifact cards from your hand and adding at least {C}{C}{C}{C}.
Activate Metalworker by paying {3} and untapping it, giving it +2/+2 until end of turn.
Repeat.

---

# 578-5200

**Cards:**

- Sword of the Paruns
- Metalworker

**Produces:** Infinite colorless mana, Infinite untap of creatures you control, Infinite mana creatures you control can produce

**Mana: , MV: 0, Colors: C, Popularity: 199**

**Steps:**

Activate Metalworker by tapping it, revealing at least two artifact cards in your hand and adding at least {C}{C}{C}{C}.
Activate Sword of the Paruns by paying {3}, untapping Metalworker
Repeat.

---

# 579-1247-2033

**Cards:**

- Pili-Pala
- Mana Reflection
- Citanul Hierophants

**Produces:** Infinite colored mana

**Mana: , MV: 0, Colors: G, Popularity: 8**

**Steps:**

Activate Pili-Pala using Paradise Mantle's ability by tapping it, adding {G}{G}.
Activate Pili-Pala's other ability by paying {2} and untapping it, adding two mana of any one color.
Repeat.

---

# 579-1247-2464

**Cards:**

- Pili-Pala
- Mana Reflection
- Song of Freyalise

**Produces:** Infinite colored mana

**Mana: , MV: 0, Colors: G, Popularity: 7**

**Steps:**

Activate Pili-Pala using Paradise Mantle's ability by tapping it, adding two mana of any one color.
Activate Pili-Pala's other ability by paying {2} and untapping it, adding two mana of any one color.
Repeat.

---

# 579-1247-4289

**Cards:**

- Pili-Pala
- Mana Reflection
- Cryptolith Rite

**Produces:** Infinite colored mana

**Mana: , MV: 0, Colors: G, Popularity: 69**

**Steps:**

Activate Pili-Pala using Paradise Mantle's ability by tapping it, adding two mana of any one color.
Activate Pili-Pala's other ability by paying {2} and untapping it, adding two mana of any one color.
Repeat.

---

# 579-1247-4474

**Cards:**

- Pili-Pala
- Mana Reflection
- Paradise Mantle

**Produces:** Infinite colored mana

**Mana: , MV: 0, Colors: G, Popularity: 44**

**Steps:**

Activate Pili-Pala using Paradise Mantle's ability by tapping it, adding two mana of any one color.
Activate Pili-Pala's other ability by paying {2} and untapping it, adding two mana of any one color.
Repeat.

---

# 579-1588-4762

**Cards:**

- Ezuri, Renegade Leader
- Devoted Druid
- Mana Reflection

**Produces:** Infinite green mana, Infinite power and toughness for certain creatures until end of turn, Infinite +1/+1 counters on creatures you control

**Mana: {G}, MV: 1, Colors: G, Popularity: 312**

**Steps:**

Activate Devoted Druid's first ability by tapping it, adding {G}{G}.
Activate Devoted Druid's second ability by putting a -1/-1 counter on it, untapping it.
Activate Devoted Druid's first ability by tapping it, adding {G}{G}.
Activate Ezuri's second ability by paying {2}{G}{G}{G}, causing all Elves you control to get +3/+3 and gain trample until end of turn.
Activate Devoted Druid's second ability by putting a -1/-1 counter on it, untapping it.
Activate Devoted Druid's first ability by tapping it, adding {G}{G}.
 Activate Devoted Druid's second ability by putting a -1/-1 counter on it, untapping it.
Repeat.

---

# 579-2585

**Cards:**

- Grim Monolith
- Mana Reflection

**Produces:** Infinite colorless mana

**Mana: , MV: 0, Colors: G, Popularity: 708**

**Steps:**

Activate Grim Monolith's first ability by tapping it, adding {6}.
Activate Grim Monolith's last ability by paying {3}, untapping it.
Repeat.

---

# 579-3360-4474

**Cards:**

- Torchling
- Paradise Mantle
- Mana Reflection

**Produces:** Infinite colored mana

**Mana: , MV: 0, Colors: RG, Popularity: 0**

**Steps:**

Equip Paradise Mantle onto Torchling.
Tap Torchling to add {R}{R}.
Spend that mana to untap Torchling.
Repeat.

---

# 579-4131

**Cards:**

- Basalt Monolith
- Mana Reflection

**Produces:** Infinite colorless mana

**Mana: , MV: 0, Colors: G, Popularity: 2797**

**Steps:**

Activate Basalt Monolith's first ability by tapping it, adding {6}.
Activate Basalt Monolith's last ability by paying {3}, untapping it.
Repeat.

---

# 586-2034-5003

**Cards:**

- Priest of Gix
- Nim Deathmantle
- Ashnod's Altar

**Produces:** Infinite black mana, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: {2}, MV: 2, Colors: B, Popularity: 821**

**Steps:**

Activate Ashnod's Altar by sacrificing Priest of Gix adding {C}{C}.
Priest of Gix dies, triggering Nim Deathmantle, causing you to pay {4} to return Priest of Gix from your graveyard to the battlefield, and attach Nim Deathmantle to it.
Priest of Gix enters the battlefield, adding {B}{B}{B}.
Repeat.

---

# 586-2451-3069-5256

**Cards:**

- Sedris, the Traitor King
- Void Maw
- Altar of Dementia
- Priest of Gix

**Produces:** Infinite ETB, Infinite LTB, Infinitely large creature until end of turn, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: {2}{B}, MV: 3, Colors: UBR, Popularity: 3**

**Steps:**

Activate Altar of Dementia by sacrificing Priest of Gix, causing target player to mill cards equal to Priest of Gix's power.
Activate Priest of Gix's unearth ability by paying {2}{B}, returning it from your graveyard to the battlefield, giving it haste and exiling it at end of turn or when it leaves the battlefield.
Priest of Gix enters the battlefield, adding {B}{B}{B}.
Activate Altar of Dementia by sacrificing Priest of Gix.
Both Priest of Gix's undying ability and Void Maw attempt to exile Priest of Gix when it would be put into your graveyard.
Choose to apply the Void Maw replacement effect, exiling Priest of Gix.
Resolve the Altar of Dementia ability, causing target player to mill cards equal to Priest of Gix's power.
Activate Void Maw by putting Priest of Gix from exile into your graveyard, giving Void Maw +2/+2 until end of turn.
Repeat from step 2.

---

# 586-3249-4050

**Cards:**

- Havengul Lich
- Phyrexian Altar
- Priest of Gix

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {3}, MV: 3, Colors: UB, Popularity: 15**

**Steps:**

Activate Phyrexian Altar by sacrificing Priest of Gix, adding {B}.
Activate Havengul Lich by paying {1}, allowing you to cast Priest of Gix from your graveyard this turn.
Cast Priest of Gix from your graveyard by paying {2}{B}.
Priest of Gix enters the battlefield, adding {B}{B}{B}.
Repeat.

---

# 586-4050-5003

**Cards:**

- Priest of Gix
- Nim Deathmantle
- Phyrexian Altar

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: {3}, MV: 3, Colors: B, Popularity: 484**

**Steps:**

Activate Phyrexian Altar by sacrificing Priest of Gix adding one mana of any color.
Priest of Gix dies, triggering Nim Deathmantle, causing you to pay {4} to return Priest of Gix from your graveyard to the battlefield, and attach Nim Deathmantle to it.
Priest of Gix enters the battlefield, adding {B}{B}{B}.
Repeat.

---

# 586-4871-5003-5256

**Cards:**

- Nim Deathmantle
- Priest of Gix
- Altar of Dementia
- Pitiless Plunderer

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill

**Mana: {3} to start the combo, MV: 3, Colors: B, Popularity: 91**

**Steps:**

Sacrifice Priest of Gix to Altar of Dementia, milling target opponent for 2.
Pitiless Plunderer and Nim Deathmantle triggers; resolve them in that order.
Pitiless Plunderer generates a Treasure token, crack it to float {B}.
Resolve Nim Deathmantle's triggered ability, paying {4} to recur Priest of Gix to the battlefield (spending initial {3}).
Priest of Gix's ETB trigger adds three {B}.
Repeat from the top, milling target opponent infinitely.

---

# 586-618-1537-1799-3189-4738

**Cards:**

- Doomsday
- Grenzo, Dungeon Warden
- Zealous Conscripts
- Goblin Sledder
- Kiki-Jiki, Mirror Breaker
- Priest of Gix

**Produces:** Infinite creature tokens with haste, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: {2}{B}{B}{B}, MV: 5, Colors: BR, Popularity: 76**

**Steps:**

Cast Doomsday by paying {B}{B}{B}, searching your library and graveyard for one any other card, Zealous Conscripts, Goblin Sledder, Kiki-Jiki, and Priest of Gix, exiling all other cards from your graveyard and library, and then placing the remaining cards on top of your library in the order previously listed and losing half your life, rounded up.
Activate Grenzo by paying {2}, putting Priest of Gix into your graveyard and then onto the battlefield, adding {B}{B}{B}.
Activate Grenzo by paying {2}, putting Kiki-Jiki into your graveyard and then onto the battlefield.
Activate Kiki-Jiki by tapping, creating a token copy of Priest of Gix.
Token copy of Priest of Gix entering the battlefield, adding {B}{B}{B}.
Activate Grenzo by paying {2}, putting Goblin Sledder into your graveyard and then onto the battlefield.
Activate Goblin Sledder by sacrificing it, giving Grenzo +1/+1 until end of turn.
Activate Grenzo by paying {2}, putting Zealous Conscripts into your graveyard and then onto the battlefield, untapping Kiki-Jiki.
Activate Kiki-Jiki by tapping, creating a token copy of Zealous Conscripts.
Repeat from step 8.

---

# 587-3205-5218

**Cards:**

- Dream Halls
- Aurora Eidolon
- Sawtooth Loon

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count, Reorder your library, putting a number of cards into your hand equal to the amount of extra cards you had in your hand

**Mana: , MV: 0, Colors: WU, Popularity: 7**

**Steps:**

Discard Eidolon to Dream Halls' effect to cast Loon.
Return Eidolon to your hand.
When Loon enters, draw two cards and put two cards on the bottom of your library and return Loon to your hand.
Repeat.

---

# 587-4557-5218

**Cards:**

- Dream Halls
- Enigma Eidolon
- Sawtooth Loon

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count, Reorder your library, putting a number of cards into your hand equal to the amount of extra cards you had in your hand

**Mana: , MV: 0, Colors: WU, Popularity: 12**

**Steps:**

Discard Eidolon to Dream Halls' effect to cast Loon.
Return Eidolon to your hand.
When Loon enters, draw two cards and put two cards on the bottom of your library and return Loon to your hand.
Repeat.

---

# 589-1274-2428

**Cards:**

- Fathom Mage
- Horizon Chimera
- Heliod, Sun-Crowned

**Produces:** Near-infinite lifegain, Near-infinite lifegain triggers, Infinite card draw, Infinite draw triggers, Near-infinite +1/+1 counters on a creature

**Mana: {2}{G}{U}, MV: 4, Colors: GWU, Popularity: 37**

**Steps:**

Cast Horizon Chimera by paying {2}{U}{G}.
Horizon Chimera enters the battlefield, triggering Fathom Mage.
Resolve Fathom Mage's trigger, putting a +1/+1 counter on Fathom Mage and drawing a card.
Horizon Chimera triggers, gaining you 1 life.
Heliod triggers, putting a +1/+1 counter on Fathom Mage.
Repeat from step 3.

---

# 589-2428-2919

**Cards:**

- Fathom Mage
- Archangel of Thune
- Horizon Chimera

**Produces:** Near-infinite lifegain, Infinite card draw, Near-infinite lifegain triggers, Infinite draw triggers, Near-infinite +1/+1 counters

**Mana: {2}{G}{U}, MV: 4, Colors: GWU, Popularity: 47**

**Steps:**

Cast Horizon Chimera by paying {2}{G}{U}.
Horizon Chimera enters the battlefield, triggering Fathom Mage.
Resolve Fathom Mage's trigger, putting a +1/+1 counter on Fathom Mage and drawing a card.
Horizon Chimera triggers, gaining you 1 life.
Archangel of Thune triggers, putting a +1/+1 counter on each creatures you control.
Repeat from step 3.

---

# 593-2484-2615

**Cards:**

- Tree of Perdition
- Blasphemous Act
- Mogg Maniac

**Produces:** Target opponent loses the game

**Mana: , MV: 0, Colors: BR, Popularity: 37**

**Steps:**

Activate Tree of Perdition, exchanging target opponent's life total with Tree of Perdition's toughness.
Cast Blasphemous Act, dealing thirteen damage to all creatures.
Mogg Maniac triggers, dealing thirteen damage to target opponent.

---

# 593-2615-4150

**Cards:**

- Tree of Perdition
- Shivan Meteor
- Mogg Maniac

**Produces:** Target opponent loses the game

**Mana: {3}{R}{R}, MV: 5, Colors: BR, Popularity: 8**

**Steps:**

Activate Tree of Perdition, exchanging target opponent's life total with Tree of Perdition's toughness.
Cast Shivan Meteor for {3}{R}{R}, dealing thirteen damage to Mogg Maniac.
Mogg Maniac triggers, dealing 20 damage to target opponent.

---

# 593-2615-4752

**Cards:**

- Tree of Perdition
- Into the Maw of Hell
- Mogg Maniac

**Produces:** Target opponent loses the game

**Mana: {4}{R}{R}, MV: 6, Colors: BR, Popularity: 5**

**Steps:**

Activate Tree of Perdition, exchanging target opponent's life total with Tree of Perdition's toughness.
Cast Into the Maw of Hell for {4}{R}{R}, destroying target land and dealing thirteen damage to Mogg Maniac.
Mogg Maniac triggers, dealing 20 damage to target opponent.

---

# 595-2452-2577

**Cards:**

- Gravecrawler
- Rooftop Storm
- Nantuko Husk

**Produces:** Infinite ETB, Infinite LTB, Infinitely large creature, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: UB, Popularity: 1083**

**Steps:**

Activate Nantuko Husk's ability by sacrificing Gravecrawler, Nantuko gets +2/+2 until end of turn.
Cast Gravecrawler from your graveyard by paying {0}.
Repeat.

---

# 597-1048-1267-4600-5241

**Cards:**

- Medomai the Ageless
- Sakashima's Student
- Mirror Gallery
- Soltari Foot Soldier
- Equilibrium

**Produces:** Infinite turns, Lock

**Mana: {2}{U}{U} each turn, MV: 4, Colors: WU, Popularity: 0**

**Steps:**

Declare Soltari Foot Soldier as an attacker.
During the declare blockers phase, when you recieve priority, activate Sakashima's Student's Ninjutsu ability by paying {1}{U} and returning Soltari Foot Soldier from the battlefield to your hand, putting Sakashima's Student from your hand onto the battlefield tapped and attacking as a copy of Medomai.
Deal combat damage with Sakashima's Student, causing you to take an additional turn after this one.
Cast Soltari Foot Soldier by paying {W}.
Equilibrium triggers, causing you to pay {1} to return Sakashima's Student from the battlefield to your hand.
Pass the turn.
Repeat.

---

# 597-1267-3395-4600-5241

**Cards:**

- Medomai the Ageless
- Sakashima's Student
- Mirror Gallery
- Soltari Foot Soldier
- Crystal Shard

**Produces:** Infinite turns, Lock

**Mana: {1}{U}{U}{W} each turn, MV: 4, Colors: WU, Popularity: 0**

**Steps:**

Declare Soltari Foot Soldier as an attacker.
During the declare blockers phase, when you recieve priority, activate Sakashima's Student's Ninjutsu ability by paying {1}{U} and returning Soltari Foot Soldier from the battlefield to your hand, putting Sakashima's Student from your hand onto the battlefield tapped and attacking as a copy of Medomai.
Deal combat damage with Sakashima's Student, causing you to take an additional turn after this one.
Cast Soltari Foot Soldier by paying {W}.
Activate Crystal Shard by paying {U} and tapping it, returning Sakashima's Student from the battlefield to your hand.
Pass the turn.
Repeat.

---

# 597-1267-3423-4600-5241

**Cards:**

- Medomai the Ageless
- Sakashima's Student
- Mirror Gallery
- Soltari Foot Soldier
- Aegis Automaton

**Produces:** Infinite turns, Lock

**Mana: {5}{U}{W}{W} each turn, MV: 8, Colors: WU, Popularity: 0**

**Steps:**

Declare Soltari Foot Soldier as an attacker.
During the declare blockers phase, when you recieve priority, activate Sakashima's Student's Ninjutsu ability by paying {1}{U} and returning Soltari Foot Soldier from the battlefield to your hand, putting Sakashima's Student from your hand onto the battlefield tapped and attacking as a copy of Medomai.
Deal combat damage with Sakashima's Student, causing you to take an additional turn after this one.
Cast Soltari Foot Soldier by paying {W}.
Activate Aegis Automaton by paying {4}{W}, returning Sakashima's Student from the battlefield to your hand.
Pass the turn.
Repeat.

---

# 597-1267-3632-4600-5241

**Cards:**

- Medomai the Ageless
- Sakashima's Student
- Mirror Gallery
- Soltari Foot Soldier
- Erratic Portal

**Produces:** Infinite turns, Lock

**Mana: {2}{U}{W} each turn, MV: 4, Colors: WU, Popularity: 0**

**Steps:**

Declare Soltari Foot Soldier as an attacker.
During the declare blockers phase, when you recieve priority, activate Sakashima's Student's Ninjutsu ability by paying {1}{U} and returning Soltari Foot Soldier from the battlefield to your hand, putting Sakashima's Student from your hand onto the battlefield tapped and attacking as a copy of Medomai.
Deal combat damage with Sakashima's Student, causing you to take an additional turn after this one.
Cast Soltari Foot Soldier by paying {W}.
Activate Erratic Portal by paying {1} and tapping it, returning Sakashima's Student from the battlefield to your hand.
Pass the turn.
Repeat.

---

# 600-1124-1180

**Cards:**

- Jace, Cunning Castaway
- Nicol Bolas, Dragon-God
- The Chain Veil

**Produces:** Exile all permanents opponents control, Infinite card draw, Infinite creature tokens, Infinite draw triggers, Infinite ETB, Infinite copies of a specific planeswalker, Mass Land Denial

**Mana: {4}, MV: 4, Colors: UBR, Popularity: 731**

**Steps:**

Activate The Chain Veil by paying {4} and tapping it, allowing you to activate each planeswalker's loyalty abilities an extra time this turn.
Activate Nicol Bolas using Jace's first loyalty ability by putting a loyalty counter on it, causing you to loot whenever a creature you control deals combat damage to a player this turn.
Activate Nicol Bolas using Jace's third loyalty ability by removing five loyalty counters from it, creating two copies of Nicol Bolas.
Repeat from step 2 using a Nicol Bolas token instead.

---

# 600-1180-1677

**Cards:**

- Jace, Cunning Castaway
- Nicol Bolas, Dragon-God
- Chandra, Acolyte of Flame

**Produces:** Infinite copies of a specific planeswalker

**Mana: , MV: 0, Colors: UBR, Popularity: 135**

**Steps:**

Activate Chandra's first loyalty ability by putting zero loyalty counters on it, putting a loyalty counter on each planeswalker you control.
Activate Nicol Bolas using Jace's third loyalty ability by removing five loyalty counters from it, creating two copies of Nicol Bolas.
Activate a Nicol Bolas token using Chandra's first loyalty ability by putting zero loyalty counters on it, putting a loyalty counter on each planeswalker you control.
Activate the other Nicol Bolas token using Jace's third loyalty ability by removing five loyalty counters from it, creating two copies of Nicol Bolas.
Repeat from step 3.

---

# 600-1180-2369

**Cards:**

- Jace, Cunning Castaway
- Nicol Bolas, Dragon-God
- Oath of Teferi

**Produces:** Exile all permanents opponents control, Infinite card draw, Infinite creature tokens, Infinite draw triggers, Infinite ETB, Infinite copies of a specific planeswalker, Mass Land Denial

**Mana: , MV: 0, Colors: WUBR, Popularity: 435**

**Steps:**

Activate Nicol Bolas using Jace's first loyalty ability by putting a loyalty counter on it, causing you to loot whenever a creature you control deals combat damage to a player this turn.
Activate Nicol Bolas using Jace's third loyalty ability by removing five loyalty counters from it, creating two copies of Nicol Bolas.
Repeat using a Nicol Bolas token instead.

---

# 600-1180-3062

**Cards:**

- Jace, Cunning Castaway
- Nicol Bolas, Dragon-God
- Pir, Imaginative Rascal

**Produces:** Exile all permanents opponents control, Infinite card draw, Infinite creature tokens, Infinite draw triggers, Infinite ETB, Infinite copies of a specific planeswalker, Mass Land Denial

**Mana: , MV: 0, Colors: UBRG, Popularity: 58**

**Steps:**

Activate Nicol Bolas using Jace's third loyalty ability by removing five loyalty counters from it, creating two copies of Nicol Bolas that enter with five loyalty counters each.
Repeat using a Nicol Bolas token instead.

---

# 600-1180-4329

**Cards:**

- Jace, Cunning Castaway
- Nicol Bolas, Dragon-God
- Oath of Gideon

**Produces:** Exile all permanents opponents control, Infinite card draw, Infinite creature tokens, Infinite draw triggers, Infinite ETB, Infinite copies of a specific planeswalker, Mass Land Denial

**Mana: , MV: 0, Colors: WUBR, Popularity: 162**

**Steps:**

Activate Nicol Bolas using Jace's third loyalty ability by removing five loyalty counters from it, creating two copies of Nicol Bolas that enter with five loyalty counters each.
Repeat using a Nicol Bolas token instead.

---

# 601-2102-3206

**Cards:**

- Manascape Refractor
- Mutavault
- Griffin Canyon

**Produces:** Infinitely large creature until end of turn

**Mana: {1}, MV: 1, Colors: C, Popularity: 81**

**Steps:**

Activate Manascape Refractor using Mutavault's second ability by paying {1}, causing Manascape Refractor to become a 2/2 creature with all creature types until end of turn.
Activate Manascape Refractor using Griffin Canyon's second ability by tapping it, untapping Manascape Refractor and giving it +1/+1 until end of turn.
Repeat step 2.

---

# 608-1209-1636-3141-5168

**Cards:**

- Xyris, the Writhing Storm
- Jace's Archivist
- Intruder Alarm
- Bloom Tender
- Kozilek, Butcher of Truth

**Produces:** Infinite creature tokens, Infinite death triggers, Infinite draw triggers, Infinite draw triggers for each opponent, Infinite ETB, Infinite LTB, Infinite looting, Infinite looting for opponents, Infinite mana creatures you control can produce, Infinite mana of colors among permanents you control, Infinite sacrifice triggers, Infinite self-discard triggers, Infinite self-discard triggers for opponents, Infinite untap of creatures

**Mana: , MV: 0, Colors: GUR, Popularity: 3**

**Steps:**

Activate Bloom Tender by tapping it, adding at least {U}{R}{G}.
Activate Jace's Archivist by paying {U} and tapping it, causing each player to discard their hand and draw cards equal to the greatest number of cards discarded by a single player this way.
Xyris triggers once for each card your opponent draw, and Kozilek triggers if it was discarded.
Resolve the first Xyris trigger, creating a 1/1 Snake creature token.
The Snake enters the battlefield, triggering Intruder Alarm, untapping all creatures.
Activate Bloom Tender by tapping it, adding at least {U}{R}{G}.
Repeat from step 4 for each remaining Xyris trigger.
Resolve the Kozilek trigger from step 3, if applicable, causing you to shuffle your graveyard into your library.
Repeat from step 2.

---

# 608-969-3259

**Cards:**

- Xyris, the Writhing Storm
- Breath of Fury
- Fervor

**Produces:** Infinite card draw, Infinite draw triggers, Near-infinite creature tokens with haste, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite untap of creatures you control, Near-infinite mana creatures you control can produce, Near-infinite combat phases

**Mana: , MV: 0, Colors: GUR, Popularity: 16**

**Steps:**

Deal combat damage with Xyris and the creature with Breath of Fury attached.
Xyris and Breath of Fury trigger.
Resolve the Xyris trigger, causing you and the opponent dealt combat damage to draw cards equal to the damage dealt by Xyris.
Xyris triggers for each card the opponent draws, creating that many 1/1 Snake creature tokens.
Resolve the Breath of Fury trigger, sacrificing the enchanted creature, attaching Breath of Fury to a Snake token, untapping all creatures you control and getting an additional combat phase after this one.
Repeat.


---

# 6-1310-5261

**Cards:**

- Isochron Scepter
- Vitalize
- Karn's Touch

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: {U}{U}, MV: 2, Colors: GU, Popularity: 10**

**Steps:**

Cast Karn's Touch by paying {U}{U}, targeting Isochron Scepter, causing it to become an artifact creature until end of turn.
Activate creatures you control by tapping those, adding {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Vitalize without paying its mana cost, untapping all creatures.
Repeat from step 2.


---

# 6-1358-5261

**Cards:**

- Isochron Scepter
- Vitalize
- Sydri, Galvanic Genius

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: {U}, MV: 1, Colors: GWUB, Popularity: 2**

**Steps:**

Activate Sydri's first ability by paying {U}, causing Isochron Scepter to become an artifact creature until end of turn.
Activate creatures you control by tapping those, adding {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Vitalize without paying its mana cost, untapping all creatures.
Repeat from step 2.


---

# 614-1283-1518-1987

**Cards:**

- Ghostly Flicker
- Will Kenrith
- Nucklavee
- Chromatic Orrery

**Produces:** Infinite card draw, Infinite colored mana, Infinite colorless mana, Infinite draw triggers, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count

**Mana: , MV: 0, Colors: UR, Popularity: 0**

**Steps:**

Activate Will Kenrith's -2 ability targeting yourself, reducing the cost of your instant, sorcery, and planeswalker spells by {2} until end of turn and drawing you 2 cards.
Activate Chromatic Orrery's first activated ability by tapping it, adding {C}{C}{C}{C}{C}.
Cast Ghostly Flicker by paying {C}, targeting Chromatic Orrery and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
Repeat.
Once you have infinite mana, you may activate Chromatic Orrery's last ability any number of times.

---

# 614-1283-1987-2427

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Nucklavee
- Chromatic Orrery

**Produces:** Infinite card draw, Infinite colored mana, Infinite colorless mana, Infinite draw triggers, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count

**Mana: , MV: 0, Colors: UR, Popularity: 1**

**Steps:**

Activate Chromatic Orrery's first activated ability by tapping it, adding {C}{C}{C}{C}{C}.
Cast Ghostly Flicker by paying {C}, targeting Chromatic Orrery and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
Repeat.
Once you have infinite mana, you may activate Chromatic Orrery's last ability any number of times.

---

# 614-1283-1987-2510

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Nucklavee
- Chromatic Orrery

**Produces:** Infinite card draw, Infinite colored mana, Infinite colorless mana, Infinite draw triggers, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count

**Mana: , MV: 0, Colors: UR, Popularity: 4**

**Steps:**

Activate Chromatic Orrery's first activated ability by tapping it, adding {C}{C}{C}{C}{C}.
Cast Ghostly Flicker by paying {C}, targeting Chromatic Orrery and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
Repeat.
Once you have infinite mana, you may activate Chromatic Orrery's last ability any number of times.

---

# 614-1283-1987-3075

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Nucklavee
- Chromatic Orrery

**Produces:** Infinite card draw, Infinite colored mana, Infinite colorless mana, Infinite draw triggers, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count

**Mana: , MV: 0, Colors: UR, Popularity: 3**

**Steps:**

Activate Chromatic Orrery's first activated ability by tapping it, adding {C}{C}{C}{C}{C}.
Cast Ghostly Flicker by paying {C}, targeting Chromatic Orrery and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
Repeat.
Once you have infinite mana, you may activate Chromatic Orrery's last ability any number of times.

---

# 614-1518-1964-1987

**Cards:**

- Ghostly Flicker
- Will Kenrith
- Nucklavee
- Meteorite

**Produces:** Infinite damage, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count

**Mana: , MV: 0, Colors: UR, Popularity: 2**

**Steps:**

Activate Will Kenrith's -2 ability targeting yourself, reducing the cost of your instant, sorcery, and planeswalker spells by {2} until end of turn and drawing you 2 cards.
Activate Meteorite by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Meteorite and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
When Meteorite enters the battlefield, deal 2 damage to any target.
Repeat.

---

# 614-1518-1987

**Cards:**

- Will Kenrith
- Ghostly Flicker
- Nucklavee

**Produces:** Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count

**Mana: , MV: 0, Colors: UR, Popularity: 4**

**Steps:**

Activate Will's second ability by removing two loyalty counters from it, causing target player to draw two cards and causing all instant, sorcery and planeswalker spells you cast to cost {2} less this turn.
Activate the aritfact and/or land by tapping it, adding at least {U}.
Cast Ghostly Flicker by paying {U}, blinking Nucklavee and the artifact and/or land.
Nucklavee enters the battlefield, triggering its first and second ability.
Resolve the first trigger, choosing not to return any red sorcery to your hand.
Resolve the second trigger, returning Ghostly Flicker from the graveyard to your hand.
Repeat.

---

# 614-1518-1987-3448

**Cards:**

- Ghostly Flicker
- Will Kenrith
- Nucklavee
- Stadium Vendors

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count

**Mana: {U}, MV: 1, Colors: UR, Popularity: 1**

**Steps:**

Cast Ghostly Flicker by paying {U}, targeting Stadium Vendors and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
When Stadium Vendors enters the battlefield, add {U}{U}.
Repeat.

---

# 614-1518-1987-3573

**Cards:**

- Ghostly Flicker
- Will Kenrith
- Nucklavee
- Tolarian Academy

**Produces:** Infinite blue mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count

**Mana: , MV: 0, Colors: UR, Popularity: 0**

**Steps:**

Activate Will Kenrith's -2 ability targeting yourself, reducing the cost of your instant, sorcery, and planeswalker spells by {2} until end of turn and drawing you 2 cards.
Activate Tolarian Academy by tapping it, adding at least {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Tolarian Academy and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
Repeat.

---

# 614-1518-1987-3941

**Cards:**

- Ghostly Flicker
- Will Kenrith
- Nucklavee
- Coveted Jewel

**Produces:** Infinite card draw, Infinite draw triggers, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Near-infinite colored mana, Near-infinite ETB, Near-infinite LTB, Near-infinite storm count

**Mana: , MV: 0, Colors: UR, Popularity: 1**

**Steps:**

Activate Will Kenrith's -2 ability targeting yourself, reducing the cost of your instant, sorcery, and planeswalker spells by {2} until end of turn and drawing you 2 cards.
Activate Coveted Jewel by tapping it, adding {U}{U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Coveted Jewel and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
When Coveted Jewel enters the battlefield, draw three cards.
Repeat.

---

# 614-1518-1987-4714

**Cards:**

- Ghostly Flicker
- Will Kenrith
- Nucklavee
- Mana Geode

**Produces:** Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite scry 1, Infinite storm count

**Mana: , MV: 0, Colors: UR, Popularity: 2**

**Steps:**

Activate Will Kenrith's -2 ability targeting yourself, reducing the cost of your instant, sorcery, and planeswalker spells by {2} until end of turn and drawing you 2 cards.
Activate Mana Geode by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Mana Geode and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
When Mana Geode enters the battlefield, scry 1.
Repeat.

---

# 614-1518-1987-4792

**Cards:**

- Ghostly Flicker
- Will Kenrith
- Nucklavee
- Paradise Plume

**Produces:** Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite magecraft triggers, Infinite storm count

**Mana: , MV: 0, Colors: UR, Popularity: 0**

**Steps:**

Activate Will Kenrith's -2 ability targeting yourself, reducing the cost of your instant, sorcery, and planeswalker spells by {2} until end of turn and drawing you 2 cards.
Activate Paradise Plume by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Paradise Plume and Nucklavee, blinking them as well as triggering Paradise Plume to gain you 1 life.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
When Paradise Plume enters the battlefield, choose "blue".
Repeat.

---

# 614-1518-1987-5116

**Cards:**

- Ghostly Flicker
- Will Kenrith
- Nucklavee
- Gilded Lotus

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count

**Mana: , MV: 0, Colors: UR, Popularity: 3**

**Steps:**

Activate Will Kenrith's -2 ability targeting yourself, reducing the cost of your instant, sorcery, and planeswalker spells by {2} until end of turn and drawing you 2 cards.
Activate Gilded Lotus by tapping it, adding {U}{U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Gilded Lotus and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
Repeat.

---

# 614-1964-1987-2427

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Nucklavee
- Meteorite

**Produces:** Infinite damage, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count

**Mana: , MV: 0, Colors: UR, Popularity: 0**

**Steps:**

Activate Meteorite by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Meteorite and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
When Meteorite enters the battlefield, deal 2 damage to any target.
Repeat.

---

# 614-1964-1987-2510

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Nucklavee
- Meteorite

**Produces:** Infinite damage, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count

**Mana: , MV: 0, Colors: UR, Popularity: 1**

**Steps:**

Activate Meteorite by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Meteorite and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
When Meteorite enters the battlefield, deal 2 damage to any target.
Repeat.

---

# 614-1964-1987-3075

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Nucklavee
- Meteorite

**Produces:** Infinite damage, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count

**Mana: , MV: 0, Colors: UR, Popularity: 3**

**Steps:**

Activate Meteorite by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Meteorite and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
When Meteorite enters the battlefield, deal 2 damage to any target.
Repeat.

---

# 614-1987-2427

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Nucklavee

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count

**Mana: {U}, MV: 1, Colors: UR, Popularity: 2**

**Steps:**

Cast Ghostly Flicker by paying {U}, targeting Nucklavee and your untapped source, blinking them both.
When Nucklavee enters the battlefield, return Ghostly Flicker to your hand.
Tap your untapped blue source for {U}.
Repeat.

---

# 614-1987-2427-3448

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Nucklavee
- Stadium Vendors

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count

**Mana: {U}, MV: 1, Colors: UR, Popularity: 0**

**Steps:**

Cast Ghostly Flicker by paying {U}, targeting Stadium Vendors and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
When Stadium Vendors enters the battlefield, add {U}{U}.
Repeat.

---

# 614-1987-2427-3573

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Nucklavee
- Tolarian Academy

**Produces:** Infinite blue mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count

**Mana: , MV: 0, Colors: UR, Popularity: 0**

**Steps:**

Activate Tolarian Academy by tapping it, adding at least {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Tolarian Academy and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
Repeat.

---

# 614-1987-2427-3941

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Nucklavee
- Coveted Jewel

**Produces:** Infinite card draw, Infinite draw triggers, Infinite ETB, Infinite LTB, Infinite storm count, Near-infinite colored mana, Near-infinite ETB, Near-infinite LTB, Near-infinite storm count

**Mana: , MV: 0, Colors: UR, Popularity: 0**

**Steps:**

Activate Coveted Jewel by tapping it, adding {U}{U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Coveted Jewel and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
When Coveted Jewel enters the battlefield, draw three cards.
Repeat.

---

# 614-1987-2427-4714

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Nucklavee
- Mana Geode

**Produces:** Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite scry 1, Infinite storm count

**Mana: , MV: 0, Colors: UR, Popularity: 0**

**Steps:**

Activate Mana Geode by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Mana Geode and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
When Mana Geode enters the battlefield, scry 1.
Repeat.

---

# 614-1987-2427-4792

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Nucklavee
- Paradise Plume

**Produces:** Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite magecraft triggers, Infinite storm count

**Mana: , MV: 0, Colors: UR, Popularity: 0**

**Steps:**

Activate Paradise Plume by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Paradise Plume and Nucklavee, blinking them as well as triggering Paradise Plume to gain you 1 life.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
When Paradise Plume enters the battlefield, choose "blue".
Repeat.

---

# 614-1987-2427-5116

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Nucklavee
- Gilded Lotus

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count

**Mana: , MV: 0, Colors: UR, Popularity: 2**

**Steps:**

Activate Gilded Lotus by tapping it, adding {U}{U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Gilded Lotus and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
Repeat.

---

# 614-1987-2510

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Nucklavee

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count

**Mana: {U}, MV: 1, Colors: UR, Popularity: 8**

**Steps:**

Cast Ghostly Flicker by paying {U}, targeting Nucklavee and your untapped source, blinking them both.
When Nucklavee enters the battlefield, return Ghostly Flicker to your hand.
Tap your untapped blue source for {U}.
Repeat.

---

# 614-1987-2510-3448

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Nucklavee
- Stadium Vendors

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count

**Mana: {U}, MV: 1, Colors: UR, Popularity: 1**

**Steps:**

Cast Ghostly Flicker by paying {U}, targeting Stadium Vendors and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
When Stadium Vendors enters the battlefield, add {U}{U}.
Repeat.

---

# 614-1987-2510-3573

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Nucklavee
- Tolarian Academy

**Produces:** Infinite blue mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count

**Mana: , MV: 0, Colors: UR, Popularity: 0**

**Steps:**

Activate Tolarian Academy by tapping it, adding at least {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Tolarian Academy and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
Repeat.

---

# 614-1987-2510-3941

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Nucklavee
- Coveted Jewel

**Produces:** Infinite card draw, Infinite draw triggers, Infinite ETB, Infinite LTB, Infinite storm count, Near-infinite colored mana, Near-infinite ETB, Near-infinite LTB, Near-infinite storm count

**Mana: , MV: 0, Colors: UR, Popularity: 1**

**Steps:**

Activate Coveted Jewel by tapping it, adding {U}{U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Coveted Jewel and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
When Coveted Jewel enters the battlefield, draw three cards.
Repeat.

---

# 614-1987-2510-4714

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Nucklavee
- Mana Geode

**Produces:** Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite scry 1, Infinite storm count

**Mana: , MV: 0, Colors: UR, Popularity: 2**

**Steps:**

Activate Mana Geode by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Mana Geode and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
When Mana Geode enters the battlefield, scry 1.
Repeat.

---

# 614-1987-2510-4792

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Nucklavee
- Paradise Plume

**Produces:** Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite magecraft triggers, Infinite storm count

**Mana: , MV: 0, Colors: UR, Popularity: 1**

**Steps:**

Activate Paradise Plume by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Paradise Plume and Nucklavee, blinking them as well as triggering Paradise Plume to gain you 1 life.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
When Paradise Plume enters the battlefield, choose "blue".
Repeat.

---

# 614-1987-2510-5116

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Nucklavee
- Gilded Lotus

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count

**Mana: , MV: 0, Colors: UR, Popularity: 5**

**Steps:**

Activate Gilded Lotus by tapping it, adding {U}{U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Gilded Lotus and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
Repeat.

---

# 614-1987-3075

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Nucklavee

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count

**Mana: {U}, MV: 1, Colors: UR, Popularity: 11**

**Steps:**

Cast Ghostly Flicker by paying {U}, targeting Nucklavee and your untapped source, blinking them both.
When Nucklavee enters the battlefield, return Ghostly Flicker to your hand.
Tap your untapped blue source for {U}.
Repeat.

---

# 614-1987-3075-3448

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Nucklavee
- Stadium Vendors

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count

**Mana: {U}, MV: 1, Colors: UR, Popularity: 3**

**Steps:**

Cast Ghostly Flicker by paying {U}, targeting Stadium Vendors and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
When Stadium Vendors enters the battlefield, add {U}{U}.
Repeat.

---

# 614-1987-3075-3573

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Nucklavee
- Tolarian Academy

**Produces:** Infinite blue mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count

**Mana: , MV: 0, Colors: UR, Popularity: 0**

**Steps:**

Activate Tolarian Academy by tapping it, adding at least {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Tolarian Academy and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
Repeat.

---

# 614-1987-3075-3941

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Nucklavee
- Coveted Jewel

**Produces:** Infinite card draw, Infinite draw triggers, Infinite ETB, Infinite LTB, Infinite storm count, Near-infinite colored mana, Near-infinite ETB, Near-infinite LTB, Near-infinite storm count

**Mana: , MV: 0, Colors: UR, Popularity: 4**

**Steps:**

Activate Coveted Jewel by tapping it, adding {U}{U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Coveted Jewel and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
When Coveted Jewel enters the battlefield, draw three cards.
Repeat.

---

# 614-1987-3075-4714

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Nucklavee
- Mana Geode

**Produces:** Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite scry 1, Infinite storm count

**Mana: , MV: 0, Colors: UR, Popularity: 4**

**Steps:**

Activate Mana Geode by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Mana Geode and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
When Mana Geode enters the battlefield, scry 1.
Repeat.

---

# 614-1987-3075-4792

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Nucklavee
- Paradise Plume

**Produces:** Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite magecraft triggers, Infinite storm count

**Mana: , MV: 0, Colors: UR, Popularity: 4**

**Steps:**

Activate Paradise Plume by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Paradise Plume and Nucklavee, blinking them as well as triggering Paradise Plume to gain you 1 life.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
When Paradise Plume enters the battlefield, choose "blue".
Repeat.

---

# 614-1987-3075-5116

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Nucklavee
- Gilded Lotus

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count

**Mana: , MV: 0, Colors: UR, Popularity: 6**

**Steps:**

Activate Gilded Lotus by tapping it, adding {U}{U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Gilded Lotus and Nucklavee, blinking them.
When Nucklavee enters the battlefield, return Ghostly Flicker to you hand.
Repeat.

---

# 617-1283-2179

**Cards:**

- Kurkesh, Onakke Ancient
- Chromatic Orrery
- Voltaic Key

**Produces:** Infinite card draw, Infinite colored mana, Infinite colorless mana, Infinite draw triggers, Infinite untap of artifacts you control

**Mana: , MV: 0, Colors: R, Popularity: 112**

**Steps:**

Activate Chromatic Orrery's first ability by tapping it, adding {5}.
Activate Voltaic Key by paying {1} and tapping it, targeting itself.
Kurkesh triggers, causing you to pay {1} to copy Voltaic Key's ability, targeting Chromatic Orrery.
Resolve both Voltaic Key abilities, untapping it and Chromatic Orrery.
Repeat.
Once you have a large amount of mana, you may instead use Chromatic Orrey's second ability to draw any number of cards.

---

# 6-1719-5261

**Cards:**

- Vizier of Tumbling Sands
- Isochron Scepter
- Vitalize

**Produces:** Infinite magecraft triggers, Infinite mana creatures you control can produce, Infinite untap of creatures you control

**Mana: , MV: 0, Colors: GU, Popularity: 285**

**Steps:**

Activate creatures by tapping them, adding at least {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Vitalize.
Resolve the copy of Vitalize, untapping all creatures you control.
Activate Vizier of Tumbling Sands by tapping it, untapping Isochron Scepter.
Repeat.

---

# 617-2179-3941

**Cards:**

- Kurkesh, Onakke Ancient
- Coveted Jewel
- Voltaic Key

**Produces:** Infinite colored mana, Infinite mana artifacts you control can produce, Infinite untap of artifacts you control

**Mana: , MV: 0, Colors: R, Popularity: 140**

**Steps:**

Activate Coveted Jewel by tapping it, adding {R}{R}{R}.
Activate Voltaic Key by paying {1} and tapping it, targeting itself.
Kurkesh triggers, causing you to pay {R} to copy Voltaic Key's ability, targeting Coveted Jewel.
Resolve both Voltaic Key abilities, untapping it and Coveted Jewel.
Repeat.

---

# 617-2179-5116

**Cards:**

- Gilded Lotus
- Voltaic Key
- Kurkesh, Onakke Ancient

**Produces:** Infinite colored mana

**Mana: , MV: 0, Colors: R, Popularity: 464**

**Steps:**

Activate Gilded Lotus by tapping it, adding {R}{R}{R}.
Activate Voltaic Key by paying {1} and tapping it, untapping Gilded Lotus.
Kurkesh triggers, causing you to pay {R} to copy Voltaic Key's ability.
Resolve the copy of Voltaic Key's ability, untapping itself.
Repeat.

---

# 6-172-5261

**Cards:**

- Isochron Scepter
- Vitalize
- Skilled Animator

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: {2}{U}, MV: 3, Colors: GU, Popularity: 0**

**Steps:**

Cast Skilled Animator by paying {2}{U}.
Skilled Animator enters the battlefield, targeting Isochron Scepter, causing it to become an artifact creature until end of turn.
Activate creatures you control by tapping those, adding {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Vitalize without paying its mana cost, untapping all creatures.
Repeat from step 3.


---

# 618-1053-1099-1799-2240-3189-3873

**Cards:**

- Doomsday
- Grenzo, Dungeon Warden
- Kiki-Jiki, Mirror Breaker
- Conspicuous Snoop
- Torch Courier
- Brazen Buccaneers
- Sling-Gang Lieutenant

**Produces:** Each opponent loses the game, Infinite creature tokens with haste, Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers

**Mana: {4}{B}{B}{B}{R}, MV: 8, Colors: BR, Popularity: 1**

**Steps:**

Cast Doomsday by paying {B}{B}{B}, searching your library and graveyard for Torch Courier, Kiki-Jiki, Sling-Gang Lieutenant, Brazen Buccaneers and Conspicuous Snoop, exiling all other cards from your graveyard and library, and then placing the remaining cards on top of your library in the order previously listed and losing half your life, rounded up.
Activate Grenzo by paying {2}, putting Conspicuous Snoop into your graveyard and then onto the battlefield.
Cast Torch Courier from the top of your library by paying {R}.
Activate Torch Courier by sacrificing it, giving Conspicuous Snoop haste until end of turn.
Activate Conspicuous Snoop using Kiki-Jiki's ability by tapping it, creating a token copy of Conspicuous Snoop with haste.
Repeat step 5 with the new Conspicuous Snoop token an arbitrarily large amount of times.
Activate Grenzo by paying {2}, putting Brazen Buccaneers into your graveyard and then onto the battlefield.
Brazen Buccaneers enters the battlefield, revealing Kiki-Jiki, putting a +1/+1 counter on Brazen Buccaneers and putting Kiki-Jiki into your graveyard.
Activate a Conspicuous Snoop using Sling-Gang Lieutenant's ability by sacrificing a Goblin, causing an opponent to lose 1 life and you to gain 1 life.
Repeat from step 9.

---

# 618-1053-1799-2240-2448-3189-3873

**Cards:**

- Doomsday
- Grenzo, Dungeon Warden
- Kiki-Jiki, Mirror Breaker
- Conspicuous Snoop
- Torch Courier
- Brazen Buccaneers
- Goblin Firestarter

**Produces:** Each opponent loses the game, Infinite creature tokens with haste, Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: {4}{B}{B}{B}{R}, MV: 8, Colors: BR, Popularity: 1**

**Steps:**

Cast Doomsday by paying {B}{B}{B}, searching your library and graveyard for Torch Courier, Kiki-Jiki, Goblin Firestarter, Brazen Buccaneers and Conspicuous Snoop, exiling all other cards from your graveyard and library, and then placing the remaining cards on top of your library in the order previously listed and losing half your life, rounded up.
Activate Grenzo by paying {2}, putting Conspicuous Snoop into your graveyard and then onto the battlefield.
Cast Torch Courier from the top of your library by paying {R}.
Activate Torch Courier by sacrificing it, giving Conspicuous Snoop haste until end of turn.
Activate Conspicuous Snoop using Kiki-Jiki's ability by tapping it, creating a token copy of Conspicuous Snoop with haste.
Repeat step 5 with the new Conspicuous Snoop token an arbitrarily large amount of times.
Activate Grenzo by paying {2}, putting Brazen Buccaneers into your graveyard and then onto the battlefield.
Brazen Buccaneers enters the battlefield, revealing Kiki-Jiki, putting a +1/+1 counter on Brazen Buccaneers and putting Kiki-Jiki into your graveyard.
Activate a Conspicuous Snoop using Goblin Firestarter's ability by sacrificing it, dealing 1 damage to any target.
Repeat from step 9.

---

# 618-1061

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Timestream Navigator

**Produces:** Infinite turns, Lock

**Mana: {2}{U}{U} each turn, MV: 4, Colors: UR, Popularity: 792**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of Timestream Navigator.
Activate token copy of Timestream Navigator by tapping it, paying {2}{U}{U}, and putting it on the bottom of your library, taking an extra turn after this one.
Pass the turn.
Repeat.

---

# 618-1090

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Restoration Angel

**Produces:** Infinite creature tokens with haste, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: RW, Popularity: 5367**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of Restoration Angel with haste.
When the Restoration Angel token enters, it triggers, blinking Kiki-Jiki.
Repeat.

---

# 618-1099-2178

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Thornbite Staff
- Sling-Gang Lieutenant

**Produces:** Infinite creature tokens with haste, Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: BR, Popularity: 710**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of Sling-Gang Lieutenant with haste.
Sling-Gang Lieutenant enters the battlefield, creating two 1/1 Goblin tokens.
Activate Sling-Gang Lieutenant by sacrificing a Goblin.
Kiki-JIki triggers, untapping itself.
Resolve the Sling-Gang Lieutenant ability, causing target player to lose 1 life and you to gain 1 life.
Repeat.

---

# 618-1228-2178

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Thornbite Staff
- Goblin Sharpshooter

**Produces:** Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: R, Popularity: 4477**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of Goblin Sharpshooter with haste.
Activate the nontoken Goblin Sharpshooter by tapping it, dealing 1 damage to any target.
Activate the token Goblin Sharpshooter by tapping it, dealing 1 damage to itself.
The token dies as a state-based action due to having zero toughness, triggering Kiki-Jiki and Goblin Sharpshooter.
Resolve both triggers, untapping Kiki-Jiki and Goblin Sharpshooter.
Repeat.

---

# 618-1295-4091

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Aphetto Alchemist
- Thassa's Oracle

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite tapped creature tokens with haste, Win the game

**Mana: {U}{U}, MV: 2, Colors: UR, Popularity: 35**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of Aphetto Alchemist.
Activate a token copy of Aphetto Alchemist by tapping it, untap Kiki-Jiki.
Repeat.
Once you have infinite token copy of Aphetto Alchemist, you may cast Thassa's Oracle by paying {U}{U}.
Thassa's Oracle enters the battlefield ability triggers, causing you to win the game.

---

# 618-1536

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Insatiable Hemophage

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite tapped creature tokens

**Mana: , MV: 0, Colors: BR, Popularity: 82**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of mutated Insatiable Hemophage.
Activate the token copy by tapping it, creating a token copy of mutated Insatiable Hemophage.
Repeat from step 2.

---

# 618-1537

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Zealous Conscripts

**Produces:** Infinite creature tokens with haste, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: R, Popularity: 27024**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of Zealous Conscripts with haste.
When the Zealous Conscripts token enters, it triggers, untapping Kiki-Jiki
Repeat.

---

# 618-1621

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Wispweaver Angel

**Produces:** Infinite creature tokens with haste, Infinite ETB, Infinite LTB, Infinite death triggers, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: RW, Popularity: 147**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of Wispweaver Angel with haste.
When the Wispweaver Angel token enters, it triggers, blinking Kiki-Jiki.
Repeat.

---

# 618-1636

**Cards:**

- Intruder Alarm
- Kiki-Jiki, Mirror Breaker

**Produces:** Infinite copies of nonlegendary creatures you control, Infinite creature tokens with haste, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mana creatures you control can produce, Infinite sacrifice triggers, Infinite untap of creatures

**Mana: , MV: 0, Colors: UR, Popularity: 1326**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of any nonlegendary creature you control.
When the the creature token enters the battlefield, Intruder Alarm triggers, untapping all creatures.
Repeat.

---

# 618-1656

**Cards:**

- Necrotic Ooze
- Kiki-Jiki, Mirror Breaker

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite tapped creature tokens

**Mana: , MV: 0, Colors: BR, Popularity: 547**

**Steps:**

Activate Necrotic Ooze's ability from Kiki-Jiki by tapping it, creating a token copy of itself with haste.
Activate the Necrotic Ooze's ability from Kiki-Jiki by tapping it, creating a token copy of itself with haste.
Repeat step 2 any number of times.

---

# 618-1741-2821

**Cards:**

- Cloud of Faeries
- Kiki-Jiki, Mirror Breaker
- Minamo, School at Water's Edge

**Produces:** Infinite creature tokens with haste, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: UR, Popularity: 761**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of Cloud of Faeries with haste that will be sacrificed at the beginning of the next end step.
The token Cloud of Faeries enters the battlefield, triggering itself, untapping Minamo and another land you control.
Activate that land by tapping it, adding at least {U}.
Activate Minamo's last ability by paying {U} and tapping it, untapping Kiki-Jiki.
Repeat.

---

# 618-1741-4222

**Cards:**

- Freed from the Real
- Kiki-Jiki, Mirror Breaker
- Cloud of Faeries

**Produces:** Infinite creature tokens with haste, Infinite ETB, Infinite mana lands you control can produce

**Mana: , MV: 0, Colors: UR, Popularity: 49**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a copy of Cloud of Faeries.
The Cloud of Faeries token enters the battlefield, untapping two lands you control.
Activate two lands you control by tapping them, adding at least {1}{U}.
Activate Freed from the Real by paying {U}, untapping Kiki-Jiki.
Repeat.

---

# 618-2034-3580

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Lightning Crafter
- Ashnod's Altar

**Produces:** Infinite damage, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: {3}{R}, MV: 4, Colors: R, Popularity: 1817**

**Steps:**

Cast Lightning Crafter by paying {3}{R}.
When Lightning Crafter enters the battlefield, its champion ability triggers.
Holding priority, activate Kiki-Jiki by tapping it, creating a token copy of Lightning Crafter with haste.
When the token Lightning Crafter enters the battlefield, its champion ability triggers, exiling Kiki-Jiki.
Activate the token Lightning Crafter by tapping it, dealing 3 damage to any target.
Activate Ashnod's Altar by sacrificing the token Lightning Crafter.
When the token Lightning Crafter leaves the battlefield, it triggers, returning Kiki-Jiki from exile to the battlefield.
Repeat from step 3.

---

# 618-2034-4681

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Karmic Guide
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite creature tokens with haste, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: RW, Popularity: 2724**

**Steps:**

Activate Kiki-Jiki by tapping it, targeting Karmic Guide.
Holding priority, activate Ashnod's Altar by sacrificing Kiki-Jiki, adding {C}{C}.
Resolve the Kiki-Jiki ability, creating a token copy of Karmic Guide with haste.
The Karmic Guide token enters the battlefield, returning Kiki-JIki from your graveyard to the battlefield.
Repeat.

---

# 618-2059

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Village Bell-Ringer

**Produces:** Infinite creature tokens with haste, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mana creatures you control can produce, Infinite sacrifice triggers, Infinite untap of creatures you control

**Mana: , MV: 0, Colors: RW, Popularity: 12603**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of Village Bell-Ringer with haste.
When the Village Bell-Ringer token enters, it triggers, untapping all creatures you control.
Repeat.

---

# 618-2075

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Glowstone Recluse

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite tapped creature tokens

**Mana: , MV: 0, Colors: RG, Popularity: 103**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of mutated Glowstone Recluse.
Activate the token copy by tapping it, creating a token copy of mutated Glowstone Recluse.
Repeat from step 2.

---

# 618-2105

**Cards:**

- Combat Celebrant
- Kiki-Jiki, Mirror Breaker

**Produces:** Infinite combat phases, Infinite creature tokens with haste, Infinite ETB

**Mana: , MV: 0, Colors: R, Popularity: 17665**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of Combat Celebrant with haste.
Proceed to your combat step.
Declare the Combat Celebrant copy as an attacker, choosing to exert it as it attacks.
The Combat Celebrant copy triggers, untapping all other creatures you control and causing you to get an additional combat phase after this one.
Repeat.

---

# 618-2178-2448

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Thornbite Staff
- Goblin Firestarter

**Produces:** Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: R, Popularity: 38**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of Goblin Firestarter with haste.
Activate a Goblin Firestarter you control by sacrificing it.
Kiki-JIki triggers, untapping itself.
Resolve the Goblin Firestarter ability, dealing 1 damage to any target.
Repeat.

---

# 618-2198

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Deceiver Exarch

**Produces:** Infinite creature tokens with haste, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: UR, Popularity: 2436**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of Deceiver Exarch with haste.
When the Deceiver Exarch token enters, it triggers, untapping Kiki-Jiki
Repeat.

---

# 618-2292-3580

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Lightning Crafter
- Viscera Seer

**Produces:** Infinite scry 1, Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: {3}{R}, MV: 4, Colors: BR, Popularity: 287**

**Steps:**

Cast Lightning Crafter by paying {3}{R}.
When Lightning Crafter enters the battlefield, its champion ability triggers.
Holding priority, activate Kiki-Jiki by tapping it, creating a token copy of Lightning Crafter with haste.
When the token Lightning Crafter enters the battlefield, its champion ability triggers, exiling Kiki-Jiki.
Activate the token Lightning Crafter by tapping it, dealing 3 damage to any target.
Activate Viscera Seer by sacrificing the token Lightning Crafter.
When the token Lightning Crafter leaves the battlefield, it triggers, returning Kiki-Jiki from exile to the battlefield.
Resolve the Viscera Seer ability.
Repeat from step 3.

---

# 618-2438-3580

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Lightning Crafter
- Carrion Feeder

**Produces:** Infinite +1/+1 counters on a creature, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite damage

**Mana: {3}{R}, MV: 4, Colors: BR, Popularity: 43**

**Steps:**

Cast Lightning Crafter by paying {3}{R}.
When Lightning Crafter enters the battlefield, its champion ability triggers.
Holding priority, activate Kiki-Jiki by tapping it, creating a token copy of Lightning Crafter with haste.
When the token Lightning Crafter enters the battlefield, its champion ability triggers, exiling Kiki-Jiki.
Activate the token Lightning Crafter by tapping it, dealing 3 damage to any target.
Activate Carrion Feeder by sacrificing the token Lightning Crafter.
When the token Lightning Crafter leaves the battlefield, it triggers, returning Kiki-Jiki from exile to the battlefield.
Resolve the Carrion Feeder ability.
Repeat from step 3.

---

# 618-2513

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Souvenir Snatcher

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite tapped creature tokens

**Mana: , MV: 0, Colors: UR, Popularity: 78**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of mutated Souvenir Snatcher.
Activate the token copy by tapping it, creating a token copy of mutated Souvenir Snatcher.
Repeat from step 2.

---

# 618-2514

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Cloudpiercer

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite tapped creature tokens

**Mana: , MV: 0, Colors: R, Popularity: 204**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of mutated Cloudpiercer.
Activate the token copy by tapping it, creating a token copy of mutated Cloudpiercer.
Repeat from step 2.

---

# 618-2781

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Felidar Guardian

**Produces:** Infinite creature tokens with haste, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: RW, Popularity: 12866**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of Felidar Guardian with haste.
When the Felidar Guardian token enters, it triggers, blinking Kiki-Jiki.
Repeat.

---

# 618-2792-2821

**Cards:**

- Great Whale
- Kiki-Jiki, Mirror Breaker
- Minamo, School at Water's Edge

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mana lands you control can produce, Infinite sacrifice triggers, Infinite creature tokens with haste, Infinite untap of lands you control

**Mana: , MV: 0, Colors: UR, Popularity: 588**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of Great Whale with haste that will be sacrificed at the beginning of the next end step.
The token Great Whale enters the battlefield, triggering itself, untapping Minamo and up to six other lands.
Activate those other lands by tapping them, adding at least {U}.
Activate Minamo's last ability by paying {U} and tapping it, untapping Kiki-Jiki.
Repeat.

---

# 618-2821-3542

**Cards:**

- Palinchron
- Kiki-Jiki, Mirror Breaker
- Minamo, School at Water's Edge

**Produces:** Infinite creature tokens with haste, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mana lands you control can produce, Infinite sacrifice triggers, Infinite untap of lands you control

**Mana: , MV: 0, Colors: UR, Popularity: 688**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of Palinchron with haste that will be sacrificed at the beginning of the next end step.
The token Palinchron enters the battlefield, triggering itself, untapping Minamo and up to six other lands.
Activate those other lands by tapping them, adding at least {U}.
Activate Minamo's last ability by paying {U} and tapping it, untapping Kiki-Jiki.
Repeat.

---

# 618-2821-3821

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Peregrine Drake
- Minamo, School at Water's Edge

**Produces:** Infinite creature tokens with haste, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mana lands you control can produce, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: UR, Popularity: 820**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of Peregrine Drake with haste that will be sacrificed at end of turn.
The Peregrine Drake token enters the battlefield, untapping Minamo and up to four other mana producing lands you control.
Activate up to four mana producing lands you control besides Minamo by tapping them, adding at least {1}{U}.
Activate Minamo's second ability by paying {U} and tapping it, untapping Kiki-Jiki.
Repeat.

---

# 618-2905

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Pestermite

**Produces:** Infinite creature tokens with haste, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: UR, Popularity: 2259**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of Pestermite with haste.
When the Pestermite token enters, it triggers, untapping Kiki-Jiki
Repeat.

---

# 618-3207

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Dirge Bat

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite tapped creature tokens

**Mana: , MV: 0, Colors: BR, Popularity: 85**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of mutated Dirge Bat.
Activate the token copy by tapping it, creating a token copy of mutated Dirge Bat.
Repeat from step 2.

---

# 618-3246

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Cavern Whisperer

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite tapped creature tokens

**Mana: , MV: 0, Colors: BR, Popularity: 60**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of mutated Cavern Whisperer.
Activate the token copy by tapping it, creating a token copy of mutated Cavern Whisperer.
Repeat from step 2.

---

# 618-3464

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Hyrax Tower Scout

**Produces:** Infinite creature tokens with haste, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: RG, Popularity: 3123**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of Hyrax Tower Scout with haste.
When the Hyrax Tower Scout token enters, it triggers, untapping Kiki-Jiki
Repeat.

---

# 618-3579

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Mindleecher

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite tapped creature tokens

**Mana: , MV: 0, Colors: BR, Popularity: 59**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of mutated Mindleecher.
Activate the token copy by tapping it, creating a token copy of mutated Mindleecher.
Repeat from step 2.

---

# 618-3580-4050

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Lightning Crafter
- Phyrexian Altar

**Produces:** Infinite damage, Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: {3}{R}, MV: 4, Colors: R, Popularity: 1275**

**Steps:**

Cast Lightning Crafter by paying {3}{R}.
When Lightning Crafter enters the battlefield, its champion ability triggers.
Holding priority, activate Kiki-Jiki by tapping it, creating a token copy of Lightning Crafter with haste.
When the token Lightning Crafter enters the battlefield, its champion ability triggers, exiling Kiki-Jiki.
Activate the token Lightning Crafter by tapping it, dealing 3 damage to any target.
Activate Phyrexian Altar by sacrificing the token Lightning Crafter.
When the token Lightning Crafter leaves the battlefield, it triggers, returning Kiki-Jiki from exile to the battlefield.
Repeat from step 3.

---

# 618-3580-5147

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Lightning Crafter
- Goblin Bombardment

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite damage

**Mana: {3}{R}, MV: 4, Colors: R, Popularity: 3334**

**Steps:**

Cast Lightning Crafter by paying {3}{R}.
When Lightning Crafter enters the battlefield, its champion ability triggers.
Holding priority, activate Kiki-Jiki by tapping it, creating a token copy of Lightning Crafter with haste.
When the token Lightning Crafter enters the battlefield, its champion ability triggers, exiling Kiki-Jiki.
Activate the token Lightning Crafter by tapping it, dealing 3 damage to any target.
Activate Goblin Bombardment by sacrificing the token Lightning Crafter.
When the token Lightning Crafter leaves the battlefield, it triggers, returning Kiki-Jiki from exile to the battlefield.
Resolve the Goblin Bombardment ability.
Repeat from step 3.

---

# 618-3580-5256

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Lightning Crafter
- Altar of Dementia

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite damage, Infinite self-mill, Infinite mill, Infinite sacrifice triggers

**Mana: {3}{R}, MV: 4, Colors: R, Popularity: 237**

**Steps:**

Cast Lightning Crafter by paying {3}{R}.
When Lightning Crafter enters the battlefield, its champion ability triggers.
Holding priority, activate Kiki-Jiki by tapping it, creating a token copy of Lightning Crafter with haste.
When the token Lightning Crafter enters the battlefield, its champion ability triggers, exiling Kiki-Jiki.
Activate the token Lightning Crafter by tapping it, dealing 3 damage to any target.
Activate Altar of Dementia by sacrificing the token Lightning Crafter.
When the token Lightning Crafter leaves the battlefield, it triggers, returning Kiki-Jiki from exile to the battlefield.
Resolve the Altar of Dementia ability.
Repeat from step 3.

---

# 618-3908

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Spark Double

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite tapped creature tokens until end of turn

**Mana: , MV: 0, Colors: UR, Popularity: 1822**

**Steps:**

Activate Spark Double by tapping it, creating a token copy of itself with haste that will be sacrificed at the next end step.
The Spark Double token enters the battlefield as a nonlegendary copy of Kiki-Jiki with an additional +1/+1 counter.
Activate the Spark Double token by tapping it, creating a token copy of itself with haste, exile that token at the end of turn.
Repeat from step 2.

---

# 618-4050-4681

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Karmic Guide
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite creature tokens with haste, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: RW, Popularity: 1198**

**Steps:**

Activate Kiki-Jiki by tapping it, targeting Karmic Guide.
Holding priority, activate Phyrexian Altar by sacrificing Kiki-Jiki, adding one mana of any color.
Resolve the Kiki-Jiki ability, creating a token copy of Karmic Guide with haste.
The Karmic Guide token enters the battlefield, returning Kiki-JIki from your graveyard to the battlefield.
Repeat.

---

# 618-4107

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Chittering Harvester

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite tapped creature tokens

**Mana: , MV: 0, Colors: BR, Popularity: 68**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of mutated Chittering Harvester.
Activate the token copy by tapping it, creating a token copy of mutated Chittering Harvester.
Repeat from step 2.

---

# 618-4358

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Gemrazer

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite tapped creature tokens

**Mana: , MV: 0, Colors: RG, Popularity: 197**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of mutated Gemrazer.
Activate the token copy by tapping it, creating a token copy of mutated Gemrazer.
Repeat from step 2.

---

# 618-4394

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Everquill Phoenix

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite tapped creature tokens

**Mana: , MV: 0, Colors: R, Popularity: 268**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of mutated Everquill Phoenix.
Activate the token copy by tapping it, creating a token copy of mutated Everquill Phoenix.
Repeat from step 2.


---

# 618-4681-5147

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Karmic Guide
- Goblin Bombardment

**Produces:** Infinite creature tokens with haste, Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: RW, Popularity: 3884**

**Steps:**

Activate Kiki-Jiki by tapping it, targeting Karmic Guide.
Holding priority, activate Goblin Bombardment by sacrificing Kiki-Jiki, dealing 1 damage to any target.
Resolve the Kiki-Jiki ability, creating a token copy of Karmic Guide with haste.
The Karmic Guide token enters the battlefield, returning Kiki-JIki from your graveyard to the battlefield.
Repeat.

---

# 618-4681-5256

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Karmic Guide
- Altar of Dementia

**Produces:** Infinite creature tokens with haste, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: RW, Popularity: 1300**

**Steps:**

Activate Kiki-Jiki by tapping it, targeting Karmic Guide.
Holding priority, activate Altar of Dementia by sacrificing Kiki-Jiki, causing target player to mill cards equal to Kiki-Jiki's power.
Resolve the Kiki-Jiki ability, creating a token copy of Karmic Guide with haste.
The Karmic Guide token enters the battlefield, returning Kiki-JIki from your graveyard to the battlefield.
Repeat.

---

# 618-4846

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Worldgorger Dragon

**Produces:** Infinite blinking, Infinite ETB, Infinite LTB, Infinite mana lands you control can produce

**Mana: {3}{R}{R}{R}, MV: 6, Colors: R, Popularity: 1627**

**Steps:**

Cast Worldgorger Dragon by paying {3}{R}{R}{R}.
Worldgorger Dragon enters the battlefield, triggering its first ability.
Holding priority, activate any number of lands you control by tapping them, adding at least {1}.
Activate Kiki-Jiki by tapping it, creating a token copy of Worldgorger Dragon.
The token Worldgorger Dragon enters the battlefield, triggering its first ability, exiling all other permanents you control.
The nontoken Worldgorger Dragon leaves the battlefield, triggering its second ability, returning nothing from exile to the battlefield.
Resolve the Worldgorger Dragon trigger from step 2, exiling the token Worldgorger Dragon.
The token Worldgorger Dragon leaves the battlefield, triggering its second ability, returning all permanents exiled with it to the battlefield.
Repeat from step 2.

---

# 618-4894

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Breaching Hippocamp

**Produces:** Infinite creature tokens with haste, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: UR, Popularity: 161**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of Breaching Hippocamp with haste.
When the Breaching Hippocamp token enters, it triggers, untapping Kiki-Jiki
Repeat.

---

# 618-5059

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Pouncing Shoreshark

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite tapped creature tokens

**Mana: , MV: 0, Colors: UR, Popularity: 126**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of mutated Pouncing Shoreshark.
Activate the token copy by tapping it, creating a token copy of mutated Pouncing Shoreshark.
Repeat from step 2.

---

# 618-697

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Trumpeting Gnarr

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite tapped creature tokens

**Mana: , MV: 0, Colors: GUR, Popularity: 93**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of mutated Trumpeting Gnarr.
Activate the token copy by tapping it, creating a token copy of mutated Trumpeting Gnarr.
Repeat from step 2.

---

# 618-725-1741

**Cards:**

- Aura of Dominion
- Kiki-Jiki, Mirror Breaker
- Cloud of Faeries

**Produces:** Infinite colored mana, Infinite colorless mana, Infinite ETB, Infinite LTB, Infinite tapped tokens, Infinite untap of creatures you control

**Mana: , MV: 0, Colors: UR, Popularity: 2**

**Steps:**

Activate Kiki-Jiki, Mirror Breaker's ability to create a token copy of Cloud of Faeries.
When the Cloud of Faeries token enters untap 2 lands to produce {2}.
Use this mana to untap Kiki-Jiki, Mirror Breaker with Aura of Dominion tapping Cloud of Faeries.
Repeat.

---

# 618-725-4939

**Cards:**

- Aura of Dominion
- Kiki-Jiki, Mirror Breaker
- Burning-Tree Emissary

**Produces:** Infinite death triggers, Infinite ETB, Infinite green mana, Infinite LTB, Infinite red mana, Infinite sacrifice triggers, Infinite tapped tokens

**Mana: , MV: 0, Colors: GUR, Popularity: 0**

**Steps:**

Activate Kiki-Jiki's ability by tapping it, creatig a token copy of Burning-Tree Emissary with haste that you will sacrifice at the beginning of the next end step.
The Burning-Tree Emissary token triggers, adding {R}{G}.
Activate Aura of Dominion by paying {1} and tapping a copy of Burning-Tree Emissary, untapping Kiki-Jiki.
Repeat.

---

# 618-729

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Great Oak Guardian

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinitely large creatures you control until end of turn, Infinite untap of creatures you control, Infinite mana creatures you control can produce, Infinite creature tokens with haste

**Mana: , MV: 0, Colors: RG, Popularity: 438**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of Great Oak Guardian with haste.
When the Great Oak Guardian token enters, it triggers, untapping untapping all creatures you control and giving them +2/+2 until end of turn.
Repeat.

---

# 618-753

**Cards:**

- Kiki-Jiki, Mirror Breaker
- Dreamtail Heron

**Produces:** Infinite ETB, Infinite death triggers, Infinite LTB, Infinite sacrifice triggers, Infinite tapped creature tokens

**Mana: , MV: 0, Colors: UR, Popularity: 128**

**Steps:**

Activate Kiki-Jiki by tapping it, creating a token copy of mutated Dreamtail Heron.
Activate the token copy by tapping it, creating a token copy of mutated Dreamtail Heron.
Repeat from step 2.

---

# 618-821-1053-1799-2240-3189-3873

**Cards:**

- Doomsday
- Grenzo, Dungeon Warden
- Kiki-Jiki, Mirror Breaker
- Conspicuous Snoop
- Torch Courier
- Brazen Buccaneers
- Mogg Fanatic

**Produces:** Each opponent loses the game, Infinite creature tokens with haste, Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: {4}{B}{B}{B}{R}, MV: 8, Colors: BR, Popularity: 3**

**Steps:**

Cast Doomsday by paying {B}{B}{B}, searching your library and graveyard for Torch Courier, Kiki-Jiki, Mogg Fanatic, Brazen Buccaneers and Conspicuous Snoop, exiling all other cards from your graveyard and library, and then placing the remaining cards on top of your library in the order previously listed and losing half your life, rounded up.
Activate Grenzo by paying {2}, putting Conspicuous Snoop into your graveyard and then onto the battlefield.
Cast Torch Courier from the top of your library by paying {R}.
Activate Torch Courier by sacrificing it, giving Conspicuous Snoop haste until end of turn.
Activate Conspicuous Snoop using Kiki-Jiki's ability by tapping it, creating a token copy of Conspicuous Snoop with haste.
Repeat step 5 with the new Conspicuous Snoop token an arbitrarily large amount of times.
Activate Grenzo by paying {2}, putting Brazen Buccaneers into your graveyard and then onto the battlefield.
Brazen Buccaneers enters the battlefield, revealing Kiki-Jiki, putting a +1/+1 counter on Brazen Buccaneers and putting Kiki-Jiki into your graveyard.
Activate a Conspicuous Snoop using Mogg Fanatic's ability by sacrificing it, dealing 1 damage to any target.
Repeat from step 9.

---

# 618-821-1053-2240-2943

**Cards:**

- Goblin Recruiter
- Conspicuous Snoop
- Kiki-Jiki, Mirror Breaker
- Torch Courier
- Mogg Fanatic

**Produces:** Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: {1}{R}{R}{R}{R}, MV: 5, Colors: R, Popularity: 2805**

**Steps:**

Cast Goblin Recruiter by paying {1}{R}.
Search your library for Mogg Fanatic, Kiki-Jiki, Torch Courier, and Conspicuous Snoop, and put them on top of your library in that order.
Draw a card by any method.
Cast Conspicuous Snoop by paying {R}{R}.
Cast Torch Courier from the top of your library by paying {R}.
Activate Torch Courier by sacrificing it, giving Conspicuous Snoop haste until end of turn.
Activate Conspicuous Snoop using the ability gained due to Kiki-Jiki being on the top of your library by tapping Conspicuous Snoop, creating a token copy of itself.
Repeat step 7 for infinite tapped token copies of Conspicuous Snoop.
Activate your untapped token copy of Conspicuous Snoop by tapping it, creating a token copy of Goblin Recruiter.
The Goblin Recruiter token enters the battlefield, searching your library for Mogg Fanatic and putting it on top of your library.
Sacrifice an arbitrarily large number of Conspicuous Snoop tokens using the ability gained due to Mogg Fanatic being on top of your library for an arbitrarily large amount of damage.

---

# 618-821-1053-2890-2943-4892-5036

**Cards:**

- Flash
- Protean Hulk
- Skill Borrower
- Kiki-Jiki, Mirror Breaker
- Goblin Recruiter
- Torch Courier
- Mogg Fanatic

**Produces:** Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB

**Mana: {1}{U}, MV: 2, Colors: GUR, Popularity: 0**

**Steps:**

Cast Flash, putting Protean Hulk into play.
Protean Hulk goes to the bin and gets Skill Borrower, Torch Courier and Goblin Recruiter.
Goblin Recruiter puts Kiki-Jiki on top of your library.
Sacrifice the Torch Courier to give Skill Borrower haste.
Use Skill Borrower's ability to use Kiki's ability: making another copy of Skill Borrower.
Repeat step 5 infinitely.
This creates infinite skill borrowers that are tapped, plus 1 that is untapped.
Use the last Skill Borrower to copy Goblin Recruiter to put Mogg Fanatic on top of your library, and then sacrifice all your Skill Borrowers to their own ability to deal Infinite damage to your opponent.

---

# 6-2064-5261

**Cards:**

- Isochron Scepter
- Vitalize
- Tezzeret's Touch

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: , MV: 0, Colors: BGU, Popularity: 1**

**Steps:**

Activate creatures you control by tapping those, adding {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Vitalize without paying its mana cost, untapping all creatures.
Repeat

---

# 6-215-527-864

**Cards:**

- Selvala, Heart of the Wilds
- Temur Sabertooth
- Eternal Witness
- Vitalize

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Infinite blinking

**Mana: {G}, MV: 1, Colors: G, Popularity: 1355**

**Steps:**

Activate Selvala by paying {G} and tapping it, adding at least {3}{G}{G}{G}{G}{G} to your mana pool.
Cast Vitalize by paying {G}, untapping all creatures you control.
Cast Eternal Witness by paying {1}{G}{G}.
Eternal Witness enters the battlefield, returning Vitalize from your graveyard to your hand.
Activate Temur Sabertooth by paying {1}{G}, returning Eternal Witness from the battlefield to your hand.
Repeat.

---

# 62-3750

**Cards:**

- Savage Ventmaw
- Aggravated Assault

**Produces:** Infinite combat damage, Infinite combat phases, Infinite green mana, Infinite mana creatures you control can produce, Infinite red mana, Infinite untap of creatures you control

**Mana: , MV: 0, Colors: RG, Popularity: 16280**

**Steps:**

Declare Savage Ventmaw as an attacker, attacking an opponent unable to block and kill it.
Savage Ventmaw triggers, adding {R}{R}{R}{G}{G}{G}.
Move to your post-combat main phase.
Activate Aggravated Assault by paying {3}{R}{R}, untapping all creatures you control and causing you to get an additional combat and main phase after this one.
Repeat.

---

# 624-1872-5105

**Cards:**

- Sigil of the New Dawn
- Composite Golem
- Phantasmal Image

**Produces:** Infinite black mana, Infinite death triggers, Infinite ETB, Infinite green mana, Infinite red mana

**Mana: {1}{U}, MV: 2, Colors: WUBRG, Popularity: 0**

**Steps:**

Play Phantasmal Image, entering as a copy of Composite Golem.
Sacrifice Phantasmal Image, adding {W}{U}{B}{R}{G}.
Pay {1}{W} into the Sigil trigger, returning Phantasmal Image to your hand.
Loop steps 1-3, floating an amount of your choice of {R}, {G}, and/or {B}.

---

# 624-2869-2890-3956-4284

**Cards:**

- Protean Hulk
- Loaming Shaman
- Leyline of Singularity
- Clone
- Phantasmal Image

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB

**Mana: {3}{U}, MV: 4, Colors: GU, Popularity: 6**

**Steps:**

Cast Clone by paying {3}{U}, choosing to have it enter the battlefield as a copy of Protean Hulk.
Put Clone into your graveyard due to the legend rule.
Clone dies, causing you to search your library for Loaming Shaman and Phantasmal Image and put them onto the battlefield.
Choose to have Phantasmal Image enter the battlefield as a copy of Protean Hulk.
Put Phantasmal Image into your graveyard due to the legend rule.
Phantasmal Image and Loaming Shaman trigger.
Resolve the Loaming Shaman trigger, shuffling Clone and Phantasmal Image from your graveyard into your library.
Resolve the Protean Hulk trigger, causing you to search your library for Clone and Phantasmal Image and put them onto the battlefield.
Choose to have Clone enter the battlefield as a copy of Loaming Shaman, and Phantasmal Image as a copy of Protean Hulk.
Put Clone and Phantasmal Image into your graveyard due to the legend rule.
Phantasmal Image and Clone trigger.
Resolve the Clone trigger, shuffling Clone and Phantasmal Image from your graveyard into your library.
Resolve the Phantasmal Image trigger, causing you to search your library for Clone and Phantasmal Image and put them onto the battlefield.
Repeat from step 9.

---

# 624-3518-3605-5131

**Cards:**

- Muldrotha, the Gravetide
- Lion's Eye Diamond
- Dance of the Dead
- Phantasmal Image

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: BGU, Popularity: 147**

**Steps:**

Cast Lion's Eye Diamond from your graveyard by paying {0}.
Activate Lion's Eye Diamond by sacrificing it and discarding your hand, adding {U}{U}{U}.
Cast Phantasmal Image from your graveyard by paying {U}{U}.
Phantasmal Image enters the battlefield as a copy of Muldrotha, putting original Muldrotha into your graveyard due to the legend rule.
 Cast Lion's Eye Diamond from your graveyard by paying {0}.
Activate Lion's Eye Diamond by sacrificing it and discarding your hand, adding {B}{B}{B}.
Cast Dance of the Dead from your graveyard by paying {B}{B}, targeting Muldrotha.
Muldrotha enters the battlefield, putting Phantasmal Image into your graveyard due to the legend rule.
Repeat.

---

# 624-3518-4812-5131

**Cards:**

- Muldrotha, the Gravetide
- Lion's Eye Diamond
- Animate Dead
- Phantasmal Image

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: BGU, Popularity: 500**

**Steps:**

Cast Lion's Eye Diamond from your graveyard by paying {0}.
Activate Lion's Eye Diamond by sacrificing it and discarding your hand, adding {U}{U}{U}.
Cast Phantasmal Image from your graveyard by paying {U}{U}.
Phantasmal Image enters the battlefield as a copy of Muldrotha, putting original Muldrotha into your graveyard due to the legend rule.
Cast Lion's Eye Diamond from your graveyard by paying {0}.
Activate Lion's Eye Diamond by sacrificing it and discarding your hand, adding {B}{B}{B}.
Cast Animate Dead from your graveyard by paying {B}{B}, targeting Muldrotha.
Muldrotha enters the battlefield, putting Phantasmal Image into your graveyard due to the legend rule.
Repeat.

---

# 628-1495

**Cards:**

- Mikaeus, the Unhallowed
- Triskelion

**Produces:** Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: B, Popularity: 7844**

**Steps:**

If Triskelion has at least three +1/+1 counters on it, activate Triskelion by removing a +1/+1 counter from it, dealing 1 damage to any target.
Repeat step 1 until there are two +1/+1 counters remaining on Triskelion.
Activate Triskelion by removing a +1/+1 counter from Triskelion, dealing 1 damage to itself.
Repeat step 3 an additional time.
Triskelion dies.
Triskelion's undying ability triggers, returning it to the battlefield with an additional +1/+1 counter on it.
Repeat.

---

# 628-2034-4053

**Cards:**

- Mikaeus, the Unhallowed
- Ashnod's Altar
- Solemnity

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: WB, Popularity: 1190**

**Steps:**

Activate Ashnod's Altar by sacrificing the additional creature, adding {C}{C}.
When the creature dies, its undying ability triggers, returning it to the battlefield from your graveyard with zero +1/+1 counters due to Solemnity.
Repeat.

---

# 628-2034-4866

**Cards:**

- Mikaeus, the Unhallowed
- Sage of Fables
- Ashnod's Altar

**Produces:** Infinite card draw, Infinite draw triggers, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers

**Mana: , MV: 0, Colors: UB, Popularity: 898**

**Steps:**

Activate Ashnod's Altar by sacrificing Sage of Fables, adding {C}{C}.
When Sage of Fables dies, its undying ability triggers, returning it from your graveyard to the battlefield with a +1/+1 counter on it.
Activate Sage of Fables by paying {2} and removing the +1/+1 counter from it, causing you to draw a card.
Repeat.

---

# 628-2034-4907

**Cards:**

- Mikaeus, the Unhallowed
- Ashnod's Altar
- Tatterkite

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: B, Popularity: 637**

**Steps:**

Activate Ashnod's Altar by sacrificing Tatterkite, adding {C}{C}.
When Tatterkite dies, its undying ability triggers, returning it to the battlefield from your graveyard with zero +1/+1 counters due to its ability.
Repeat.

---

# 628-2034-5296

**Cards:**

- Workhorse
- Mikaeus, the Unhallowed
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: B, Popularity: 272**

**Steps:**

Activate Workhorse by removing all +1/+1 counters, adding that many {C}.
Activate Ashnod's Altar by sacrificing Workhorse, adding {C}{C}.
Workhorse undying ability triggers, returning it to the battlefield with an additional +1/+1 counter on it.
Repeat.

---

# 628-2122-2292-4772

**Cards:**

- Mikaeus, the Unhallowed
- Mindless Automaton
- Doubling Season
- Viscera Seer

**Produces:** Infinite card draw, Infinite draw triggers, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers

**Mana: , MV: 0, Colors: BG, Popularity: 4**

**Steps:**

Activate Mindless Automaton by removing two +1/+1 counters from it, causing you to draw a card.
Activate Viscera Seer by sacrificing Mindless Automaton.
Mindless Automaton's undying ability triggers, returning it to the battlefield with a total of six +1/+1 counters on it.
Resolve the Viscera Seer ability, scrying 1.
Activate Mindless Automaton by removing six +1/+1 counters from it, causing you to draw three cards.
Repeat from step 2.

---

# 628-2292-2890-3693-4892

**Cards:**

- Flash
- Protean Hulk
- Mikaeus, the Unhallowed
- Walking Ballista
- Viscera Seer

**Produces:** Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite scry 1

**Mana: {1}{U}, MV: 2, Colors: BGU, Popularity: 0**

**Steps:**

Cast Flash, choosing Protean Hulk.
Let Hulk die in Flash resolution.
Pull Walking Ballista and Mikaeus, the Unhallowed on Hulk death trigger.
Sacrifice Ballista tosacrificeoutlet, it returns with a +1/+1 counter from Mikaeus.
Use counter to deal 1 damage to any opponent.
Sacrifice Ballista to outlet again.
Repeat

---

# 6-2825-4028

**Cards:**

- Zhur-Taa Druid
- Elite Arcanist
- Vitalize

**Produces:** Infinite damage, Infinite magecraft triggers, Infinite mana creatures you control can produce, Infinite storm count, Infinite untap of creatures you control

**Mana: , MV: 0, Colors: GUR, Popularity: 4**

**Steps:**

Activate Zhur-Taa Druid by tapping it, adding {G}.
Zhur-Taa Druid triggers, dealing 1 damage to each opponent.
Activate Elite Arcanist by paying {1} and tapping it, casting a copy of Vitalize without paying its mana cost.
Resolve Vitalize, untapping all creatures you control.
Repeat.

---

# 628-2757-4762

**Cards:**

- Mikaeus, the Unhallowed
- Devoted Druid
- Earthcraft

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: BG, Popularity: 161**

**Steps:**

Tap Druid for {G}.
Untap Druid using her own ability, adding -1/-1 to her.
Do this until she dies.
Mikaeus triggers, returning Druid with a +1/+1 counter.
Druid is summoning sick.
Tap a basic land floating mana.
Tap Druid with Earthcraft to untap the land.
Untap Druid with her own ability.
Do this until Druid dies.

---

# 628-2899-3983-4907

**Cards:**

- Mikaeus, the Unhallowed
- Kaervek, the Spiteful
- Tatterkite
- Night of Souls' Betrayal

**Produces:** Draw the game, Infinite death triggers, Infinite ETB, Infinite LTB

**Mana: {3}, MV: 3, Colors: B, Popularity: 9**

**Steps:**

Cast Tatterkite by paying {3}.
Tatterkite enters the battlefield and dies as a state-based action due to having 0 toughness.
Tatterkite's undying ability triggers, returning it from your graveyard to the battlefield with zero +1/+1 counters on it due to its effect.
Repeat from step 2.
NOTE: This combo creates a mandatory infinite loop that will draw the game if it isn't interacted with.

---

# 628-2899-4929

**Cards:**

- Mikaeus, the Unhallowed
- Kaervek, the Spiteful
- Cryptic Trilobite

**Produces:** Infinite colorless mana that can only be spent to activate abilities, Infinite death triggers, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: B, Popularity: 5**

**Steps:**

Cast Cryptic Trilobite for X = 0 by paying {0}.
Cryptic Trilobite dies due to having zero toughness.
Cryptic Trilobite's undying ability from Mikaeus triggers, returning it to the battlefield with a +1/+1 counter.
Activate Cryptic Trilobite by removing the +1/+1 counter from it, adding {C}{C} that can only be spent on activated abilities.
Repeat from step 2.

---

# 628-3693

**Cards:**

- Walking Ballista
- Mikaeus, the Unhallowed

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: B, Popularity: 10465**

**Steps:**

Activate Walking Ballista's last ability by removing a +1/+1 counter from it, dealing 1 damage to itself.
Walking Ballista dies, triggering its undying ability, returning it from your graveyard to the battlefield with a +1/+1 counter on it.
Repeat.

---

# 628-3983-4929

**Cards:**

- Mikaeus, the Unhallowed
- Night of Souls' Betrayal
- Cryptic Trilobite

**Produces:** Infinite colorless mana that can only be spent to activate abilities, Infinite death triggers, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: B, Popularity: 6**

**Steps:**

Cast Cryptic Trilobite for X = 0 by paying {0}.
Cryptic Trilobite dies due to having zero toughness.
Cryptic Trilobite's undying ability from Mikaeus triggers, returning it to the battlefield with a +1/+1 counter.
Activate Cryptic Trilobite by removing the +1/+1 counter from it, adding {C}{C} that can only be spent on activated abilities.
Repeat from step 2.

---

# 628-4050-4053

**Cards:**

- Mikaeus, the Unhallowed
- Phyrexian Altar
- Solemnity

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: WB, Popularity: 1090**

**Steps:**

Activate Phyrexian Altar by sacrificing the additional creature, adding one mana of any color.
When the creature dies, its undying ability triggers, returning it to the battlefield from your graveyard with zero +1/+1 counters due to Solemnity.
Repeat.

---

# 628-4050-4907

**Cards:**

- Mikaeus, the Unhallowed
- Phyrexian Altar
- Tatterkite

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: B, Popularity: 509**

**Steps:**

Activate Phyrexian Altar by sacrificing Tatterkite, adding one mana of any color.
When Tatterkite dies, its undying ability triggers, returning it to the battlefield from your graveyard with zero +1/+1 counters due to its ability.
Repeat.

---

# 628-4050-5296

**Cards:**

- Workhorse
- Mikaeus, the Unhallowed
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: B, Popularity: 186**

**Steps:**

Activate Workhorse by removing all +1/+1 counters, adding that many {C}.
Activate Phyrexian Altar by sacrificing Workhorse, adding one mana of any color.
Workhorse undying ability triggers, returning it to the battlefield with an additional +1/+1 counter on it.
Repeat.

---

# 628-4053-5256

**Cards:**

- Mikaeus, the Unhallowed
- Altar of Dementia
- Solemnity

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: WB, Popularity: 744**

**Steps:**

Activate Altar of Dementia by sacrificing the additional creature.
When the creature dies, its undying ability triggers, returning it to the battlefield from your graveyard with zero +1/+1 counters due to Solemnity.
Resolve the Altar of Dementia ability from step 1, causing target player to mill cards equal to the sacrificed creature's power.
Repeat.

---

# 628-4907-5256

**Cards:**

- Mikaeus, the Unhallowed
- Altar of Dementia
- Tatterkite

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: B, Popularity: 443**

**Steps:**

Activate Altar of Dementia by sacrificing Tatterkite.
When Tatterkite dies, its undying ability triggers, returning it to the battlefield from your graveyard with zero +1/+1 counters due to its ability.
Resolve the Altar of Dementia ability from step 1, causing target player to mill cards equal to Tatterkite's power.
Repeat.

---

# 628-5256-5296

**Cards:**

- Workhorse
- Mikaeus, the Unhallowed
- Altar of Dementia

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: B, Popularity: 135**

**Steps:**

Activate Workhorse by removing all +1/+1 counters, adding that many {C}.
Activate Altar of Dementia by sacrificing Workhorse.
Workhorse undying ability triggers, returning it to the battlefield with an additional +1/+1 counter on it.
Resolve the Altar of Dementia ability, causing target player to mill one card.
Repeat.

---

# 6-3007-5261

**Cards:**

- Isochron Scepter
- Vitalize
- Toymaker

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: {1}, MV: 1, Colors: G, Popularity: 1**

**Steps:**

Activate Toymaker's first ability by paying {1}, tapping it and discarding a card, causing Isochron Scepter to become an artifact creature until end of turn.
Activate creatures you control by tapping those, adding {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Vitalize without paying its mana cost, untapping all creatures.
Repeat from step 2.


---

# 6-3088-5261

**Cards:**

- Isochron Scepter
- Vitalize
- Xenic Poltergeist

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: {1}, MV: 1, Colors: BG, Popularity: 2**

**Steps:**

Activate Xenic Poltergeist's first ability by paying {1} and tapping it, causing Isochron Scepter to become an artifact creature until your next upkeep.
Activate creatures you control by tapping those, adding {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Vitalize without paying its mana cost, untapping all creatures.
Repeat from step 2.


---

# 631-1785-2178-5010

**Cards:**

- Soldevi Adnate
- Thornbite Staff
- Golgari Thug
- Grim Haruspex

**Produces:** Infinite death triggers, Infinite draw triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite self-mill, Infinite storm count

**Mana: , MV: 0, Colors: B, Popularity: 7**

**Steps:**

Activate Soldevi Adnate by tapping it and sacrificing Golgari Thug, adding {B}{B}.
Soldevi Adnate, Golgari Thug, and Grim Haruspex trigger.
Resolve the Soldevi Adnate trigger, untapping it.
Resolve the Golgari Thug trigger, putting it from your graveyard on top of your library.
Resolve the Grim Haruspex trigger, drawing Golgari Thug from your library.
Cast Golgari Thug by paying {1}{B}.
Repeat.

---

# 636-2286

**Cards:**

- Teferi's Puzzle Box
- Spirit of the Labyrinth

**Produces:** Players can't draw more than one card per turn, Players shuffle their hands into their libraries during each draw step, Lock

**Mana: , MV: 0, Colors: W, Popularity: 239**

**Steps:**

At the beginning of each draw step, and after the player whose turn it is draws a card, Teferi's Puzzle Box triggers, causing all players to shuffle their hands into their libraries, and draw that many cards.
Because Spirit of the Labyrinth prevents any player from drawing more than one card, the active player will not draw any cards, and each other player will draw one card.

---

# 640-2018-4050-5197

**Cards:**

- Luminous Broodmoth
- Dross Harvester
- Downdraft
- Phyrexian Altar

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite sacrifice triggers

**Mana: {G}, MV: 1, Colors: WBG, Popularity: 0**

**Steps:**

Activate Downdraft by paying {G}, causing Luminous Broodmoth to lose flying until end of turn.
Activate Phyrexian Altar by sacrificing Luminous Broodmoth, adding {G}.
Dross Harvester triggers, causing you to gain two life.
Luminous Broodmoth triggers, returning itself from your graveyard to the battlefield with a flying counter on it.
Repeat.

---

# 6-4104-5261

**Cards:**

- Isochron Scepter
- Vitalize
- Tezzeret, Agent of Bolas

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: , MV: 0, Colors: BGU, Popularity: 0**

**Steps:**

Activate Tezzeret's second loyalty ability by removing a loyalty counter on it, causing Isochron Scepter to become an artifact creature until end of turn.
Activate creatures you control by tapping those, adding at least {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Vitalize without paying its mana cost, untapping all creatures.
Repeat from step 2.


---

# 64-1193-4095

**Cards:**

- Mythos of Illuna
- Radiate
- Warden of the Eye

**Produces:** Infinite copies of all permanents, Infinite magecraft triggers, Infinite mana permanents on the battlefield can produce, Infinite storm count, Return all noncreature, nonland cards from your graveyard to your hand

**Mana: {5}{U}{U}{R}{R}, MV: 9, Colors: RGWU, Popularity: 0**

**Steps:**

Cast Mythos of Illuna by paying {2}{U}{U}, targeting anything but Warden of the Eye.
In response, cast Radiate by paying {3}{R}{R}, creating copies of Mythos of Illuna that target each permanent besides the original target.
Resolve all copies of Mythos of Illuna besides the original, creating token copies of each permanent besides the original target.
The token copy of Warden of the Eye enters the battlefield, triggering itself, returning Radiate from your graveyard to your hand.
Activate the token lands or other mana-producing permanents created in step 3 by tapping them, adding at least {3}{R}{R}.
Repeat from step 2, doubling the number of copies created in step 3 each repetition.

---

# 641-2018-4053

**Cards:**

- Luminous Broodmoth
- Solemnity
- Kroxa, Titan of Death's Hunger

**Produces:** Infinite lifeloss, Infinite LTB, Infinite ETB, Infinite sacrifice triggers, Infinite death triggers

**Mana: {B}{R}, MV: 2, Colors: RWB, Popularity: 55**

**Steps:**

Cast Kroxa by paying {B}{R}.
When Kroxa enters the battlefield, its first and second abilities trigger.
Resolve the second Kroxa trigger, causing each opponent to discard a card and then lose 3 life if they didn't discard a nonland card.
Resolve the first Kroxa trigger, causing you to sacrifice it.
When Kroxa dies, Luminous Broodmoth triggers, returning Kroxa from your graveyard to the battlefield without a flying counter on it due to Solemnity.
Repeat from step 2.

---

# 64-2103-2665

**Cards:**

- Progenitor Mimic
- Capture of Jingzhou
- Warden of the Eye

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: RGWU, Popularity: 0**

**Steps:**

Cast Capture of Jingzhou by paying its mana cost, taking an extra turn after this one.
At the beginning of your next upkeep, Progenitor Mimic triggers, creating a token copy of Warden of the Eye.
When the token Warden of the Eye enters the battlefield, it triggers itself, returning Capture of Jingzhou from your graveyard to your hand.
Repeat.

---

# 64-2103-4305

**Cards:**

- Warden of the Eye
- Followed Footsteps
- Capture of Jingzhou

**Produces:** Infinite turns, Lock

**Mana: {3}{U}{U} each turn, MV: 5, Colors: URW, Popularity: 0**

**Steps:**

Cast Capture of Jingzhou by paying {3}{U}{U}, causing you to take an extra turn after this one.
Move to your next turn.
At the beginning of your upkeep, Followed Footsteps triggers, creating a token copy of Warden of the Eye.
The Warden of the Eye token enters the battlefield, returning Capture of Jingzhou from your graveyard to your hand.
Repeat.

---

# 64-2104-2665

**Cards:**

- Progenitor Mimic
- Temporal Manipulation
- Warden of the Eye

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: RGWU, Popularity: 0**

**Steps:**

Cast Temporal Manipulation by paying its mana cost, taking an extra turn after this one.
At the beginning of your next upkeep, Progenitor Mimic triggers, creating a token copy of Warden of the Eye.
When the token Warden of the Eye enters the battlefield, it triggers itself, returning Temporal Manipulation from your graveyard to your hand.
Repeat.

---

# 64-2104-4305

**Cards:**

- Warden of the Eye
- Followed Footsteps
- Temporal Manipulation

**Produces:** Infinite turns, Lock

**Mana: {3}{U}{U} each turn, MV: 5, Colors: URW, Popularity: 0**

**Steps:**

Cast Temporal Manipulation by paying {3}{U}{U}, causing you to take an extra turn after this one.
Move to your next turn.
At the beginning of your upkeep, Followed Footsteps triggers, creating a token copy of Warden of the Eye.
The Warden of the Eye token enters the battlefield, returning Temporal Manipulation from your graveyard to your hand.
Repeat.

---

# 6-4241-5261

**Cards:**

- Isochron Scepter
- Vitalize
- Karn, Silver Golem

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: {1}, MV: 1, Colors: G, Popularity: 4**

**Steps:**

Activate Karn by paying {1}, causing Isochron Scepter to become an artifact creature until end of turn.
Activate creatures you control by tapping those, adding {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Vitalize without paying its mana cost, untapping all creatures.
Repeat from step 2.


---

# 64-2665-3617

**Cards:**

- Progenitor Mimic
- Time Walk
- Warden of the Eye

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: RGWU, Popularity: 0**

**Steps:**

Cast Time Walk by paying its mana cost, taking an extra turn after this one.
At the beginning of your next upkeep, Progenitor Mimic triggers, creating a token copy of Warden of the Eye.
When the token Warden of the Eye enters the battlefield, it triggers itself, returning Time Walk from your graveyard to your hand.
Repeat.

---

# 64-2665-4377

**Cards:**

- Progenitor Mimic
- Walk the Aeons
- Warden of the Eye

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: RGWU, Popularity: 0**

**Steps:**

Cast Walk the Aeons by paying its mana cost, taking an extra turn after this one.
At the beginning of your next upkeep, Progenitor Mimic triggers, creating a token copy of Warden of the Eye.
When the token Warden of the Eye enters the battlefield, it triggers itself, returning Walk the Aeons from your graveyard to your hand.
Repeat.

---

# 64-2665-4872

**Cards:**

- Progenitor Mimic
- Time Warp
- Warden of the Eye

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: RGWU, Popularity: 0**

**Steps:**

Cast Time Warp by paying its mana cost, taking an extra turn after this one.
At the beginning of your next upkeep, Progenitor Mimic triggers, creating a token copy of Warden of the Eye.
When the token Warden of the Eye enters the battlefield, it triggers itself, returning Time Warp from your graveyard to your hand.
Repeat.

---

# 643-1182-1374

**Cards:**

- Haakon, Stromgald Scourge
- Maskwood Nexus
- Stonecoil Serpent

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: , MV: 0, Colors: B, Popularity: 4**

**Steps:**

Cast Stonecoil Serpent by paying {0}.
Stonecoil Serpent dies as a state based action due to having zero toughness.
Repeat.

---

# 643-1374-3693

**Cards:**

- Haakon, Stromgald Scourge
- Maskwood Nexus
- Walking Ballista

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: , MV: 0, Colors: B, Popularity: 12**

**Steps:**

Cast Walking Ballista by paying {0}.
Walking Ballista dies as a state based action due to having zero toughness.
Repeat.

---

# 643-2034-4302

**Cards:**

- Bishop of Wings
- Maskwood Nexus
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: W, Popularity: 113**

**Steps:**

Activate Ashnod's Altar by sacrificing another creature, adding {C}{C}.
When the creature dies, Bishop of Wings' second ability triggers, creating a 1/1 Spirit creature token.
When the Spirit token enters the battlefield, Bishop of Wings' first ability triggers, causing you to gain 4 life.
Repeat.

---

# 643-3581-4302

**Cards:**

- Kykar, Wind's Fury
- Bishop of Wings
- Maskwood Nexus

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite red mana, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: URW, Popularity: 29**

**Steps:**

Sacrifice a creature to Kykar's ability, adding {R}.
Bishop of Wings triggers, creating a 1/1 creature token.
Bishop of Wings triggers again, gaining you 4 life.
Repeat.

---

# 643-4050-4302

**Cards:**

- Bishop of Wings
- Maskwood Nexus
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: W, Popularity: 119**

**Steps:**

Activate Phyrexian Altar by sacrificing another creature, adding one mana of any color.
When the creature dies, Bishop of Wings' second ability triggers, creating a 1/1 Spirit creature token.
When the Spirit token enters the battlefield, Bishop of Wings' first ability triggers, causing you to gain 4 life.
Repeat.

---

# 643-4302-5256

**Cards:**

- Bishop of Wings
- Maskwood Nexus
- Altar of Dementia

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: W, Popularity: 81**

**Steps:**

Activate Altar of Dementia by sacrificing another creature.
When the creature dies, Bishop of Wings' second ability triggers, creating a 1/1 Spirit creature token.
When the Spirit token enters the battlefield, Bishop of Wings' first ability triggers, causing you to gain 4 life.
Resolve the Altar of Dementia ability from step 1, causing target player to mill cards equal to the sacrificed creature's power.
Repeat.

---

# 64-3617-4305

**Cards:**

- Warden of the Eye
- Followed Footsteps
- Time Walk

**Produces:** Infinite turns, Lock

**Mana: {1}{U} each turn, MV: 2, Colors: URW, Popularity: 0**

**Steps:**

Cast Time Walk by paying {1}{U}, causing you to take an extra turn after this one.
Move to your next turn.
At the beginning of your upkeep, Followed Footsteps triggers, creating a token copy of Warden of the Eye.
The Warden of the Eye token enters the battlefield, returning Time Walk from your graveyard to your hand.
Repeat.

---

# 643-656-1374

**Cards:**

- Haakon, Stromgald Scourge
- Maskwood Nexus
- Ugin's Conjurant

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: , MV: 0, Colors: B, Popularity: 1**

**Steps:**

Cast Ugin's Conjurant by paying {0}.
Ugin's Conjurant dies as a state based action due to having zero toughness.
Repeat.

---

# 644-1048-1267-4600-5241

**Cards:**

- Medomai the Ageless
- Sakashima's Student
- Mirror Gallery
- Triton Shorestalker
- Equilibrium

**Produces:** Infinite turns, Lock

**Mana: {2}{U}{U} each turn, MV: 4, Colors: WU, Popularity: 0**

**Steps:**

Declare Triton Shorestalker as an attacker.
During the declare blockers phase, when you recieve priority, activate Sakashima's Student's Ninjutsu ability by paying {1}{U} and returning Triton Shorestalker from the battlefield to your hand, putting Sakashima's Student from your hand onto the battlefield tapped and attacking as a copy of Medomai.
Deal combat damage with Sakashima's Student, causing you to take an additional turn after this one.
Cast Triton Shorestalker by paying {U}.
Equilibrium triggers, causing you to pay {1} to return Sakashima's Student from the battlefield to your hand.
Pass the turn.
Repeat.

---

# 644-1267-3395-4600-5241

**Cards:**

- Medomai the Ageless
- Triton Shorestalker
- Sakashima's Student
- Crystal Shard
- Mirror Gallery

**Produces:** Infinite turns, Lock

**Mana: {1}{U}{U}{U}, MV: 4, Colors: WU, Popularity: 0**

**Steps:**

Attack with Triton Shorestalker and when it isn't blocked, cast Sakashima's Student's for it's ninjutsu cost, paying {1}{U} and returning Triton Shorestalker to hand.
Have Sakashima's Student enter the battlefield as a copy of Medomai the Ageless and deal combat damage, gaining you an extra turn.
During your second main phase, cast Triton Shorestalker for {U}.
Return Sakashima's Student to your hand with Crystal Shard for {U}.
Pass the turn to yourself and repeat.

---

# 644-1267-3423-4600-5241

**Cards:**

- Medomai the Ageless
- Sakashima's Student
- Triton Shorestalker
- Mirror Gallery
- Aegis Automaton

**Produces:** Infinite turns, Lock

**Mana: {5}{W}{U}{U}, MV: 8, Colors: WU, Popularity: 1**

**Steps:**

Attack with Triton Shorestalker and when it isn't blocked, cast Sakashima's Student's for it's ninjutsu cost, paying {1}{U} and returning Triton Shorestalker to hand.
Have Sakashima's Student enter the battlefield as a copy of Medomai the Ageless and deal combat damage, gaining you an extra turn.
During your second main phase, cast Triton Shorestalker for {U}.
Return Sakashima's Student to your hand with Aegis Automaton for {4}{W}.
Pass the turn to yourself and repeat.

---

# 644-1267-3632-4600-5241

**Cards:**

- Medomai the Ageless
- Triton Shorestalker
- Sakashima's Student
- Erratic Portal
- Mirror Gallery

**Produces:** Infinite turns, Lock

**Mana: {2}{U}{U}, MV: 4, Colors: WU, Popularity: 1**

**Steps:**

Attack with Triton Shorestalker and when it isn't blocked, cast Sakashima's Student's for it's ninjutsu cost, paying {1}{U} and returning Triton Shorestalker to hand.
Have Sakashima's Student enter the battlefield as a copy of Medomai the Ageless and deal combat damage, gaining you an extra turn.
During your second main phase, cast Triton Shorestalker for {U}.
Return Sakashima's Student to your hand with Erratic Portal for {1}.
Pass the turn to yourself and repeat.

---

# 64-4305-4377

**Cards:**

- Warden of the Eye
- Followed Footsteps
- Walk the Aeons

**Produces:** Infinite turns, Lock

**Mana: {4}{U}{U} each turn, MV: 6, Colors: URW, Popularity: 1**

**Steps:**

Cast Walk the Aeons by paying {4}{U}{U}, causing you to take an extra turn after this one.
Move to your next turn.
At the beginning of your upkeep, Followed Footsteps triggers, creating a token copy of Warden of the Eye.
The Warden of the Eye token enters the battlefield, returning Walk the Aeons from your graveyard to your hand.
Repeat.

---

# 64-4305-4872

**Cards:**

- Warden of the Eye
- Followed Footsteps
- Time Warp

**Produces:** Infinite turns, Lock

**Mana: {3}{U}{U} each turn, MV: 5, Colors: URW, Popularity: 1**

**Steps:**

Cast Time Warp by paying {3}{U}{U}, causing you to take an extra turn after this one.
Move to your next turn.
At the beginning of your upkeep, Followed Footsteps triggers, creating a token copy of Warden of the Eye.
The Warden of the Eye token enters the battlefield, returning Time Warp from your graveyard to your hand.
Repeat.

---

# 645-914-2034-3750

**Cards:**

- Alesha, Who Smiles at Death
- Dockside Extortionist
- Aggravated Assault
- Ashnod's Altar

**Produces:** Infinite colored mana, Infinite combat phases, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite Treasure tokens, Infinite colorless mana, Infinite untap of creatures you control

**Mana: {W/B}{W/B}, MV: 2, Colors: RWB, Popularity: 7**

**Steps:**

Declare Alesha as an attacker.
Alesha triggers, causing you to pay {W/B}{W/B} to return Dockside Extortionist from your graveyard to the battlefield tapped and attacking.
When Dockside Extortionist enters the battlefield, it triggers, creating at least five Treasure tokens.
Move to your postcombat main phase.
Activate Ashnod's Altar by sacrificing Dockside Extortionist, adding {C}{C}.
Activate three Treasures by tapping and sacrificing them, adding {1}{R}{R}.
Activate Aggravated Assault by paying {3}{R}{R}, causing you to untap all creatures you control and to get an additional combat and main phase after this one.
Move to your next combat phase.
Declare Alesha as an attacker.
Alesha triggers, holding priority, activate two Treasures by tapping and sacrificing them, adding {W/B}{W/B}.
Resolve the Alesha trigger, causing you to pay {W/B}{W/B} to return Dockside Extortionist from your graveyard to the battlefield tapped and attacking.
Repeat from step 3.

---

# 6-4694-5261

**Cards:**

- Isochron Scepter
- Vitalize
- March of the Machines

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: , MV: 0, Colors: GU, Popularity: 0**

**Steps:**

Activate creatures you control by tapping those, adding {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Vitalize without paying its mana cost, untapping all creatures.
Repeat

---

# 6-4832-5261

**Cards:**

- Isochron Scepter
- Vitalize
- Ensoul Artifact

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: , MV: 0, Colors: GU, Popularity: 2**

**Steps:**

Activate creatures you control by tapping those, adding {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Vitalize without paying its mana cost, untapping all creatures.
Repeat

---

# 6-4916-5261

**Cards:**

- Isochron Scepter
- Vitalize
- Animate Artifact

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: , MV: 0, Colors: GU, Popularity: 1**

**Steps:**

Activate creatures you control by tapping those, adding {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Vitalize without paying its mana cost, untapping all creatures.
Repeat.

---

# 650-2034-3175

**Cards:**

- Sun Titan
- Ashnod's Altar
- Unhallowed Pact

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: WB, Popularity: 29**

**Steps:**

Activate Ashnod's Altar by sacrificing Sun Titan.
When Sun Titan dies, Unhallowed Pact triggers, returning Sun Titan from your graveyard to the battlefield.
When Sun Titan enters, it triggers, returning Unhallowed Pact from your graveyard to the battlefield attached to Sun Titan.
Repeat.

---

# 650-3175-4050

**Cards:**

- Sun Titan
- Phyrexian Altar
- Unhallowed Pact

**Produces:** Infinite sacrifice triggers, Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: WB, Popularity: 19**

**Steps:**

Activate Phyrexian Altar by sacrificing Sun Titan.
When Sun Titan dies, Unhallowed Pact triggers, returning Sun Titan from your graveyard to the battlefield.
When Sun Titan enters, it triggers, returning Unhallowed Pact from your graveyard to the battlefield attached to Sun Titan.
Repeat.

---

# 650-3175-5256

**Cards:**

- Sun Titan
- Altar of Dementia
- Unhallowed Pact

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: WB, Popularity: 24**

**Steps:**

Activate Altar of Dementia by sacrificing Sun Titan.
When Sun Titan dies, Unhallowed Pact triggers, returning Sun Titan from your graveyard to the battlefield.
When Sun Titan enters, it triggers, returning Unhallowed Pact from your graveyard to the battlefield attached to Sun Titan.
Resolve the Altar of Dementia ability.
Repeat.

---

# 6-5089-5261

**Cards:**

- Isochron Scepter
- Vitalize
- Karn, the Great Creator

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: , MV: 0, Colors: G, Popularity: 24**

**Steps:**

Activate Karn's first loyalty ability by adding a loyalty counter on it, causing Isochron Scepter to become an artifact creature until end of turn.
Activate creatures you control by tapping those, adding at least {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Vitalize without paying its mana cost, untapping all creatures.
Repeat from step 2.


---

# 651-1226-4046

**Cards:**

- Outrider en-Kor
- Task Force
- Noxious Gearhulk

**Produces:** Infinite lifegain

**Mana: {4}{B}{B}, MV: 6, Colors: WB, Popularity: 2**

**Steps:**

Pay {0} to activate Outrider en-Kor, targeting Task Force.
Task Force triggers, giving itself +0/+3 untill end of turn.
Repeat steps 1-2 untill Task Force has infinite toughness.
Cast Noxious Gearhulk, destroying Task Force and gaining life equal to its toughness.

---

# 651-1501-4046

**Cards:**

- Outrider en-Kor
- Task Force
- Predator's Rapport

**Produces:** Infinite lifegain

**Mana: {2}{G}, MV: 3, Colors: GW, Popularity: 3**

**Steps:**

Pay {0} to activate Outrider en-Kor, targeting Task Force.
Task Force triggers, giving itself +0/+3 untill end of turn.
Repeat steps 1-2 untill Task Force has infinite toughness.
Cast Predator's Rapport targeting Task Force, gaining life equal to its toughness.

---

# 651-1502-4046

**Cards:**

- Outrider en-Kor
- Task Force
- Arguel's Blood Fast // Temple of Aclazotz

**Produces:** Infinite lifegain

**Mana: , MV: 0, Colors: WB, Popularity: 6**

**Steps:**

Pay {0} to activate Outrider en-Kor, targeting Task Force.
Task Force triggers, giving itself +0/+3 untill end of turn.
Repeat steps 1-2 untill Task Force has infinite toughness.
Tap Temple of Aclazotz, sacrificing Task Force and gaining life equal to its toughness.

---

# 651-1946-2603

**Cards:**

- Nomads en-Kor
- Task Force
- Worthy Cause

**Produces:** Infinite lifegain

**Mana: {W}, MV: 1, Colors: W, Popularity: 89**

**Steps:**

Activate Nomads en-Kor by paying {0}, targeting Task Force.
Task Force triggers, giving itself +0/+3 until end of turn.
Resolve Nomads en-Kor's ability, causing the next one damage dealt to Nomads en-Kor this turn to be dealt to Task Force instead.
Repeat an arbitrarily large number of times.
Cast Worthy Cause by paying {W} and sacrificing Task Force, causing you to gain life equal to Task Force's toughness.

---

# 651-2200-4046

**Cards:**

- Outrider en-Kor
- Task Force
- Diamond Valley

**Produces:** Infinite lifegain

**Mana: , MV: 0, Colors: W, Popularity: 29**

**Steps:**

Pay {0} to activate Outrider en-Kor, targeting Task Force.
Task Force triggers, giving itself +0/+3 untill end of turn.
Repeat steps 1-2 untill Task Force has infinite toughness.
Tap Diamond Valley sacrificing Task Force, gaining life equal to its toughness.

---

# 651-2342-2603

**Cards:**

- Shaman en-Kor
- Task Force
- Worthy Cause

**Produces:** Infinite lifegain

**Mana: {W}, MV: 1, Colors: W, Popularity: 66**

**Steps:**

Activate Shaman en-Kor's first ability by paying {0}, targeting Task Force.
Task Force triggers, giving itself +0/+3 until end of turn.
Resolve Shaman en-Kor's ability, causing the next one damage dealt to Shaman en-Kor this turn to be dealt to Task Force instead.
Repeat an arbitrarily large number of times.
Cast Worthy Cause by paying {W} and sacrificing Task Force, causing you to gain life equal to Task Force's toughness.

---

# 651-2603-2816

**Cards:**

- Umbral Mantle
- Task Force
- Worthy Cause

**Produces:** Infinite lifegain

**Mana: {W}, MV: 1, Colors: W, Popularity: 27**

**Steps:**

Activate Umbral Mantle's equip ability by paying {0}, targeting Task Force.
Task Force triggers, giving itself +0/+3 until end of turn.
Resolve the Umbral Mantle ability, attaching it to Task Force.
Repeat from step 1 an arbitrarily large number of times.
Cast Worthy Cause by paying {W} and by sacrificing Task Force, causing you to gain life equal to Task Force's toughness.

---

# 651-2603-3140

**Cards:**

- Soltari Guerrillas
- Task Force
- Worthy Cause

**Produces:** Infinite lifegain

**Mana: {W}, MV: 1, Colors: RW, Popularity: 0**

**Steps:**

Activate Soltari Guerrillas by paying {0}, targeting Task Force.
Task Force triggers, giving itself +0/+3 until end of turn.
Resolve Soltari Guerrillas's ability, causing the next one combat damage dealt by Soltari Guerrillas to an opponent this turn to be dealt to Task Force instead.
Repeat an arbitrarily large number of times.
Cast Worthy Cause by paying {W} and sacrificing Task Force, causing you to gain life equal to Task Force's toughness.

---

# 651-2603-4046

**Cards:**

- Outrider en-Kor
- Task Force
- Worthy Cause

**Produces:** Infinite lifegain

**Mana: {W}, MV: 1, Colors: W, Popularity: 237**

**Steps:**

Activate Outrider en-Kor by paying {0}, targeting Task Force.
Task Force triggers, giving itself +0/+3 until end of turn.
Resolve Outrider en-Kor's ability, causing the next one damage dealt to Outrider en-Kor this turn to be dealt to Task Force instead.
Repeat an arbitrarily large number of times.
Cast Worthy Cause by paying {W} and sacrificing Task Force, causing you to gain life equal to Task Force's toughness.

---

# 651-2603-4594

**Cards:**

- Spirit en-Kor
- Task Force
- Worthy Cause

**Produces:** Infinite lifegain

**Mana: {W}, MV: 1, Colors: W, Popularity: 38**

**Steps:**

Activate Spirit en-Kor by paying {0}, targeting Task Force.
Task Force triggers, giving itself +0/+3 until end of turn.
Resolve Spirit en-Kor's ability, causing the next one damage dealt to Spirit en-Kor this turn to be dealt to Task Force instead.
Repeat an arbitrarily large number of times.
Cast Worthy Cause by paying {W} and sacrificing Task Force, causing you to gain life equal to Task Force's toughness.

---

# 651-2603-4943

**Cards:**

- Lancers en-Kor
- Task Force
- Worthy Cause

**Produces:** Infinite lifegain

**Mana: {W}, MV: 1, Colors: W, Popularity: 23**

**Steps:**

Activate Lancers en-Kor's by paying {0}, targeting Task Force.
Task Force triggers, giving itself +0/+3 until end of turn.
Resolve Lancers en-Kor's ability, causing the next one damage dealt to Lancers en-Kor this turn to be dealt to Task Force instead.
Repeat an arbitrarily large number of times.
Cast Worthy Cause by paying {W} and sacrificing Task Force, causing you to gain life equal to Task Force's toughness.

---

# 651-2603-4955

**Cards:**

- Grafted Wargear
- Task Force
- Worthy Cause

**Produces:** Infinite lifegain

**Mana: {W}, MV: 1, Colors: W, Popularity: 7**

**Steps:**

Activate Grafted Wargear's equip ability by paying {0}, targeting Task Force.
Task Force triggers, giving itself +0/+3 until end of turn.
Resolve the Grafted Wargear ability, attaching it to Task Force.
Repeat from step 1 an arbitrarily large number of times.
Cast Worthy Cause by paying {W} and by sacrificing Task Force, causing you to gain life equal to Task Force's toughness.

---

# 651-2849-4046

**Cards:**

- Outrider en-Kor
- Task Force
- Sheltering Word

**Produces:** Infinite lifegain

**Mana: {1}{G}, MV: 2, Colors: GW, Popularity: 7**

**Steps:**

Pay {0} to activate Outrider en-Kor, targeting Task Force.
Task Force triggers, giving itself +0/+3 untill end of turn.
Repeat steps 1-2 untill Task Force has infinite toughness.
Cast Sheltering Word targeting Task Force, gaining life equal to its toughness.

---

# 651-3397-4046

**Cards:**

- Outrider en-Kor
- Task Force
- Sever Soul

**Produces:** Infinite lifegain

**Mana: {3}{B}{B}, MV: 5, Colors: WB, Popularity: 2**

**Steps:**

Pay {0} to activate Outrider en-Kor, targeting Task Force.
Task Force triggers, giving itself +0/+3 untill end of turn.
Repeat steps 1-2 untill Task Force has infinite toughness.
Cast Sever Soul targeting Task Force, gaining life equal to its toughness.

---

# 651-3405-4046

**Cards:**

- Outrider en-Kor
- Task Force
- Ayli, Eternal Pilgrim

**Produces:** Infinite lifegain

**Mana: {1}, MV: 1, Colors: WB, Popularity: 51**

**Steps:**

Pay {0} to activate Outrider en-Kor, targeting Task Force.
Task Force triggers, giving itself +0/+3 untill end of turn.
Repeat steps 1-2 untill Task Force has infinite toughness.
Pay {1} to activate Ayli, sacrificing Task Force and gaining life equal to its toughness.

---

# 651-3533-4046

**Cards:**

- Outrider en-Kor
- Task Force
- Doomgape

**Produces:** Infinite lifegain

**Mana: , MV: 0, Colors: WBG, Popularity: 0**

**Steps:**

Pay {0} to activate Outrider en-Kor, targeting Task Force.
Task Force triggers, giving itself +0/+3 untill end of turn.
Repeat steps 1-2 untill Task Force has infinite toughness.
Sacrifice Task Force to Doomgape, gaining life equal to its toughness.

---

# 651-3588-4046

**Cards:**

- Task Force
- Animal Boneyard
- Outrider en-Kor

**Produces:** Infinite lifegain

**Mana: , MV: 0, Colors: W, Popularity: 196**

**Steps:**

Pay {0} to activate Outrider en-Kor, targeting Task Force.
Task Force triggers, giving itself +0/+3 untill end of turn.
Repeat steps 1-2 untill Task Force has infinite toughness.
Tap the land equiped with Animal Boneyard, sacrificing Task Force and gaining life equal to its toughness.

---

# 651-3997-4046

**Cards:**

- Outrider en-Kor
- Task Force
- Heal the Scars

**Produces:** Infinite lifegain

**Mana: {3}{G}, MV: 4, Colors: GW, Popularity: 2**

**Steps:**

Pay {0} to activate Outrider en-Kor, targeting Task Force.
Task Force triggers, giving itself +0/+3 untill end of turn.
Repeat steps 1-2 untill Task Force has infinite toughness.
Cast Heal the Scars targeting Task Force, gaining life equal to its toughness.

---

# 651-4046-4194

**Cards:**

- Outrider en-Kor
- Task Force
- Consuming Vapors

**Produces:** Infinite lifegain

**Mana: {3}{B}, MV: 4, Colors: WB, Popularity: 2**

**Steps:**

Pay {0} to activate Outrider en-Kor, targeting Task Force.
Task Force triggers, giving itself +0/+3 untill end of turn.
Repeat steps 1-2 untill Task Force has infinite toughness.
Cast Consuming Vapors sacrificing Task Force, gaining life equal to its toughness.

---

# 651-4046-4337

**Cards:**

- Outrider en-Kor
- Task Force
- Vraska's Stoneglare

**Produces:** Infinite lifegain

**Mana: {4}{B}{G}, MV: 6, Colors: WBG, Popularity: 0**

**Steps:**

Pay {0} to activate Outrider en-Kor, targeting Task Force.
Task Force triggers, giving itself +0/+3 untill end of turn.
Repeat steps 1-2 untill Task Force has infinite toughness.
Cast Vraska's Stoneglare, destroying Task Force and gaining life equal to its toughness.

---

# 651-4046-4361

**Cards:**

- Outrider en-Kor
- Task Force
- Miren, the Moaning Well

**Produces:** Infinite lifegain

**Mana: {3}, MV: 3, Colors: W, Popularity: 170**

**Steps:**

Pay {0} to activate Outrider en-Kor, targeting Task Force.
Task Force triggers, giving itself +0/+3 untill end of turn.
Repeat steps 1-2 untill Task Force has infinite toughness.
Pay {3} and tap Miren, the Moaning Well, sacrificing Task Force and gaining life equal to its toughness.

---

# 651-4046-4479

**Cards:**

- Outrider en-Kor
- Task Force
- Life Chisel

**Produces:** Infinite lifegain

**Mana: , MV: 0, Colors: W, Popularity: 24**

**Steps:**

Pay {0} to activate Outrider en-Kor, targeting Task Force.
Task Force triggers, giving itself +0/+3 untill end of turn.
Repeat steps 1-2 untill Task Force has infinite toughness.
Sacrifice Task Force to Life Chisel, gaining life equal to its toughness.

---

# 651-4046-4595

**Cards:**

- Outrider en-Kor
- Task Force
- Garruk, Apex Predator

**Produces:** Infinite lifegain

**Mana: , MV: 0, Colors: WBG, Popularity: 0**

**Steps:**

Pay {0} to activate Outrider en-Kor, targeting Task Force.
Task Force triggers, giving itself +0/+3 untill end of turn.
Repeat steps 1-2 untill Task Force has infinite toughness.
Activate Garruk's -3 ability destroying Task Force, gaining life equal to its toughness.

---

# 651-4046-5306

**Cards:**

- Outrider en-Kor
- Task Force
- Disciple of Griselbrand

**Produces:** Infinite lifegain

**Mana: {1}, MV: 1, Colors: WB, Popularity: 30**

**Steps:**

Pay {0} to activate Outrider en-Kor, targeting Task Force.
Task Force triggers, giving itself +0/+3 untill end of turn.
Repeat steps 1-2 untill Task Force has infinite toughness.
Pay {1} to activate Disciple of Griselbrand sacrificing Task Force, gaining life equal to its toughness.

---

# 651-928-4046

**Cards:**

- Outrider en-Kor
- Task Force
- Huatli, the Sun's Heart

**Produces:** Infinite lifegain

**Mana: , MV: 0, Colors: GW, Popularity: 21**

**Steps:**

Activate Outrider en-Kor by paying {0}, targeting Task Force.
Task Force triggers, giving itself +0/+3 until end of turn.
Resolve Outrider en-Kor's ability, causing the next one damage dealt to Outrider en-Kor this turn to be dealt to Task Force instead.
Repeat an arbitrarily large number of times.
Activate Hualti by removing three loyalty counters from it, causing you to gain life equal to Task Force's toughness.

---

# 654-1021-2167-3470

**Cards:**

- Lotus Cobra
- Squandered Resources
- Amulet of Vigor
- Drownyard Temple

**Produces:** Infinite landfall triggers

**Mana: {1}, MV: 1, Colors: BG, Popularity: 270**

**Steps:**

Activate Drownyard Temple's first ability by tapping it, adding {C}.
Activate Squandered Resources by sacrificing Drownyard Temple, adding {C}.
Activate Drownyard Temple's second ability by paying {3}, returning it from your graveyard to the battlefield tapped.
When Drownyard Temple enters the battlefield, Lotus Cobra and Amulet of Vigor trigger.
Resolve the Lotus Cobra trigger, adding {1}.
Resolve the Amulet of Vigor trigger, untapping Drownyard Temple.
Repeat.

---

# 654-1021-2167-4482

**Cards:**

- Drownyard Temple
- Ancient Greenwarden
- Squandered Resources
- Amulet of Vigor

**Produces:** Infinite landfall triggers

**Mana: {1}, MV: 1, Colors: BG, Popularity: 133**

**Steps:**

Activate Drownyard Temple's first ability by tapping it, adding {C}.
Activate Squandered Resources by sacrificing Drownyard Temple, adding {C}.
Activate Drownyard Temple's last ability by paying {3}, returning it from your graveyard to the battlefield tapped.
When Drownyard Temple enters the battlefield, Amulet of Vigor triggers twice due to Ancient Greenwarden.
Resolve one Amulet of Vigor trigger, untapping Drownyward Temple.
Activate Drownyard Temple's first ability by tapping it, adding {C}.
Resolve the remaining Amulet of Vigor trigger, untapping Drownyward Temple.
Repeat.

---

# 654-774-1846-4270

**Cards:**

- Patron of the Moon
- Amulet of Vigor
- Trade Routes
- High Tide

**Produces:** Infinite colored mana, Infinite landfall triggers

**Mana: {U}, MV: 1, Colors: U, Popularity: 700**

**Steps:**

Cast High Tide.
Tap two Islands for {4}.
Activate Trade Routes twice for {2}, returning the tapped Islands to hand.
Activate Patron of the Moon for {1}, putting both Islands onto the battlefield tapped.
Amulet of Vigor triggers, untapping both Islands.
Repeat the loop, floating {U} each iteration.

---

# 654-774-2404-3886-4637

**Cards:**

- Soratami Mirror-Mage
- Omnath, Locus of Creation
- Patron of the Moon
- Amulet of Vigor
- Gaea's Cradle

**Produces:** Infinite card draw, Infinite draw triggers, Near-infinite damage, Near-infinite green mana, Near-infinite landfall triggers, Near-infinite lifegain, Near-infinite lifegain triggers, Near-infinite mana lands you control can produce, Near-infinite storm count

**Mana: {4}{R}{G}{W}{U}, MV: 8, Colors: RGWU, Popularity: 8**

**Steps:**

Activate Soratami Mirror-Mage by paying {3} and returning Gaea's Cradle and two other mana-producing lands from the battlefield to your hand, returning Omnath from the battlefield to your hand.
Cast Omnath by paying {W}{U}{R}{G}.
Omnath enters the battlefield, triggering itself, causing you to draw a card.
Activate Patron of the Moon by paying {1}, putting Gaea's Cradle and another mana-producing land from your hand onto the battlefield tapped.
When the lands enter the battlefield, Omnath triggers twice and Amulet of Vigor triggers twice.
Resolve both Omnath triggers, causing you to gain 4 life and add {W}{U}{R}{G}.
Resolve both Amulet of Vigor triggers, untapping the lands that entered the battlefield.
Activate Gaea's Cradle by tapping it, adding at least {G}{G}{G}.
Activate the additional land by tapping it, adding {1}.
Activate Patron of the Moon again by paying {1}, putting the third land from your hand onto the battlefield tapped.
When the land enters the battlefield, Omnath and Amulet of Vigor trigger.
Resolve Omnath's trigger, dealing 4 damage to each opponent and each planeswalker you don't control.
Resolve Amulet of Vigor's trigger, untapping that land.
Activate that land by tapping it, adding {1}.
Repeat.

---

# 654-880-1659

**Cards:**

- Perilous Forays
- Seed the Land
- Amulet of Vigor

**Produces:** Put all lands with a basic land type from your library onto the battlefield tapped

**Mana: {1}, MV: 1, Colors: G, Popularity: 22**

**Steps:**

Activate Perilous Forays by paying {1} and sacrificing a creature you control, searching your library for a land card with a basic land type and putting it on the battlefield tapped.
When the land enters the battlefield, Seed the Land and Amulet of Vigor trigger.
Resolve the Seed the Land trigger, creating a creature token.
Resolve the Amulet of Vigor trigger, untapping the land.
Activate the land by tapping it, adding {1}.
Repeat.

---

# 654-880-2783

**Cards:**

- Perilous Forays
- Nesting Dragon
- Amulet of Vigor

**Produces:** Put all lands with a basic land type from your library onto the battlefield tapped

**Mana: {1}, MV: 1, Colors: RG, Popularity: 47**

**Steps:**

Activate Perilous Forays by paying {1} and sacrificing a creature you control.
If the creature was a Dragon Egg, it triggers, creating a 2/2 Dragon creature token.
Resolve the Perilous Forays ability, searching your library for a land card with a basic land type and putting it on the battlefield tapped.
When the land enters the battlefield, Nesting Dragon and Amulet of Vigor trigger.
Resolve the Nesting Dragon trigger, creating a creature token.
Resolve the Amulet of Vigor trigger, untapping the land.
Activate the land by tapping it, adding {1}.
Repeat.

---

# 654-880-3703

**Cards:**

- Perilous Forays
- Sporemound
- Amulet of Vigor

**Produces:** Put all lands with a basic land type from your library onto the battlefield tapped

**Mana: {1}, MV: 1, Colors: G, Popularity: 71**

**Steps:**

Activate Perilous Forays by paying {1} and sacrificing a creature you control, searching your library for a land card with a basic land type and putting it on the battlefield tapped.
When the land enters the battlefield, Sporemound and Amulet of Vigor trigger.
Resolve the Sporemound trigger, creating a creature token.
Resolve the Amulet of Vigor trigger, untapping the land.
Activate the land by tapping it, adding {1}.
Repeat.

---

# 654-880-4488

**Cards:**

- Perilous Forays
- Rampaging Baloths
- Amulet of Vigor

**Produces:** Put all lands with a basic land type from your library onto the battlefield tapped

**Mana: {1}, MV: 1, Colors: G, Popularity: 548**

**Steps:**

Activate Perilous Forays by paying {1} and sacrificing a creature you control, searching your library for a land card with a basic land type and putting it on the battlefield tapped.
When the land enters the battlefield, Rampaging Baloths and Amulet of Vigor trigger.
Resolve the Rampaging Baloths trigger, creating a creature token.
Resolve the Amulet of Vigor trigger, untapping the land.
Activate the land by tapping it, adding {1}.
Repeat.

---

# 654-880-4677

**Cards:**

- Perilous Forays
- Zendikar's Roil
- Amulet of Vigor

**Produces:** Put all lands with a basic land type from your library onto the battlefield tapped

**Mana: {1}, MV: 1, Colors: G, Popularity: 432**

**Steps:**

Activate Perilous Forays by paying {1} and sacrificing a creature you control, searching your library for a land card with a basic land type and putting it on the battlefield tapped.
When the land enters the battlefield, Zendikar's Roil and Amulet of Vigor trigger.
Resolve the Zendikar's Roil trigger, creating a creature token.
Resolve the Amulet of Vigor trigger, untapping the land.
Activate the land by tapping it, adding {1}.
Repeat.

---

# 654-880-4862

**Cards:**

- Perilous Forays
- Omnath, Locus of Rage
- Amulet of Vigor

**Produces:** Near-infinite damage, Put all lands with a basic land type from your library onto the battlefield tapped

**Mana: {1}, MV: 1, Colors: RG, Popularity: 665**

**Steps:**

Activate Perilous Forays by paying {1} and sacrificing a creature you control.
If the creature was an Elemental, Omnath triggers, dealing 3 damage to any target.
Resolve the Perilous Forays ability, searching your library for a land card with a basic land type and putting it on the battlefield tapped.
When the land enters the battlefield, Omnath and Amulet of Vigor trigger.
Resolve the Omnath trigger, creating a creature token.
Resolve the Amulet of Vigor trigger, untapping the land.
Activate the land by tapping it, adding {1}.
Repeat.

---

# 65-615-717-1094-2628

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Cartographer
- Slippery Karst

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: BGU, Popularity: 3**

**Steps:**

Activate Slippery Karst's cycling ability by paying {0} and discarding it.
Bone Miser, Slippery Karst, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Slippery Karst trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Cartographer.
Cartographer enters the battlefield, returning Slippery Karst from your graveyard to your hand.
Repeat.

---

# 65-615-717-1583-2628

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Cartographer
- Drifting Meadow

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: GWUB, Popularity: 0**

**Steps:**

Activate Drifting Meadow's cycling ability by paying {0} and discarding it.
Bone Miser, Drifting Meadow, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Drifting Meadow trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Cartographer.
Cartographer enters the battlefield, returning Drifting Meadow from your graveyard to your hand.
Repeat.

---

# 65-615-717-2628-3855

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Cartographer
- Remote Isle

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: BGU, Popularity: 3**

**Steps:**

Activate Remote Isle's cycling ability by paying {0} and discarding it.
Bone Miser, Remote Isle, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Remote Isle trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Cartographer.
Cartographer enters the battlefield, returning Remote Isle from your graveyard to your hand.
Repeat.

---

# 65-615-717-2628-4310

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Cartographer
- Blasted Landscape

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: BGU, Popularity: 3**

**Steps:**

Activate Blasted Landscape's cycling ability by paying {0} and discarding it.
Bone Miser, Blasted Landscape, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Blasted Landscape trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Cartographer.
Cartographer enters the battlefield, returning Blasted Landscape from your graveyard to your hand.
Repeat.

---

# 65-615-717-2628-4371

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Cartographer
- Irrigated Farmland

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: GWUB, Popularity: 0**

**Steps:**

Activate Irrigated Farmland's cycling ability by paying {0} and discarding it.
Bone Miser, Irrigated Farmland, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Irrigated Farmland trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Cartographer.
Cartographer enters the battlefield, returning Irrigated Farmland from your graveyard to your hand.
Repeat.

---

# 65-615-717-2628-4606

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Cartographer
- Sheltered Thicket

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: UBRG, Popularity: 2**

**Steps:**

Activate Sheltered Thicket's cycling ability by paying {0} and discarding it.
Bone Miser and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Cartographer.
Cartographer enters the battlefield, returning Sheltered Thicket from your graveyard to your hand.
Repeat any number of times.
Resolve all Sheltered Thicket abilities, drawing a card each time.

---

# 65-615-717-2628-4607

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Cartographer
- Smoldering Crater

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: UBRG, Popularity: 1**

**Steps:**

Activate Smoldering Crater's cycling ability by paying {0} and discarding it.
Bone Miser, Smoldering Crater, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Smoldering Crater trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Cartographer.
Cartographer enters the battlefield, returning Smoldering Crater from your graveyard to your hand.
Repeat.

---

# 65-615-717-2628-4686

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Cartographer
- Polluted Mire

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: BGU, Popularity: 3**

**Steps:**

Activate Polluted Mire's cycling ability by paying {0} and discarding it.
Bone Miser, Polluted Mire, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Polluted Mire trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Cartographer.
Cartographer enters the battlefield, returning Polluted Mire from your graveyard to your hand.
Repeat.

---

# 65-615-717-808-2628

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Cartographer
- Canyon Slough

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: UBRG, Popularity: 2**

**Steps:**

Activate Canyon Slough's cycling ability by paying {0} and discarding it.
Bone Miser, Canyon Slough, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Canyon Slough trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Cartographer.
Cartographer enters the battlefield, returning Canyon Slough from your graveyard to your hand.
Repeat.

---

# 65-615-717-875-2628

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Cartographer
- Fetid Pools

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: BGU, Popularity: 3**

**Steps:**

Activate Fetid Pools's cycling ability by paying {0} and discarding it.
Bone Miser, Fetid Pools, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Fetid Pools trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Cartographer.
Cartographer enters the battlefield, returning Fetid Pools from your graveyard to your hand.
Repeat.

---

# 65-615-717-881-2628

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Cartographer
- Scattered Groves

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: GWUB, Popularity: 0**

**Steps:**

Activate Scattered Groves's cycling ability by paying {0} and discarding it.
Bone Miser, Scattered Groves, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Scattered Groves trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Cartographer.
Cartographer enters the battlefield, returning Scattered Groves from your graveyard to your hand.
Repeat.

---

# 656-2018-4053

**Cards:**

- Luminous Broodmoth
- Solemnity
- Ugin's Conjurant

**Produces:** Draw the game, Infinite LTB, Infinite ETB, Infinite death triggers

**Mana: , MV: 0, Colors: W, Popularity: 8**

**Steps:**

Cast Ugin's Conjurant by paying {0}.
Ugin's Conjurant enters the battlefield and dies as a state-based action due to having 0 toughness.
Luminous Broodmoth triggers, returning Ugin's Conjurant from your graveyard to the battlefield without a flying counter due to Solemnity.
Repeat from step 2.

---

# 656-2232-3187-3771

**Cards:**

- Animar, Soul of Elements
- Cloudstone Curio
- Ugin's Conjurant
- Wandering Archaic // Explore the Vastlands

**Produces:** Infinite +1/+1 counters on certain creatures, Infinite ETB, Infinite LTB, Infinite storm count, Infinite +1/+1 counters on a creature

**Mana: , MV: 0, Colors: GUR, Popularity: 48**

**Steps:**

Cast Ugin's Conjurant, choosing one for X, but paying {0} due to Animar.
Animar triggers, putting a +1/+1 counter on itself.
Ugin's Conjurant enters the battlefield, triggering Cloudstone Curio, returning Wandering Archaic from the battlefield to your hand.
Cast Wandering Archaic by paying {0}.
Animar triggers, putting a +1/+1 counter on itself.
Wandering Archaic enters the battlefield, triggering Cloudstone Curio, returning Ugin's Conjurant from the battlefield to your hand.
Repeat.

---

# 656-678

**Cards:**

- Ugin's Conjurant
- Enduring Renewal

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: , MV: 0, Colors: W, Popularity: 247**

**Steps:**

Cast Ugin's Conjurant by paying {0}.
Ugin's Conjurant enters the battlefield and dies as a state-based action due to having zero or less toughness.
Enduring Renewal triggers, returning Ugin's Conjurant from your graveyard to your hand.
Repeat.

---

# 65-717-1094-2628-2993

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Stoic Builder
- Slippery Karst

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: BGU, Popularity: 1**

**Steps:**

Activate Slippery Karst's cycling ability by paying {0} and discarding it.
Bone Miser, Slippery Karst, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Slippery Karst trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Stoic Builder.
Stoic Builder enters the battlefield, returning Slippery Karst from your graveyard to your hand.
Repeat.

---

# 65-717-1094-2628-4477

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Greenwarden of Murasa
- Slippery Karst

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: BGU, Popularity: 3**

**Steps:**

Activate Slippery Karst's cycling ability by paying {0} and discarding it.
Bone Miser, Slippery Karst, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Slippery Karst trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Greenwarden of Murasa.
Greenwarden of Murasa enters the battlefield, returning Slippery Karst from your graveyard to your hand.
Repeat.

---

# 65-717-1094-2628-4652

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Tilling Treefolk
- Slippery Karst

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: BGU, Popularity: 14**

**Steps:**

Activate Slippery Karst's cycling ability by paying {0} and discarding it.
Bone Miser, Slippery Karst, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Slippery Karst trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Tilling Treefolk.
Tilling Treefolk enters the battlefield, returning Slippery Karst and up to one other land from your graveyard to your hand.
Repeat.

---

# 65-717-1094-2628-5181

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Golgari Findbroker
- Slippery Karst

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: BGU, Popularity: 1**

**Steps:**

Cycle Slippery Karst for {0} due to Fluctuator.
Escape Protocol and Bone Miser trigger.
Stack the triggers such that Bone Miser's ability resolves first, adding {B}{B}.
Resolve Escape Protocol's ability using {1} to pay for it to blink Golgari Findbroker.
When Golgari Findbroker ETBs, return Slippery Karst to your hand.
Resolve the cycling trigger and draw a card.

---

# 65-717-1583-2628-2993

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Stoic Builder
- Drifting Meadow

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: GWUB, Popularity: 0**

**Steps:**

Activate Drifting Meadow's cycling ability by paying {0} and discarding it.
Bone Miser, Drifting Meadow, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Drifting Meadow trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Stoic Builder.
Stoic Builder enters the battlefield, returning Drifting Meadow from your graveyard to your hand.
Repeat.

---

# 65-717-1583-2628-4477

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Greenwarden of Murasa
- Drifting Meadow

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: GWUB, Popularity: 0**

**Steps:**

Activate Drifting Meadow's cycling ability by paying {0} and discarding it.
Bone Miser, Drifting Meadow, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Drifting Meadow trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Greenwarden of Murasa.
Greenwarden of Murasa enters the battlefield, returning Drifting Meadow from your graveyard to your hand.
Repeat.

---

# 65-717-1583-2628-4652

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Tilling Treefolk
- Drifting Meadow

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: GWUB, Popularity: 11**

**Steps:**

Activate Drifting Meadow's cycling ability by paying {0} and discarding it.
Bone Miser, Drifting Meadow, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Drifting Meadow trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Tilling Treefolk.
Tilling Treefolk enters the battlefield, returning Drifting Meadow and up to one other land from your graveyard to your hand.
Repeat.

---

# 65-717-1583-2628-5181

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Golgari Findbroker
- Drifting Meadow

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: GWUB, Popularity: 0**

**Steps:**

Activate Drifting Meadow's cycling ability by paying {0} and discarding it.
Bone Miser, Drifting Meadow, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Drifting Meadow trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Golgari Findbroker.
Golgari Findbroker enters the battlefield, returning Drifting Meadow from your graveyard to your hand.
Repeat.

---

# 65-717-2628-2993-3855

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Stoic Builder
- Remote Isle

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: BGU, Popularity: 1**

**Steps:**

Activate Remote Isle's cycling ability by paying {0} and discarding it.
Bone Miser, Remote Isle, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Remote Isle trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Stoic Builder.
Stoic Builder enters the battlefield, returning Remote Isle from your graveyard to your hand.
Repeat.

---

# 65-717-2628-2993-4310

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Stoic Builder
- Blasted Landscape

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: BGU, Popularity: 1**

**Steps:**

Activate Blasted Landscape's cycling ability by paying {0} and discarding it.
Bone Miser, Blasted Landscape, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Blasted Landscape trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Stoic Builder.
Stoic Builder enters the battlefield, returning Blasted Landscape from your graveyard to your hand.
Repeat.

---

# 65-717-2628-2993-4371

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Stoic Builder
- Irrigated Farmland

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: GWUB, Popularity: 0**

**Steps:**

Activate Irrigated Farmland's cycling ability by paying {0} and discarding it.
Bone Miser, Irrigated Farmland, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Irrigated Farmland trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Stoic Builder.
Stoic Builder enters the battlefield, returning Irrigated Farmland from your graveyard to your hand.
Repeat.

---

# 65-717-2628-2993-4606

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Stoic Builder
- Sheltered Thicket

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: UBRG, Popularity: 1**

**Steps:**

Activate Sheltered Thicket's cycling ability by paying {0} and discarding it.
Bone Miser, Sheltered Thicket, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Sheltered Thicket trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Stoic Builder.
Stoic Builder enters the battlefield, returning Sheltered Thicket from your graveyard to your hand.
Repeat.

---

# 65-717-2628-2993-4607

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Stoic Builder
- Smoldering Crater

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: UBRG, Popularity: 1**

**Steps:**

Activate Smoldering Crater's cycling ability by paying {0} and discarding it.
Bone Miser, Smoldering Crater, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Smoldering Crater trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Stoic Builder.
Stoic Builder enters the battlefield, returning Smoldering Crater from your graveyard to your hand.
Repeat.

---

# 65-717-2628-2993-4686

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Stoic Builder
- Polluted Mire

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: BGU, Popularity: 1**

**Steps:**

Activate Polluted Mire's cycling ability by paying {0} and discarding it.
Bone Miser, Polluted Mire, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Polluted Mire trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Stoic Builder.
Stoic Builder enters the battlefield, returning Polluted Mire from your graveyard to your hand.
Repeat.

---

# 65-717-2628-3855-4477

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Greenwarden of Murasa
- Remote Isle

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: BGU, Popularity: 3**

**Steps:**

Activate Remote Isle's cycling ability by paying {0} and discarding it.
Bone Miser, Remote Isle, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Remote Isle trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Greenwarden of Murasa.
Greenwarden of Murasa enters the battlefield, returning Remote Isle from your graveyard to your hand.
Repeat.

---

# 65-717-2628-3855-4652

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Tilling Treefolk
- Remote Isle

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: BGU, Popularity: 13**

**Steps:**

Activate Remote Isle's cycling ability by paying {0} and discarding it.
Bone Miser, Remote Isle, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Remote Isle trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Tilling Treefolk.
Tilling Treefolk enters the battlefield, returning Remote Isle and up to one other land from your graveyard to your hand.
Repeat.

---

# 65-717-2628-3855-5181

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Golgari Findbroker
- Remote Isle

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: BGU, Popularity: 1**

**Steps:**

Cycle Remote Isle for {0} due to Fluctuator.
Escape Protocol and Bone Miser trigger.
Stack the triggers such that Bone Miser's ability resolves first, adding {B}{B}.
Resolve Escape Protocol's ability using {1} to pay for it to blink Golgari Findbroker.
When Golgari Findbroker ETBs, return Remote Isle to your hand.
Resolve the cycling trigger and draw a card.

---

# 65-717-2628-4310-4477

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Greenwarden of Murasa
- Blasted Landscape

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: BGU, Popularity: 1**

**Steps:**

Activate Blasted Landscape's cycling ability by paying {0} and discarding it.
Bone Miser, Blasted Landscape, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Blasted Landscape trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Greenwarden of Murasa.
Greenwarden of Murasa enters the battlefield, returning Blasted Landscape from your graveyard to your hand.
Repeat.

---

# 65-717-2628-4310-4652

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Tilling Treefolk
- Blasted Landscape

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: BGU, Popularity: 18**

**Steps:**

Activate Blasted Landscape's cycling ability by paying {0} and discarding it.
Bone Miser, Blasted Landscape, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Blasted Landscape trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Tilling Treefolk.
Tilling Treefolk enters the battlefield, returning Blasted Landscape and up to one other land from your graveyard to your hand.
Repeat.

---

# 65-717-2628-4310-5181

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Golgari Findbroker
- Blasted Landscape

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: BGU, Popularity: 1**

**Steps:**

Activate Blasted Landscape's cycling ability by paying {0} and discarding it.
Bone Miser, Blasted Landscape, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Blasted Landscape trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Golgari Findbroker.
Golgari Findbroker enters the battlefield, returning Blasted Landscape from your graveyard to your hand.
Repeat.

---

# 65-717-2628-4371-4477

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Greenwarden of Murasa
- Irrigated Farmland

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: GWUB, Popularity: 0**

**Steps:**

Activate Irrigated Farmland's cycling ability by paying {0} and discarding it.
Bone Miser, Irrigated Farmland, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Irrigated Farmland trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Greenwarden of Murasa.
Greenwarden of Murasa enters the battlefield, returning Irrigated Farmland from your graveyard to your hand.
Repeat.

---

# 65-717-2628-4371-4652

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Tilling Treefolk
- Irrigated Farmland

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: GWUB, Popularity: 20**

**Steps:**

Activate Irrigated Farmland's cycling ability by paying {0} and discarding it.
Bone Miser, Irrigated Farmland, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Irrigated Farmland trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Tilling Treefolk.
Tilling Treefolk enters the battlefield, returning Irrigated Farmland and up to one other land from your graveyard to your hand.
Repeat.

---

# 65-717-2628-4371-5181

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Golgari Findbroker
- Irrigated Farmland

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: GWUB, Popularity: 0**

**Steps:**

Activate Irrigated Farmland's cycling ability by paying {0} and discarding it.
Bone Miser, Irrigated Farmland, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Irrigated Farmland trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Golgari Findbroker.
Golgari Findbroker enters the battlefield, returning Irrigated Farmland from your graveyard to your hand.
Repeat.

---

# 65-717-2628-4477-4606

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Greenwarden of Murasa
- Sheltered Thicket

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: UBRG, Popularity: 1**

**Steps:**

Activate Sheltered Thicket's cycling ability by paying {0} and discarding it.
Bone Miser, Sheltered Thicket, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Sheltered Thicket trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Greenwarden of Murasa.
Greenwarden of Murasa enters the battlefield, returning Sheltered Thicket from your graveyard to your hand.
Repeat.

---

# 65-717-2628-4477-4607

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Greenwarden of Murasa
- Smoldering Crater

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: UBRG, Popularity: 1**

**Steps:**

Activate Smoldering Crater's cycling ability by paying {0} and discarding it.
Bone Miser, Smoldering Crater, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Smoldering Crater trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Greenwarden of Murasa.
Greenwarden of Murasa enters the battlefield, returning Smoldering Crater from your graveyard to your hand.
Repeat.

---

# 65-717-2628-4477-4686

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Greenwarden of Murasa
- Polluted Mire

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: BGU, Popularity: 3**

**Steps:**

Activate Polluted Mire's cycling ability by paying {0} and discarding it.
Bone Miser, Polluted Mire, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Polluted Mire trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Greenwarden of Murasa.
Greenwarden of Murasa enters the battlefield, returning Polluted Mire from your graveyard to your hand.
Repeat.

---

# 65-717-2628-4606-4652

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Tilling Treefolk
- Sheltered Thicket

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: UBRG, Popularity: 19**

**Steps:**

Activate Sheltered Thicket's cycling ability by paying {0} and discarding it.
Bone Miser, Sheltered Thicket, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Sheltered Thicket trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Tilling Treefolk.
Tilling Treefolk enters the battlefield, returning Sheltered Thicket and up to one other land from your graveyard to your hand.
Repeat.

---

# 65-717-2628-4606-5181

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Golgari Findbroker
- Sheltered Thicket

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: UBRG, Popularity: 1**

**Steps:**

Cycle Sheltered Thicket for {0} due to Fluctuator.
Escape Protocol and Bone Miser trigger.
Stack the triggers such that Bone Miser's ability resolves first, adding {B}{B}.
Resolve Escape Protocol's ability using {1} to pay for it to blink Golgari Findbroker.
When Golgari Findbroker ETBs, return Sheltered Thicket to your hand.
Resolve the cycling trigger and draw a card.

---

# 65-717-2628-4607-4652

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Tilling Treefolk
- Smoldering Crater

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: UBRG, Popularity: 9**

**Steps:**

Activate Smoldering Crater's cycling ability by paying {0} and discarding it.
Bone Miser, Smoldering Crater, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Smoldering Crater trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Tilling Treefolk.
Tilling Treefolk enters the battlefield, returning Smoldering Crater and up to one other land from your graveyard to your hand.
Repeat.

---

# 65-717-2628-4607-5181

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Golgari Findbroker
- Smoldering Crater

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: UBRG, Popularity: 1**

**Steps:**

Cycle Smoldering Crater for {0} due to Fluctuator.
Escape Protocol and Bone Miser trigger.
Stack the triggers such that Bone Miser's ability resolves first, adding {B}{B}.
Resolve Escape Protocol's ability using {1} to pay for it to blink Golgari Findbroker.
When Golgari Findbroker ETBs, return Smoldering Crater to your hand.
Resolve the cycling trigger and draw a card.

---

# 65-717-2628-4652-4686

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Tilling Treefolk
- Polluted Mire

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: BGU, Popularity: 13**

**Steps:**

Activate Polluted Mire's cycling ability by paying {0} and discarding it.
Bone Miser, Polluted Mire, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Polluted Mire trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Tilling Treefolk.
Tilling Treefolk enters the battlefield, returning Polluted Mire and up to one other land from your graveyard to your hand.
Repeat.

---

# 65-717-2628-4686-5181

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Golgari Findbroker
- Polluted Mire

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: BGU, Popularity: 1**

**Steps:**

Cycle Polluted Mire for {0} due to Fluctuator.
Escape Protocol and Bone Miser trigger.
Stack the triggers such that Bone Miser's ability resolves first, adding {B}{B}.
Resolve Escape Protocol's ability using {1} to pay for it to blink Golgari Findbroker.
When Golgari Findbroker ETBs, return Polluted Mire to your hand.
Resolve the cycling trigger and draw a card.

---

# 65-717-808-2628-2993

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Stoic Builder
- Canyon Slough

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: UBRG, Popularity: 1**

**Steps:**

Activate Canyon Slough's cycling ability by paying {0} and discarding it.
Bone Miser, Canyon Slough, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Canyon Slough trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Stoic Builder.
Stoic Builder enters the battlefield, returning Canyon Slough from your graveyard to your hand.
Repeat.

---

# 65-717-808-2628-4477

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Greenwarden of Murasa
- Canyon Slough

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: UBRG, Popularity: 1**

**Steps:**

Activate Canyon Slough's cycling ability by paying {0} and discarding it.
Bone Miser, Canyon Slough, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Canyon Slough trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Greenwarden of Murasa.
Greenwarden of Murasa enters the battlefield, returning Canyon Slough from your graveyard to your hand.
Repeat.

---

# 65-717-808-2628-4652

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Tilling Treefolk
- Canyon Slough

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: UBRG, Popularity: 19**

**Steps:**

Activate Canyon Slough's cycling ability by paying {0} and discarding it.
Bone Miser, Canyon Slough, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Canyon Slough trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Tilling Treefolk.
Tilling Treefolk enters the battlefield, returning Canyon Slough and up to one other land from your graveyard to your hand.
Repeat.

---

# 65-717-808-2628-5181

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Golgari Findbroker
- Canyon Slough

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: UBRG, Popularity: 1**

**Steps:**

Activate Canyon Slough's cycling ability by paying {0} and discarding it.
Bone Miser, Canyon Slough, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Canyon Slough trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Golgari Findbroker.
Golgari Findbroker enters the battlefield, returning Canyon Slough from your graveyard to your hand.
Repeat.

---

# 65-717-808-864-2628

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Eternal Witness
- Canyon Slough

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: UBRG, Popularity: 29**

**Steps:**

Activate Canyon Slough's cycling ability by paying {0} and discarding it.
Bone Miser, Canyon Slough, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Canyon Slough trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Eternal Witness.
Eternal Witness enters the battlefield, returning Canyon Slough from your graveyard to your hand.
Repeat.

---

# 65-717-864-1094-2628

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Eternal Witness
- Slippery Karst

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: BGU, Popularity: 40**

**Steps:**

Activate Slippery Karst's cycling ability by paying {0} and discarding it.
Bone Miser, Slippery Karst, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Slippery Karst trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Eternal Witness.
Eternal Witness enters the battlefield, returning Slippery Karst from your graveyard to your hand.
Repeat.

---

# 65-717-864-1583-2628

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Eternal Witness
- Drifting Meadow

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: GWUB, Popularity: 28**

**Steps:**

Activate Drifting Meadow's cycling ability by paying {0} and discarding it.
Bone Miser, Drifting Meadow, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Drifting Meadow trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Eternal Witness.
Eternal Witness enters the battlefield, returning Drifting Meadow from your graveyard to your hand.
Repeat.

---

# 65-717-864-2628-3855

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Eternal Witness
- Remote Isle

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: BGU, Popularity: 39**

**Steps:**

Activate Remote Isle's cycling ability by paying {0} and discarding it.
Bone Miser, Remote Isle, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Remote Isle trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Eternal Witness.
Eternal Witness enters the battlefield, returning Remote Isle from your graveyard to your hand.
Repeat.

---

# 65-717-864-2628-4310

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Eternal Witness
- Blasted Landscape

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: BGU, Popularity: 32**

**Steps:**

Activate Blasted Landscape's cycling ability by paying {0} and discarding it.
Bone Miser, Blasted Landscape, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Blasted Landscape trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Eternal Witness.
Eternal Witness enters the battlefield, returning Blasted Landscape from your graveyard to your hand.
Repeat.

---

# 65-717-864-2628-4371

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Eternal Witness
- Irrigated Farmland

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: GWUB, Popularity: 45**

**Steps:**

Activate Irrigated Farmland's cycling ability by paying {0} and discarding it.
Bone Miser, Irrigated Farmland, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Irrigated Farmland trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Eternal Witness.
Eternal Witness enters the battlefield, returning Irrigated Farmland from your graveyard to your hand.
Repeat.

---

# 65-717-864-2628-4606

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Eternal Witness
- Sheltered Thicket

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: UBRG, Popularity: 29**

**Steps:**

Activate Sheltered Thicket's cycling ability by paying {0} and discarding it.
Bone Miser, Sheltered Thicket, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Sheltered Thicket trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Eternal Witness.
Eternal Witness enters the battlefield, returning Sheltered Thicket from your graveyard to your hand.
Repeat.

---

# 65-717-864-2628-4607

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Eternal Witness
- Smoldering Crater

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: UBRG, Popularity: 17**

**Steps:**

Activate Smoldering Crater's cycling ability by paying {0} and discarding it.
Bone Miser, Smoldering Crater, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Smoldering Crater trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Eternal Witness.
Eternal Witness enters the battlefield, returning Smoldering Crater from your graveyard to your hand.
Repeat.

---

# 65-717-864-2628-4686

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Eternal Witness
- Polluted Mire

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: BGU, Popularity: 37**

**Steps:**

Activate Polluted Mire's cycling ability by paying {0} and discarding it.
Bone Miser, Polluted Mire, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Polluted Mire trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Eternal Witness.
Eternal Witness enters the battlefield, returning Polluted Mire from your graveyard to your hand.
Repeat.

---

# 65-717-864-875-2628

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Eternal Witness
- Fetid Pools

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: BGU, Popularity: 53**

**Steps:**

Activate Fetid Pools's cycling ability by paying {0} and discarding it.
Bone Miser, Fetid Pools, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Fetid Pools trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Eternal Witness.
Eternal Witness enters the battlefield, returning Fetid Pools from your graveyard to your hand.
Repeat.

---

# 65-717-864-881-2628

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Eternal Witness
- Scattered Groves

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: GWUB, Popularity: 43**

**Steps:**

Activate Scattered Groves's cycling ability by paying {0} and discarding it.
Bone Miser, Scattered Groves, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Scattered Groves trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Eternal Witness.
Eternal Witness enters the battlefield, returning Scattered Groves from your graveyard to your hand.
Repeat.

---

# 65-717-875-2628-2993

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Stoic Builder
- Fetid Pools

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: BGU, Popularity: 1**

**Steps:**

Activate Fetid Pools's cycling ability by paying {0} and discarding it.
Bone Miser, Fetid Pools, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Fetid Pools trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Stoic Builder.
Stoic Builder enters the battlefield, returning Fetid Pools from your graveyard to your hand.
Repeat.

---

# 65-717-875-2628-4477

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Greenwarden of Murasa
- Fetid Pools

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: BGU, Popularity: 4**

**Steps:**

Activate Fetid Pools's cycling ability by paying {0} and discarding it.
Bone Miser, Fetid Pools, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Fetid Pools trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Greenwarden of Murasa.
Greenwarden of Murasa enters the battlefield, returning Fetid Pools from your graveyard to your hand.
Repeat.

---

# 65-717-875-2628-4652

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Tilling Treefolk
- Fetid Pools

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: BGU, Popularity: 21**

**Steps:**

Activate Fetid Pools's cycling ability by paying {0} and discarding it.
Bone Miser, Fetid Pools, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Fetid Pools trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Tilling Treefolk.
Tilling Treefolk enters the battlefield, returning Fetid Pools and up to one other land from your graveyard to your hand.
Repeat.

---

# 65-717-875-2628-5181

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Golgari Findbroker
- Fetid Pools

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: BGU, Popularity: 1**

**Steps:**

Activate Fetid Pools's cycling ability by paying {0} and discarding it.
Bone Miser, Fetid Pools, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Fetid Pools trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Golgari Findbroker.
Golgari Findbroker enters the battlefield, returning Fetid Pools from your graveyard to your hand.
Repeat.

---

# 65-717-881-2628-2993

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Stoic Builder
- Scattered Groves

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: GWUB, Popularity: 0**

**Steps:**

Activate Scattered Groves's cycling ability by paying {0} and discarding it.
Bone Miser, Scattered Groves, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Scattered Groves trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Stoic Builder.
Stoic Builder enters the battlefield, returning Scattered Groves from your graveyard to your hand.
Repeat.

---

# 65-717-881-2628-4477

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Greenwarden of Murasa
- Scattered Groves

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: GWUB, Popularity: 0**

**Steps:**

Activate Scattered Groves's cycling ability by paying {0} and discarding it.
Bone Miser, Scattered Groves, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Scattered Groves trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Greenwarden of Murasa.
Greenwarden of Murasa enters the battlefield, returning Scattered Groves from your graveyard to your hand.
Repeat.

---

# 65-717-881-2628-4652

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Tilling Treefolk
- Scattered Groves

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: GWUB, Popularity: 19**

**Steps:**

Activate Scattered Groves's cycling ability by paying {0} and discarding it.
Bone Miser, Scattered Groves, and Escape Protocol trigger.
Resolve the Bone Miser trigger, adding {B}{B}.
Resolve the Scattered Groves trigger, drawing a card.
Resolve the Escape Protocol trigger, causing you to pay {1} to blink Tilling Treefolk.
Tilling Treefolk enters the battlefield, returning Scattered Groves and up to one other land from your graveyard to your hand.
Repeat.

---

# 65-717-881-2628-5181

**Cards:**

- Escape Protocol
- Fluctuator
- Bone Miser
- Golgari Findbroker
- Scattered Groves

**Produces:** Infinite black mana, Infinite card draw, Infinite ETB, Infinite LTB

**Mana: , MV: 0, Colors: GWUB, Popularity: 0**

**Steps:**

Cycle Scattered Groves for {0} due to Fluctuator.
Escape Protocol and Bone Miser trigger.
Stack the triggers such that Bone Miser's ability resolves first, adding {B}{B}.
Resolve Escape Protocol's ability using {1} to pay for it to blink Golgari Findbroker.
When Golgari Findbroker ETBs, return Scattered Groves to your hand.
Resolve the cycling trigger and draw a card.

---

# 659-1636

**Cards:**

- Intruder Alarm
- Krenko, Mob Boss

**Produces:** Infinite ETB, Infinite creature tokens

**Mana: , MV: 0, Colors: UR, Popularity: 889**

**Steps:**

Tap Krenko to activate it's ability, creating X goblin tokens where X is the number of Goblins you control.
Token's ETB causes Intruder Alarm to trigger, untapping Krenko.


---

# 659-2034-5200

**Cards:**

- Krenko, Mob Boss
- Sword of the Paruns
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite creature tokens, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite untap of creatures you control, Infinite mana creatures you control can produce

**Mana: , MV: 0, Colors: R, Popularity: 1825**

**Steps:**

Activate Krenko by tapping it, creating at least two 1/1 Goblin creature tokens.
Activate Ashnod's Altar twice by sacrificing two Goblin tokens, adding {C}{C}{C}{C}.
Activate Sword of Paruns by paying {3}, untapping Krenko.
Repeat.

---

# 659-3259-4412

**Cards:**

- Krenko, Mob Boss
- Hellraiser Goblin
- Breath of Fury

**Produces:** Infinite combat damage, Infinite combat phases, Infinite creature tokens, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mana creatures you control can produce, Infinite sacrifice triggers, Infinite untap of creatures you control

**Mana: {2}{R}{R}, MV: 4, Colors: R, Popularity: 101**

**Steps:**

Activate Krenko by tapping it, creating that many 1/1 Goblin tokens equal to the number of Goblins you control.
Cast Breath of Fury by paying {2}{R}{R}, enchanting a Goblin token.
Move to combat.
Attack with enchanted Goblin token, dealing damage to player.
Breath of Fury triggers, sacrificing the enchanted Goblin and enchanting other Goblin token, untapping your creatures and gaining an additional combat phase after this one.
Activate Krenko by tapping it, creating that many Goblin tokens equal to the number of Goblins you control.
Repeat from step 3.

---

# 661-777-3685-4659

**Cards:**

- Krark-Clan Ironworks
- Spine of Ish Sah
- Sculpting Steel
- Foundry Inspector

**Produces:** Destroy all permanents opponents control on each of your turns, Lock, Mass Land Denial

**Mana: {2}, MV: 2, Colors: C, Popularity: 2947**

**Steps:**

Cast Sculpting Steel by paying {2}.
Sculpting Steel enters the battlefield as a copy of Spine of Ish Sah.
Sculpting Steel enters the battlefield, destroying target permanent.
Activate Krark-Clan Ironworks by sacrificing Sculpting Steel, adding {C}{C}.
Sculpting Steel triggers, returning to your hand.
Repeat.

---

# 662-4096-4404-4853

**Cards:**

- Goblin Welder
- Corridor Monitor
- Dross Scorpion
- Liquimetal Coating

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: UR, Popularity: 4**

**Steps:**

Activate Liquimetal Coating by tapping it, causing Goblin Welder to become an artifact in addition to its other types until end of turn.
Activate Goblin Welder by tapping it, sacrificing Dross Scorpion and returning Corridor Monitor from your graveyard to the battlefield.
Dross Scorpion and Corridor Monitor trigger.
Resolve the Dross Scorpion trigger, untapping Goblin Welder.
Holding priority, activate Goblin Welder by tapping it, sacrificing Corridor Monitor and returning Dross Scorpion from your graveyard to the battlefield.
Resolve the Corridor Monitor trigger from step 2, untapping Goblin Welder.
Repeat from step 2.

---

# 662-4096-4407-4853

**Cards:**

- Goblin Welder
- Unbender Tine
- Dross Scorpion
- Liquimetal Coating

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: URW, Popularity: 0**

**Steps:**

Activate Liquimetal Coating by tapping it, causing Goblin Welder to become an artifact in addition to its other types until end of turn.
Activate Goblin Welder by tapping it, sacrificing Dross Scorpion and returning Unbender Tine from your graveyard to the battlefield.
Dross Scorpion triggers, untapping Goblin Welder.
Activate Unbender Tine by tapping it, targeting Goblin Welder.
Holding priority, activate Goblin Welder by tapping it, sacrificing Unbender Tine and returning Dross Scorpion from your graveyard to the battlefield.
Resolve the Unbender Tine ability, untapping Goblin Welder.
Repeat from step 2.

---

# 662-4096-4853-5167

**Cards:**

- Goblin Welder
- Esper Sojourners
- Dross Scorpion
- Liquimetal Coating

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: WUBR, Popularity: 0**

**Steps:**

Activate Liquimetal Coating by tapping it, causing Goblin Welder to become an artifact in addition to its other types until end of turn.
Activate Goblin Welder by tapping it, sacrificing Dross Scorpion and returning Esper Sojourners from your graveyard to the battlefield.
Dross Scorpion triggers, untapping Goblin Welder.
Activate Goblin Welder by tapping it, sacrificing Esper Sojourners and returning Dross Scorpion from your graveyard to the battlefield.
Esper Sojourners triggers, untapping Goblin Welder.
Repeat from step 2.

---

# 666-3542

**Cards:**

- Palinchron
- Extraplanar Lens

**Produces:** Infinite ETB, Infinite LTB, Infinite mana lands you control can produce, Infinite storm count

**Mana: {5}{U}{U}, MV: 7, Colors: U, Popularity: 812**

**Steps:**

Cast Palinchron for {5}{U}{U}.
Palinchron enters the battlefield, untapping at least six Islands you control.
Activate six Islands you control by tapping them, adding twelve {U}.
Activate Palinchron by paying {2}{U}{U}, returning Palinchron to your hand.
Repeat.

---

# 67-2034-4681

**Cards:**

- Karmic Guide
- Reveillark
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite recursion of creature cards with power 2 or less

**Mana: , MV: 0, Colors: W, Popularity: 10216**

**Steps:**

Activate Ashnod's Altar by sacrificing Karmic Guide.
Activate Ashnod's Altar by sacrificing Reveillark.
When Reveillark dies, it triggers, returning Karmic Guide and up to one other creature with power 2 or less from your graveyard to the battlefield.
When Karmic Guide enters the battlefield, it triggers, returning Reveillark from your graveyard to the battlefield.
Repeat.

---

# 672-2145

**Cards:**

- Erayo, Soratami Ascendant // Erayo's Essence
- Eidolon of Rhetoric

**Produces:** Opponents can't resolve any spell for the rest of the game, Lock

**Mana: , MV: 0, Colors: WU, Popularity: 0**

**Steps:**

Erayo counters the first spell cast, and Eidolon of Rhetoric only lets player cast one spell a turn.

---

# 67-4050-4681

**Cards:**

- Karmic Guide
- Reveillark
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite recursion of creature cards with power 2 or less

**Mana: , MV: 0, Colors: W, Popularity: 6213**

**Steps:**

Activate Phyrexian Altar by sacrificing Karmic Guide.
Activate Phyrexian Altar by sacrificing Reveillark.
When Reveillark dies, it triggers, returning Karmic Guide and up to one other creature with power 2 or less from your graveyard to the battlefield.
When Karmic Guide enters the battlefield, it triggers, returning Reveillark from your graveyard to the battlefield.
Repeat.

---

# 67-413-4681

**Cards:**

- Karmic Guide
- Reveillark
- Blasting Station

**Produces:** Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite recursion of creature cards with power 2 or less

**Mana: , MV: 0, Colors: W, Popularity: 2422**

**Steps:**

Activate Blasting Station by tapping it and sacrificing Reveillark.
When Reveillark dies, it triggers, returning Karmic Guide and up to one other creature with power 2 or less from your graveyard to the battlefield.
When Karmic Guide and up to one other creature enter the battlefield, Karmic Guide triggers, and Blasting Station triggeers once for each creature that entered the battlefield.
Resolve all Blasting Station triggers, untapping it.
Holding priority, activate Blasting Station by tapping it and sacrificing Karmic Guide.
Resolve the Karmic Guide trigger from step 4, returning Reveillark from your graveyard to the battlefield.
When Reveillark enters the battlefield, Blasting Station triggers, untapping Blasting Station.
Resolve the Blasting Station ability from step 1.
Repeat.

---

# 67-4681-5256

**Cards:**

- Karmic Guide
- Reveillark
- Altar of Dementia

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill, Infinite recursion of creature cards with power 2 or less

**Mana: , MV: 0, Colors: W, Popularity: 8385**

**Steps:**

Activate Altar of Dementia by sacrificing Karmic Guide.
Activate Altar of Dementia by sacrificing Reveillark.
When Reveillark dies, it triggers, returning Karmic Guide and up to one other creature with power 2 or less from your graveyard to the battlefield.
When Karmic Guide enters the battlefield, it triggers, returning Reveillark from your graveyard to the battlefield.
Resolve the Altar of Dementia ability from step 2.
Repeat.

---

# 67-624-2869

**Cards:**

- Leyline of Singularity
- Reveillark
- Phantasmal Image

**Produces:** Infinite death triggers, Infinite ETB, Return some creature cards from your graveyard to the battlefield

**Mana: , MV: 0, Colors: WU, Popularity: 0**

**Steps:**

Have Phantasmal Image enter the battlefield as a copy of Reveillark.
Choose to have the Phantasmal Image copy die due to the legend rule.
Use the copy's trigger to return Image and any other creature with power 2 or less to the battlefield.
Repeat steps 1-3.

---

# 677-2567-4050

**Cards:**

- Horde of Notions
- Avenger of Zendikar
- Phyrexian Altar

**Produces:** Cast a subset of spells in your graveyard, Infinite colored mana, Infinite creature tokens, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite recursion of Elemental cards in your graveyard, Infinite storm count

**Mana: {5}{G}{G}, MV: 7, Colors: WUBRG, Popularity: 471**

**Steps:**

Cast Avenger of Zendikar by paying {5}{G}{G}.
Avenger of Zendikar enters the battlefield, triggering itself, creating at least five 0/1 Plant creature tokens.
Activate Phyreixan Altar five times by sacrificing Avenger of Zendikar and four Plant tokens, adding {W}{U}{B}{R}{G}.
Activate Horde of Notions by paying {W}{U}{B}{R}{G}, casting Avenger of Zendikar from your graveyard without paying its mana cost.
Repeat from step 2.
Once you have infinite creature tokens, you may activate Phyrexian Altar any number of times.

---

# 678-1182

**Cards:**

- Stonecoil Serpent
- Enduring Renewal

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: , MV: 0, Colors: W, Popularity: 128**

**Steps:**

Cast Stonecoil Serpent by paying {0}.
Stonecoil Serpent enters the battlefield and dies as a state-based action due to having zero or less toughness.
Enduring Renewal triggers, returning Stonecoil Serpent from your graveyard to your hand.
Repeat.

---

# 678-1778-5256

**Cards:**

- Enduring Renewal
- Memnite
- Altar of Dementia

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill, Infinite storm count

**Mana: , MV: 0, Colors: W, Popularity: 281**

**Steps:**

Activate Altar of Dementia by sacrificing Memnite.
Enduring Renewal triggers, returning Memnite from your graveyard to your hand.
Resolve the Altar of Dementia, causing target player to mill cards equal to Memnite's power.
Cast Memnite by paying {0}.
Repeat.

---

# 678-2034

**Cards:**

- Enduring Renewal
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: W, Popularity: 1404**

**Steps:**

Activate Ashnod's Altar by sacrificing the creature, adding {C}{C}.
When the creature dies, Enduring Renewal triggers, returning the creature from your graveyard to your hand.
Cast the creature by paying its mana cost.
Repeat.
If the creature can be cast using {C} or less, this combo nets infinite colorless mana.

---

# 678-2363

**Cards:**

- Hangarback Walker
- Enduring Renewal

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: , MV: 0, Colors: W, Popularity: 171**

**Steps:**

Cast Hangarback Walker by paying {0}.
Hangarback Walker enters the battlefield and dies as a state-based action due to having zero or less toughness.
Enduring Renewal triggers, returning Hangarback Walker from your graveyard to your hand.
Repeat.

---

# 678-3180

**Cards:**

- Chamber Sentry
- Enduring Renewal

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count, Infinite death triggers

**Mana: , MV: 0, Colors: WUBRG, Popularity: 0**

**Steps:**

Cast Chamber Sentry by paying {0}.
Chamber Sentry enters the battlefield and dies as a state-based action due to having zero or less toughness.
Enduring Renewal triggers, returning Chamber Sentry from your graveyard to your hand.
Repeat.

---

# 678-3693

**Cards:**

- Walking Ballista
- Enduring Renewal

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: , MV: 0, Colors: W, Popularity: 616**

**Steps:**

Cast Walking Ballista by paying {0}.
Walking Ballista enters the battlefield and dies as a state-based action due to having zero or less toughness.
Enduring Renewal triggers, returning Walking Ballista from your graveyard to your hand.
Repeat.

---

# 678-4050

**Cards:**

- Enduring Renewal
- Phyrexian Altar

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: W, Popularity: 936**

**Steps:**

Activate Phyrexian Altar by sacrificing the creature, adding one mana of any color.
When the creature dies, Enduring Renewal triggers, returning the creature from your graveyard to your hand.
Cast the creature by paying its mana cost.
Repeat.

---

# 678-4487

**Cards:**

- Phyrexian Marauder
- Enduring Renewal

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: , MV: 0, Colors: W, Popularity: 54**

**Steps:**

Cast Phyrexian Marauder by paying {0}.
Phyrexian Marauder enters the battlefield and dies as a state-based action due to having zero or less toughness.
Enduring Renewal triggers, returning Phyrexian Marauder from your graveyard to your hand.
Repeat.

---

# 678-4809

**Cards:**

- Shifting Wall
- Enduring Renewal

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: , MV: 0, Colors: W, Popularity: 70**

**Steps:**

Cast Shifting Wall by paying {0}.
Shifting Wall enters the battlefield and dies as a state-based action due to having zero or less toughness.
Enduring Renewal triggers, returning Shifting Wall from your graveyard to your hand.
Repeat.

---

# 678-4929

**Cards:**

- Cryptic Trilobite
- Enduring Renewal

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: , MV: 0, Colors: W, Popularity: 61**

**Steps:**

Cast Cryptic Trilobite by paying {0}.
Cryptic Trilobite enters the battlefield and dies as a state-based action due to having zero or less toughness.
Enduring Renewal triggers, returning Cryptic Trilobite from your graveyard to your hand.
Repeat.

---

# 679-1173-5261

**Cards:**

- Lich's Mastery
- Isochron Scepter
- Final Fortune

**Produces:** Infinite turns, Lock

**Mana: {2} each turn, MV: 2, Colors: BR, Popularity: 60**

**Steps:**

Activate Isochron Scepter by paying {2}, casting a copy of Final Fortune without paying its mana cost.
Resolve Final Fortune, taking an extra turn after this one.
Repeat each turn.
At the beginning of each extra turn's end step, Final Fortune triggers to cause you to lose the game, but you cannot lose the game due to Lich's Mastery.

---

# 679-2428

**Cards:**

- Lich's Mastery
- Horizon Chimera

**Produces:** Infinite card draw

**Mana: , MV: 0, Colors: BGU, Popularity: 32**

**Steps:**

Draw a card, either with your draw step or by casting a card draw spell, which triggers Horizon Chimeria and gains you a life.
Gaining a life triggers Lich's Mastery, drawing a card.
Repeat to draw your library.
You do not lose the game after drawing your last card because Lich's Mastery is on the battlefield.

---

# 680-2615

**Cards:**

- Triskaidekaphobia
- Tree of Perdition

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: B, Popularity: 3124**

**Steps:**

At the beginning of your upkeep, Triskaidekaphobia triggers; hold priority.
Activate Tree of Perdition to make target opponent's life total 13.
Allow Triskaidekaphobia's trigger to resolve, making that opponent lose the game.


---

# 687-1183-2034-2249

**Cards:**

- Tayam, Luminous Enigma
- Pentavus
- Ashnod's Altar
- Death's Presence

**Produces:** Infinite colorless mana, Infinite ETB, Infinite LTB, Infinite death triggers, Infinite sacrifice triggers, Infinite self-mill, Infinite recursion of some permanent cards in your graveyard

**Mana: {6}, MV: 6, Colors: WBG, Popularity: 0**

**Steps:**

Activate Pentavus 3 times, removing 3 +1/+1 counters and creating 3 1/1 tokens.
Each of these tokens will enter with a vigilance counter.
Activate Tayam, removing the viglience counters, milling yourself 3 and reanimating a 3 mana value or less permanent.
Sacrifice all three 1/1s to Ashnod's Altar, generating {6}.
Death's Presence triggers, putting 3 +1/+1 counters back on pentavus.

---

# 687-1322-2034-2987

**Cards:**

- Tayam, Luminous Enigma
- Channeler Initiate
- Ashnod's Altar
- Concordant Crossroads

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite self-mill

**Mana: {3}{G}, MV: 4, Colors: WBG, Popularity: 4**

**Steps:**

Cast Channeler Initiate by paying {1}{G}.
Channeler Initiate enters the battlefield with a vigilance counter, putting three -1/-1 counters on itself.
Activate Channeler Initiate by tapping and removing a -1/-1 counter from it, adding one mana of any color.
Activate Tayam by paying {3} and removing all counters from Channeler Initiate.
Holding priority, activate Ashnod's Altar by sacrificing Channeler Initiate, adding {C}{C}.
Resolve the Tayam ability, milling three cards and returning Channeler Initiate from your graveyard to the battlefield.
Repeat from step 2.

---

# 687-1429-2438-5004

**Cards:**

- Tayam, Luminous Enigma
- Cathodion
- Carrion Feeder
- Lesser Masticore

**Produces:** Infinite +1/+1 counters on a creature, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: WBG, Popularity: 57**

**Steps:**

Activate Carrion Feeder by sacrificing Cathodion.
Cathodion triggers, adding {C}{C}{C}.
Resolve the Carrion Feeder ability, putting a +1/+1 counter on it.
Activate Carrion Feeder by sacrificing Lesser Manticore.
Lesser Manticore's persist ability triggers, returning it to the battlefield with a -1/-1 and a vigilance counter.
Resolve the Carrion Feeder ability, putting a +1/+1 counter on it.
Activate Tayam by paying {3}, removing a +1/+1 counter from Carrion Feeder and removing both counters from Lesser Manticore, causing yourself to mill three cards and return Cathodion from your graveyard to the battlefield.
Repeat.

---

# 687-2012-2034-3644

**Cards:**

- Tayam, Luminous Enigma
- Ashnod's Altar
- Strangleroot Geist
- Young Wolf

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite self-mill, Put a selection of permanant cards from your library and graveyard onto the battlefield

**Mana: , MV: 0, Colors: WBG, Popularity: 2838**

**Steps:**

Activate Ashnod's Altar twice by sacrificing Strangleroot Geist and Young Wolf, adding {C}{C}{C}{C}.
Strangleroot Geist and Young Wolf's undying abilities trigger, returning both from your graveyard to the battlefield with a +1/+1 counter and a vigilance counter.
Activate Tayam by paying {3}, removing both counters from Young Wolf, and removing a +1/+1 counter from Strangleroot Geist, causing you to mill three cards and allowing you to return a permanent with mana value three or less from your graveyard to the battlefield.
Repeat.

---

# 687-2034-2086-5319

**Cards:**

- Tayam, Luminous Enigma
- Geralf's Messenger
- Ashnod's Altar
- Kitchen Finks

**Produces:** Infinite blinking of some creatures and some creature cards in graveyard and in library, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite self-mill, Put a selection of permanant cards from your library and graveyard onto the battlefield

**Mana: , MV: 0, Colors: WBG, Popularity: 265**

**Steps:**

Activate Ashnod's Altar by sacrificing Geralf's Messenger, adding {C}{C}.
When Geralf's Messenger dies, its undying ability triggers, returning it from your graveyard to the battlefield with a +1/+1 and a vigilance counter on it.
When Geralf's Messenger enters the battlefield, it triggers, causing target opponent to lose 2 life.
Activate Ashnod's Altar by sacrificing Kitchen Finks, adding {C}{C}.
When Kitchen Finks dies, its persist ability triggers, returning it from your graveyard to the battlefield with a -1/-1 and a vigilance counter on it.
When Kitchen Finks enters the battlefield, it triggers, causing you to gain 2 life.
Activate Tayam by paying {3} and removing the +1/+1 counter from Geralf's Messenger, the -1-1 counter from Kitchen Finks, and a vigilance counter from any creature you control, milling yourself three cards then returning any permanent card with mana value 3 or less from your graveyard to the battlefield.
Repeat.

---

# 687-2034-2987-5295

**Cards:**

- Tayam, Luminous Enigma
- Channeler Initiate
- Ashnod's Altar
- Thousand-Year Elixir

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite self-mill

**Mana: {3}{G}, MV: 4, Colors: WBG, Popularity: 16**

**Steps:**

Cast Channeler Initiate by paying {1}{G}.
Channeler Initiate enters the battlefield with a vigilance counter, putting three -1/-1 counters on itself.
Activate Channeler Initiate by tapping and removing a -1/-1 counter from it, adding one mana of any color.
Activate Tayam by paying {3} and removing all counters from Channeler Initiate.
Holding priority, activate Ashnod's Altar by sacrificing Channeler Initiate, adding {C}{C}.
Resolve the Tayam ability, milling three cards and returning Channeler Initiate from your graveyard to the battlefield.
Repeat from step 2.

---

# 687-2034-4351

**Cards:**

- Tayam, Luminous Enigma
- Hallowed Spiritkeeper
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite creature tokens, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: WBG, Popularity: 787**

**Steps:**

Activate Ashnod's Altar by sacrificing Hallowed Spiritkeeper, adding {C}{C}.
Hallowed Spiritkeeper dies, creating at least four 1/1 Spirit creature tokens that enter with vigilance counters on them.
Activate Ashnod's Altar by sacrificing a Spirit token, adding {C}{C}.
Activate Tayam by paying {3} and removing vigilance counters from three Spirit tokens, causing yourself to mill three cards and returned Hallowed Spiritkeeper from your graveyard to the battlefield.
Repeat.

---

# 687-876-2034-2987

**Cards:**

- Tayam, Luminous Enigma
- Channeler Initiate
- Ashnod's Altar
- Lightning Greaves

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite self-mill

**Mana: {3}{G}, MV: 4, Colors: WBG, Popularity: 10**

**Steps:**

Cast Channeler Initiate by paying {1}{G}.
Channeler Initiate enters the battlefield with a vigilance counter, putting three -1/-1 counters on itself.
Equip Lightning Grieves to Channeler Initiate by paying {0}.
Activate Channeler Initiate by tapping and removing a -1/-1 counter from it, adding one mana of any color.
Activate Tayam by paying {3} and removing all counters from Channeler Initiate.
Holding priority, activate Ashnod's Altar by sacrificing Channeler Initiate, adding {C}{C}.
Resolve the Tayam ability, milling three cards and returning Channeler Initiate from your graveyard to the battlefield.
Repeat from step 2.

---

# 690-3966

**Cards:**

- Exquisite Blood
- Sanguine Bond

**Produces:** Infinite lifegain triggers, Infinite lifeloss, Infinite lifegain

**Mana: , MV: 0, Colors: B, Popularity: 127360**

**Steps:**

Gain life.
Sanguine Bond triggers, causing an opponent to lose 1 life.
Exquisite Blood triggers, causing you to gain 1 life.
Repeat from step 2.

---

# 690-4996

**Cards:**

- Beacon of Immortality
- Sanguine Bond

**Produces:** Target opponent loses the game

**Mana: {5}{W}, MV: 6, Colors: WB, Popularity: 15214**

**Steps:**

Cast Beacon of Immortality by paying {5}{W}, doubling your life total and shuffling Beacon of Immortality into your library.
Sanguine Bond triggers, causing target opponent who had an equal of lower life total than you to lose life equal to the life you gained.
 The opponent loses the game due to having zero or less life.

---

# 704-2034-4215

**Cards:**

- Verdant Succession
- Elvish Soultiller
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: G, Popularity: 7**

**Steps:**

Activate Ashnod's Altar by sacrificing Elvish Soultiller, adding {C}{C}.
Elvish Soultiller dies, triggering itself and Verdant Succession.
Resolve the Elvish Soultiller trigger, shuffling all Elves or Mutants from your graveyard into your library.
Resolve the Verdant Succession trigger, searching your library for Elvish Soultiller, putting it onto the battlefield and shuffling your library.
Repeat.

---

# 704-4050-4215

**Cards:**

- Verdant Succession
- Elvish Soultiller
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: G, Popularity: 5**

**Steps:**

Activate Phyrexian Altar by sacrificing Elvish Soultiller, adding one mana of any color.
Elvish Soultiller dies, triggering itself and Verdant Succession.
Resolve the Elvish Soultiller trigger, shuffling all Elves or Mutants from your graveyard into your library.
Resolve the Verdant Succession trigger, searching your library for Elvish Soultiller, putting it onto the battlefield and shuffling your library.
Repeat.

---

# 704-4215-5256

**Cards:**

- Verdant Succession
- Elvish Soultiller
- Altar of Dementia

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: G, Popularity: 9**

**Steps:**

Activate Altar of Dementia by sacrificing Elvish Soultiller.
Elvish Soultiller dies, triggering itself and Verdant Succession.
Resolve the Elvish Soultiller trigger, shuffling all Elves or Mutants from your graveyard into your library.
Resolve the Verdant Succession trigger, searching your library for Elvish Soultiller, putting it onto the battlefield and shuffling your library.
Resolve the Altar of Dementia ability, causing target player to mill cards equal to Elvish Soultiller's power.
Repeat.

---

# 70-5141

**Cards:**

- Balancing Act
- Teferi's Protection

**Produces:** Each opponent sacrifices all permanents they control, Mass Land Denial

**Mana: {4}{W}{W}{W}, MV: 7, Colors: W, Popularity: 569**

**Steps:**

Cast Balancing Act by paying {2}{W}{W}.
Holding priority, cast Teferi's Protection by paying {2}{W}, causing all permanents you control to phase out.
Resolve Balancing Act, causing each opponent to sacrifice all their permanents as you control no permanents that aren't phased out.

---

# 706-3584

**Cards:**

- Thousand-Year Storm
- Spelljack

**Produces:** Infinite magecraft triggers, Infinite storm count

**Mana: {3}{U}{U}{U} plus enough mana to cast the additional instant card, MV: 6, Colors: UR, Popularity: 107**

**Steps:**

Cast any other instant card from your hand by paying its mana cost.
Holding priority, cast Spelljack by paying {3}{U}{U}{U} targeting the instant.
Thousand-Year Storm triggers, creating at least one copy of Spelljack that is targeting the original Spelljack.
Resolve the first copy of Spelljack, countering the original Spelljack and exiling it with the ability to cast it for free from exile.
All remaining copies of Spelljack fail to resolve due to having no legal targets.
Cast Spelljack from exile without paying its mana cost, targeting the instant cast in Step 1.
Repeat from step 3.

---

# 712-3360-4474

**Cards:**

- Torchling
- Paradise Mantle
- Wake Thrasher

**Produces:** Infinitely large creature

**Mana: , MV: 0, Colors: UR, Popularity: 0**

**Steps:**

Equip Paradise Mantle onto Torchling.
Tap Torchling to add {R}.
Spend that mana to untap Torchling, Wake Thrasher gets +1/+1.
Repeat.

---

# 712-3457

**Cards:**

- Seeker of Skybreak
- Wake Thrasher

**Produces:** Infinitely large creature until end of turn

**Mana: , MV: 0, Colors: GU, Popularity: 34**

**Steps:**

Activate Seeker of Skybreak by tapping it, untapping itself.
Wake Thrasher triggers, giving itself +1/+1 until end of turn.
Repeat.

---

# 719-1322-3638

**Cards:**

- Xenograft
- Turntimber Ranger
- Concordant Crossroads

**Produces:** Infinite creature tokens with haste, Infinite ETB, Infinitely large creature

**Mana: {3}{G}{G}, MV: 5, Colors: GU, Popularity: 5**

**Steps:**

Cast Turntimber Ranger by paying {3}{G}{G}.
Turntimber Ranger enters the battlefield, creating a 2/2 Wolf creature token and putting a +1/+1 counter on Turntimber Ranger.
2/2 Wolf creature token enters the battlefield triggering Turntimber Ranger, creating a 2/2 Wolf creature token and putting a +1/+1 counter on Turntimber Ranger.
Repeat from step 2.

---

# 719-2034-3413

**Cards:**

- Xathrid Necromancer
- Xenograft
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: UB, Popularity: 11**

**Steps:**

Activate Ashnod's Altar by sacrificing any other creature, adding {C}{C}.
Xathrid Necromancer triggers, creating a 2/2 Zombie creature token.
Repeat.

---

# 719-3413-4050

**Cards:**

- Xathrid Necromancer
- Xenograft
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: UB, Popularity: 10**

**Steps:**

Activate Phyrexian Altar by sacrificing any other creature, adding one mana of any color.
Xathrid Necromancer triggers, creating a 2/2 Zombie creature token.
Repeat.

---

# 719-3413-5256

**Cards:**

- Xathrid Necromancer
- Xenograft
- Altar of Dementia

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: UB, Popularity: 7**

**Steps:**

Activate Altar of Dementia by sacrificing any other creature.
Xathrid Necromancer triggers, creating a 2/2 Zombie creature token.
Resolve the Altar of Dementia ability, causing target player to mill cards equal to the sacrificed creature's power.
Repeat.

---

# 719-3581-4302

**Cards:**

- Kykar, Wind's Fury
- Bishop of Wings
- Xenograft

**Produces:** Infinite ETB, Infinite LTB, Infinite death triggers, Infinite lifegain, Infinite lifegain triggers, Infinite red mana, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: URW, Popularity: 6**

**Steps:**

Sacrifice a Spirit to Kykar's ability, gaining {R}.
Bishop of Wings triggers, creating a 1/1 Spirit token.
When the token ETB, Bishop of Wings triggers again, gaining you 4 life.
Repeat.

---

# 719-3638

**Cards:**

- Xenograft
- Turntimber Ranger

**Produces:** Infinite creature tokens, Infinite ETB, Infinitely large creature

**Mana: {3}{G}{G}, MV: 5, Colors: GU, Popularity: 129**

**Steps:**

Cast Turntimber Ranger by paying {3}{G}{G}.
Turntimber Ranger enters the battlefield, creating a 2/2 Wolf creature token and putting a +1/+1 counter on Turntimber Ranger.
2/2 Wolf creature token enters the battlefield triggering Turntimber Ranger, creating a 2/2 Wolf creature token and putting a +1/+1 counter on Turntimber Ranger.
Repeat from step 2.

---

# 728-2452-2577

**Cards:**

- Gravecrawler
- Rooftop Storm
- Grimgrin, Corpse-Born

**Produces:** Infinite +1/+1 counters on a creature, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: UB, Popularity: 15275**

**Steps:**

Activate Grimgrin's ability by sacrificing Gravecrawler, untapping Grimgrin and putting a +1/+1 counter on Grimgrin.
Cast Gravecrawler from your graveyard by paying {0}.
Repeat.

---

# 731-1089-1525-4298

**Cards:**

- Abundance
- Borborygmos Enraged
- Curiosity
- Corrupted Conscience

**Produces:** Each opponent loses the game, Near-infinite self-discard triggers

**Mana: , MV: 0, Colors: GUR, Popularity: 0**

**Steps:**

Activate Borborygmos by discarding a land, dealing three infect damage to an opponent.
Curiosity triggers, causing you to reveal cards from the top of your library until you reveal a land card, put it into your hand and put all other cards revealed this way on the bottom of your library.
Repeat.

---

# 731-1525-2396-4298

**Cards:**

- Abundance
- Borborygmos Enraged
- Ophidian Eye
- Corrupted Conscience

**Produces:** Each opponent loses the game, Near-infinite self-discard triggers

**Mana: , MV: 0, Colors: GUR, Popularity: 0**

**Steps:**

Activate Borborygmos by discarding a land, dealing three infect damage to an opponent.
Ophidian Eye triggers, causing you to reveal cards from the top of your library until you reveal a land card, put it into your hand and put all other cards revealed this way on the bottom of your library.
Repeat.

---

# 738-1202-1969-2034

**Cards:**

- Glissa, the Traitor
- Grave Pact
- Ashnod's Altar
- Myr Moonvessel

**Produces:** Near-infinite colorless mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 21**

**Steps:**

Sacrifice Myr Moonvessel to Ashnod's Altar, adding {C}{C}.
Myr Moonvessel and Grave Pact trigger.
Resolve Myr Moonvessel's trigger, adding {C}.
Resolve Grave Pact's trigger, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Myr Moonvessel to your hand.
Cast Myr Moonvessel by paying {1}.
Repeat until your opponents no longer control any creatures.

---

# 738-1202-1969-4050

**Cards:**

- Glissa, the Traitor
- Grave Pact
- Phyrexian Altar
- Myr Moonvessel

**Produces:** Near-infinite colored mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 12**

**Steps:**

Sacrifice Myr Moonvessel to Phyrexian Altar, adding one mana of any color.
Myr Moonvessel and Grave Pact trigger.
Resolve Myr Moonvessel's trigger, adding {C}.
Resolve Grave Pact's trigger, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Myr Moonvessel to your hand.
Cast Myr Moonvessel by paying {1}.
Repeat until your opponents no longer control any creatures.

---

# 738-1202-1969-4659

**Cards:**

- Glissa, the Traitor
- Grave Pact
- Krark-Clan Ironworks
- Myr Moonvessel

**Produces:** Near-infinite colorless mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 20**

**Steps:**

Sacrifice Myr Moonvessel to Krark-Clan Ironworks, adding {C}{C}.
Myr Moonvessel and Grave Pact trigger.
Resolve Myr Moonvessel's trigger, adding {C}.
Resolve Grave Pact's trigger, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Myr Moonvessel to your hand.
Cast Myr Moonvessel by paying {1}.
Repeat until your opponents no longer control any creatures.

---

# 738-1202-1969-5256

**Cards:**

- Glissa, the Traitor
- Grave Pact
- Altar of Dementia
- Myr Moonvessel

**Produces:** Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite mill, Near-infinite sacrifice triggers, Near-infinite self-mill, Near-infinite storm count, Lock, Opponents sacrifice all their creatures each turn

**Mana: , MV: 0, Colors: BG, Popularity: 8**

**Steps:**

Sacrifice Myr Moonvessel to Altar of Dementia.
Myr Moonvessel and Grave Pact trigger.
Resolve Myr Moonvessel's trigger, adding {C}.
Resolve Grave Pact's trigger, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Myr Moonvessel to your hand.
Resolve Altar of Dementia's ability, causing target player to mill cards equal to the sacrificed creature's power.
Cast Myr Moonvessel by paying {1}.
Repeat until your opponents no longer control any creatures.

---

# 738-1202-2034-3370

**Cards:**

- Glissa, the Traitor
- Butcher of Malakir
- Ashnod's Altar
- Myr Moonvessel

**Produces:** Near-infinite colorless mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 8**

**Steps:**

Sacrifice Myr Moonvessel to Ashnod's Altar, adding {C}{C}.
Myr Moonvessel and Butcher of Malakir trigger.
Resolve Myr Moonvessel's trigger, adding {C}.
Resolve Butcher of Malakir's trigger, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Myr Moonvessel to your hand.
Cast Myr Moonvessel by paying {1}.
Repeat until your opponents no longer control any creatures.

---

# 738-1202-2034-4733

**Cards:**

- Glissa, the Traitor
- Dictate of Erebos
- Ashnod's Altar
- Myr Moonvessel

**Produces:** Near-infinite colorless mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 20**

**Steps:**

Sacrifice Myr Moonvessel to Ashnod's Altar, adding {C}{C}.
Myr Moonvessel and Dictate of Erebos trigger.
Resolve Myr Moonvessel's trigger, adding {C}.
Resolve Dictate of Erebos's trigger, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Myr Moonvessel to your hand.
Cast Myr Moonvessel by paying {1}.
Repeat until your opponents no longer control any creatures.

---

# 738-1202-3370-4050

**Cards:**

- Glissa, the Traitor
- Butcher of Malakir
- Phyrexian Altar
- Myr Moonvessel

**Produces:** Near-infinite colored mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 6**

**Steps:**

Sacrifice Myr Moonvessel to Phyrexian Altar, adding one mana of any color.
Myr Moonvessel and Butcher of Malakir trigger.
Resolve Myr Moonvessel's trigger, adding {C}.
Resolve Butcher of Malakir's trigger, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Myr Moonvessel to your hand.
Cast Myr Moonvessel by paying {1}.
Repeat until your opponents no longer control any creatures.

---

# 738-1202-3370-4659

**Cards:**

- Glissa, the Traitor
- Butcher of Malakir
- Krark-Clan Ironworks
- Myr Moonvessel

**Produces:** Near-infinite colorless mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 4**

**Steps:**

Sacrifice Myr Moonvessel to Krark-Clan Ironworks, adding {C}{C}.
Myr Moonvessel and Butcher of Malakir trigger.
Resolve Myr Moonvessel's trigger, adding {C}.
Resolve Butcher of Malakir's trigger, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Myr Moonvessel to your hand.
Cast Myr Moonvessel by paying {1}.
Repeat until your opponents no longer control any creatures.

---

# 738-1202-3370-5256

**Cards:**

- Glissa, the Traitor
- Butcher of Malakir
- Altar of Dementia
- Myr Moonvessel

**Produces:** Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite mill, Near-infinite sacrifice triggers, Near-infinite self-mill, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 4**

**Steps:**

Sacrifice Myr Moonvessel to Altar of Dementia.
Myr Moonvessel and Butcher of Malakir trigger.
Resolve Myr Moonvessel's trigger, adding {C}.
Resolve Butcher of Malakir's trigger, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Myr Moonvessel to your hand.
Resolve Altar of Dementia's ability, causing target player to mill cards equal to the sacrificed creature's power.
Cast Myr Moonvessel by paying {1}.
Repeat until your opponents no longer control any creatures.

---

# 738-1202-4050-4733

**Cards:**

- Glissa, the Traitor
- Dictate of Erebos
- Phyrexian Altar
- Myr Moonvessel

**Produces:** Near-infinite colored mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 14**

**Steps:**

Sacrifice Myr Moonvessel to Phyrexian Altar, adding one mana of any color.
Myr Moonvessel and Dictate of Erebos trigger.
Resolve Myr Moonvessel's trigger, adding {C}.
Resolve Dictate of Erebos's trigger, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Myr Moonvessel to your hand.
Cast Myr Moonvessel by paying {1}.
Repeat until your opponents no longer control any creatures.

---

# 738-1202-4659-4733

**Cards:**

- Glissa, the Traitor
- Dictate of Erebos
- Krark-Clan Ironworks
- Myr Moonvessel

**Produces:** Near-infinite colorless mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 18**

**Steps:**

Sacrifice Myr Moonvessel to Krark-Clan Ironworks, adding {C}{C}.
Myr Moonvessel and Dictate of Erebos trigger.
Resolve Myr Moonvessel's trigger, adding {C}.
Resolve Dictate of Erebos's trigger, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Myr Moonvessel to your hand.
Cast Myr Moonvessel by paying {1}.
Repeat until your opponents no longer control any creatures.

---

# 738-1202-4733-5256

**Cards:**

- Glissa, the Traitor
- Dictate of Erebos
- Altar of Dementia
- Myr Moonvessel

**Produces:** Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite mill, Near-infinite sacrifice triggers, Near-infinite self-mill, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 7**

**Steps:**

Sacrifice Myr Moonvessel to Altar of Dementia.
Myr Moonvessel and Dictate of Erebos trigger.
Resolve Myr Moonvessel's trigger, adding {C}.
Resolve Dictate of Erebos's trigger, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Myr Moonvessel to your hand.
Resolve Altar of Dementia's ability, causing target player to mill cards equal to the sacrificed creature's power.
Cast Myr Moonvessel by paying {1}.
Repeat until your opponents no longer control any creatures.

---

# 738-1778-1969-2034

**Cards:**

- Glissa, the Traitor
- Grave Pact
- Ashnod's Altar
- Memnite

**Produces:** Near-infinite colorless mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 50**

**Steps:**

Sacrifice Memnite to Ashnod's Altar, adding {C}{C}.
Grave Pact triggers, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Memnite to your hand.
Cast Memnite by paying {0}.
Repeat until your opponents no longer control any creatures.

---

# 738-1778-1969-4050

**Cards:**

- Glissa, the Traitor
- Grave Pact
- Phyrexian Altar
- Memnite

**Produces:** Near-infinite colored mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 21**

**Steps:**

Sacrifice Memnite to Phyrexian Altar, adding one mana of any color.
Grave Pact triggers, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Memnite to your hand.
Cast Memnite by paying {0}.
Repeat until your opponents no longer control any creatures.

---

# 738-1778-1969-4659

**Cards:**

- Glissa, the Traitor
- Grave Pact
- Krark-Clan Ironworks
- Memnite

**Produces:** Near-infinite colorless mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 48**

**Steps:**

Sacrifice Memnite to Krark-Clan Ironworks, adding {C}{C}.
Grave Pact triggers, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Memnite to your hand.
Cast Memnite by paying {0}.
Repeat until your opponents no longer control any creatures.

---

# 738-1778-1969-5256

**Cards:**

- Glissa, the Traitor
- Grave Pact
- Altar of Dementia
- Memnite

**Produces:** Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite mill, Near-infinite sacrifice triggers, Near-infinite self-mill, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 10**

**Steps:**

Sacrifice Memnite to Altar of Dementia.
Grave Pact triggers, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Memnite to your hand.
Resolve Altar of Dementia's ability, causing target player to mill cards equal to the sacrificed creature's power.
Cast Memnite by paying {0}.
Repeat until your opponents no longer control any creatures.

---

# 738-1778-2034-3370

**Cards:**

- Glissa, the Traitor
- Butcher of Malakir
- Ashnod's Altar
- Memnite

**Produces:** Near-infinite colorless mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 12**

**Steps:**

Sacrifice Memnite to Ashnod's Altar, adding {C}{C}.
Butcher of Malakir triggers, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Memnite to your hand.
Cast Memnite by paying {0}.
Repeat until your opponents no longer control any creatures.

---

# 738-1778-2034-4733

**Cards:**

- Glissa, the Traitor
- Dictate of Erebos
- Ashnod's Altar
- Memnite

**Produces:** Near-infinite colorless mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 44**

**Steps:**

Sacrifice Memnite to Ashnod's Altar, adding {C}{C}.
Dictate of Erebos triggers, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Memnite to your hand.
Cast Memnite by paying {0}.
Repeat until your opponents no longer control any creatures.

---

# 738-1778-3370-4050

**Cards:**

- Glissa, the Traitor
- Butcher of Malakir
- Phyrexian Altar
- Memnite

**Produces:** Near-infinite colored mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 5**

**Steps:**

Sacrifice Memnite to Phyrexian Altar, adding one mana of any color.
Butcher of Malakir triggers, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Memnite to your hand.
Cast Memnite by paying {0}.
Repeat until your opponents no longer control any creatures.

---

# 738-1778-3370-4659

**Cards:**

- Glissa, the Traitor
- Butcher of Malakir
- Krark-Clan Ironworks
- Memnite

**Produces:** Near-infinite colorless mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 7**

**Steps:**

Sacrifice Memnite to Krark-Clan Ironworks, adding {C}{C}.
Butcher of Malakir triggers, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Memnite to your hand.
Cast Memnite by paying {0}.
Repeat until your opponents no longer control any creatures.

---

# 738-1778-3370-5256

**Cards:**

- Glissa, the Traitor
- Butcher of Malakir
- Altar of Dementia
- Memnite

**Produces:** Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite mill, Near-infinite sacrifice triggers, Near-infinite self-mill, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 3**

**Steps:**

Sacrifice Memnite to Altar of Dementia.
Butcher of Malakir triggers, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Memnite to your hand.
Resolve Altar of Dementia's ability, causing target player to mill cards equal to the sacrificed creature's power.
Cast Memnite by paying {0}.
Repeat until your opponents no longer control any creatures.

---

# 738-1778-4050-4733

**Cards:**

- Glissa, the Traitor
- Dictate of Erebos
- Phyrexian Altar
- Memnite

**Produces:** Near-infinite colored mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 16**

**Steps:**

Sacrifice Memnite to Phyrexian Altar, adding one mana of any color.
Dictate of Erebos triggers, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Memnite to your hand.
Cast Memnite by paying {0}.
Repeat until your opponents no longer control any creatures.

---

# 738-1778-4659-4733

**Cards:**

- Glissa, the Traitor
- Dictate of Erebos
- Krark-Clan Ironworks
- Memnite

**Produces:** Near-infinite colorless mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 41**

**Steps:**

Sacrifice Memnite to Krark-Clan Ironworks, adding {C}{C}.
Dictate of Erebos triggers, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Memnite to your hand.
Cast Memnite by paying {0}.
Repeat until your opponents no longer control any creatures.

---

# 738-1778-4733-5256

**Cards:**

- Glissa, the Traitor
- Dictate of Erebos
- Altar of Dementia
- Memnite

**Produces:** Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite mill, Near-infinite sacrifice triggers, Near-infinite self-mill, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 10**

**Steps:**

Sacrifice Memnite to Altar of Dementia.
Dictate of Erebos triggers, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Memnite to your hand.
Resolve Altar of Dementia's ability, causing target player to mill cards equal to the sacrificed creature's power.
Cast Memnite by paying {0}.
Repeat until your opponents no longer control any creatures.

---

# 738-1969-2034-3652

**Cards:**

- Glissa, the Traitor
- Grave Pact
- Ashnod's Altar
- Ornithopter

**Produces:** Near-infinite colorless mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 88**

**Steps:**

Sacrifice Ornithopter to Ashnod's Altar, adding {C}{C}.
Grave Pact triggers, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Ornithopter to your hand.
Cast Ornithopter by paying {0}.
Repeat until your opponents no longer control any creatures.

---

# 738-1969-2034-5004

**Cards:**

- Glissa, the Traitor
- Grave Pact
- Ashnod's Altar
- Cathodion

**Produces:** Near-infinite colorless mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 30**

**Steps:**

Sacrifice Cathodion to Ashnod's Altar, adding {C}{C}.
Cathodion and Grave Pact trigger.
Resolve Cathodion's trigger, adding {C}{C}{C}.
Resolve Grave Pact's trigger, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Cathodion to your hand.
Cast Cathodion by paying {3}.
Repeat until your opponents no longer control any creatures.

---

# 738-1969-3652-4050

**Cards:**

- Glissa, the Traitor
- Grave Pact
- Phyrexian Altar
- Ornithopter

**Produces:** Near-infinite colored mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 26**

**Steps:**

Sacrifice Ornithopter to Phyrexian Altar, adding one mana of any color.
Grave Pact triggers, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Ornithopter to your hand.
Cast Ornithopter by paying {0}.
Repeat until your opponents no longer control any creatures.

---

# 738-1969-3652-4659

**Cards:**

- Glissa, the Traitor
- Grave Pact
- Krark-Clan Ironworks
- Ornithopter

**Produces:** Near-infinite colorless mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 59**

**Steps:**

Sacrifice Ornithopter to Krark-Clan Ironworks, adding {C}{C}.
Grave Pact triggers, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Ornithopter to your hand.
Cast Ornithopter by paying {0}.
Repeat until your opponents no longer control any creatures.

---

# 738-1969-3652-5256

**Cards:**

- Glissa, the Traitor
- Grave Pact
- Altar of Dementia
- Ornithopter

**Produces:** Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite mill, Near-infinite sacrifice triggers, Near-infinite self-mill, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 30**

**Steps:**

Sacrifice Ornithopter to Altar of Dementia.
Grave Pact triggers, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Ornithopter to your hand.
Resolve Altar of Dementia's ability, causing target player to mill cards equal to the sacrificed creature's power.
Cast Ornithopter by paying {0}.
Repeat until your opponents no longer control any creatures.

---

# 738-1969-4050-5004

**Cards:**

- Glissa, the Traitor
- Grave Pact
- Phyrexian Altar
- Cathodion

**Produces:** Near-infinite colored mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 10**

**Steps:**

Sacrifice Cathodion to Phyrexian Altar, adding one mana of any color.
Cathodion and Grave Pact trigger.
Resolve Cathodion's trigger, adding {C}{C}{C}.
Resolve Grave Pact's trigger, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Cathodion to your hand.
Cast Cathodion by paying {3}.
Repeat until your opponents no longer control any creatures.

---

# 738-1969-4242-4659

**Cards:**

- Glissa, the Traitor
- Grave Pact
- Krark-Clan Ironworks
- Su-Chi

**Produces:** Near-infinite colorless mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 2**

**Steps:**

Activate Krark-Clan Ironworks by sacrificing Su-Chi, adding {C}{C}.
When Su-Chi dies, Grave Pact and Su-Chi trigger.
Resolve Su-Chi's trigger, adding {C}{C}{C}{C}.
Resolve Grave Pact's ability, causing each other player to sacrifice a creature.
Glissa triggers once for each creature that dies this way, causing you to return Su-Chi (and possibly additional artifact cards) from your graveyard to your hand.
Cast Su-Chi by paying {4}.
Repeat until your opponents control no creatures.
Repeat each turn.

---

# 738-1969-4659-5004

**Cards:**

- Glissa, the Traitor
- Grave Pact
- Krark-Clan Ironworks
- Cathodion

**Produces:** Near-infinite colorless mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 26**

**Steps:**

Sacrifice Cathodion to Krark-Clan Ironworks, adding {C}{C}.
Cathodion and Grave Pact trigger.
Resolve Cathodion's trigger, adding {C}{C}{C}.
Resolve Grave Pact's trigger, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Cathodion to your hand.
Cast Cathodion by paying {3}.
Repeat until your opponents no longer control any creatures.

---

# 738-1969-5004-5256

**Cards:**

- Glissa, the Traitor
- Grave Pact
- Altar of Dementia
- Cathodion

**Produces:** Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite mill, Near-infinite sacrifice triggers, Near-infinite self-mill, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 10**

**Steps:**

Sacrifice Cathodion to Altar of Dementia.
Cathodion and Grave Pact trigger.
Resolve Cathodion's trigger, adding {C}{C}{C}.
Resolve Grave Pact's trigger, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Cathodion to your hand.
Resolve Altar of Dementia's ability, causing target player to mill cards equal to the sacrificed creature's power.
Cast Cathodion by paying {3}.
Repeat until your opponents no longer control any creatures.

---

# 738-2034-3370-3652

**Cards:**

- Glissa, the Traitor
- Butcher of Malakir
- Ashnod's Altar
- Ornithopter

**Produces:** Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock, Near-infinite colorless mana, Near-infinite death triggers, Near-infinite ETB

**Mana: , MV: 0, Colors: BG, Popularity: 17**

**Steps:**

Sacrifice Ornithopter to Ashnod's Altar, adding {C}{C}.
Butcher of Malakir triggers, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Ornithopter to your hand.
Cast Ornithopter by paying {0}.
Repeat until your opponents no longer control any creatures.

---

# 738-2034-3370-5004

**Cards:**

- Glissa, the Traitor
- Butcher of Malakir
- Ashnod's Altar
- Cathodion

**Produces:** Near-infinite colorless mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 5**

**Steps:**

Sacrifice Cathodion to Ashnod's Altar, adding {C}{C}.
Cathodion and Butcher of Malakir trigger.
Resolve Cathodion's trigger, adding {C}{C}{C}.
Resolve Butcher of Malakir's trigger, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Cathodion to your hand.
Cast Cathodion by paying {3}.
Repeat until your opponents no longer control any creatures.

---

# 738-2034-3652-4733

**Cards:**

- Glissa, the Traitor
- Dictate of Erebos
- Ashnod's Altar
- Ornithopter

**Produces:** Near-infinite colorless mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 53**

**Steps:**

Sacrifice Ornithopter to Ashnod's Altar, adding {C}{C}.
Dictate of Erebos triggers, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Ornithopter to your hand.
Cast Ornithopter by paying {0}.
Repeat until your opponents no longer control any creatures.

---

# 738-2034-4733-5004

**Cards:**

- Glissa, the Traitor
- Dictate of Erebos
- Ashnod's Altar
- Cathodion

**Produces:** Near-infinite colorless mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 19**

**Steps:**

Sacrifice Cathodion to Ashnod's Altar, adding {C}{C}.
Cathodion and Dictate of Erebos trigger.
Resolve Cathodion's trigger, adding {C}{C}{C}.
Resolve Dictate of Erebos's trigger, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Cathodion to your hand.
Cast Cathodion by paying {3}.
Repeat until your opponents no longer control any creatures.

---

# 738-3370-3652-4050

**Cards:**

- Glissa, the Traitor
- Butcher of Malakir
- Phyrexian Altar
- Ornithopter

**Produces:** Near-infinite colored mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 1**

**Steps:**

Sacrifice Ornithopter to Phyrexian Altar, adding one mana of any color.
Butcher of Malakir triggers, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Ornithopter to your hand.
Cast Ornithopter by paying {0}.
Repeat until your opponents no longer control any creatures.

---

# 738-3370-3652-4659

**Cards:**

- Glissa, the Traitor
- Butcher of Malakir
- Krark-Clan Ironworks
- Ornithopter

**Produces:** Near-infinite colorless mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 12**

**Steps:**

Sacrifice Ornithopter to Krark-Clan Ironworks, adding {C}{C}.
Butcher of Malakir triggers, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Ornithopter to your hand.
Cast Ornithopter by paying {0}.
Repeat until your opponents no longer control any creatures.

---

# 738-3370-3652-5256

**Cards:**

- Glissa, the Traitor
- Butcher of Malakir
- Altar of Dementia
- Ornithopter

**Produces:** Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite mill, Near-infinite sacrifice triggers, Near-infinite self-mill, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 4**

**Steps:**

Sacrifice Ornithopter to Altar of Dementia.
Butcher of Malakir triggers, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Ornithopter to your hand.
Resolve Altar of Dementia's ability, causing target player to mill cards equal to the sacrificed creature's power.
Cast Ornithopter by paying {0}.
Repeat until your opponents no longer control any creatures.

---

# 738-3370-4050-5004

**Cards:**

- Glissa, the Traitor
- Butcher of Malakir
- Phyrexian Altar
- Cathodion

**Produces:** Near-infinite colored mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 4**

**Steps:**

Sacrifice Cathodion to Phyrexian Altar, adding one mana of any color.
Cathodion and Butcher of Malakir trigger.
Resolve Cathodion's trigger, adding {C}{C}{C}.
Resolve Butcher of Malakir's trigger, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Cathodion to your hand.
Cast Cathodion by paying {3}.
Repeat until your opponents no longer control any creatures.

---

# 738-3370-4659-5004

**Cards:**

- Glissa, the Traitor
- Butcher of Malakir
- Krark-Clan Ironworks
- Cathodion

**Produces:** Near-infinite colorless mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 3**

**Steps:**

Sacrifice Cathodion to Krark-Clan Ironworks, adding {C}{C}.
Cathodion and Butcher of Malakir trigger.
Resolve Cathodion's trigger, adding {C}{C}{C}.
Resolve Butcher of Malakir's trigger, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Cathodion to your hand.
Cast Cathodion by paying {3}.
Repeat until your opponents no longer control any creatures.

---

# 738-3370-5004-5256

**Cards:**

- Glissa, the Traitor
- Butcher of Malakir
- Altar of Dementia
- Cathodion

**Produces:** Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite mill, Near-infinite sacrifice triggers, Near-infinite self-mill, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 2**

**Steps:**

Sacrifice Cathodion to Altar of Dementia.
Cathodion and Butcher of Malakir trigger.
Resolve Cathodion's trigger, adding {C}{C}{C}.
Resolve Butcher of Malakir's trigger, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Cathodion to your hand.
Resolve Altar of Dementia's ability, causing target player to mill cards equal to the sacrificed creature's power.
Cast Cathodion by paying {3}.
Repeat until your opponents no longer control any creatures.

---

# 738-3652-4050-4733

**Cards:**

- Glissa, the Traitor
- Dictate of Erebos
- Phyrexian Altar
- Ornithopter

**Produces:** Near-infinite colored mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 22**

**Steps:**

Sacrifice Ornithopter to Phyrexian Altar, adding one mana of any color.
Dictate of Erebos triggers, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Ornithopter to your hand.
Cast Ornithopter by paying {0}.
Repeat until your opponents no longer control any creatures.

---

# 738-3652-4659-4733

**Cards:**

- Glissa, the Traitor
- Dictate of Erebos
- Krark-Clan Ironworks
- Ornithopter

**Produces:** Near-infinite colorless mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 46**

**Steps:**

Sacrifice Ornithopter to Krark-Clan Ironworks, adding {C}{C}.
Dictate of Erebos triggers, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Ornithopter to your hand.
Cast Ornithopter by paying {0}.
Repeat until your opponents no longer control any creatures.

---

# 738-3652-4733-5256

**Cards:**

- Glissa, the Traitor
- Dictate of Erebos
- Altar of Dementia
- Ornithopter

**Produces:** Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite mill, Near-infinite sacrifice triggers, Near-infinite self-mill, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 15**

**Steps:**

Sacrifice Ornithopter to Altar of Dementia.
Dictate of Erebos triggers, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Ornithopter to your hand.
Resolve Altar of Dementia's ability, causing target player to mill cards equal to the sacrificed creature's power.
Cast Ornithopter by paying {0}.
Repeat until your opponents no longer control any creatures.

---

# 738-4050-4733-5004

**Cards:**

- Glissa, the Traitor
- Dictate of Erebos
- Phyrexian Altar
- Cathodion

**Produces:** Near-infinite colored mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 9**

**Steps:**

Sacrifice Cathodion to Phyrexian Altar, adding one mana of any color.
Cathodion and Dictate of Erebos trigger.
Resolve Cathodion's trigger, adding {C}{C}{C}.
Resolve Dictate of Erebos's trigger, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Cathodion to your hand.
Cast Cathodion by paying {3}.
Repeat until your opponents no longer control any creatures.

---

# 738-4659-4733-5004

**Cards:**

- Glissa, the Traitor
- Dictate of Erebos
- Krark-Clan Ironworks
- Cathodion

**Produces:** Near-infinite colorless mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 20**

**Steps:**

Sacrifice Cathodion to Krark-Clan Ironworks, adding {C}{C}.
Cathodion and Dictate of Erebos trigger.
Resolve Cathodion's trigger, adding {C}{C}{C}.
Resolve Dictate of Erebos's trigger, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Cathodion to your hand.
Cast Cathodion by paying {3}.
Repeat until your opponents no longer control any creatures.

---

# 738-4733-5004-5256

**Cards:**

- Glissa, the Traitor
- Dictate of Erebos
- Altar of Dementia
- Cathodion

**Produces:** Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite mill, Near-infinite sacrifice triggers, Near-infinite self-mill, Near-infinite storm count, Opponents sacrifice all their creatures each turn, Lock

**Mana: , MV: 0, Colors: BG, Popularity: 9**

**Steps:**

Sacrifice Cathodion to Altar of Dementia.
Cathodion and Dictate of Erebos trigger.
Resolve Cathodion's trigger, adding {C}{C}{C}.
Resolve Dictate of Erebos's trigger, causing each opponent to sacrifice a creature.
Glissa triggers at least once, allowing you to return Cathodion to your hand.
Resolve Altar of Dementia's ability, causing target player to mill cards equal to the sacrificed creature's power.
Cast Cathodion by paying {3}.
Repeat until your opponents no longer control any creatures.

---

# 739-1173-5261

**Cards:**

- Gideon of the Trials
- Isochron Scepter
- Final Fortune

**Produces:** Infinite turns, Lock

**Mana: {2} each turn, MV: 2, Colors: RW, Popularity: 83**

**Steps:**

Activate Isochron Scepter by paying {2}, casting a copy of Final Fortune without paying its mana cost.
Resolve Final Fortune, taking an extra turn after this one.
Repeat each turn.
At the beginning of each extra turn's end step, Final Fortune triggers to cause you to lose the game, but you cannot lose the game due to Gideon of the Trials's emblem.

---

# 739-2358-3350

**Cards:**

- Gideon of the Trials
- Axis of Mortality
- Blood Celebrant

**Produces:** Target player loses the game on each of your turns

**Mana: , MV: 0, Colors: WB, Popularity: 161**

**Steps:**

At the beginning of your upkeep, Axis of Mortality triggers.
Activate Blood Celebrant by paying {B} and one life, adding {B}.
Repeat step 2 until you have zero life.
Resolve the Axis of Mortality trigger, swapping your life total with an opponent.
The opponent loses the game due to having zero life.
You may repeat this on each of your turns.

---

# 739-2749-3350

**Cards:**

- Gideon of the Trials
- Axis of Mortality
- Wall of Blood

**Produces:** Target player loses the game on each of your turns

**Mana: , MV: 0, Colors: WB, Popularity: 501**

**Steps:**

At the beginning of your upkeep, Axis of Mortality triggers.
Activate Wall of Blood by paying 1 life, giving Wall of Blood +1/+1 until end of turn.
Repeat step 2 until you have zero life.
Resolve the Axis of Mortality trigger, swapping your life total with an opponent.
The opponent loses the game due to having zero life.
You may repeat this on each of your turns.

---

# 739-2935-3350

**Cards:**

- Gideon of the Trials
- Axis of Mortality
- Ethereal Champion

**Produces:** Target player loses the game on each of your turns

**Mana: , MV: 0, Colors: W, Popularity: 28**

**Steps:**

At the beginning of your upkeep, Axis of Mortality triggers.
Activate Ethereal Champion by paying 1 life, preventing the next one damage that will be dealt to Ethereal Champion this turn.
Repeat step 2 until you have zero life.
Resolve the Axis of Mortality trigger, swapping your life total with an opponent.
The opponent loses the game due to having zero life.
You may repeat this on each of your turns.

---

# 739-3041-5109

**Cards:**

- Gideon of the Trials
- Coalhauler Swine
- Volcano Hellion

**Produces:** Infinite damage

**Mana: {2}{R}{R}, MV: 4, Colors: RW, Popularity: 1**

**Steps:**

Cast Volcano Hellion by paying {2}{R}{R}.
Volcano Hellion enters the battlefield, triggering itself, dealing an arbitrarily large amount of damage to Coalhauler Swine and to you, which does not cause you to lose the game due to Gideon of the Trials's emblem.
Coalhauler Swine triggers, dealing an equal amount of damage to each player, which again does not cause you to lose the game.

---

# 739-3350-3591

**Cards:**

- Gideon of the Trials
- Axis of Mortality
- Necropotence

**Produces:** Target player loses the game on each of your turns

**Mana: , MV: 0, Colors: WB, Popularity: 202**

**Steps:**

At the beginning of your upkeep, Axis of Mortality triggers.
Activate Necropotence by paying 1 life, exiling the top card of your library face down.
Repeat step 2 until you have zero life.
Resolve the Axis of Mortality trigger, swapping your life total with an opponent.
The opponent loses the game due to having zero life.
You may repeat this on each of your turns.

---

# 739-3350-3859

**Cards:**

- Gideon of the Trials
- Axis of Mortality
- Cavern Harpy

**Produces:** Target player loses the game on each of your turns

**Mana: , MV: 0, Colors: WUB, Popularity: 3**

**Steps:**

At the beginning of your upkeep, Axis of Mortality triggers.
Activate Cavern Harpy by paying 1 life.
Repeat step 2 until you have zero life.
Resolve the last Cavern Harpy trigger, returning it to your hand.
The remaining Cavern Harpy triggers fizzle.
Resolve the Axis of Mortality trigger, swapping your life total with an opponent.
The opponent loses the game due to having zero life.
You may repeat this on each of your turns.

---

# 739-937-2358

**Cards:**

- Gideon of the Trials
- Magus of the Mirror
- Blood Celebrant

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WB, Popularity: 103**

**Steps:**

During your upkeep, activate Blood Celebrant by paying {B} and one life, adding {B}.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 739-937-2749

**Cards:**

- Gideon of the Trials
- Magus of the Mirror
- Wall of Blood

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WB, Popularity: 377**

**Steps:**

During your upkeep, activate Wall of Blood by paying 1 life, giving Wall of Blood +1/+1 until end of turn.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 739-937-2935

**Cards:**

- Gideon of the Trials
- Magus of the Mirror
- Ethereal Champion

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WB, Popularity: 12**

**Steps:**

During your upkeep, activate Ethereal Champion by paying 1 life, preventing the next one damage that will be dealt to Ethereal Champion this turn.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 739-937-3591

**Cards:**

- Gideon of the Trials
- Magus of the Mirror
- Necropotence

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WB, Popularity: 121**

**Steps:**

During your upkeep, activate Necropotence by paying 1 life, exiling the top card of your library face down.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 739-937-3859

**Cards:**

- Gideon of the Trials
- Magus of the Mirror
- Cavern Harpy

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WUB, Popularity: 2**

**Steps:**

During your upkeep, activate Cavern Harpy by paying 1 life.
Repeat step 1 until you have zero life.
Resolve the last Cavern Harpy trigger, returning it to your hand.
The remaining Cavern Harpy triggers fizzle.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 742-1295

**Cards:**

- Demonic Consultation
- Thassa's Oracle

**Produces:** Exile your library, Win the game

**Mana: {U}{U}{B}, MV: 3, Colors: UB, Popularity: 135659**

**Steps:**

Cast Demonic Consultation by paying {B}, naming Thassa's Oracle and thus exiling your library due to you not having a card named Thassa's Oracle in your library.
Cast Thassa's Oracle by paying {U}{U}.
Thassa's Oracle enters the battlefield, causing you to win the game.

---

# 742-1295-2890-3077-3944-4892

**Cards:**

- Flash
- Protean Hulk
- Spellseeker
- Thassa's Oracle
- Blood Pet
- Demonic Consultation

**Produces:** Exile your library, Win the game

**Mana: , MV: 0, Colors: BGU, Popularity: 0**

**Steps:**

Cast Flash, targeting Protean Hulk.
Protean Hulk dies on ETB, fetching Blood Pet, Spellseeker, and Thassa's Oracle.
Arrange the stack such that Spellseeker's trigger is on top, so that when it resolves, it fetches Demonic Consultation.
Cast Demonic Consultation by sacrificing Blood Pet, adding 1 black mana to your mana pool.
Make sure Demonic Consultation targets a card not in your library, causing you to exile your entire library.
Then, Thassa's Oracle ETB resolves, and since you have no library, you win the game.

---

# 742-2836

**Cards:**

- Demonic Consultation
- Laboratory Maniac

**Produces:** Exile your library, Win the game

**Mana: {B}, MV: 1, Colors: UB, Popularity: 12824**

**Steps:**

Cast Demonic Consultation by paying {B}, naming Laboratory Maniac and thus exiling your library due to you not having a card named Laboratory Maniac in your library.
Draw a card, causing you to win the game due to Laboratory Maniac.

---

# 742-3096

**Cards:**

- Demonic Consultation
- Jace, Wielder of Mysteries

**Produces:** Exile your library, Win the game

**Mana: {B}, MV: 1, Colors: UB, Popularity: 8407**

**Steps:**

Cast Demonic Consultation by paying {B}, naming Jace, Wielder of Mysteries and thus exiling your library due to you not having a card named Jace, Wielder of Mysteries in your library.
Activate Jace's first loyalty ability by putting a loyalty counter on it, causing target player to mill two cards and you to win the game due to drawing from an empty library.

---

# 751-1283-5068

**Cards:**

- Shrieking Drake
- Chromatic Orrery
- Lapis Lazuli Talisman

**Produces:** Infinite colored mana, Infinite colorless mana, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: , MV: 0, Colors: U, Popularity: 3**

**Steps:**

Activate Chromatic Orrery by tapping it, adding {C}{C}{C}{C}{C}.
Cast Shrieking Drake.
Pay for Talisman to untap Chromatic Orrery.
Return Shrieking Drake to hand using its ability.

---

# 751-1425-2757

**Cards:**

- Shrieking Drake
- Earthcraft
- Primordial Sage

**Produces:** Infinite card draw, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: , MV: 0, Colors: GU, Popularity: 50**

**Steps:**

Activate a basic Island you control by tapping it, adding {U}.
Cast Shrieking Drake by paying {U}.
Primordial Sage triggers, allowing you to draw a card.
Shrieking Drake enters the battlefield, triggering itself.
Holding priority, activate Earthcraft by tapping Shrieking Drake, untapping a tapped basic Island.
Resolve Shrieking Drake's trigger, returning it from the battlefield to your hand.
Repeat.

---

# 751-1622-2792

**Cards:**

- Minion Reflector
- Great Whale
- Shrieking Drake

**Produces:** Infinite creature tokens with haste, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mana lands you control can produce, Infinite sacrifice triggers, Infinite storm count

**Mana: {5}{U}{U}, including at least {4}{U}{U} from lands, MV: 7, Colors: U, Popularity: 7**

**Steps:**

Cast Great Whale by paying {5}{U}{U}.
Great Whale enters the battlefield, triggering itself and Minion Reflector.
Resolve Great Whale's trigger, untapping up to seven lands you control.
Activate those lands by tapping them, adding at least {4}{U}{U}.
Resolve Minion Reflector's trigger, paying {2} to create a token copy of Great Whale.
The Great Whale token enters the battlefield, triggering itself, untapping up to seven lands you control.
Activate those lands by tapping them, adding at least {4}{U}{U}.
Cast Shrieking Drake by paying {U}.
Shrieking Drake enters the battlefield, triggering itself and Minion Reflector.
Resolve Shrieking Drake's trigger, returning the nontoken Great Whale from the battlefield to your hand.
Resolve Minion Reflector's trigger, paying {2} to create a token copy of Shrieking Drake.
The Shrieking Drake token enters the battlefield, triggering itself, returning the nontoken Shrieking Drake from the battlefield to your hand.
Repeat.
If your seven lands can produce at least {5}{U}{U}, this combo produces infinite mana.

---

# 751-1622-3821

**Cards:**

- Minion Reflector
- Peregrine Drake
- Shrieking Drake

**Produces:** Infinite ETB, Infinite LTB, Infinite mana lands you control can produce, Infinite sacrifice triggers, Infinite storm count, Infinite creature tokens with haste, Infinite death triggers

**Mana: {4}{U} from lands, MV: 5, Colors: U, Popularity: 29**

**Steps:**

Cast Peregrine Drake by paying {4}{U}.
Peregrine Drake enters the battlefield, triggering itself and Minion Reflector.
Resolve Peregrine Drake's ability, untapping up to five lands.
Activate those lands by tapping them, adding at least {4}{U}.
Resolve Minion Reflector's ability, paying {2} to create a token copy of Peregrine Drake with haste that will be sacrificed at end of turn.
The token copy of Peregrine Drake enters the battlefield, triggering itself, untapping up to five lands.
Activate those lands by tapping them, adding at least {4}{U}.
Cast Shrieking Drake by paying {U}.
Shrieking Drake enters the battlefield, triggering itself and Minion Reflector.
Resolve Minion Reflector's ability, paying {2} to create a token copy of Shrieking Drake with haste that will be sacrificed at end of turn.
The token copy of Shrieking Drake enters the battlefield, triggering itself, returning the nontoken Shrieking Drake from the battlefield to your hand.
Resolve the nontoken Shrieking Drake's ability, returning the nontoken Peregrine Drake from the battlefield to your hand.
Repeat.
If you control a land that can tap to produce at least {2}, this combo produces infinite mana.

---

# 751-1636

**Cards:**

- Intruder Alarm
- Shrieking Drake

**Produces:** Infinite ETB, Infinite LTB, Infinite mana creatures you control can produce, Infinite storm count, Infinite untap of creatures

**Mana: , MV: 0, Colors: U, Popularity: 5603**

**Steps:**

Activate all mana-producing creatures you control by tapping them, adding at least {U}.
Cast Shrieking Drake by paying {U}.
Shrieking Drake enters the battlefield, triggering Intruder Alarm and Shrieking Drake.
Resolve the Intruder Alarm's trigger, untapping all creatures you control.
Resolve the Shrieking Drake's trigger, returning it to your hand.
Repeat.

---

# 751-1741-2397

**Cards:**

- Cloud of Faeries
- Shrieking Drake
- Panharmonicon

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: {1}{U}, MV: 2, Colors: U, Popularity: 2062**

**Steps:**

Cast Cloud of Faeries by paying {1}{U}.
Cloud of Faeries enters the battlefield, triggering their abilities twice each.
Resolve the first Cloud of Faeries ability, untap two lands.
Holding priority, activate two lands by tapping those, adding at least {1}{U}.
Repeat step 3 for each remaining Cloud of Faeries trigger  Cast Shrieking Drake by paying {U}.
Shrieking Drake enters the battlefield, triggering their abilities twice each.
Resolve the first Shrieking Drake ability, returning itself to hand.
Resolve the second Shrieking Drake ability, returning Cloud of Faeries to hand.
Repeat.

---

# 751-1741-2499

**Cards:**

- Cloud of Faeries
- Shrieking Drake
- Yarok, the Desecrated

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: , MV: 0, Colors: BGU, Popularity: 765**

**Steps:**

Activate up to two lands by tapping them, adding at least {1}{U}.
Cast Cloud of Faeries by paying {1}{U}.
When Cloud of Faeries enters the battlefield, it triggers twice.
Resolve the first trigger, untapping up to two lands.
Holding priority, activate up to two lands by tapping them, adding at least {1}{U}.
Resolve the second Cloud of Faeries trigger, untapping up to two lands.
Cast Shrieking Drake by paying {U}.
When Shrieking Drake enters the battlefield, it triggers twice, returning it and Cloud of Faeries from the battlefield to your hand.
Repeat.

---

# 751-2397-3821

**Cards:**

- Peregrine Drake
- Shrieking Drake
- Panharmonicon

**Produces:** Infinite ETB, Infinite LTB, Infinite mana lands you control can produce, Infinite storm count

**Mana: {4}{U}, MV: 5, Colors: U, Popularity: 3345**

**Steps:**

Cast Peregrine Drake by paying {4}{U}.
When Peregrine Drake enters the battlefield, it triggers itself twice due to Panharmonicon.
Resolve one Peregrine Drake trigger, untapping five lands.
Activate those lands by tapping them to add at least {2}{U}.
Resolve the remaining Peregrine Drake trigger, untapping five lands.
Activate those lands by tapping them to add at least {2}{U}.
Cast Shrieking Drake by paying {U}.
When Shrieking Drake enters the battlefield, it triggers itself twice due to Panharmonicon, returning itself and Peregrine Drake from the battlefield to your hand.
Repeat.
If you can produce at least one additional mana in step 4, this combo produces infinite mana.

---

# 751-2757

**Cards:**

- Shrieking Drake
- Earthcraft

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count

**Mana: , MV: 0, Colors: GU, Popularity: 2253**

**Steps:**

Activate a basic Island you control by tapping it, adding {U}.
Cast Shrieking Drake by paying {U}.
Shrieking Drake enters the battlefield, triggering itself.
Holding priority, activate Earthcraft by tapping Shrieking Drake, untapping a tapped basic Island.
Resolve Shrieking Drake's trigger, returning it from the battlefield to your hand.
Repeat.

---

# 751-2757-3314

**Cards:**

- Shrieking Drake
- Earthcraft
- Chulane, Teller of Tales

**Produces:** Infinite card draw, Infinite ETB, Infinite LTB, Infinite storm count, Near-infinite ETB, Near-infinite landfall triggers, Near-infinite LTB, Near-infinite storm count, Put all lands from your hand and library onto the battlefield

**Mana: , MV: 0, Colors: GWU, Popularity: 616**

**Steps:**

Activate a basic Island you control by tapping it, adding {U}.
Cast Shrieking Drake by paying {U}.
Chulane triggers, causing you to draw a card and allowing you to put a land card from your hand onto the battlefield.
Shrieking Drake enters the battlefield, triggering itself.
Holding priority, activate Earthcraft by tapping Shrieking Drake, untapping a tapped basic Island.
Resolve Shrieking Drake's trigger, returning it from the battlefield to your hand.
Repeat.

---

# 751-3314-4093

**Cards:**

- Chulane, Teller of Tales
- Mana Breach
- Shrieking Drake

**Produces:** Infinite card draw, Infinite draw triggers, Near-infinite ETB, Near-infinite landfall triggers, Near-infinite LTB, Near-infinite storm count

**Mana: , MV: 0, Colors: GWU, Popularity: 2064**

**Steps:**

Activate a land by tapping it, adding {U}.
Cast Shrieking Drake by paying {U}.
Mana Breach and Chulane triggers.
Resolve the Mana Breach trigger, returning a land to your hand.
Resolve the Chulane triggers, causing you to draw a card and put land from your hand onto the battlefield.
Shrieking Drake enters the battlefield triggers, returning itself from the battlefield to your hand.
Repeat.

---

# 75-4762

**Cards:**

- Devoted Druid
- Quillspike

**Produces:** Infinitely large creature until end of turn

**Mana: , MV: 0, Colors: BG, Popularity: 5102**

**Steps:**

Activate Devoted Druid's first ability by tapping it, adding {G}.
Activate Devoted Druid's second ability by putting a -1/-1 counter on it, untapping itself.
Activate Quillspike by paying {B/G} and removing a -1/-1 counter from Devoted Druid, giving Quillspike +3/+3 until end of turn.
Repeat.

---

# 757-2003-2402

**Cards:**

- Magosi, the Waterveil
- Nesting Grounds
- Contagion Engine

**Produces:** Infinite turns, Lock

**Mana: {5} each turn, MV: 5, Colors: U, Popularity: 326**

**Steps:**

Activate Contagion Engine by paying {4} and tapping it, putting an eon counter on Magosi.
Activate Nesting Grounds's last ability by paying {1} and tapping it, moving an eon counter from Magosi to Nesting Grounds.
Activate Magosi's last ability by tapping it, removing an eon counter from it and returning it to your hand, taking an extra turn after this one.
Play Magosi from your hand.
Move to your next turn.
Activate Contagion Engine by paying {4} and tapping it, putting an eon counter on Nesting Grounds.
Activate Nesting Grounds's last ability by paying {1} and tapping it, moving an eon counter from Nesting Grounds to Magosi.
Repeat from step 3.

---

# 757-2402-3933

**Cards:**

- Magosi, the Waterveil
- Nesting Grounds
- Karn's Bastion

**Produces:** Infinite turns, Lock

**Mana: {5} each turn, MV: 5, Colors: U, Popularity: 1328**

**Steps:**

Activate Karn's Bastion's last ability by paying {4} and tapping it, putting an eon counter on Magosi.
Activate Nesting Grounds's last ability by paying {1} and tapping it, moving an eon counter from Magosi to Nesting Grounds.
Activate Magosi's last ability by tapping it, removing an eon counter from it, and returning it to your hand, taking an extra turn after this one.
Play Magosi from your hand.
Move to your next turn.
Activate Karn's Bastion's last ability by paying {4} and tapping it, putting an eon counter on Nesting Grounds.
Activate Nesting Grounds's last ability by paying {1} and tapping it, moving an eon counter from Nesting Grounds to Magosi.
Repeat from step 3.

---

# 757-2402-4353

**Cards:**

- Magosi, the Waterveil
- Nesting Grounds
- Atraxa, Praetors' Voice

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: GWUB, Popularity: 233**

**Steps:**

Activate Nesting Grounds's last ability by paying {1} and tapping it, moving an eon counter from Magosi to Nesting Grounds.
Activate Magosi's last ability by tapping it, removing an eon counter from it, and returning it from the battlefield to your hand, taking an extra turn after this one.
Play Magosi.
At the beginning of your end step, Atraxa triggers, causing you to proliferate, putting an additional eon counter on Nesting Grounds.
On your next extra turn, activate Nesting Grounds's last ability by paying {1} and tapping it, moving an eon counter from Nesting Grounds to Magosi.
Repeat from step 2.

---

# 757-2402-4883

**Cards:**

- Magosi, the Waterveil
- Nesting Grounds
- Contagion Clasp

**Produces:** Infinite turns, Lock

**Mana: {5} each turn, MV: 5, Colors: U, Popularity: 286**

**Steps:**

Activate Contagion Clasp by paying {4} and tapping it, putting an eon counter on Magosi.
Activate Nesting Grounds's last ability by paying {1} and tapping it, moving an eon counter from Magosi to Nesting Grounds.
Activate Magosi's last ability by tapping it, removing an eon counter from it and returning it to your hand, taking an extra turn after this one.
Play Magosi from your hand.
Move to your next turn.
Activate Contagion Clasp by paying {4} and tapping it, putting an eon counter on Nesting Grounds.
Activate Nesting Grounds's last ability by paying {1} and tapping it, moving an eon counter from Nesting Grounds to Magosi.
Repeat from step 3.

---

# 757-943-4235

**Cards:**

- Magosi, the Waterveil
- Rings of Brighthearth
- Deserted Temple

**Produces:** Infinite turns, Lock

**Mana: {3}{U} each turn, MV: 4, Colors: U, Popularity: 234**

**Steps:**

Activate Magosi's second ability by paying {U} and tapping it.
Rings of Brighthearth triggers, choose not to pay.
Resolve the Magosi ability, putting an eon counter on it and causing you to skip your next turn.
Activate Deserted Temple's second ability by paying {1} and tapping it, untapping Magosi.
Activate Magosi's third ability by tapping it, removing an eon counter from it and returning it from the battlefield to your hand.
Rings of Brighthearth triggers, causing you to pay {2} to copy Magosi's ability.
Resolve both Magosi abilities, causing you to take two extra turns after this one.
Play Magosi.
Move to your first extra turn, which is skipped due to Magosi's ability which resolved in step 3.
Move to your second extra turn.
Repeat.

---

# 759-4996

**Cards:**

- Beacon of Immortality
- Tainted Remedy

**Produces:** Target opponent loses the game

**Mana: {5}{W}, MV: 6, Colors: WB, Popularity: 2412**

**Steps:**

Cast Beacon of Immortality by paying {5}{W}, causing target opponent to lose life equal to their life total due to Tainted Remedy.
The opponent loses the game due to having zero or less life.

---

# 763-1274-4929

**Cards:**

- Heliod, Sun-Crowned
- Cryptic Trilobite
- Juju Bubble

**Produces:** Infinite lifegain, Infinite lifegain triggers

**Mana: {2}, MV: 2, Colors: W, Popularity: 27**

**Steps:**

Activate Juju Bubble by paying {2}, causing you to gain 1 life.
Heliod triggers, putting a +1/+1 counter on Cryptic Trilobite.
Activate Cryptic Trilobite by removing a +1/+1 counter from it, adding {C}{C} that can only be spent to activate abilities.
Repeat.

---

# 763-4017-4929

**Cards:**

- Sunbond
- Cryptic Trilobite
- Juju Bubble

**Produces:** Infinite lifegain, Infinite lifegain triggers

**Mana: {2}, MV: 2, Colors: W, Popularity: 23**

**Steps:**

Activate Juju Bubble by paying {2}, causing you to gain 1 life.
Sunbond triggers, putting a +1/+1 counter on Cryptic Trilobite.
Activate Cryptic Trilobite by removing a +1/+1 counter from it, adding {C}{C} that can only be spent to activate abilities.
Repeat.

---

# 767-2011

**Cards:**

- Najeela, the Blade-Blossom
- Druids' Repository

**Produces:** Infinite combat phases, Infinite creature tokens, Infinite ETB, Infinite lifegain, Infinite lifegain triggers

**Mana: , MV: 0, Colors: WUBRG, Popularity: 6163**

**Steps:**

Declare Najeela and four other creature as attackers.
Najeela triggers, creating a 1/1 Warrior creature token that is tapped and attacking.
Druids' Repository triggers five times, putting five charge counters on it.
Activate Druids' Repository five times by removing five charge counters from it, adding {W}{U}{B}{R}{G}.
Activate Najeela by paying {W}{U}{B}{R}{G}, untapping all attacking creatures, giving them trample, lifelink, and haste, and gaining an additional combat phase after this one.
Repeat each combat phase.

---

# 770-1636

**Cards:**

- Intruder Alarm
- Man-o'-War

**Produces:** Infinite ETB, Infinite LTB, Infinite mana creatures you control can produce, Infinite storm count, Infinite untap of creatures

**Mana: , MV: 0, Colors: U, Popularity: 551**

**Steps:**

Activate all mana-producing creatures you control by tapping them, adding at least {2}{U}.
Cast Man-o'-War by paying {2}{U}.
Man-o'-War enters the battlefield, triggering Intruder Alarm and Man-o'-War.
Resolve the Intruder Alarm's trigger, untapping all creatures you control.
Resolve the Man-o'-War's trigger, returning it to your hand.
Repeat.

---

# 770-2397-3821

**Cards:**

- Peregrine Drake
- Man-o'-War
- Panharmonicon

**Produces:** Infinite ETB, Infinite LTB, Infinite mana lands you control can produce, Infinite storm count

**Mana: {4}{U}, MV: 5, Colors: U, Popularity: 4038**

**Steps:**

Cast Peregrine Drake by paying {4}{U}.
When Peregrine Drake enters the battlefield, it triggers itself twice due to Panharmonicon.
Resolve one Peregrine Drake trigger, untapping five lands.
Activate those lands by tapping them to add at least {3}{U}.
Resolve the remaining Peregrine Drake trigger, untapping five lands.
Activate those lands by tapping them to add at least {3}{U}.
Cast Man-o'-War by paying {2}{U}.
When Man-o'-War enters the battlefield, it triggers itself twice due to Panharmonicon, returning itself and Peregrine Drake from the battlefield to your hand.
Repeat.
If you can produce at least one additional mana in step 4, this combo produces infinite mana.

---

# 770-2499-3821

**Cards:**

- Peregrine Drake
- Man-o'-War
- Yarok, the Desecrated

**Produces:** Infinite ETB, Infinite LTB, Infinite mana lands you control can produce, Infinite storm count

**Mana: {4}{U}, MV: 5, Colors: BGU, Popularity: 851**

**Steps:**

Cast Peregrine Drake by paying {4}{U}.
When Peregrine Drake enters the battlefield, it triggers itself twice due to Yarok.
Resolve one Peregrine Drake trigger, untapping five lands.
Activate those lands by tapping them to add at least {3}{U}.
Resolve the remaining Peregrine Drake trigger, untapping five lands.
Activate those lands by tapping them to add at least {3}{U}.
Cast Man-o'-War by paying {2}{U}.
When Man-o'-War enters the battlefield, it triggers itself twice due to Yarokg, returning itself and Peregrine Drake from the battlefield to your hand.
Repeat.
If you can produce at least one additional mana in step 4, this combo produces infinite mana.

---

# 770-2506-4191

**Cards:**

- Aluren
- Molten Echoes
- Man-o'-War

**Produces:** Infinite creature tokens with haste, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: , MV: 0, Colors: GUR, Popularity: 1**

**Steps:**

Cast Man-o'-War without paying its mana cost.
Man-o'-War enters the battlefield, targeting itself.
Molten Echoes triggers, creating a token copy of Man-o'-War.
Token copy of Man-o'-War enters the battlefield, returning original Man-o'-War to hand.
Resolve the original Man-o'-War triggers, fails to resolve due to having no legal targets.
Repeat.

---

# 771-1328

**Cards:**

- Spellbinder
- Savage Beating

**Produces:** Infinite combat phases, Infinite damage, Infinite magecraft triggers, Infinite storm count

**Mana: , MV: 0, Colors: R, Popularity: 907**

**Steps:**

Declare the creature with Spellbinder equipped as an attacker, attacking an opponent unable to block it.
Deal combat damage with the creature, triggering Spellbinder, casting a copy of Savage Beating without paying its mana cost.
Resolve Savage Beating, untapping all creatures you control and getting an additional combat phase after this one.
Repeat.

---

# 772-2034-3175

**Cards:**

- Sun Titan
- Ashnod's Altar
- Shade's Form

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite colorless mana

**Mana: , MV: 0, Colors: WB, Popularity: 26**

**Steps:**

Activate Ashnod's Altar by sacrificing Sun Titan.
When Sun Titan dies, Shade's Form triggers, returning Sun Titan from your graveyard to the battlefield.
When Sun Titan enters, it triggers, returning Shade's Form from your graveyard to the battlefield attached to Sun Titan.
Repeat.

---

# 772-3175-4050

**Cards:**

- Sun Titan
- Phyrexian Altar
- Shade's Form

**Produces:** Infinite LTB, Infinite sacrifice triggers, Infinite colored mana, Infinite death triggers, Infinite ETB

**Mana: , MV: 0, Colors: WB, Popularity: 17**

**Steps:**

Activate Phyrexian Altar by sacrificing Sun Titan.
When Sun Titan dies, Shade's Form triggers, returning Sun Titan from your graveyard to the battlefield.
When Sun Titan enters, it triggers, returning Shade's Form from your graveyard to the battlefield attached to Sun Titan.
Repeat.

---

# 772-3175-5256

**Cards:**

- Sun Titan
- Altar of Dementia
- Shade's Form

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: WB, Popularity: 17**

**Steps:**

Activate Altar of Dementia by sacrificing Sun Titan.
When Sun Titan dies, Shade's Form triggers, returning Sun Titan from your graveyard to the battlefield.
When Sun Titan enters, it triggers, returning Shade's Form from your graveyard to the battlefield attached to Sun Titan.
Resolve the Altar of Dementia ability.
Repeat.

---

# 776-1329-1414

**Cards:**

- Jeskai Ascendancy
- Emry, Lurker of the Loch
- Lotus Petal

**Produces:** Infinite colored mana, Infinite ETB, Infinite looting, Infinite LTB, Infinitely large creatures, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: URW, Popularity: 439**

**Steps:**

Activate Lotus Petal by tapping and sacrificing it, adding one mana of of any color.
Activate Emry by tapping it, targeting Lotus Petal.
Cast Lotus Petal from your graveyard by paying {0}.
Jeskai Ascendacy first and second abilities trigger.
Resolve the first Jeskai Ascendancy trigger, giving creatures you control +1/+1 until end of turn and untapping them.
Resolve the second Jeskai Ascendancy trigger, allowing you to loot.


---

# 776-1329-2478

**Cards:**

- Jeskai Ascendancy
- Emry, Lurker of the Loch
- Mishra's Bauble

**Produces:** Infinite card draw, Infinite ETB, Infinite looting, Infinite LTB, Infinitely large creatures, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: URW, Popularity: 330**

**Steps:**

Activate Mishra's Bauble by tapping and sacrificing it, looking at the top card of a player's library and drawing a card at the beginning of the next turn's upkeep.
Activate Emry by tapping it, targeting Mishra's Bauble.
Cast Mishra's Bauble from your graveyard by paying {0}.
Jeskai Ascendacy first and second abilities trigger.
Resolve the first Jeskai Ascendancy trigger, giving creatures you control +1/+1 until end of turn and untapping them.
Resolve the second Jeskai Ascendancy trigger, allowing you to loot.


---

# 776-1792-3682

**Cards:**

- Jeskai Ascendancy
- Mox Amber
- Retraction Helix

**Produces:** Infinite colored mana, Infinite looting, Infinite mana creatures you control can produce, Infinite storm count, Infinite untap of creatures you control

**Mana: {U}, MV: 1, Colors: URW, Popularity: 342**

**Steps:**

Cast Retraction Helix by paying {U}, targeting a creature you control without summoning sickness.
Jeskai Ascendacy first and second abilities trigger.
Resolve the first Jeskai Ascendancy trigger, giving creatures you control +1/+1 until end of turn and untapping them.
Resolve the second Jeskai Ascendancy trigger, allowing you to loot.
Activate Mox Amber by tapping it, adding one mana of any color you can produce among legendary creatures and planeswalkers you control.
Activate the creature by tapping it, returning Mox Amber to your hand.
Cast Mox Amber by paying {0}.
Repeat from step 2.


---

# 776-3209

**Cards:**

- Jeskai Ascendancy
- Sprout Swarm

**Produces:** Infinite creature tokens, Infinite draw triggers, Infinite ETB, Infinite looting, Infinitely large creatures you control until end of turn, Infinite magecraft triggers, Infinite mana creatures you control can produce, Infinite storm count, Infinite untap of creatures you control

**Mana: , MV: 0, Colors: RGWU, Popularity: 63**

**Steps:**

Cast Sprout Swarm with buyback by tapping five untapped creatures you control.
Jeskai Ascendancy's first and second ability triggers.
Resolve Jeskai Ascendancy's first trigger, untapping all creatures you control and giving them +1/+1 until end of turn.
Resolve Jeskai Ascendancy's second trigger, allowing you to loot.
Resolve Sprout Swarm, creating a 1/1 Saproling creature token and returning Sprout Swarm to your hand.
Repeat.

---

# 776-3690-3923

**Cards:**

- Jeskai Ascendancy
- Sylvan Awakening
- Mystic Speculation

**Produces:** Infinite looting, Infinitely large creatures, Infinite magecraft triggers, Infinite mana lands you control can produce, Infinite storm count

**Mana: {2}{G}, MV: 3, Colors: RGWU, Popularity: 4**

**Steps:**

Cast Sylvan Awakening by paying {2}{G}, causing all lands you control to become 2/2 Elemental creatures that are still lands until end of turn.
Jeskai Ascendacy first and second abilities trigger.
Resolve the first Jeskai Ascendancy trigger, giving creatures you control +1/+1 until end of turn and untapping them.
Resolve the second Jeskai Ascendancy trigger, allowing you to loot.
Activate all of your lands by tapping those, adding at least {3}{U}.
Cast Mystic Speculation with buyback by paying {2}{U}.
Jeskai Ascendacy first and second abilities trigger.
Resolve the first Jeskai Ascendancy trigger, giving creatures you control +1/+1 until end of turn and untapping them.
Resolve the second Jeskai Ascendancy trigger, allowing you to loot.
Repeat from step 5.

---

# 777-1395-5078

**Cards:**

- Sensei's Divining Top
- Foundry Inspector
- Elsha of the Infinite

**Produces:** Infinite card draw, Near-infinite storm count, Infinite draw triggers, Near-infinitely large creature until end of turn

**Mana: , MV: 0, Colors: URW, Popularity: 671**

**Steps:**

Activate Sensei's Divining Top by tapping it, causing you to draw a card and put Sensei's Divining Top on top of your library.
Cast Sensei's Divining Top from the top of your library by paying {0}.
Elsha's prowess ability triggers, giving it +1/+1 until end of turn.
Repeat

---

# 777-1661-5078

**Cards:**

- Sensei's Divining Top
- Foundry Inspector
- Magus of the Future

**Produces:** Infinite draw triggers, Infinite card draw, Near-infinite storm count

**Mana: , MV: 0, Colors: U, Popularity: 221**

**Steps:**

Activate Sensei's Divining Top by tapping it, causing you to draw a card and put Sensei's Divining Top on top of your library.
Cast Sensei's Divining Top from the top of your library by paying {0}.
Repeat

---

# 777-4311-5078

**Cards:**

- Sensei's Divining Top
- Foundry Inspector
- Future Sight

**Produces:** Infinite card draw, Near-infinite storm count, Infinite draw triggers

**Mana: , MV: 0, Colors: U, Popularity: 809**

**Steps:**

Activate Sensei's Divining Top by tapping it, causing you to draw a card and put Sensei's Divining Top on top of your library.
Cast Sensei's Divining Top from the top of your library by paying {0}.
Repeat

---

# 777-985-5078

**Cards:**

- Sensei's Divining Top
- Foundry Inspector
- Mystic Forge

**Produces:** Infinite card draw, Near-infinite storm count, Infinite draw triggers

**Mana: , MV: 0, Colors: C, Popularity: 45422**

**Steps:**

Activate Sensei's Divining Top by tapping it, causing you to draw a card and put Sensei's Divining Top on top of your library.
Cast Sensei's Divining Top from the top of your library by paying {0}.
Repeat

---

# 780-864-4050

**Cards:**

- Eternal Witness
- Phyrexian Altar
- Supernatural Stamina

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {B}, MV: 1, Colors: BG, Popularity: 155**

**Steps:**

Cast Supernatural Stamina by paying {B}, giving Eternal Witness +2/+0 and a new triggered ability until end of turn.
Activate Phyrexian Altar by sacrificing Eternal Witness, adding {B}.
When Eternal Witness dies, it triggers its own ability from Supernatural Stamina, returning Eternal Witness from your graveyard to the battlefield tapped.
When Eternal Witness enters the battlefield, it triggers, returning Supernatural Stamina from your graveyard to your hand.
Repeat.

---

# 782-2580-5141

**Cards:**

- Lethal Vapors
- Teferi's Protection
- Grand Abolisher

**Produces:** Skip all your future turns, causing your opponents to eventually draw from an empty library and lose the game, You have protection from everything, Your life total can't change, Lock

**Mana: {4}{W}{B}{B}, MV: 7, Colors: WB, Popularity: 588**

**Steps:**

Cast Lethal Vapors by paying {2}{B}{B}.
Activate Lethal Vapors an arbitrarily large number of times.
Cast Teferi's Protection by paying {2}{W}: until your next turn your life total can't change and you have protection from everything.
Allow all the activated abilities from Lethal Vapors to resolve, skipping an arbitrarily large number of turns.

---

# 783-1399-3814

**Cards:**

- Argothian Elder
- Jungle Basin
- Wirewood Lodge

**Produces:** Infinite colorless mana

**Mana: , MV: 0, Colors: G, Popularity: 103**

**Steps:**

Activate Jungle Basin by tapping it, adding {1}{G}.
Activate Argothian Elder by tapping it, untapping Jungle Basin and Wirewood Lodge.
Activate Wirewood Lodge's second ability by paying {G} and tapping it, untap Argothian Elder.
Repeat.

---

# 787-1124

**Cards:**

- Teferi, Temporal Archmage
- The Chain Veil

**Produces:** Infinite card draw, Infinite colored mana, Infinite colorless mana, Infinite planeswalker activations

**Mana: , MV: 0, Colors: U, Popularity: 19326**

**Steps:**

Activate The Chain Veil by paying {4} and tapping it, allowing all planeswalkers you control to activate their loyalty abilities and additional time this turn.
Activate Teferi's second loyalty ability by removing a loyalty counter from it, untapping the Chain Veil and the three mana-producing permanents.
Repeat from step 1 until Teferi dies due to having zero loyalty.
Cast Teferi from your command zone.
Activate Teferi's first loyalty ability by adding a loyalty counter to it, looking at the top two cards of your library and putting one card from the top of your library into your hand and the other onto the bottom of your library.
Do this x times, where x is equal to one half times the number of times you activated The Chain Veil this turn minus four, rounded down.
Activate Teferi's second loyalty ability, untapping the Chain Veil and the three mana-producing permanents.
Repeat step 7 an additional time.
Activate Teferi's second loyalty ability by untapping the three mana producing permanents and the additional mana producing permanent, adding {4}{U}.
Repeat step 9 until Teferi dies due to having zero loyalty.
Repeat from step 4.

---

# 787-3094

**Cards:**

- Teferi, Temporal Archmage
- Lithoform Engine

**Produces:** Infinite mana lands you control can produce, Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: U, Popularity: 1953**

**Steps:**

Activate Teferi, Temporal Archmage's second ability by removing a loyalty counter from it.
In resopnse, activate Lithoform Engine's first ability by paying {2} and tapping it, copying Teferi's activated ability.
Let the copied ability resolve, untapping three lands and Lithoform Engine.
Activate those lands by tapping them, adding at least {3}.
Repeat from step 2.
Once you have infinite mana, you may untap any permanents in step 3.

---

# 790-1218-1972

**Cards:**

- Windfall
- Tainted Strike
- Nekusar, the Mindrazer

**Produces:** Each opponent loses the game

**Mana: {2}{U}{B}, MV: 4, Colors: UBR, Popularity: 1869**

**Steps:**

Cast Tainted Strike by paying {B}, giving Nekusar infect until end of turn.
Cast Windfall by paying {2}{U}, causing each player to discard their hand and then draw a number of cards equal to the greatest number of cards a player discarded this way.
Nekusar triggers for each card drawn this way, giving each opponent a poison counter for each card they drew.
Each opponent loses the game due to having ten or more poison counters

---

# 790-1368-4682

**Cards:**

- Smothering Tithe
- Underworld Breach
- Windfall

**Produces:** Infinite draw triggers for all players, Infinite looting for all players, Infinite self-discard triggers for all players, Near-infinite colored mana, Near-infinite Treasure tokens

**Mana: {2}{U}, MV: 3, Colors: URW, Popularity: 8276**

**Steps:**

Cast Windfall from your graveyard for its escape cost by paying {2}{U} and exiling three cards from your graveyard, causing each player to discard at least three cards and draw at least three cards.
Smothering Tithe triggers for each card drawn by your opponents, creating that many Treasure tokens.
Activate three of the Treasure tokens by tapping and sacrificing them, adding {2}{U}.
Repeat.

---

# 790-1972-3681

**Cards:**

- Windfall
- Grafted Exoskeleton
- Nekusar, the Mindrazer

**Produces:** Each opponent loses the game

**Mana: {2}{U}, MV: 3, Colors: UBR, Popularity: 1498**

**Steps:**

Cast Windfall by paying {2}{U}, causing each player to discard their hand and then draw a number of cards equal to the greatest number of cards a player discarded this way.
Nekusar triggers for each card drawn this way, giving each opponent a poison counter for each card they drew.
Each opponent loses the game due to having ten or more poison counters

---

# 790-1972-4651

**Cards:**

- Windfall
- Phyresis
- Nekusar, the Mindrazer

**Produces:** Each opponent loses the game

**Mana: {2}{U}, MV: 3, Colors: UBR, Popularity: 4499**

**Steps:**

Cast Windfall by paying {2}{U}, causing each player to discard their hand and then draw a number of cards equal to the greatest number of cards a player discarded this way.
Nekusar triggers for each card drawn this way, giving each opponent a poison counter for each card they drew.
Each opponent loses the game due to having ten or more poison counters

---

# 79-1912-4013

**Cards:**

- Biomancer's Familiar
- Eldrazi Displacer
- Birthing Hulk

**Produces:** Infinite colorless mana, Infinite creature tokens, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite blinking of most creatures

**Mana: {C}, MV: 1, Colors: GWU, Popularity: 7**

**Steps:**

Activate Eldrazi Displacer by paying {C}, blinking Birthing Hulk.
Birthing Hulk enters the battlefield, creating two 1/1 colorless Eldrazi Scion tokens.
Activate Eldrazi Scion by sacrificing it, adding {C}.
Repeat.

---

# 79-2713-4013

**Cards:**

- Zirda, the Dawnwaker
- Eldrazi Displacer
- Birthing Hulk

**Produces:** Infinite blinking, Infinite colorless mana, Infinite creature tokens, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite blinking of most creatures

**Mana: {C}, MV: 1, Colors: RGW, Popularity: 8**

**Steps:**

Activate Eldrazi Displacer by paying {C}, blinking Birthing Hulk.
Birthing Hulk enters the battlefield, creating two 1/1 Eldrazi Scion creature tokens.
Activate an Eldrazi Scion by sacrificing it, adding {C}.
Repeat.

---

# 79-4013-4893

**Cards:**

- Training Grounds
- Eldrazi Displacer
- Birthing Hulk

**Produces:** Infinite blinking, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite blinking of most creatures

**Mana: {C}, MV: 1, Colors: GWU, Popularity: 15**

**Steps:**

Activate Eldrazi Displacer's ability by paying {C}, blinking Birthing Hulk.
Birthing Hulk enters the battlefield tapped, triggering itself, creating two 1/1 Eldrazi Scion tokens.
Activate an Eldrazi Scion by sacrificing it, adding {C}.
Repeat.
Once you have infinite Eldrazi Scion tokens, you may activate any number of them.

---

# 797-1061-1953

**Cards:**

- Brudiclad, Telchor Engineer
- Timestream Navigator
- Stolen Identity

**Produces:** Infinite turns, Lock

**Mana: {6}{U}{U}{U}{U} on your first turn, with {2}{U}{U} available on each extra turn, MV: 10, Colors: UR, Popularity: 93**

**Steps:**

Cast Stolen Identity by paying {4}{U}{U}, creating a token copy of Timestream Navigator.
At the beginning of your combat phase, Brudiclad triggers, creating a 2/1 Phyrexian Myr creature token, then choosing to have all tokens you control become copies of the Timestream Navigator token.
Activate Timestream Navigator by paying {2}{U}{U} and tapping it and putting it onto the bottom of your library, causing you to take an extra turn after this one.
Move to your next turn.
Repeat from step 2.

---

# 797-1953-2105

**Cards:**

- Brudiclad, Telchor Engineer
- Combat Celebrant
- Stolen Identity

**Produces:** Infinite combat phases, Infinite damage

**Mana: {4}{U}{U}, MV: 6, Colors: UR, Popularity: 260**

**Steps:**

Cast Stolen Identity by paying {4}{U}{U}, creating a token copy of Combat Celebrant.
At the beginning of your combat phase, Brudiclad triggers, creating a 2/1 Phyrexian Myr creature token, then choosing to have all tokens you control become copies of the Combat Celebrant token.
Declare one of the Combat Celebrant copy as an attacker, choosing to exert it as it attacks.
The Combat Celebrant copy triggers, untapping all other creatures you control and causing you to get an additional combat phase after this one.
Repeat from step 2.

---

# 799-1164-5131

**Cards:**

- Muldrotha, the Gravetide
- Mirror of Fate
- Karn's Temporal Sundering

**Produces:** Infinite turns, Lock

**Mana: {9}{U}{U} each turn, MV: 11, Colors: BGU, Popularity: 7**

**Steps:**

Cast Karn's Temporal Sundering by paying {4}{U}{U}, taking an extra turn after this one.
Activate Mirror of Fate by tapping and sacrificing it, choosing Karn's Temporal Sundering from exile and putting it on the top of your library.
Cast Mirror of Fate from your graveyard by paying {5}.
Move to your next turn.
Repeat.

---

# 799-1271-3212

**Cards:**

- God-Eternal Kefnet
- Scroll Rack
- Karn's Temporal Sundering

**Produces:** Infinite turns, Skip your draw steps, Lock

**Mana: {3}{U}{U} each turn, MV: 5, Colors: U, Popularity: 237**

**Steps:**

Tap Scroll Rack and pay {1} to activate it, putting Karn's Temporal Sundering on top of your library.
Pass the turn.
On your next draw step, when you draw Karn's Temporal Sundering, reveal it due to Kefnet's ability, making a copy that costs {2} less to cast.
Cast the copy for {2}{U}{U}, granting you an extra turn and returning up to one nonland permanent to its owner's hand.

---

# 799-1702-3212

**Cards:**

- God-Eternal Kefnet
- Jace, the Mind Sculptor
- Karn's Temporal Sundering

**Produces:** Infinite turns, Lock

**Mana: {2}{U}{U} each turn, MV: 4, Colors: U, Popularity: 169**

**Steps:**

Activate Jace's zero loyalty ability, putting Karn's Temporal Sundering on top of your library.
Pass the turn.
On your next draw step, when you draw Karn's Temporal Sundering, reveal it due to Kefnet's ability, making a copy that costs {2} less to cast.
Cast the copy for {2}{U}{U}, granting you an extra turn and returning up to one nonland permanent to its owner's hand.

---

# 799-1750-4861-5261

**Cards:**

- Isochron Scepter
- Pull from Eternity
- Kess, Dissident Mage
- Karn's Temporal Sundering

**Produces:** Infinite turns, Lock

**Mana: {6}{U}{U} each turn, MV: 8, Colors: WUBR, Popularity: 0**

**Steps:**

Cast Karn's Temporal Sundering by paying {4}{U}{U}, causing you to take an extra turn after this one and exile Karn's Temporal Sundering.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Pull from Eternity without paying its mana cost.
Resolve Pull from Eternity, putting Karn's Temporal Sundering into your graveyard from exile.
Move to your next turn.
Cast Karn's Temporal Sundering from your graveyard by paying {4}{U}{U}, causing you to take an extra turn after this one and exile Karn's Temporal Sundering.
Repeat from step 2.

---

# 799-1750-4903-5261

**Cards:**

- Isochron Scepter
- Pull from Eternity
- Backdraft Hellkite
- Karn's Temporal Sundering

**Produces:** Infinite turns, Lock

**Mana: {6}{U}{U}, MV: 8, Colors: URW, Popularity: 1**

**Steps:**

Cast the extra turn spell and move to your extra turn.
Activate Isochron Sceptre to cast Pull from Eternity, putting the extra turn spell from exile to your graveyard.
Attack with Backdraft Hellkite to give your extra turn flashback, then cast it.
Repeat for infinite turns.

---

# 799-958-1750-5261

**Cards:**

- Isochron Scepter
- Pull from Eternity
- Dralnu, Lich Lord
- Karn's Temporal Sundering

**Produces:** Infinite turns, Lock

**Mana: {6}{U}{U} each turn, MV: 8, Colors: WUB, Popularity: 0**

**Steps:**

Cast Karn's Temporal Sundering by paying {4}{U}{U}, causing you to take an extra turn after this one and exile Karn's Temporal Sundering.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Pull from Eternity without paying its mana cost.
Resolve Pull from Eternity, putting Karn's Temporal Sundering into your graveyard from exile.
Move to your next turn.
Activate Dralnu by tapping it, giving Karn's Temporal Sundering flashback until end of turn.
Cast Karn's Temporal Sundering from your graveyard by paying {4}{U}{U}, causing you to take an extra turn after this one and exile Karn's Temporal Sundering.
Repeat from step 2.

---

# 800-1656-3181

**Cards:**

- Necrotic Ooze
- Knacksaw Clique
- Krosan Restorer

**Produces:** Exile each opponent's library, Infinite colored mana

**Mana: , MV: 0, Colors: BGU, Popularity: 22**

**Steps:**

Activate Krosan Restorer threshold ability with Necrotic Ooze to untap up to three lands.
Activate Knacksaw Qlique with Nectrotic Ooze to untap it, and have target opponent remove the top card of their library from the game.
Until end of turn you may play that card.
Continue looping as long as needed, generating infinite mana among lands you control.
From here, you could either cast every card from your opponent' libraries, or Move to your next turn and win from them decking out.

---

# 800-1912-4474

**Cards:**

- Knacksaw Clique
- Paradise Mantle
- Biomancer's Familiar

**Produces:** Exile each opponent's library

**Mana: , MV: 0, Colors: GU, Popularity: 43**

**Steps:**

Activate Knacksaw Clique by tapping it, adding {U}.
Activate Knacksaw Clique by paying {U} and untap it, exiling the top card of target opponent's library.
Repeat.

---

# 800-4474-4893

**Cards:**

- Knacksaw Clique
- Paradise Mantle
- Training Grounds

**Produces:** Exile each opponent's library

**Mana: , MV: 0, Colors: U, Popularity: 101**

**Steps:**

Activate Knacksaw Clique by tapping it, adding {U}.
Activate Knacksaw Clique by paying {U} and untap it, exiling the top card of target opponent's library.
Repeat.

---

# 802-1003-1846-3198

**Cards:**

- High Tide
- Lore Drakkis
- Phyrexian Walker
- Snap

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: {U}{U}, MV: 2, Colors: UR, Popularity: 6**

**Steps:**

Cast High Tide by paying {U}.
Cast Lore Drakkis for its Mutate cost by paying {U}{U}, targeting Phyrexian Walker.
Lore Drakkis's mutate ability triggers, causing you to return Snap from your graveyard to your hand.
Cast Snap by paying {1}{U}, returning the mutated creature that contains the nontoken Lore Drakkis from the battlefield to your hand and untapping two Islands.
Cast Phyrexian Walker by paying {0}.
Repeat from step 2.

---

# 802-1235-1741-2649

**Cards:**

- Vadrok, Apex of Thunder
- Cloud of Faeries
- Twinflame
- Snap

**Produces:** Cast a subset of spells in your graveyard, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: {2}{W/U}{R}{R}{R}, plus commander tax if applicable, MV: 6, Colors: URW, Popularity: 145**

**Steps:**

Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under Cloud of Faeries.
The Cloud of Faeries mutated creature's ability from Vadrok triggers, casting Twinflame from your graveyard without paying its mana cost.
Resolve Twinflame, creating a token copy of the Cloud of Faeries mutated creature with haste.
The token copy of the Cloud of Faeries mutated creature triggers, untapping two lands you control.
Cast Snap by paying {1}{U}, returning the nontoken Cloud of Faeries and Vadrok from the battlefield to your hand and untapping two lands you control.
Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under the token Cloud of Faeries mutated creature.
The token Cloud of Faeries mutated creature triggers once for each of its Vadrok abilities.
Resolve one of these triggers, casting Twinflame from your graveyard without paying its mana cost.
Resolve Twinflame, creating a token copy of the Cloud of Faeries mutated creature with haste.
The token copy of the Cloud of Faeries mutated creature triggers, untapping two lands you control.
Resolve a second trigger from step 7, casting Snap from your graveyard without paying its mana cost, targeting the mutated creature that includes the nontoken Vadrok.
Resolve Snap, returning Vadrok from the battlefield to your hand as well as multiple token creatures which cease to exist, and untapping two lands you control.
Resolve any remaining triggers from step 7, casting any noncreature cards with mana value 3 or less that were not already cast since step 7 from your graveyard without paying their casting costs.
Repeat from step 6, adding one additional token Vadrok to each new iteration of the Cloud of Faeries mutated creature token.

---

# 802-1235-2649-3821

**Cards:**

- Vadrok, Apex of Thunder
- Peregrine Drake
- Twinflame
- Snap

**Produces:** Cast a subset of spells in your graveyard, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: {1}{W/U}{R}{R}{R}, plus commander tax if applicable, MV: 5, Colors: URW, Popularity: 84**

**Steps:**

Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under Peregrine Drake.
The Peregrine Drake mutated creature's ability from Vadrok triggers, casting Twinflame from your graveyard without paying its mana cost.
Resolve Twinflame, creating a token copy of the Peregrine Drake mutated creature with haste.
The token copy of the Peregrine Drake mutated creature triggers, untapping five lands you control.
Cast Snap by paying {1}{U}, returning the nontoken Peregrine Drake and Vadrok from the battlefield to your hand and untapping two lands you control.
Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under the token Peregrine Drake mutated creature.
The token Peregrine Drake mutated creature triggers once for each of its Vadrok abilities.
Resolve one of these triggers, casting Twinflame from your graveyard without paying its mana cost.
Resolve Twinflame, creating a token copy of the Peregrine Drake mutated creature with haste.
The token copy of the Peregrine Drake mutated creature triggers, untapping five lands you control.
Resolve a second trigger from step 7, casting Snap from your graveyard without paying its mana cost, targeting the mutated creature that includes the nontoken Vadrok.
Resolve Snap, returning Vadrok from the battlefield to your hand as well as multiple token creatures which cease to exist, and untapping two lands you control.
Resolve any remaining triggers from step 7, casting any noncreature cards with mana value 3 or less that were not already cast since step 7 from your graveyard without paying their casting costs.
Repeat from step 6, adding one additional token Vadrok to each new iteration of the Peregrine Drake mutated creature token.

---

# 802-1741-2649-2959

**Cards:**

- Vadrok, Apex of Thunder
- Cloud of Faeries
- Heat Shimmer
- Snap

**Produces:** Cast a subset of spells in your graveyard, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: {2}{W/U}{R}{R}{R}, plus commander tax if applicable, MV: 6, Colors: URW, Popularity: 57**

**Steps:**

Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under Cloud of Faeries.
The Cloud of Faeries mutated creature's ability from Vadrok triggers, casting Heat Shimmer from your graveyard without paying its mana cost.
Resolve Heat Shimmer, creating a token copy of the Cloud of Faeries mutated creature with haste.
The token copy of the Cloud of Faeries mutated creature triggers, untapping two lands you control.
Cast Snap by paying {1}{U}, returning the nontoken Cloud of Faeries and Vadrok from the battlefield to your hand and untapping two lands you control.
Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under the token Cloud of Faeries mutated creature.
The token Cloud of Faeries mutated creature triggers once for each of its Vadrok abilities.
Resolve one of these triggers, casting Heat Shimmer from your graveyard without paying its mana cost.
Resolve Heat Shimmer, creating a token copy of the Cloud of Faeries mutated creature with haste.
The token copy of the Cloud of Faeries mutated creature triggers, untapping two lands you control.
Resolve a second trigger from step 7, casting Snap from your graveyard without paying its mana cost, targeting the mutated creature that includes the nontoken Vadrok.
Resolve Snap, returning Vadrok from the battlefield to your hand as well as multiple token creatures which cease to exist, and untapping two lands you control.
Resolve any remaining triggers from step 7, casting any noncreature cards with mana value 3 or less that were not already cast since step 7 from your graveyard without paying their casting costs.
Repeat from step 6, adding one additional token Vadrok to each new iteration of the Cloud of Faeries mutated creature token.

---

# 802-1741-2649-4615

**Cards:**

- Vadrok, Apex of Thunder
- Cloud of Faeries
- Quasiduplicate
- Snap

**Produces:** Cast a subset of spells in your graveyard, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: {2}{W/U}{R}{R}{R}, plus commander tax if applicable, MV: 6, Colors: URW, Popularity: 171**

**Steps:**

Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under Cloud of Faeries.
The Cloud of Faeries mutated creature's ability from Vadrok triggers, casting Quasiduplicate from your graveyard without paying its mana cost.
Resolve Quasiduplicate, creating a token copy of the Cloud of Faeries mutated creature with haste.
The token copy of the Cloud of Faeries mutated creature triggers, untapping two lands you control.
Cast Snap by paying {1}{U}, returning the nontoken Cloud of Faeries and Vadrok from the battlefield to your hand and untapping two lands you control.
Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under the token Cloud of Faeries mutated creature.
The token Cloud of Faeries mutated creature triggers once for each of its Vadrok abilities.
Resolve one of these triggers, casting Quasiduplicate from your graveyard without paying its mana cost.
Resolve Quasiduplicate, creating a token copy of the Cloud of Faeries mutated creature with haste.
The token copy of the Cloud of Faeries mutated creature triggers, untapping two lands you control.
Resolve a second trigger from step 7, casting Snap from your graveyard without paying its mana cost, targeting the mutated creature that includes the nontoken Vadrok.
Resolve Snap, returning Vadrok from the battlefield to your hand as well as multiple token creatures which cease to exist, and untapping two lands you control.
Resolve any remaining triggers from step 7, casting any noncreature cards with mana value 3 or less that were not already cast since step 7 from your graveyard without paying their casting costs.
Repeat from step 6, adding one additional token Vadrok to each new iteration of the Cloud of Faeries mutated creature token.

---

# 802-1846-2493

**Cards:**

- High Tide
- Archaeomancer
- Snap

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count

**Mana: {U}, MV: 1, Colors: U, Popularity: 12611**

**Steps:**

Cast High Tide by paying {U}, causing Islands to add an additional {U} this turn.
Activate two Islands by tapping them, adding {U}{U}{U}{U}.
Cast Archaeomancer by paying {2}{U}{U}.
Archaeomancer enters the battlefield, returning High Tide from your graveyard to your hand.
Activate an Island by tapping it, adding {U}{U}.
Cast High Tide by paying {U}, causing Islands to add an additional {U} this turn.
Activate an Island by tapping it, adding {U}{U}{U}.
Cast Snap by paying {1}{U}, returning Archaeomancer from the battlefield to your hand and untapping two Islands.
Activate two Islands by tapping them, adding six {U}.
Cast Archaeomancer by paying {2}{U}{U}.
Archaeomancer enters the battlefield, returning Snap from your graveyard to your hand.
Repeat from step 8.

---

# 802-1846-3198-3652

**Cards:**

- High Tide
- Lore Drakkis
- Ornithopter
- Snap

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: {U}{U}, MV: 2, Colors: UR, Popularity: 27**

**Steps:**

Cast High Tide by paying {U}.
Cast Lore Drakkis for its Mutate cost by paying {U}{U}, targeting Ornithopter.
Lore Drakkis's mutate ability triggers, causing you to return Snap from your graveyard to your hand.
Cast Snap by paying {1}{U}, returning the mutated creature that contains the nontoken Lore Drakkis from the battlefield to your hand and untapping two Islands.
Cast Ornithopter by paying {0}.
Repeat from step 2.

---

# 802-2649-2959-3821

**Cards:**

- Vadrok, Apex of Thunder
- Peregrine Drake
- Heat Shimmer
- Snap

**Produces:** Cast a subset of spells in your graveyard, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: {1}{W/U}{R}{R}{R}, plus commander tax if applicable, MV: 5, Colors: URW, Popularity: 41**

**Steps:**

Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under Peregrine Drake.
The Peregrine Drake mutated creature's ability from Vadrok triggers, casting Heat Shimmer from your graveyard without paying its mana cost.
Resolve Heat Shimmer, creating a token copy of the Peregrine Drake mutated creature with haste.
The token copy of the Peregrine Drake mutated creature triggers, untapping five lands you control.
Cast Snap by paying {1}{U}, returning the nontoken Peregrine Drake and Vadrok from the battlefield to your hand and untapping two lands you control.
Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under the token Peregrine Drake mutated creature.
The token Peregrine Drake mutated creature triggers once for each of its Vadrok abilities.
Resolve one of these triggers, casting Heat Shimmer from your graveyard without paying its mana cost.
Resolve Heat Shimmer, creating a token copy of the Peregrine Drake mutated creature with haste.
The token copy of the Peregrine Drake mutated creature triggers, untapping five lands you control.
Resolve a second trigger from step 7, casting Snap from your graveyard without paying its mana cost, targeting the mutated creature that includes the nontoken Vadrok.
Resolve Snap, returning Vadrok from the battlefield to your hand as well as multiple token creatures which cease to exist, and untapping two lands you control.
Resolve any remaining triggers from step 7, casting any noncreature cards with mana value 3 or less that were not already cast since step 7 from your graveyard without paying their casting costs.
Repeat from step 6, adding one additional token Vadrok to each new iteration of the Peregrine Drake mutated creature token.

---

# 802-2649-3147-3664

**Cards:**

- Vadrok, Apex of Thunder
- Lotus Field
- Snap
- Azorius Chancery

**Produces:** Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Infinite colored mana, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: {1}{U} plus enough mana to pay for commander tax, if applicable, MV: 2, Colors: URW, Popularity: 67**

**Steps:**

Cast Snap by paying {1}{U}, returning the additional creature to your hand and untapping Lotus Field and Azorius Chancery.
Activate Lotus Field and the land by tapping them, adding at least {1}{W/U}{R}{R}{R}.
Cast the additional creature by paying {0}.
Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R} plus commander tax if applicable, mutating it under the additional creature.
The mutated creature's ability from Vadrok triggers, casting Snap from your graveyard without paying its mana cost.
Resolve Snap, returning both cards that compose the mutated creature from the battlefield to your hand and untapping Lotus Field and Azorius Chancery.
Repeat from step 2.

---

# 802-2649-3821-4615

**Cards:**

- Vadrok, Apex of Thunder
- Peregrine Drake
- Quasiduplicate
- Snap

**Produces:** Cast a subset of spells in your graveyard, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: {1}{W/U}{R}{R}{R}, plus commander tax if applicable, MV: 5, Colors: URW, Popularity: 122**

**Steps:**

Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under Peregrine Drake.
The Peregrine Drake mutated creature's ability from Vadrok triggers, casting Quasiduplicate from your graveyard without paying its mana cost.
Resolve Quasiduplicate, creating a token copy of the Peregrine Drake mutated creature with haste.
The token copy of the Peregrine Drake mutated creature triggers, untapping five lands you control.
Cast Snap by paying {1}{U}, returning the nontoken Peregrine Drake and Vadrok from the battlefield to your hand and untapping two lands you control.
Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under the token Peregrine Drake mutated creature.
The token Peregrine Drake mutated creature triggers once for each of its Vadrok abilities.
Resolve one of these triggers, casting Quasiduplicate from your graveyard without paying its mana cost.
Resolve Quasiduplicate, creating a token copy of the Peregrine Drake mutated creature with haste.
The token copy of the Peregrine Drake mutated creature triggers, untapping five lands you control.
Resolve a second trigger from step 7, casting Snap from your graveyard without paying its mana cost, targeting the mutated creature that includes the nontoken Vadrok.
Resolve Snap, returning Vadrok from the battlefield to your hand as well as multiple token creatures which cease to exist, and untapping two lands you control.
Resolve any remaining triggers from step 7, casting any noncreature cards with mana value 3 or less that were not already cast since step 7 from your graveyard without paying their casting costs.
Repeat from step 6, adding one additional token Vadrok to each new iteration of the Peregrine Drake mutated creature token.

---

# 802-864-914-5257

**Cards:**

- Riku of Two Reflections
- Dockside Extortionist
- Eternal Witness
- Snap

**Produces:** Infinite colored mana, Infinite creature tokens, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {1}{R}, MV: 2, Colors: GUR, Popularity: 12**

**Steps:**

Cast Dockside Extortionist for {1}{R}.
When Dockside Extortionist enters the battlefield, its own ETB triggers and Riku of Two Reflections triggers.
Stack the triggers such that Dockside Extortionist's trigger resolves first, creating 5 Treasure tokens.
Pay for the Riku of Two Reflections trigger using 2 Treasures, creating a token copy of Dockside Extortionist that creates another 5 Treasure tokens.
Cast Snap using two of your 8 Treasures, returning Dockside Extortionist to your hand and untapping two lands, leaving you with 6 Treasure tokens and two untapped lands.
Cast Eternal Witness with an untapped land and two Treasure tokens, leaving an untapped land and four Treasure tokens.
When it enters the battlefield, Eternal Witness and Riku of Two Reflections trigger.
Stack the triggers such that Eternal Witness resolves first, returning Snap to your hand.
Before the Riku trigger resolves, cast Snap using an untapped land and a Treasure, returning Dockside Extortionist to your hand and leaving you with 2 untapped lands and 3 Treasure tokens.
Pay for the Riku of Two Reflectons trigger with 2 Treasure tokens, creating a token copy of Eternal Witness that returns Snap to your hand on ETB.
You are now back where you started, but with an extra Treasure token, an Eternal Witness token, and a Dockside Extortionist token, and with 2 untapped lands instead of {1}{R}.
Repeat for infinite Treasure tokens and creature tokens.

---

# 802-914-1235-2649

**Cards:**

- Vadrok, Apex of Thunder
- Dockside Extortionist
- Twinflame
- Snap

**Produces:** Cast a subset of spells in your graveyard, Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Infinite Treasure tokens, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: {1}{W/U}{R}{R}, plus commander tax if applicable, plus one additional red, white, or blue mana if opponents control exactly three artifacts and/or enchantments, MV: 4, Colors: URW, Popularity: 23**

**Steps:**

Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under Dockside Extortionist.
The Dockside Extortionist mutated creature's ability from Vadrok triggers, casting Twinflame from your graveyard without paying its mana cost.
Resolve Twinflame, creating a token copy of the Dockside Extortionist mutated creature with haste.
The token copy of the Dockside Extortionist mutated creature triggers, creating at least three Treasure tokens.
Activate three Treasure tokens by tapping and sacrificing them, adding {U}{R}{R}.
Cast Snap by paying {1}{U}, returning the nontoken Dockside Extortionist and Vadrok from the battlefield to your hand and untapping two lands you control.
Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under the token Dockside Extortionist mutated creature.
The token Dockside Extortionist mutated creature triggers once for each of its Vadrok abilities.
Resolve one of these triggers, casting Twinflame from your graveyard without paying its mana cost.
Resolve Twinflame, creating a token copy of the Dockside Extortionist mutated creature with haste.
The token copy of the Dockside Extortionist mutated creature triggers, creating at least three Treasure tokens.
Activate three Treasure tokens by tapping and sacrificing them, adding {U}{R}{R}.
Resolve a second trigger from step 8, casting Snap from your graveyard without paying its mana cost, targeting the mutated creature that includes the nontoken Vadrok.
Resolve Snap, returning Vadrok from the battlefield to your hand as well as multiple token creatures which cease to exist, and untapping two lands you control.
Resolve any remaining triggers from step 8, casting any noncreature cards with mana value 3 or less that were not already cast since step 8 from your graveyard without paying their casting costs.
Repeat from step 7, adding one additional token Vadrok to each new iteration of the Dockside Extortionist mutated creature token.

---

# 802-914-2649-2959

**Cards:**

- Vadrok, Apex of Thunder
- Dockside Extortionist
- Heat Shimmer
- Snap

**Produces:** Cast a subset of spells in your graveyard, Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Infinite Treasure tokens, Infinite untap of lands you control, Infinite mana lands you control can produce

**Mana: {1}{W/U}{R}{R}, plus commander tax if applicable, plus one additional red, white, or blue mana if opponents control exactly three artifacts and/or enchantments, MV: 4, Colors: URW, Popularity: 10**

**Steps:**

Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under Dockside Extortionist.
The Dockside Extortionist mutated creature's ability from Vadrok triggers, casting Heat Shimmer from your graveyard without paying its mana cost.
Resolve Heat Shimmer, creating a token copy of the Dockside Extortionist mutated creature with haste.
The token copy of the Dockside Extortionist mutated creature triggers, creating at least three Treasure tokens.
Activate three Treasure tokens by tapping and sacrificing them, adding {U}{R}{R}.
Cast Snap by paying {1}{U}, returning the nontoken Dockside Extortionist and Vadrok from the battlefield to your hand and untapping two lands you control.
Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under the token Dockside Extortionist mutated creature.
The token Dockside Extortionist mutated creature triggers once for each of its Vadrok abilities.
Resolve one of these triggers, casting Heat Shimmer from your graveyard without paying its mana cost.
Resolve Heat Shimmer, creating a token copy of the Dockside Extortionist mutated creature with haste.
The token copy of the Dockside Extortionist mutated creature triggers, creating at least three Treasure tokens.
Activate three Treasure tokens by tapping and sacrificing them, adding {U}{R}{R}.
Resolve a second trigger from step 8, casting Snap from your graveyard without paying its mana cost, targeting the mutated creature that includes the nontoken Vadrok.
Resolve Snap, returning Vadrok from the battlefield to your hand as well as multiple token creatures which cease to exist, and untapping two lands you control.
Resolve any remaining triggers from step 8, casting any noncreature cards with mana value 3 or less that were not already cast since step 8 from your graveyard without paying their casting costs.
Repeat from step 7, adding one additional token Vadrok to each new iteration of the Dockside Extortionist mutated creature token.

---

# 802-914-2649-4615

**Cards:**

- Vadrok, Apex of Thunder
- Dockside Extortionist
- Quasiduplicate
- Snap

**Produces:** Cast a subset of spells in your graveyard, Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Infinite Treasure tokens, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: {1}{W/U}{R}{R}, plus commander tax if applicable, plus one additional red, white, or blue mana if opponents control exactly three artifacts and/or enchantments, MV: 4, Colors: URW, Popularity: 12**

**Steps:**

Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under Dockside Extortionist.
The Dockside Extortionist mutated creature's ability from Vadrok triggers, casting Quasiduplicate from your graveyard without paying its mana cost.
Resolve Quasiduplicate, creating a token copy of the Dockside Extortionist mutated creature with haste.
The token copy of the Dockside Extortionist mutated creature triggers, creating at least three Treasure tokens.
Activate three Treasure tokens by tapping and sacrificing them, adding {U}{R}{R}.
Cast Snap by paying {1}{U}, returning the nontoken Dockside Extortionist and Vadrok from the battlefield to your hand and untapping two lands you control.
Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under the token Dockside Extortionist mutated creature.
The token Dockside Extortionist mutated creature triggers once for each of its Vadrok abilities.
Resolve one of these triggers, casting Quasiduplicate from your graveyard without paying its mana cost.
Resolve Quasiduplicate, creating a token copy of the Dockside Extortionist mutated creature with haste.
The token copy of the Dockside Extortionist mutated creature triggers, creating at least three Treasure tokens.
Activate three Treasure tokens by tapping and sacrificing them, adding {U}{R}{R}.
Resolve a second trigger from step 8, casting Snap from your graveyard without paying its mana cost, targeting the mutated creature that includes the nontoken Vadrok.
Resolve Snap, returning Vadrok from the battlefield to your hand as well as multiple token creatures which cease to exist, and untapping two lands you control.
Resolve any remaining triggers from step 8, casting any noncreature cards with mana value 3 or less that were not already cast since step 8 from your graveyard without paying their casting costs.
Repeat from step 7, adding one additional token Vadrok to each new iteration of the Dockside Extortionist mutated creature token.

---

# 803-1134-1267-3395

**Cards:**

- Medomai the Ageless
- Preeminent Captain
- Arcane Adaptation
- Crystal Shard

**Produces:** Infinite turns, Lock

**Mana: {U} each turn, MV: 1, Colors: WU, Popularity: 3**

**Steps:**

Declare Preeminent Captain as an attacker.
Preeminent Captain triggers, putting Medomai from your hand onto the battlefield tapped and attacking.
Deal combat damage with Medomai, causing you to take an extra turn after this one.
Activate Crystal Shard by paying {U} and tapping it, returning Medomai to your hand.
Pass the turn.
Repeat.

---

# 803-1134-1267-3632

**Cards:**

- Medomai the Ageless
- Preeminent Captain
- Arcane Adaptation
- Erratic Portal

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: WU, Popularity: 1**

**Steps:**

Declare Preeminent Captain as an attacker.
Preeminent Captain triggers, putting Medomai from your hand onto the battlefield tapped and attacking.
Deal combat damage with Medomai, causing you to take an extra turn after this one.
Activate Erratic Portal by paying {1} and tapping it, returning Medomai to your hand.
Pass the turn.
Repeat.

---

# 803-1322-3638

**Cards:**

- Arcane Adaptation
- Turntimber Ranger
- Concordant Crossroads

**Produces:** Infinite creature tokens with haste, Infinite ETB, Infinitely large creature

**Mana: {3}{G}{G}, MV: 5, Colors: GU, Popularity: 22**

**Steps:**

Cast Turntimber Ranger by paying {3}{G}{G}.
Turntimber Ranger enters the battlefield, creating a 2/2 Wolf creature token and putting a +1/+1 counter on Turntimber Ranger.
2/2 Wolf creature token enters the battlefield triggering Turntimber Ranger, creating a 2/2 Wolf creature token and putting a +1/+1 counter on Turntimber Ranger.
Repeat from step 2.

---

# 803-1424-4620

**Cards:**

- Arcane Adaptation
- Captain of the Mists
- Presence of Gond

**Produces:** Infinite ETB, Infinite creature tokens

**Mana: , MV: 0, Colors: GU, Popularity: 2**

**Steps:**

Tap Captain of the Mists to activate Presence of Gond, creating a human elf token.
On ETB, the token triggers Captain of the Mists, untapping it.

---

# 803-2034-3413

**Cards:**

- Xathrid Necromancer
- Arcane Adaptation
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: UB, Popularity: 23**

**Steps:**

Activate Ashnod's Altar by sacrificing any other creature, adding {C}{C}.
Xathrid Necromancer triggers, creating a 2/2 Zombie creature token.
Repeat.

---

# 803-3413-4050

**Cards:**

- Xathrid Necromancer
- Arcane Adaptation
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: UB, Popularity: 18**

**Steps:**

Activate Phyrexian Altar by sacrificing any other creature, adding one mana of any color.
Xathrid Necromancer triggers, creating a 2/2 Zombie creature token.
Repeat.

---

# 803-3413-5256

**Cards:**

- Xathrid Necromancer
- Arcane Adaptation
- Altar of Dementia

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: UB, Popularity: 16**

**Steps:**

Activate Altar of Dementia by sacrificing any other creature.
Xathrid Necromancer triggers, creating a 2/2 Zombie creature token.
Resolve the Altar of Dementia ability, causing target player to mill cards equal to the sacrificed creature's power.
Repeat.

---

# 803-3581-4302

**Cards:**

- Kykar, Wind's Fury
- Bishop of Wings
- Arcane Adaptation

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite red mana, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: URW, Popularity: 41**

**Steps:**

Sacrifice a Spirit to Kykar's ability, gaining {R}.
Bishop of Wings triggers, creating a 1/1 Spirit token.
When the token ETB, Bishop of Wings triggers again, gaining you 4 life.
Repeat.

---

# 803-3638

**Cards:**

- Arcane Adaptation
- Turntimber Ranger

**Produces:** Infinite creature tokens, Infinite ETB, Infinitely large creature

**Mana: {3}{G}{G}, MV: 5, Colors: GU, Popularity: 728**

**Steps:**

Cast Turntimber Ranger by paying {3}{G}{G}.
Turntimber Ranger enters the battlefield, creating a 2/2 Wolf creature token and putting a +1/+1 counter on Turntimber Ranger.
2/2 Wolf creature token enters the battlefield triggering Turntimber Ranger, creating a 2/2 Wolf creature token and putting a +1/+1 counter on Turntimber Ranger.
Repeat from step 2.

---

# 804-2034-2533-3175

**Cards:**

- Sun Titan
- Sakashima the Impostor
- Loyal Retainers
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: {4}{W}{W}, MV: 6, Colors: WU, Popularity: 2**

**Steps:**

Cast Sun Titan.
When Sun Titan enters the battlefield you may, return Loyal Retainers to the battlefield.
Activate Loyal Retainers, targeting Sakashima the Impostor.
Have Sakashima the Impostor enter as a copy of Sun Titan.
With Sakashima's enter the battlefield ability, return Loyal Retainers to the battlefield.
Sacrifice Sakashima to Ashnod's Altar.
Activate Loyal Retainers, targeting Sakashima the Impostor.
Repeat.

---

# 804-2533-3175-4050

**Cards:**

- Sun Titan
- Sakashima the Impostor
- Loyal Retainers
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: {4}{W}{W}, MV: 6, Colors: WU, Popularity: 2**

**Steps:**

Cast Sun Titan.
When Sun Titan enters the battlefield you may, return Loyal Retainers to the battlefield.
Activate Loyal Retainers, targeting Sakashima the Impostor.
Have Sakashima the Impostor enter as a copy of Sun Titan.
With Sakashima's enter the battlefield ability, return Loyal Retainers to the battlefield.
Sacrifice Sakashima to Phyrexian Altar.
Activate Loyal Retainers, targeting Sakashima the Impostor.
Repeat.

---

# 804-2533-3175-5256

**Cards:**

- Sun Titan
- Sakashima the Impostor
- Loyal Retainers
- Altar of Dementia

**Produces:** Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers

**Mana: {4}{W}{W}, MV: 6, Colors: WU, Popularity: 6**

**Steps:**

Cast Sun Titan.
When Sun Titan enters the battlefield you may, return Loyal Retainers to the battlefield.
Activate Loyal Retainers, targeting Sakashima the Impostor.
Have Sakashima the Impostor enter as a copy of Sun Titan.
With Sakashima's enter the battlefield ability, return Loyal Retainers to the battlefield.
Sacrifice Sakashima to Altar of Dementia.
Activate Loyal Retainers, targeting Sakashima the Impostor.
Repeat.

---

# 809-893-4853

**Cards:**

- Dross Scorpion
- Myr Turbine
- Fanatical Devotion

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: W, Popularity: 4**

**Steps:**

Activate Myr Turbine by tapping it, creating a 1/1 Myr artifact creature token.
Activate Fanatical Devotion by sacrificing a Myr token.
Dross Scorpion triggers, untapping Myr Turbine.
Resolve the Fanatical Devotion's ability, regenerate target creature.
Repeat.

---

# 813-1193-4095

**Cards:**

- Mythos of Illuna
- Radiate
- Scholar of the Ages

**Produces:** Infinite copies of all permanents, Infinite magecraft triggers, Infinite mana permanents on the battlefield can produce, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: {5}{U}{U}{R}{R}, MV: 9, Colors: GUR, Popularity: 2**

**Steps:**

Cast Mythos of Illuna by paying {2}{U}{U}, targeting anything but Scholar of the Ages.
In response, cast Radiate by paying {3}{R}{R}, creating copies of Mythos of Illuna that target each permanent besides the original target.
Resolve all copies of Mythos of Illuna besides the original, creating token copies of each permanent besides the original target.
The token copy of Scholar of the Ages enters the battlefield, triggering itself, returning Radiate from your graveyard to your hand.
Activate the token lands or other mana-producing permanents created in step 3 by tapping them, adding at least {3}{R}{R}.
Repeat from step 2, doubling the number of copies created in step 3 each repetition.

---

# 813-1283-1518-1987

**Cards:**

- Ghostly Flicker
- Will Kenrith
- Scholar of the Ages
- Chromatic Orrery

**Produces:** Infinite card draw, Infinite colored mana, Infinite colorless mana, Infinite draw triggers, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 6**

**Steps:**

Activate Will Kenrith's -2 ability targeting yourself, reducing the cost of your instant, sorcery, and planeswalker spells by {2} until end of turn and drawing you 2 cards.
Activate Chromatic Orrery's first activated ability by tapping it, adding {C}{C}{C}{C}{C}.
Cast Ghostly Flicker by paying {C}, targeting Chromatic Orrery and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
Repeat.
Once you have infinite mana, you may activate Chromatic Orrery's last ability any number of times.

---

# 813-1283-1987

**Cards:**

- Ghostly Flicker
- Scholar of the Ages
- Chromatic Orrery

**Produces:** Infinite card draw, Infinite colored mana, Infinite colorless mana, Infinite draw triggers, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 59**

**Steps:**

Activate Chromatic Orrery's first activated ability by tapping it, adding {C}{C}{C}{C}{C}.
Cast Ghostly Flicker for {3} targeting Chromatic Orrery and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
Repeat.
Once you have infinite mana, you may activate Chromatic Orrery's last ability any number of times.

---

# 813-1283-1987-2427

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Scholar of the Ages
- Chromatic Orrery

**Produces:** Infinite card draw, Infinite colored mana, Infinite colorless mana, Infinite draw triggers, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 4**

**Steps:**

Activate Chromatic Orrery's first activated ability by tapping it, adding {C}{C}{C}{C}{C}.
Cast Ghostly Flicker by paying {C}, targeting Chromatic Orrery and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
Repeat.
Once you have infinite mana, you may activate Chromatic Orrery's last ability any number of times.

---

# 813-1283-1987-3075

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Scholar of the Ages
- Chromatic Orrery

**Produces:** Infinite card draw, Infinite colored mana, Infinite colorless mana, Infinite draw triggers, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: UR, Popularity: 4**

**Steps:**

Activate Chromatic Orrery's first activated ability by tapping it, adding {C}{C}{C}{C}{C}.
Cast Ghostly Flicker by paying {C}, targeting Chromatic Orrery and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
Repeat.
Once you have infinite mana, you may activate Chromatic Orrery's last ability any number of times.

---

# 813-1518-1964-1987

**Cards:**

- Ghostly Flicker
- Will Kenrith
- Scholar of the Ages
- Meteorite

**Produces:** Infinite damage, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 5**

**Steps:**

Activate Will Kenrith's -2 ability targeting yourself, reducing the cost of your instant, sorcery, and planeswalker spells by {2} until end of turn and drawing you 2 cards.
Activate Meteorite by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Meteorite and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Meteorite enters the battlefield, deal 2 damage to any target.
Repeat.

---

# 813-1518-1987

**Cards:**

- Will Kenrith
- Ghostly Flicker
- Scholar of the Ages

**Produces:** Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 32**

**Steps:**

Activate Will's second ability by removing two loyalty counters from it, causing target player to draw two cards and causing all instant, sorcery and planeswalker spells you cast to cost {2} less this turn.
Activate the aritfact and/or land by tapping it, adding at least {U}.
Cast Ghostly Flicker by paying {U}, blinking Scholar of the Ages and the artifact and/or land.
Scholar of the Ages enters the battlefield, returning Ghostly Flicker from the graveyard to your hand.
Repeat.

---

# 813-1518-1987-3448

**Cards:**

- Ghostly Flicker
- Will Kenrith
- Scholar of the Ages
- Stadium Vendors

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: {U}, MV: 1, Colors: UR, Popularity: 4**

**Steps:**

Cast Ghostly Flicker by paying {U}, targeting Stadium Vendors and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Stadium Vendors enters the battlefield, add {U}{U}.
Repeat.

---

# 813-1518-1987-3573

**Cards:**

- Ghostly Flicker
- Will Kenrith
- Scholar of the Ages
- Tolarian Academy

**Produces:** Infinite blue mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 0**

**Steps:**

Activate Will Kenrith's -2 ability targeting yourself, reducing the cost of your instant, sorcery, and planeswalker spells by {2} until end of turn and drawing you 2 cards.
Activate Tolarian Academy by tapping it, adding at least {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Tolarian Academy and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
Repeat.

---

# 813-1518-1987-3941

**Cards:**

- Ghostly Flicker
- Will Kenrith
- Scholar of the Ages
- Coveted Jewel

**Produces:** Infinite card draw, Infinite draw triggers, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Near-infinite colored mana, Near-infinite ETB, Near-infinite LTB, Near-infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 14**

**Steps:**

Activate Will Kenrith's -2 ability targeting yourself, reducing the cost of your instant, sorcery, and planeswalker spells by {2} until end of turn and drawing you 2 cards.
Activate Coveted Jewel by tapping it, adding {U}{U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Coveted Jewel and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Coveted Jewel enters the battlefield, draw three cards.
Repeat.

---

# 813-1518-1987-4714

**Cards:**

- Ghostly Flicker
- Will Kenrith
- Scholar of the Ages
- Mana Geode

**Produces:** Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite scry 1, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 6**

**Steps:**

Activate Will Kenrith's -2 ability targeting yourself, reducing the cost of your instant, sorcery, and planeswalker spells by {2} until end of turn and drawing you 2 cards.
Activate Mana Geode by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Mana Geode and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Mana Geode enters the battlefield, scry 1.
Repeat.

---

# 813-1518-1987-4792

**Cards:**

- Ghostly Flicker
- Will Kenrith
- Scholar of the Ages
- Paradise Plume

**Produces:** Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 7**

**Steps:**

Activate Will Kenrith's -2 ability targeting yourself, reducing the cost of your instant, sorcery, and planeswalker spells by {2} until end of turn and drawing you 2 cards.
Activate Paradise Plume by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Paradise Plume and Scholar of the Ages, blinking them as well as triggering Paradise Plume to gain you 1 life.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Paradise Plume enters the battlefield, choose "blue".
Repeat.

---

# 813-1518-1987-5116

**Cards:**

- Ghostly Flicker
- Will Kenrith
- Scholar of the Ages
- Gilded Lotus

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 19**

**Steps:**

Activate Will Kenrith's -2 ability targeting yourself, reducing the cost of your instant, sorcery, and planeswalker spells by {2} until end of turn and drawing you 2 cards.
Activate Gilded Lotus by tapping it, adding {U}{U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Gilded Lotus and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
Repeat.

---

# 813-1846-1987

**Cards:**

- High Tide
- Scholar of the Ages
- Ghostly Flicker

**Produces:** Infinite blinking of artifacts, creatures, and lands, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite mana lands you control can produce, Infinite storm count, Infinite landfall triggers, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 999**

**Steps:**

Activate an Island by tapping it, adding {U}.
Cast High Tide by paying {U}, creating a delayed triggered ability that adds {U} whenever an Island is tapped for mana this turn.
Activate four Islands by tapping them, adding {U}{U}{U}{U}.
High Tide's delayed trigger triggers four times, adding an additional {U}{U}{U}{U}.
Cast Scholar of the Ages by paying {5}{U}{U}.
Scholar of the Ages enters the battlefield, triggering itself, returning High Tide from your graveyard to your hand.
Cast High Tide by paying {U}, creating a second delayed triggered ability.
Activate two Islands by tapping them, adding {U}{U}.
High Tide delayed triggers trigger a combined total of four times, adding an additional {U}{U}{U}{U}{U}{U}.
Cast Ghostly Flicker by paying {2}{U}, blinking an Island and Scholar of the Ages.
Scholar of the Ages enters the battlefield, triggering itself, returning High Tide and Ghostly Flicker from your graveyard to your hand.
Repeat from step 7, except that you activate only one Island in step 8 and trigger an increasing number of High Tide delayed triggered abilities in step 9.

---

# 813-1964-1987-2427

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Scholar of the Ages
- Meteorite

**Produces:** Infinite damage, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 5**

**Steps:**

Activate Meteorite by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Meteorite and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Meteorite enters the battlefield, deal 2 damage to any target.
Repeat.

---

# 813-1964-1987-2510

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Scholar of the Ages
- Meteorite

**Produces:** Infinite damage, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 4**

**Steps:**

Activate Meteorite by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Meteorite and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Meteorite enters the battlefield, deal 2 damage to any target.
Repeat.

---

# 813-1964-1987-3075

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Scholar of the Ages
- Meteorite

**Produces:** Infinite damage, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: UR, Popularity: 5**

**Steps:**

Activate Meteorite by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Meteorite and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Meteorite enters the battlefield, deal 2 damage to any target.
Repeat.

---

# 813-1987-2427

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Scholar of the Ages

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: {U}, MV: 1, Colors: U, Popularity: 8**

**Steps:**

Cast Ghostly Flicker by paying {U}, targeting Scholar of the Ages and your untapped source, blinking them both.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to your hand.
Tap your untapped blue source for {U}.
Repeat.

---

# 813-1987-2427-3448

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Scholar of the Ages
- Stadium Vendors

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: {U}, MV: 1, Colors: UR, Popularity: 3**

**Steps:**

Cast Ghostly Flicker by paying {U}, targeting Stadium Vendors and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Stadium Vendors enters the battlefield, add {U}{U}.
Repeat.

---

# 813-1987-2427-3573

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Scholar of the Ages
- Tolarian Academy

**Produces:** Infinite blue mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 0**

**Steps:**

Activate Tolarian Academy by tapping it, adding at least {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Tolarian Academy and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
Repeat.

---

# 813-1987-2427-3941

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Scholar of the Ages
- Coveted Jewel

**Produces:** Infinite card draw, Infinite draw triggers, Infinite ETB, Infinite LTB, Infinite storm count, Near-infinite colored mana, Near-infinite ETB, Near-infinite LTB, Near-infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 3**

**Steps:**

Activate Coveted Jewel by tapping it, adding {U}{U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Coveted Jewel and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Coveted Jewel enters the battlefield, draw three cards.
Repeat.

---

# 813-1987-2427-4714

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Scholar of the Ages
- Mana Geode

**Produces:** Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite scry 1, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 3**

**Steps:**

Activate Mana Geode by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Mana Geode and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Mana Geode enters the battlefield, scry 1.
Repeat.

---

# 813-1987-2427-4792

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Scholar of the Ages
- Paradise Plume

**Produces:** Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 2**

**Steps:**

Activate Paradise Plume by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Paradise Plume and Scholar of the Ages, blinking them as well as triggering Paradise Plume to gain you 1 life.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Paradise Plume enters the battlefield, choose "blue".
Repeat.

---

# 813-1987-2427-5116

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Scholar of the Ages
- Gilded Lotus

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 4**

**Steps:**

Activate Gilded Lotus by tapping it, adding {U}{U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Gilded Lotus and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
Repeat.

---

# 813-1987-2510

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Scholar of the Ages

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: {U}, MV: 1, Colors: U, Popularity: 23**

**Steps:**

Cast Ghostly Flicker by paying {U}, targeting Scholar of the Ages and your untapped source, blinking them both.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to your hand.
Tap your untapped blue source for {U}.
Repeat.

---

# 813-1987-2510-3448

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Scholar of the Ages
- Stadium Vendors

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: {U}, MV: 1, Colors: UR, Popularity: 2**

**Steps:**

Cast Ghostly Flicker by paying {U}, targeting Stadium Vendors and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Stadium Vendors enters the battlefield, add {U}{U}.
Repeat.

---

# 813-1987-2510-3573

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Scholar of the Ages
- Tolarian Academy

**Produces:** Infinite blue mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 0**

**Steps:**

Activate Tolarian Academy by tapping it, adding at least {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Tolarian Academy and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
Repeat.

---

# 813-1987-2510-3941

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Scholar of the Ages
- Coveted Jewel

**Produces:** Infinite card draw, Infinite draw triggers, Infinite ETB, Infinite LTB, Infinite storm count, Near-infinite colored mana, Near-infinite ETB, Near-infinite LTB, Near-infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 9**

**Steps:**

Activate Coveted Jewel by tapping it, adding {U}{U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Coveted Jewel and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Coveted Jewel enters the battlefield, draw three cards.
Repeat.

---

# 813-1987-2510-4714

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Scholar of the Ages
- Mana Geode

**Produces:** Infinite LTB, Infinite magecraft triggers, Infinite scry 1, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand, Infinite ETB

**Mana: , MV: 0, Colors: U, Popularity: 4**

**Steps:**

Activate Mana Geode by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Mana Geode and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Mana Geode enters the battlefield, scry 1.
Repeat.

---

# 813-1987-2510-4792

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Scholar of the Ages
- Paradise Plume

**Produces:** Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 5**

**Steps:**

Activate Paradise Plume by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Paradise Plume and Scholar of the Ages, blinking them as well as triggering Paradise Plume to gain you 1 life.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Paradise Plume enters the battlefield, choose "blue".
Repeat.

---

# 813-1987-2510-5116

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Scholar of the Ages
- Gilded Lotus

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 10**

**Steps:**

Activate Gilded Lotus by tapping it, adding {U}{U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Gilded Lotus and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
Repeat.

---

# 813-1987-3075

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Scholar of the Ages

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: {U}, MV: 1, Colors: UR, Popularity: 24**

**Steps:**

Cast Ghostly Flicker by paying {U}, targeting Scholar of the Ages and your untapped source, blinking them both.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to your hand.
Tap your untapped blue source for {U}.
Repeat.

---

# 813-1987-3075-3448

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Scholar of the Ages
- Stadium Vendors

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: {U}, MV: 1, Colors: UR, Popularity: 4**

**Steps:**

Cast Ghostly Flicker by paying {U}, targeting Stadium Vendors and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Stadium Vendors enters the battlefield, add {U}{U}.
Repeat.

---

# 813-1987-3075-3573

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Scholar of the Ages
- Tolarian Academy

**Produces:** Infinite blue mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: UR, Popularity: 0**

**Steps:**

Activate Tolarian Academy by tapping it, adding at least {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Tolarian Academy and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
Repeat.

---

# 813-1987-3075-3941

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Scholar of the Ages
- Coveted Jewel

**Produces:** Infinite card draw, Infinite draw triggers, Infinite ETB, Infinite LTB, Infinite storm count, Near-infinite colored mana, Near-infinite ETB, Near-infinite LTB, Near-infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: UR, Popularity: 5**

**Steps:**

Activate Coveted Jewel by tapping it, adding {U}{U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Coveted Jewel and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Coveted Jewel enters the battlefield, draw three cards.
Repeat.

---

# 813-1987-3075-4714

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Scholar of the Ages
- Mana Geode

**Produces:** Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite scry 1, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: UR, Popularity: 4**

**Steps:**

Activate Mana Geode by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Mana Geode and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Mana Geode enters the battlefield, scry 1.
Repeat.

---

# 813-1987-3075-4792

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Scholar of the Ages
- Paradise Plume

**Produces:** Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: UR, Popularity: 2**

**Steps:**

Activate Paradise Plume by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Paradise Plume and Scholar of the Ages, blinking them as well as triggering Paradise Plume to gain you 1 life.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Paradise Plume enters the battlefield, choose "blue".
Repeat.

---

# 813-1987-3075-5116

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Scholar of the Ages
- Gilded Lotus

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: UR, Popularity: 6**

**Steps:**

Activate Gilded Lotus by tapping it, adding {U}{U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Gilded Lotus and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
Repeat.

---

# 813-2103-2628

**Cards:**

- Escape Protocol
- Scholar of the Ages
- Capture of Jingzhou

**Produces:** Infinite turns, Lock

**Mana: {4}{U}{U} plus enough mana to cycle the instant/sorcery each turn, MV: 6, Colors: U, Popularity: 1**

**Steps:**

Cast Capture of Jingzhou by paying {3}{U}{U}, causing you to take an extra turn after this one.
Activate any instant/sorcery card in your hand's cycling ability by paying its cycling cost and discarding it.
Escape Protocol triggers, causing you to pay {1} to blink Scholar of the Ages.
Scholar of the Ages enters the battlefield, returning Capture of Jingzhou and the card with cycling from your graveyard to your hand.
Resolve the cycling ability from step 2, causing you to draw a card.
Repeat each turn.

---

# 813-2103-2665

**Cards:**

- Progenitor Mimic
- Capture of Jingzhou
- Scholar of the Ages

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: GU, Popularity: 0**

**Steps:**

Cast Capture of Jingzhou by paying its mana cost, taking an extra turn after this one.
At the beginning of your next upkeep, Progenitor Mimic triggers, creating a token copy of Scholar of the Ages.
When the token Scholar of the Ages enters the battlefield, it triggers itself, returning Capture of Jingzhou and up to one additional target instant or sorcery card from your graveyard to your hand.
Repeat.

---

# 813-2103-4305

**Cards:**

- Scholar of the Ages
- Followed Footsteps
- Capture of Jingzhou

**Produces:** Infinite creature tokens, Infinite turns, Lock

**Mana: {3}{U}{U} each turn, MV: 5, Colors: U, Popularity: 5**

**Steps:**

Cast Capture of Jingzhou by paying {3}{U}{U}, taking an extra turn after this one.
Move to your next turn.
At the beginning of your upkeep, Followed Footsteps triggers, creating a copy of Scholar of the Ages.
Scholar of the Ages enters the battlefield, returning Capture of Jingzhou to your hand.
Repeat.

---

# 813-2104-2628

**Cards:**

- Escape Protocol
- Scholar of the Ages
- Temporal Manipulation

**Produces:** Infinite turns, Lock

**Mana: {4}{U}{U} plus enough mana to cycle the instant/sorcery each turn, MV: 6, Colors: U, Popularity: 5**

**Steps:**

Cast Temporal Manipulation by paying {3}{U}{U}, causing you to take an extra turn after this one.
Activate any instant/sorcery card in your hand's cycling ability by paying its cycling cost and discarding it.
Escape Protocol triggers, causing you to pay {1} to blink Scholar of the Ages.
Scholar of the Ages enters the battlefield, returning Temporal Manipulation and the card with cycling from your graveyard to your hand.
Resolve the cycling ability from step 2, causing you to draw a card.
Repeat each turn.

---

# 813-2104-2665

**Cards:**

- Progenitor Mimic
- Temporal Manipulation
- Scholar of the Ages

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: GU, Popularity: 2**

**Steps:**

Cast Temporal Manipulation by paying its mana cost, taking an extra turn after this one.
At the beginning of your next upkeep, Progenitor Mimic triggers, creating a token copy of Scholar of the Ages.
When the token Scholar of the Ages enters the battlefield, it triggers itself, returning Temporal Manipulation and up to one additional target instant or sorcery card from your graveyard to your hand.
Repeat.

---

# 813-2104-4305

**Cards:**

- Scholar of the Ages
- Followed Footsteps
- Temporal Manipulation

**Produces:** Infinite creature tokens, Infinite turns, Lock

**Mana: {3}{U}{U} each turn, MV: 5, Colors: U, Popularity: 9**

**Steps:**

Cast Temporal Manipulation by paying {3}{U}{U}, taking an extra turn after this one.
Move to your next turn.
At the beginning of your upkeep, Followed Footsteps triggers, creating a copy of Scholar of the Ages.
Scholar of the Ages enters the battlefield, returning Temporal Manipulation to your hand.
Repeat.

---

# 813-2628-4276

**Cards:**

- Escape Protocol
- Scholar of the Ages
- Turnabout

**Produces:** Infinite card draw, Infinite draw triggers, Infinite self-discard triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite magecraft triggers, Near-infinite mana lands you control can produce, Near-infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 19**

**Steps:**

Activate all mana-producing lands you control by tapping them, adding at least {3}{U}{U} plus enough mana to pay for the cycling cost of an instant/sorcery card in your hand.
Cast Turnabout by paying {2}{U}{U}, untapping all lands you control.
Activate any instant/sorcery card in your hand's cycling ability by paying its cycling cost and discarding it.
Escape Protocol triggers, causing you to pay {1} to blink Scholar of the Ages.
Scholar of the Ages enters the battlefield, returning Turnabout and the card with cycling from your graveyard to your hand.
Resolve the cycling ability from step 2, causing you to draw a card.
Repeat.

---

# 813-2628-4377

**Cards:**

- Escape Protocol
- Scholar of the Ages
- Walk the Aeons

**Produces:** Infinite turns, Lock

**Mana: {5}{U}{U} plus enough mana to cycle the instant/sorcery each turn, MV: 7, Colors: U, Popularity: 1**

**Steps:**

Cast Walk the Aeons by paying {5}{U}{U}, causing you to take an extra turn after this one.
Activate any instant/sorcery card in your hand's cycling ability by paying its cycling cost and discarding it.
Escape Protocol triggers, causing you to pay {1} to blink Scholar of the Ages.
Scholar of the Ages enters the battlefield, returning Walk the Aeons and the card with cycling from your graveyard to your hand.
Resolve the cycling ability from step 2, causing you to draw a card.
Repeat each turn.

---

# 813-2628-4821

**Cards:**

- Escape Protocol
- Scholar of the Ages
- Dramatic Reversal

**Produces:** Infinite card draw, Infinite draw triggers, Infinite self-discard triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite magecraft triggers, Near-infinite mana nonland permanents you control can produce, Near-infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 2**

**Steps:**

Activate all nonland mana-producing permanents you control by tapping them, adding at least {3}{U} plus enough mana to pay for the cycling cost of an instant/sorcery card in your hand.
Cast Dramatic Reversal by paying {1}{U}, untapping all nonland permanents you control.
Activate any instant/sorcery card in your hand's cycling ability by paying its cycling cost and discarding it.
Escape Protocol triggers, causing you to pay {1} to blink Scholar of the Ages.
Scholar of the Ages enters the battlefield, returning Dramatic Reversal and the card with cycling from your graveyard to your hand.
Resolve the cycling ability from step 2, causing you to draw a card.
Repeat.

---

# 813-2628-4872

**Cards:**

- Escape Protocol
- Scholar of the Ages
- Time Warp

**Produces:** Infinite turns, Lock

**Mana: {4}{U}{U} plus enough mana to cycle the instant/sorcery each turn, MV: 6, Colors: U, Popularity: 9**

**Steps:**

Cast Time Warp by paying {3}{U}{U}, causing you to take an extra turn after this one.
Activate any instant/sorcery card in your hand's cycling ability by paying its cycling cost and discarding it.
Escape Protocol triggers, causing you to pay {1} to blink Scholar of the Ages.
Scholar of the Ages enters the battlefield, returning Time Warp and the card with cycling from your graveyard to your hand.
Resolve the cycling ability from step 2, causing you to draw a card.
Repeat each turn.

---

# 813-2665-3617

**Cards:**

- Progenitor Mimic
- Time Walk
- Scholar of the Ages

**Produces:** Infinite turns, Lock

**Mana: {1}{U} each turn, MV: 2, Colors: GU, Popularity: 0**

**Steps:**

Cast Time Walk by paying {1}{U}, taking an extra turn after this one.
At the beginning of your next upkeep, Progenitor Mimic triggers, creating a token copy of Scholar of the Ages.
When the token Scholar of the Ages enters the battlefield, it triggers, returning Time Walk from your graveyard to your hand.
Repeat.

---

# 813-2665-4377

**Cards:**

- Progenitor Mimic
- Walk the Aeons
- Scholar of the Ages

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: GU, Popularity: 2**

**Steps:**

Cast Walk the Aeons by paying its mana cost, taking an extra turn after this one.
At the beginning of your next upkeep, Progenitor Mimic triggers, creating a token copy of Scholar of the Ages.
When the token Scholar of the Ages enters the battlefield, it triggers itself, returning Walk the Aeons and up to one additional target instant or sorcery card from your graveyard to your hand.
Repeat.

---

# 813-2665-4872

**Cards:**

- Progenitor Mimic
- Time Warp
- Scholar of the Ages

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: GU, Popularity: 3**

**Steps:**

Cast Time Warp by paying its mana cost, taking an extra turn after this one.
At the beginning of your next upkeep, Progenitor Mimic triggers, creating a token copy of Scholar of the Ages.
When the token Scholar of the Ages enters the battlefield, it triggers itself, returning Time Warp and up to one additional target instant or sorcery card from your graveyard to your hand.
Repeat.

---

# 813-3617-4305

**Cards:**

- Scholar of the Ages
- Followed Footsteps
- Time Walk

**Produces:** Infinite creature tokens, Infinite turns, Lock

**Mana: {1}{U} each turn, MV: 2, Colors: U, Popularity: 0**

**Steps:**

Cast Time Walk by paying {1}{U}, taking an extra turn after this one.
Move to your next turn.
At the beginning of your upkeep, Followed Footsteps triggers, creating a copy of Scholar of the Ages.
Scholar of the Ages enters the battlefield, returning Time Walk to your hand.
Repeat.

---

# 813-4305-4377

**Cards:**

- Scholar of the Ages
- Followed Footsteps
- Walk the Aeons

**Produces:** Infinite creature tokens, Infinite turns, Lock

**Mana: {3}{U}{U} each turn, MV: 5, Colors: U, Popularity: 6**

**Steps:**

Cast Walk the Aeons by paying {3}{U}{U}, taking an extra turn after this one.
Move to your next turn.
At the beginning of your upkeep, Followed Footsteps triggers, creating a copy of Scholar of the Ages.
Scholar of the Ages enters the battlefield, returning Walk the Aeons to your hand.
Repeat.

---

# 813-4305-4872

**Cards:**

- Scholar of the Ages
- Followed Footsteps
- Time Warp

**Produces:** Infinite creature tokens, Infinite turns, Lock

**Mana: {4}{U}{U} each turn, MV: 6, Colors: U, Popularity: 12**

**Steps:**

Cast Time Warp by paying {3}{U}{U}, taking an extra turn after this one.
Move to your next turn.
At the beginning of your upkeep, Followed Footsteps triggers, creating a copy of Scholar of the Ages.
Scholar of the Ages enters the battlefield, returning Time Warp to your hand.
Repeat.

---

# 816-3111

**Cards:**

- Rune-Tail, Kitsune Ascendant // Rune-Tail's Essence
- Protector of the Crown

**Produces:** Creatures you control can't be dealt damage, You can't be dealt damage, Lock

**Mana: {2}{W}, MV: 3, Colors: W, Popularity: 1297**

**Steps:**

Cast Rune-Tail, Kitsune Ascendant.
Rune-Tail, Kitsune Ascendant flips due to having 30 or more life.
Since creatures can not take damage and Protector of the Crown prevents you from taking damage, you are unable to take damage.

---

# 821-2018-4053

**Cards:**

- Solemnity
- Luminous Broodmoth
- Mogg Fanatic

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite damage

**Mana: , MV: 0, Colors: RW, Popularity: 6**

**Steps:**

Activate Mogg Fanatic by sacrificing it.
When Mogg Fanatic dies, Luminous Broodmoth triggers, returning Mogg Fanatic from your graveyard to the battlefield without a flying counter on it due to Solemnity.
Resolve the Mogg Fanatic ability.
Repeat.

---

# 822-1310-5261

**Cards:**

- Isochron Scepter
- Roar of the Kha
- Karn's Touch

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: {U}{U}, MV: 2, Colors: WU, Popularity: 0**

**Steps:**

Cast Karn's Touch by paying {U}{U}, targeting Isochron Scepter, causing it to become an artifact creature until end of turn.
Activate creatures you control by tapping those, adding {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Roar of the Kha without paying its mana cost, untapping all creatures.
Repeat from step 2.


---

# 822-1358-5261

**Cards:**

- Isochron Scepter
- Roar of the Kha
- Sydri, Galvanic Genius

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: {U}, MV: 1, Colors: WUB, Popularity: 3**

**Steps:**

Activate Sydri's first ability by paying {U}, causing Isochron Scepter to become an artifact creature until end of turn.
Activate creatures you control by tapping those, adding {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Roar of the Kha without paying its mana cost, untapping all creatures.
Repeat from step 2.


---

# 822-2064-5261

**Cards:**

- Isochron Scepter
- Roar of the Kha
- Tezzeret's Touch

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: , MV: 0, Colors: WUB, Popularity: 1**

**Steps:**

Activate creatures you control by tapping those, adding {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Roar of the Kha without paying its mana cost, untapping all creatures.
Repeat

---

# 822-3007-5261

**Cards:**

- Isochron Scepter
- Roar of the Kha
- Toymaker

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: {1}, MV: 1, Colors: W, Popularity: 2**

**Steps:**

Activate Toymaker's first ability by paying {1}, tapping it and discarding a card, causing Isochron Scepter to become an artifact creature until end of turn.
Activate creatures you control by tapping those, adding {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Roar of the Kha without paying its mana cost, untapping all creatures.
Repeat from step 2.


---

# 822-3088-5261

**Cards:**

- Isochron Scepter
- Roar of the Kha
- Xenic Poltergeist

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: {1}, MV: 1, Colors: WB, Popularity: 1**

**Steps:**

Activate Xenic Poltergeist's first ability by paying {1} and tapping it, causing Isochron Scepter to become an artifact creature until your next upkeep.
Activate creatures you control by tapping those, adding {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Roar of the Kha without paying its mana cost, untapping all creatures.
Repeat from step 2.


---

# 822-4104-5261

**Cards:**

- Isochron Scepter
- Roar of the Kha
- Tezzeret, Agent of Bolas

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: , MV: 0, Colors: WUB, Popularity: 2**

**Steps:**

Activate Tezzeret's second loyalty ability by removing a loyalty counter on it, causing Isochron Scepter to become an artifact creature until end of turn.
Activate creatures you control by tapping those, adding at least {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Roar of the Kha without paying its mana cost, untapping all creatures.
Repeat from step 2.


---

# 822-4241-5261

**Cards:**

- Isochron Scepter
- Roar of the Kha
- Karn, Silver Golem

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: {1}, MV: 1, Colors: W, Popularity: 4**

**Steps:**

Activate Karn by paying {1}, causing Isochron Scepter to become an artifact creature until end of turn.
Activate creatures you control by tapping those, adding {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Roar of the Kha without paying its mana cost, untapping all creatures.
Repeat from step 2.


---

# 822-4694-5261

**Cards:**

- Isochron Scepter
- Roar of the Kha
- March of the Machines

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: , MV: 0, Colors: WU, Popularity: 2**

**Steps:**

Activate creatures you control by tapping those, adding {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Roar of the Kha without paying its mana cost, untapping all creatures.
Repeat

---

# 822-4832-5261

**Cards:**

- Isochron Scepter
- Roar of the Kha
- Ensoul Artifact

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: , MV: 0, Colors: WU, Popularity: 2**

**Steps:**

Activate creatures you control by tapping those, adding {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Roar of the Kha without paying its mana cost, untapping all creatures.
Repeat

---

# 822-4916-5261

**Cards:**

- Isochron Scepter
- Roar of the Kha
- Animate Artifact

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: , MV: 0, Colors: WU, Popularity: 0**

**Steps:**

Activate creatures you control by tapping those, adding {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Roar of the Kha without paying its mana cost, untapping all creatures.
Repeat.

---

# 824-2228-2464

**Cards:**

- Leech Bonder
- Song of Freyalise
- Hapatra, Vizier of Poisons

**Produces:** Infinite creature tokens, Infinite ETB

**Mana: , MV: 0, Colors: BGU, Popularity: 3**

**Steps:**

Activate Leech Bonder by tapping it, adding {U}.
Activate Leech Bonder by paying {U} and untapping it, moving a -1/-1 counter from a creature you control to any other creature you control.
Haptra triggers, creating a 1/1 Snake creature token.
Repeat.

---

# 824-2464-2760

**Cards:**

- Leech Bonder
- Song of Freyalise
- Nest of Scarabs

**Produces:** Infinite creature tokens, Infinite ETB

**Mana: , MV: 0, Colors: BGU, Popularity: 2**

**Steps:**

Activate Leech Bonder by tapping it, adding {U}.
Activate Leech Bonder by paying {U} and untapping it, moving a -1/-1 counter from a creature you control to any other creature you control.
Nest of Scarabs triggers, creating a 1/1 Insect creature token.
Repeat.

---

# 83-301-687-2034

**Cards:**

- Tayam, Luminous Enigma
- Mortician Beetle
- Ashnod's Altar
- Putrid Goblin

**Produces:** Infinite +1/+1 counters on a creature, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite self-mill, Put a selection of permanant cards from your library and graveyard onto the battlefield

**Mana: {1}, MV: 1, Colors: WBG, Popularity: 34**

**Steps:**

Activate Ashnod's Altar by sacrificing Putrid Goblin, adding {C}{C}.
Putrid Goblin's persist ability and Mortician Beetle trigger.
Resolve the Putrid Goblin trigger, returning it from your graveyard to the battlefield with a -1/-1 and a vigilance counter.
Resolve the Mortician Beetle trigger, putting a +1/+1 counter on it.
Activate Tayam by paying {3}, removing a +1/+1 counter from Mortician Beetle and removing both counters from Putrid Goblin.
Holding priority, activate Ashnod's Altar by sacrificing Putrid Goblin, adding {C}{C}.
Putrid Goblin's persist ability and Mortician Beetle trigger.
Resolve the Putrid Goblin trigger, returning it from your graveyard to the battlefield with a -1/-1 and a vigilance counter.
Resolve the Mortician Beetle trigger, putting a +1/+1 counter on it.
Activate Ashnod's Altar by sacrificing Putrid Goblin, adding {C}{C}.
Mortician Beetle triggers, putting a +1/+1 counter on itself.
Resolve the Tayam ability from step 5, causing yourself to mill three cards and return Putrid Goblin from your graveyard to the battlefield.
Repeat.

---

# 83-687-2012-2034

**Cards:**

- Tayam, Luminous Enigma
- Mortician Beetle
- Ashnod's Altar
- Strangleroot Geist

**Produces:** Infinite +1/+1 counters on a creature, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite self-mill, Put a selection of permanant cards from your library and graveyard onto the battlefield

**Mana: {1}, MV: 1, Colors: WBG, Popularity: 45**

**Steps:**

Activate Ashnod's Altar by sacrificing Strangleroot Geist, adding {C}{C}.
Strangleroot Geist's undying ability and Mortician Beetle trigger.
Resolve the Strangleroot Geist trigger, returning it from your graveyard to the battlefield with a +1/+1 and a vigilance counter.
Resolve the Mortician Beetle trigger, putting a +1/+1 counter on it.
Activate Tayam by paying {3}, removing a +1/+1 counter from Mortician Beetle and removing both counters from Strangleroot Geist.
Holding priority, activate Ashnod's Altar by sacrificing Strangleroot Geist, adding {C}{C}.
Strangleroot Geist's undying ability and Mortician Beetle trigger.
Resolve the Strangleroot Geist trigger, returning it from your graveyard to the battlefield with a +1/+1 and a vigilance counter.
Resolve the Mortician Beetle trigger, putting a +1/+1 counter on it.
Activate Ashnod's Altar by sacrificing Strangleroot Geist, adding {C}{C}.
Mortician Beetle triggers, putting a +1/+1 counter on itself.
Resolve the Tayam ability from step 5, causing yourself to mill three cards and return Strangleroot Geist from your graveyard to the battlefield.
Repeat.

---

# 83-687-2034-2086

**Cards:**

- Tayam, Luminous Enigma
- Mortician Beetle
- Ashnod's Altar
- Kitchen Finks

**Produces:** Infinite +1/+1 counters on a creature, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite sacrifice triggers, Infinite self-mill, Put a selection of permanant cards from your library and graveyard onto the battlefield

**Mana: {1}, MV: 1, Colors: WBG, Popularity: 44**

**Steps:**

Activate Ashnod's Altar by sacrificing Kitchen Finks, adding {C}{C}.
Kitchen Finks's persist ability and Mortician Beetle trigger.
Resolve the Kitchen Finks trigger, returning it from your graveyard to the battlefield with a -1/-1 and a vigilance counter.
Kitchen Finks enters the battlefield, causing you to gain two life.
Resolve the Mortician Beetle trigger, putting a +1/+1 counter on it.
Activate Tayam by paying {3}, removing a +1/+1 counter from Mortician Beetle and removing both counters from Kitchen Finks.
Holding priority, activate Ashnod's Altar by sacrificing Kitchen Finks, adding {C}{C}.
Kitchen Finks's persist ability and Mortician Beetle trigger.
Resolve the Kitchen Finks trigger, returning it from your graveyard to the battlefield with a -1/-1 and a vigilance counter.
Kitchen Finks enters the battlefield, causing you to gain two life.
Resolve the Mortician Beetle trigger, putting a +1/+1 counter on it.
Activate Ashnod's Altar by sacrificing Kitchen Finks, adding {C}{C}.
Mortician Beetle triggers, putting a +1/+1 counter on itself.
Resolve the Tayam ability from step 6, causing yourself to mill three cards and return Kitchen Finks from your graveyard to the battlefield.
Kitchen Finks enters the battlefield, causing you to gain two life.
Repeat.

---

# 83-687-2034-2620

**Cards:**

- Tayam, Luminous Enigma
- Mortician Beetle
- Ashnod's Altar
- Safehold Elite

**Produces:** Infinite +1/+1 counters on a creature, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite self-mill, Put a selection of permanant cards from your library and graveyard onto the battlefield

**Mana: {1}, MV: 1, Colors: WBG, Popularity: 45**

**Steps:**

Activate Ashnod's Altar by sacrificing Safehold Elite, adding {C}{C}.
Safehold Elite's persist ability and Mortician Beetle trigger.
Resolve the Safehold Elite trigger, returning it from your graveyard to the battlefield with a -1/-1 and a vigilance counter.
Resolve the Mortician Beetle trigger, putting a +1/+1 counter on it.
Activate Tayam by paying {3}, removing a +1/+1 counter from Mortician Beetle and removing both counters from Safehold Elite.
Holding priority, activate Ashnod's Altar by sacrificing Safehold Elite, adding {C}{C}.
Safehold Elite's persist ability and Mortician Beetle trigger.
Resolve the Safehold Elite trigger, returning it from your graveyard to the battlefield with a -1/-1 and a vigilance counter.
Resolve the Mortician Beetle trigger, putting a +1/+1 counter on it.
Activate Ashnod's Altar by sacrificing Safehold Elite, adding {C}{C}.
Mortician Beetle triggers, putting a +1/+1 counter on itself.
Resolve the Tayam ability from step 5, causing yourself to mill three cards and return Safehold Elite from your graveyard to the battlefield.
Repeat.

---

# 83-687-2034-3644

**Cards:**

- Tayam, Luminous Enigma
- Mortician Beetle
- Ashnod's Altar
- Young Wolf

**Produces:** Infinite +1/+1 counters on a creature, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite self-mill, Put a selection of permanant cards from your library and graveyard onto the battlefield

**Mana: {1}, MV: 1, Colors: WBG, Popularity: 48**

**Steps:**

Activate Ashnod's Altar by sacrificing Young Wolf, adding {C}{C}.
Young Wolf's undying ability and Mortician Beetle trigger.
Resolve the Young Wolf trigger, returning it from your graveyard to the battlefield with a +1/+1 and a vigilance counter.
Resolve the Mortician Beetle trigger, putting a +1/+1 counter on it.
Activate Tayam by paying {3}, removing a +1/+1 counter from Mortician Beetle and removing both counters from Young Wolf.
Holding priority, activate Ashnod's Altar by sacrificing Young Wolf, adding {C}{C}.
Young Wolf's undying ability and Mortician Beetle trigger.
Resolve the Young Wolf trigger, returning it from your graveyard to the battlefield with a +1/+1 and a vigilance counter.
Resolve the Mortician Beetle trigger, putting a +1/+1 counter on it.
Activate Ashnod's Altar by sacrificing Young Wolf, adding {C}{C}.
Mortician Beetle triggers, putting a +1/+1 counter on itself.
Resolve the Tayam ability from step 5, causing yourself to mill three cards and return Young Wolf from your graveyard to the battlefield.
Repeat.

---

# 83-687-2034-4350

**Cards:**

- Tayam, Luminous Enigma
- Mortician Beetle
- Ashnod's Altar
- Butcher Ghoul

**Produces:** Infinite +1/+1 counters on a creature, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite self-mill, Put a selection of permanant cards from your library and graveyard onto the battlefield

**Mana: {1}, MV: 1, Colors: WBG, Popularity: 19**

**Steps:**

Activate Ashnod's Altar by sacrificing Butcher Ghoul, adding {C}{C}.
Butcher Ghoul's undying ability and Mortician Beetle trigger.
Resolve the Butcher Ghoul trigger, returning it from your graveyard to the battlefield with a +1/+1 and a vigilance counter.
Resolve the Mortician Beetle trigger, putting a +1/+1 counter on it.
Activate Tayam by paying {3}, removing a +1/+1 counter from Mortician Beetle and removing both counters from Butcher Ghoul.
Holding priority, activate Ashnod's Altar by sacrificing Butcher Ghoul, adding {C}{C}.
Butcher Ghoul's undying ability and Mortician Beetle trigger.
Resolve the Butcher Ghoul trigger, returning it from your graveyard to the battlefield with a +1/+1 and a vigilance counter.
Resolve the Mortician Beetle trigger, putting a +1/+1 counter on it.
Activate Ashnod's Altar by sacrificing Butcher Ghoul, adding {C}{C}.
Mortician Beetle triggers, putting a +1/+1 counter on itself.
Resolve the Tayam ability from step 5, causing yourself to mill three cards and return Butcher Ghoul from your graveyard to the battlefield.
Repeat.

---

# 83-687-2034-5319

**Cards:**

- Tayam, Luminous Enigma
- Mortician Beetle
- Ashnod's Altar
- Geralf's Messenger

**Produces:** Infinite +1/+1 counters on a creature, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite self-mill, Put a selection of permanant cards from your library and graveyard onto the battlefield

**Mana: {1}, MV: 1, Colors: WBG, Popularity: 21**

**Steps:**

Activate Ashnod's Altar by sacrificing Geralf's Messenger, adding {C}{C}.
Geralf's Messenger's undying ability and Mortician Beetle trigger.
Resolve the Geralf's Messenger trigger, returning it from your graveyard to the battlefield with a +1/+1 and a vigilance counter.
Geralf's Messenger enters the battlefield, causing target opponent to lose 2 life.
Resolve the Mortician Beetle trigger, putting a +1/+1 counter on it.
Activate Tayam by paying {3}, removing a +1/+1 counter from Mortician Beetle and removing both counters from Geralf's Messenger.
Holding priority, activate Ashnod's Altar by sacrificing Geralf's Messenger, adding {C}{C}.
Geralf's Messenger's undying ability and Mortician Beetle trigger.
Resolve the Geralf's Messenger trigger, returning it from your graveyard to the battlefield with a +1/+1 and a vigilance counter.
Geralf's Messenger enters the battlefield, causing target opponent to lose 2 life.
Resolve the Mortician Beetle trigger, putting a +1/+1 counter on it.
Activate Ashnod's Altar by sacrificing Geralf's Messenger, adding {C}{C}.
Mortician Beetle triggers, putting a +1/+1 counter on itself.
Resolve the Tayam ability from step 6, causing yourself to mill three cards and return Geralf's Messenger from your graveyard to the battlefield.
Geralf's Messenger enters the battlefield, causing target opponent to lose 2 life.
Repeat.

---

# 849-1812-2034-2577

**Cards:**

- Gravecrawler
- Ashnod's Altar
- Anax, Hardened in the Forge
- Prismite

**Produces:** Infinite colored mana, Infinite colorless mana, Infinite creature tokens, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: BR, Popularity: 2**

**Steps:**

Activate Ashnod's Altar by sacrificing Gravecrawler, adding {C}{C}.
Anax triggers, creating a 1/1 Satyr creature token.
Activate Prismite by paying {2}, adding {B}.
Cast Gravecrawler from your graveyard by paying {B}.
Repeat any number of times.
Activate Ashnod's Altar any number of times by sacrificing any number of Satyr tokens, adding any amount of colorless mana.
Activate Prismite any number of times by paying any amount of colorless mana, adding any amount of colored mana.

---

# 849-1812-2034-3240

**Cards:**

- Nether Traitor
- Ashnod's Altar
- Anax, Hardened in the Forge
- Prismite

**Produces:** Infinite colored mana, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: BR, Popularity: 0**

**Steps:**

Activate Ashnod's Altar by sacrificing Nether Traitor, adding {C}{C}.
Nether Traitor dies, triggering Anax, crating a 1/1 Satyr creature token.
Activate Prismite by paying {2}, adding {B}.
Activate Ashnod's Altar by sacrificing the Satyr token, adding {C}{C}.
The Satyr dies, triggering Nether Traitor, causing you to pay {B} to return Nether Traitor from your graveyard to the battlefield.
Repeat.

---

# 849-2034-2577-3537

**Cards:**

- Gravecrawler
- Ashnod's Altar
- Anax, Hardened in the Forge
- Bog Initiate

**Produces:** Infinite black mana, Infinite colorless mana, Infinite creature tokens, Infinite death triggers, Infinite ETB, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: BR, Popularity: 2**

**Steps:**

Activate Ashnod's Altar by sacrificing Gravecrawler, adding {C}{C}.
Anax triggers, creating a 1/1 Satyr creature token.
Activate Bog Initiate by paying {1}, adding {B}.
Cast Gravecrawler from your graveyard by paying {B}.
Repeat any number of times.
Activate Ashnod's Altar any number of times by sacrificing any number of Satyr tokens, adding any amount of colorless mana.
Activate Bog Initiate any number of times by paying any amount of colorless mana, adding any amount of black mana.

---

# 849-2034-2577-5115

**Cards:**

- Gravecrawler
- Ashnod's Altar
- Anax, Hardened in the Forge
- Gemstone Array

**Produces:** Infinite creature tokens, Infinite death triggers, Infinite ETB, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite storm count, Infinite colorless mana, Infinite colored mana, Infinite charge counters on a permanent

**Mana: , MV: 0, Colors: BR, Popularity: 1**

**Steps:**

Activate Ashnod's Altar by sacrificing Gravecrawler, adding {C}{C}.
Anax triggers, creating a 1/1 Satyr creature token.
Activate Gemstone Array by paying {2}, putting a charge counter on it.
Activate Gemstone Array by removing a charge counter, adding {B}.
Cast Gravecrawler from your graveyard by paying {B}.
Repeat any number of times.
Activate Ashnod's Altar any number of times by sacrificing any number of Satyr tokens, adding any amount of colorless mana.
Activate Gemstone Array any number of times by paying any amount of colorless mana, adding any number of charge counters.
Activate Gemstone Array any number of times by removing any number of charge counters, adding any amount of colored mana.

---

# 849-2034-3240-3537

**Cards:**

- Nether Traitor
- Ashnod's Altar
- Anax, Hardened in the Forge
- Bog Initiate

**Produces:** Infinite black mana, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: BR, Popularity: 4**

**Steps:**

Activate Ashnod's Altar by sacrificing Nether Traitor, adding {C}{C}.
Nether Traitor dies, triggering Anax, crating a 1/1 Satyr creature token.
Activate Bog Initiate by paying {1}, adding {B}.
Activate Ashnod's Altar by sacrificing the Satyr token, adding {C}{C}.
The Satyr dies, triggering Nether Traitor, causing you to pay {B} to return Nether Traitor from your graveyard to the battlefield.
Repeat.

---

# 849-2034-3240-5115

**Cards:**

- Nether Traitor
- Ashnod's Altar
- Anax, Hardened in the Forge
- Gemstone Array

**Produces:** Infinite charge counters on a permanent, Infinite colored mana, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: BR, Popularity: 0**

**Steps:**

Activate Ashnod's Altar by sacrificing Nether Traitor, adding {C}{C}.
Nether Traitor dies, triggering Anax, crating a 1/1 Satyr creature token.
Activate Gemstone Array's first ability by paying {2}, putting a charge counter on it.
Activate Gemstone Array's second ability by removing a charge counter from it, adding {B}.
Activate Ashnod's Altar by sacrificing the Satyr token, adding {C}{C}.
The Satyr dies, triggering Nether Traitor, causing you to pay {B} to return Nether Traitor from your graveyard to the battlefield.
Repeat.

---

# 849-3240-4050

**Cards:**

- Nether Traitor
- Phyrexian Altar
- Anax, Hardened in the Forge

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: BR, Popularity: 221**

**Steps:**

Activate Phyrexian Altar by sacrificing Nether Traitor, adding {B}.
When Nether Traitor dies, Anax triggers, creating a creature token.
Activate Phyrexian Altar by sacrificing the creature token, adding one mana of any color.
When the creature token dies, Nether Traitor triggers, causing you to pay {B} to return Nether Traitor from your graveyard to the battlefield.
Repeat.

---

# 849-913-2034-2577

**Cards:**

- Gravecrawler
- Ashnod's Altar
- Anax, Hardened in the Forge
- Signpost Scarecrow

**Produces:** Infinite colored mana, Infinite colorless mana, Infinite creature tokens, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: BR, Popularity: 0**

**Steps:**

Activate Ashnod's Altar by sacrificing Gravecrawler, adding {C}{C}.
Anax triggers, creating a 1/1 Satyr creature token.
Activate Signpost Scarecrow by paying {2}, adding {B}.
Cast Gravecrawler from your graveyard by paying {B}.
Repeat any number of times.
Activate Ashnod's Altar any number of times by sacrificing any number of Satyr tokens, adding any amount of colorless mana.
Activate Signpost Scarecrow any number of times by paying any amount of colorless mana, adding any amount of colored mana.

---

# 849-913-2034-3240

**Cards:**

- Nether Traitor
- Ashnod's Altar
- Anax, Hardened in the Forge
- Signpost Scarecrow

**Produces:** Infinite colored mana, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: BR, Popularity: 0**

**Steps:**

Activate Ashnod's Altar by sacrificing Nether Traitor, adding {C}{C}.
Nether Traitor dies, triggering Anax, crating a 1/1 Satyr creature token.
Activate Signpost Scarecrow by paying {2}, adding {B}.
Activate Ashnod's Altar by sacrificing the Satyr token, adding {C}{C}.
The Satyr dies, triggering Nether Traitor, causing you to pay {B} to return Nether Traitor from your graveyard to the battlefield.
Repeat.

---

# 855-4929-5189

**Cards:**

- Ghave, Guru of Spores
- Cryptic Trilobite
- Corpsejack Menace

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: WBG, Popularity: 1689**

**Steps:**

Activate Cryptic Trilobite's first ability by removing a +1/+1 counter from it, adding {C}{C}.
Activate Ghave's first ability by paying {1} and removing a +1/+1 counter from Cryptic Trilobite, creating a 1/1 Saproling creature token.
Activate Ghave's second ability by paying {1} and sacrificing the Saproling token, putting two +1/+1 counters on Cryptic Trilobite.
Repeat.

---

# 856-1201-1308-1651

**Cards:**

- Cauldron Familiar
- Witch's Oven
- Clock of Omens
- Anointed Procession

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite tapped Food tokens

**Mana: , MV: 0, Colors: WB, Popularity: 120**

**Steps:**

Activate Witch's Oven by tapping and sacrificing Cauldron Familiar, creating two Food tokens.
Activate Clock of Omens by tapping two Food tokens, untapping Witch's Oven.
Activate Cauldron Familiar by sacrificing a Food, returning Cauldron Familiar from your graveyard to the battlefield.
When Caludron Familiar enters the battlefield, it triggers, causing each opponent to lose 1 life and you to gain 1 life.
Repeat.

---

# 856-1201-1651-2557

**Cards:**

- Cauldron Familiar
- Witch's Oven
- Clock of Omens
- Parallel Lives

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite tapped Food tokens

**Mana: , MV: 0, Colors: BG, Popularity: 426**

**Steps:**

Activate Witch's Oven by tapping it and sacrificing Cauldron Familiar, creating two Food artifact tokens.
Activate Clock of Omens by tapping two Food tokens, untapping Witch's Oven.
Activate Cauldron Familiar by sacrificing a Food, returning Cauldron Familiar from your graveyard to the battlefield.
When Caludron Familiar enters the battlefield, it triggers, causing each opponent to lose 1 life and you to gain 1 life.
Repeat.

---

# 856-1201-1651-3129

**Cards:**

- Cauldron Familiar
- Witch's Oven
- Clock of Omens
- Primal Vigor

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite tapped Food tokens

**Mana: , MV: 0, Colors: BG, Popularity: 121**

**Steps:**

Activate Witch's Oven by tapping it and sacrificing Cauldron Familiar, creating two Food artifact tokens.
Activate Clock of Omens by tapping two Food tokens, untapping Witch's Oven.
Activate Cauldron Familiar by sacrificing a Food, returning Cauldron Familiar from your graveyard to the battlefield.
When Caludron Familiar enters the battlefield, it triggers, causing each opponent to lose 1 life and you to gain 1 life.
Repeat.

---

# 856-1201-1651-4772

**Cards:**

- Cauldron Familiar
- Witch's Oven
- Clock of Omens
- Doubling Season

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite tapped Food tokens

**Mana: , MV: 0, Colors: BG, Popularity: 419**

**Steps:**

Activate Witch's Oven by tapping and sacrificing Cauldron Familiar, creating two Food tokens.
Activate Clock of Omens by tapping two Food tokens, untapping Witch's Oven.
Activate Cauldron Familiar by sacrificing a Food, returning Cauldron Familiar from your graveyard to the battlefield.
When Caludron Familiar enters the battlefield, it triggers, causing each opponent to lose 1 life and you to gain 1 life.
Repeat.

---

# 856-1201-1651-4871

**Cards:**

- Cauldron Familiar
- Witch's Oven
- Clock of Omens
- Pitiless Plunderer

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite tapped Treasure tokens

**Mana: , MV: 0, Colors: B, Popularity: 1065**

**Steps:**

Activate Witch's Oven by tapping it and sacrificing Cauldron Familiar.
When Cauldron Familar dies, Pitless Plunderer triggers, creating a Treasure artifact token.
Resolve the Witch's Oven ability, creating a Food artifact token.
Activate Clock of Omens by tapping the Treasure and Food, untapping Witch's Oven.
Activate Cauldron Familiar by sacrificing a Food, returning Cauldron Familiar from your graveyard to the battlefield.
When Caludron Familiar enters the battlefield, it triggers, causing each opponent to lose 1 life and you to gain 1 life.
Repeat.

---

# 862-2034-3249

**Cards:**

- Havengul Lich
- Ashnod's Altar
- Crimson Kobolds

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: UBR, Popularity: 3**

**Steps:**

Activate Ashnod's Altar by sacrificing Crimson Kobolds, adding {C}{C}.
Activate Havengul Lich by paying {1}, targeting Crimson Kobolds.
Cast Crimson Kobolds from graveyard by paying {0}.
Repeat.

---

# 862-2232-2459-2624

**Cards:**

- God-Eternal Oketra
- Cloudstone Curio
- Crimson Kobolds
- Rograkh, Son of Rohgahh

**Produces:** Infinite creature tokens, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: , MV: 0, Colors: RW, Popularity: 5**

**Steps:**

Cast Rograkh by paying {0}.
Oketra triggers, creating a 4/4 Zombie creature token.
Cloudstone Curio triggers, returning nothing to your hand.
Rograkh enters the battlefield, triggering Cloudstone Curio, returning nothing to your hand.
Cast Crimson Kobolds by paying {0}.
Oketra triggers, creating a 4/4 Zombie creature token.
Cloudstone Curio triggers, returning Rograkh to your hand.
Crimson Kobolds enters the battlefield, triggering Cloudstone Curio, returning nothing to your hand.
Cast Rograkh by paying {0}.
Oketra triggers, creating a 4/4 Zombie creature token.
Cloudstone Curio triggers, returning Crimson Kobolds to your hand.
Rograkh enters the battlefield, triggering Cloudstone Curio, returning nothing to your hand.
Repeat from step 5.

---

# 862-3249-4050

**Cards:**

- Havengul Lich
- Phyrexian Altar
- Crimson Kobolds

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: UBR, Popularity: 3**

**Steps:**

Activate Phyrexian Altar by sacrificing Crimson Kobolds, adding one mana of any color.
Activate Havengul Lich by paying {1}, targeting Crimson Kobolds.
Cast Crimson Kobolds from graveyard by paying {0}.
Repeat.

---

# 862-3249-5231

**Cards:**

- Havengul Lich
- Thermopod
- Crimson Kobolds

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: UBR, Popularity: 0**

**Steps:**

Activate Thermopod's second ability by sacrificing Crimson Kobolds, adding {R}.
Activate Havengul Lich by paying {1}, targeting Crimson Kobolds.
Cast Crimson Kobolds from graveyard by paying {0}.
Repeat.

---

# 864-1193-4095

**Cards:**

- Mythos of Illuna
- Radiate
- Eternal Witness

**Produces:** Infinite copies of all permanents, Infinite storm count, Infinite recursion of most cards in your graveyard

**Mana: {5}{U}{U}{R}{R}, MV: 9, Colors: GUR, Popularity: 26**

**Steps:**

Cast Mythos of Illuna targeting anything but Eternal Witness, holding priority, and then cast Radiate targeting Mythos of Illuna.
When Radiate resolves you will have Mythos copies targeting every targetable permanent (except what the original Mythos card is targeting).
When each of the copies resolve, target Radiate in your graveyard with the new Eternal Witness token's ability and return Radiate to your hand.
Before the original Mythos of Illuna card resolves, cast Radiate again targeting Mythos by spending mana from the tokens you just created.
Repeat this process, effectively doubling the number of copies created, allowing you to return Radiate and another card with two Witness triggers.
Repeat.

---

# 864-1532-2034-3255-3747

**Cards:**

- Child of Alara
- Faith's Reward
- Commander's Sphere
- Ashnod's Altar
- Eternal Witness

**Produces:** Infinite card draw, Infinite colorless mana, Infinite death triggers, Infinite draw triggers, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: WUBRG, Popularity: 13**

**Steps:**

Activate Commander's Sphere's first ability by tapping it, adding {W}.
Activate Commander's Sphere's second ability by sacrificing it, causing you to draw a card.
Activate Ashnod's Altar by sacrificing Eternal Witness and Child of Alara, adding {C}{C}{C}{C}.
Child of Alara dies, destroying all nonland permanents.
Cast Faith's Reward by paying {3}{W}, returning all permanent cards put into your graveyard this turn to the battlefield under your control.
Eternal Witness enters the battlefield, returning Faith's Reward from your graveyard to your hand.
Repeat.

---

# 864-2034-3622-4766

**Cards:**

- Deathrender
- Gravedigger
- Eternal Witness
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: BG, Popularity: 4**

**Steps:**

Activate Ashnod's Altar by sacrificing Eternal Witness, adding {C}{C}.
Eternal Witness dies, triggering Deathrender, putting Gravedigger from your hand onto the battlefield and attaching Deathrender to it.
Gravedigger enters the battlefield, returning Eternal Witness from your graveyard to your hand.
Activate Ashnod's Altar by sacrificing Gravedigger, adding {C}{C}.
Gravedigger dies, triggering Deathrender, putting Eternal Witness from your hand onto the battlefield and attaching Deathrender to it.
Eternal Witness enters the battlefield, returning Gravedigger from your graveyard to your hand.
Repeat.

---

# 864-2103-2334

**Cards:**

- Soulherder
- Eternal Witness
- Capture of Jingzhou

**Produces:** Infinite turns, Lock

**Mana: {3}{U}{U} each turn, MV: 5, Colors: GWU, Popularity: 86**

**Steps:**

With Soulherder and a creature based spell recursion effect on the battlefield, cast the extra turn spell.
Move to end step and target the creature with Soulherder's ability.
When creature re-enters the battlefield, target the extra turn spell in your graveyard and return it to your hand, then pass to yourself.
Repeat

---

# 864-2103-2665

**Cards:**

- Progenitor Mimic
- Capture of Jingzhou
- Eternal Witness

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: GU, Popularity: 42**

**Steps:**

Cast Capture of Jingzhou by paying its mana cost, taking an extra turn after this one.
At the beginning of your next upkeep, Progenitor Mimic triggers, creating a token copy of Eternal Witness.
When the token Eternal Witness enters the battlefield, it triggers itself, returning Capture of Jingzhou from your graveyard to your hand.
Repeat.

---

# 864-2103-4305

**Cards:**

- Eternal Witness
- Followed Footsteps
- Capture of Jingzhou

**Produces:** Infinite creature tokens, Infinite turns, Lock

**Mana: {3}{U}{U}, MV: 5, Colors: GU, Popularity: 9**

**Steps:**

Cast Capture of Jingzhou by paying {3}{U}{U}, taking an extra turn after this one.
Move to your next turn.
At the beginning of your upkeep, Followed Footsteps triggers, creating a copy of Eternal Witness.
Eternal Witness enters the battlefield, returning Capture of Jingzhou from your graveyard to your hand.
Repeat.

---

# 864-2103-4428

**Cards:**

- Thassa, Deep-Dwelling
- Eternal Witness
- Capture of Jingzhou

**Produces:** Infinite turns, Lock

**Mana: {3}{U}{U} each turn, MV: 5, Colors: GU, Popularity: 131**

**Steps:**

Cast Capture of Jingzhou by paying {3}{U}{U}, getting an extra turn after this one.
At the beginning of your end step, Thassa triggers, blinking Eternal Witness.
Eternal Witness enters the battlefield, returning Capture of Jingzhou from your graveyard to your hand.
Repeat.

---

# 864-2104-2334

**Cards:**

- Soulherder
- Eternal Witness
- Temporal Manipulation

**Produces:** Infinite turns, Lock

**Mana: {3}{U}{U} each turn, MV: 5, Colors: GWU, Popularity: 297**

**Steps:**

With Soulherder and a creature based spell recursion effect on the battlefield, cast the extra turn spell.
Move to end step and target the creature with Soulherder's ability.
When creature re-enters the battlefield, target the extra turn spell in your graveyard and return it to your hand, then pass to yourself.
Repeat

---

# 864-2104-2665

**Cards:**

- Progenitor Mimic
- Temporal Manipulation
- Eternal Witness

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: GU, Popularity: 74**

**Steps:**

Cast Temporal Manipulation by paying its mana cost, taking an extra turn after this one.
At the beginning of your next upkeep, Progenitor Mimic triggers, creating a token copy of Eternal Witness.
When the token Eternal Witness enters the battlefield, it triggers itself, returning Temporal Manipulation from your graveyard to your hand.
Repeat.

---

# 864-2104-4305

**Cards:**

- Eternal Witness
- Followed Footsteps
- Temporal Manipulation

**Produces:** Infinite creature tokens, Infinite turns, Lock

**Mana: {3}{U}{U}, MV: 5, Colors: GU, Popularity: 7**

**Steps:**

Cast Temporal Manipulation by paying {3}{U}{U}, taking an extra turn after this one.
Move to your next turn.
At the beginning of your upkeep, Followed Footsteps triggers, creating a copy of Eternal Witness.
Eternal Witness enters the battlefield, returning Temporal Manipulation from your graveyard to your hand.
Repeat.

---

# 864-2104-4428

**Cards:**

- Thassa, Deep-Dwelling
- Eternal Witness
- Temporal Manipulation

**Produces:** Infinite turns, Lock

**Mana: {3}{U}{U} each turn, MV: 5, Colors: GU, Popularity: 358**

**Steps:**

Cast Temporal Manipulation by paying {3}{U}{U}, getting an extra turn after this one.
At the beginning of your end step, Thassa triggers, blinking Eternal Witness.
Eternal Witness enters the battlefield, returning Temporal Manipulation from your graveyard to your hand.
Repeat.

---

# 864-2292-3622-4766

**Cards:**

- Deathrender
- Gravedigger
- Eternal Witness
- Viscera Seer

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite scry 1

**Mana: , MV: 0, Colors: BG, Popularity: 2**

**Steps:**

Activate Viscera Seer by sacrificing Eternal Witness.
Eternal Witness dies, triggering Deathrender, putting Gravedigger from your hand onto the battlefield and attaching Deathrender to it.
Gravedigger enters the battlefield, returning Eternal Witness from your graveyard to your hand.
Resolve the Viscera Seer ability from step 1, causing you to scry 1.
Activate Viscera Seer by sacrificing Gravedigger.
Gravedigger dies, triggering Deathrender, putting Eternal Witness from your hand onto the battlefield and attaching Deathrender to it.
Eternal Witness enters the battlefield, returning Gravedigger from your graveyard to your hand.
Resolve the Viscera Seer ability from step 5, causing you to scry 1.
Repeat.

---

# 864-2334-3617

**Cards:**

- Soulherder
- Eternal Witness
- Time Walk

**Produces:** Infinite turns, Lock

**Mana: {1}{U} each turn, MV: 2, Colors: GWU, Popularity: 0**

**Steps:**

With Soulherder and a creature based spell recursion effect on the battlefield, cast the extra turn spell.
Move to end step and target the creature with Soulherder's ability.
When creature re-enters the battlefield, target the extra turn spell in your graveyard and return it to your hand, then pass to yourself.
Repeat

---

# 864-2334-4377

**Cards:**

- Soulherder
- Eternal Witness
- Walk the Aeons

**Produces:** Infinite turns, Lock

**Mana: {4}{U}{U} each turn, MV: 6, Colors: GWU, Popularity: 57**

**Steps:**

With Soulherder and a creature based spell recursion effect on the battlefield, cast the extra turn spell.
Move to end step and target the creature with Soulherder's ability.
When creature re-enters the battlefield, target the extra turn spell in your graveyard and return it to your hand, then pass to yourself.
Repeat

---

# 864-2334-4872

**Cards:**

- Soulherder
- Eternal Witness
- Time Warp

**Produces:** Infinite turns, Lock

**Mana: {3}{U}{U} each turn, MV: 5, Colors: GWU, Popularity: 508**

**Steps:**

With Soulherder and a creature based spell recursion effect on the battlefield, cast the extra turn spell.
Move to end step and target the creature with Soulherder's ability.
When creature re-enters the battlefield, target the extra turn spell in your graveyard and return it to your hand, then pass to yourself.
Repeat

---

# 864-2665-3617

**Cards:**

- Progenitor Mimic
- Time Walk
- Eternal Witness

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: GU, Popularity: 0**

**Steps:**

Cast Time Walk by paying its mana cost, taking an extra turn after this one.
At the beginning of your next upkeep, Progenitor Mimic triggers, creating a token copy of Eternal Witness.
When the token Eternal Witness enters the battlefield, it triggers itself, returning Time Walk from your graveyard to your hand.
Repeat.

---

# 864-2665-4377

**Cards:**

- Progenitor Mimic
- Walk the Aeons
- Eternal Witness

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: GU, Popularity: 85**

**Steps:**

Cast Walk the Aeons by paying its mana cost, taking an extra turn after this one.
At the beginning of your next upkeep, Progenitor Mimic triggers, creating a token copy of Eternal Witness.
When the token Eternal Witness enters the battlefield, it triggers itself, returning Walk the Aeons from your graveyard to your hand.
Repeat.

---

# 864-2665-4872

**Cards:**

- Progenitor Mimic
- Time Warp
- Eternal Witness

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: GU, Popularity: 211**

**Steps:**

Cast Time Warp by paying its mana cost, taking an extra turn after this one.
At the beginning of your next upkeep, Progenitor Mimic triggers, creating a token copy of Eternal Witness.
When the token Eternal Witness enters the battlefield, it triggers itself, returning Time Warp from your graveyard to your hand.
Repeat.

---

# 864-2730-4050

**Cards:**

- Kaya's Ghostform
- Phyrexian Altar
- Eternal Witness

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: BG, Popularity: 1974**

**Steps:**

Activate Phyrexian Altar by sacrificing Eternal Witness, adding {B}.
When Eternal Witness dies, Kaya's Ghostform triggers, returning Eternal Witness from your graveyard to the battlefield.
When Eternal Witness enters the battlefield, it triggers, returning Kaya's Ghostform from your graveyard to your hand.
Cast Kaya's Ghostform by paying {B}, attaching it to Eternal Witness.
Repeat.

---

# 864-3617-4305

**Cards:**

- Eternal Witness
- Followed Footsteps
- Time Walk

**Produces:** Infinite creature tokens, Infinite turns, Lock

**Mana: {1}{U}, MV: 2, Colors: GU, Popularity: 0**

**Steps:**

Cast Time Walk by paying {1}{U}, taking an extra turn after this one.
Move to your next turn.
At the beginning of your upkeep, Followed Footsteps triggers, creating a copy of Eternal Witness.
Eternal Witness enters the battlefield, returning Time Walk from your graveyard to your hand.
Repeat.

---

# 864-3617-4428

**Cards:**

- Thassa, Deep-Dwelling
- Eternal Witness
- Time Walk

**Produces:** Infinite turns, Lock

**Mana: {1}{U} each turn, MV: 2, Colors: GU, Popularity: 0**

**Steps:**

Cast Time Walk by paying {1}{U}, getting an extra turn after this one.
At the beginning of your end step, Thassa triggers, blinking Eternal Witness.
Eternal Witness enters the battlefield, returning Time Walk from your graveyard to your hand.
Repeat.

---

# 864-3622-4050-4766

**Cards:**

- Deathrender
- Gravedigger
- Eternal Witness
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: BG, Popularity: 4**

**Steps:**

Activate Phyrexian Altar by sacrificing Eternal Witness, adding one mana of any color.
Eternal Witness dies, triggering Deathrender, putting Gravedigger from your hand onto the battlefield and attaching Deathrender to it.
Gravedigger enters the battlefield, returning Eternal Witness from your graveyard to your hand.
Activate Phyrexian Altar by sacrificing Gravedigger, adding one mana of any color.
Gravedigger dies, triggering Deathrender, putting Eternal Witness from your hand onto the battlefield and attaching Deathrender to it.
Eternal Witness enters the battlefield, returning Gravedigger from your graveyard to your hand.
Repeat.

---

# 864-3622-4766-5256

**Cards:**

- Deathrender
- Gravedigger
- Eternal Witness
- Altar of Dementia

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: BG, Popularity: 5**

**Steps:**

Activate Altar of Dementia by sacrificing Eternal Witness.
Eternal Witness dies, triggering Deathrender, putting Gravedigger from your hand onto the battlefield and attaching Deathrender to it.
Gravedigger enters the battlefield, returning Eternal Witness from your graveyard to your hand.
Resolve the Altar of Dementia ability from step 1, causing target player to mill cards equal to Eternal Witness' power.
Activate Altar of Dementia by sacrificing Gravedigger.
Gravedigger dies, triggering Deathrender, putting Eternal Witness from your hand onto the battlefield and attaching Deathrender to it.
Eternal Witness enters the battlefield, returning Gravedigger from your graveyard to your hand.
Resolve the Altar of Dementia ability from step 5, causing target player to mill cards equal to Gravedigger's power.
Repeat.

---

# 864-3890-4050

**Cards:**

- Eternal Witness
- Phyrexian Altar
- Unearth

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count, Infinite magecraft triggers

**Mana: , MV: 0, Colors: BG, Popularity: 2397**

**Steps:**

Sacrifice Eternal Witness to Phyrexian Altar, for {B}.
Cast Unearth, returning Eternal Witness from your graveyard to the battlefield.
Eternal Witness enters, returning Unearth from your graveyard to your hand.
Repeat.

---

# 864-4305-4377

**Cards:**

- Eternal Witness
- Followed Footsteps
- Walk the Aeons

**Produces:** Infinite creature tokens, Infinite turns, Lock

**Mana: {4}{U}{U}, MV: 6, Colors: GU, Popularity: 11**

**Steps:**

Cast Walk the Aeons by paying {4}{U}{U}, taking an extra turn after this one.
Move to your next turn.
At the beginning of your upkeep, Followed Footsteps triggers, creating a copy of Eternal Witness.
Eternal Witness enters the battlefield, returning Walk the Aeons from your graveyard to your hand.
Repeat.

---

# 864-4305-4872

**Cards:**

- Eternal Witness
- Followed Footsteps
- Time Warp

**Produces:** Infinite creature tokens, Infinite turns, Lock

**Mana: {3}{U}{U}, MV: 5, Colors: GU, Popularity: 20**

**Steps:**

Cast Time Warp by paying {3}{U}{U}, taking an extra turn after this one.
Move to your next turn.
At the beginning of your upkeep, Followed Footsteps triggers, creating a copy of Eternal Witness.
Eternal Witness enters the battlefield, returning Time Warp from your graveyard to your hand.
Repeat.

---

# 864-4377-4428

**Cards:**

- Thassa, Deep-Dwelling
- Eternal Witness
- Walk the Aeons

**Produces:** Infinite turns, Lock

**Mana: {4}{U}{U} each turn, MV: 6, Colors: GU, Popularity: 104**

**Steps:**

Cast Walk the Aeons by paying {4}{U}{U}, getting an extra turn after this one.
At the beginning of your end step, Thassa triggers, blinking Eternal Witness.
Eternal Witness enters the battlefield, returning Walk the Aeons from your graveyard to your hand.
Repeat.

---

# 864-4428-4872

**Cards:**

- Thassa, Deep-Dwelling
- Eternal Witness
- Time Warp

**Produces:** Infinite turns, Lock

**Mana: {3}{U}{U} each turn, MV: 5, Colors: GU, Popularity: 623**

**Steps:**

Cast Time Warp by paying {3}{U}{U}, getting an extra turn after this one.
At the beginning of your end step, Thassa triggers, blinking Eternal Witness.
Eternal Witness enters the battlefield, returning Time Warp from your graveyard to your hand.
Repeat.

---

# 864-933-2103

**Cards:**

- Conjurer's Closet
- Eternal Witness
- Capture of Jingzhou

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {3}{U}{U}, MV: 5, Colors: GU, Popularity: 81**

**Steps:**

Cast Capture of Jingzhou by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Eternal Witness.
Eternal Witness enters the battlefield, returning Capture of Jingzhou from your graveyard to your hand.
Repeat.

---

# 864-933-2104

**Cards:**

- Conjurer's Closet
- Eternal Witness
- Temporal Manipulation

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {3}{U}{U}, MV: 5, Colors: GU, Popularity: 217**

**Steps:**

Cast Temporal Manipulation by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Eternal Witness.
Eternal Witness enters the battlefield, returning Temporal Manipulation from your graveyard to your hand.
Repeat.

---

# 864-933-3617

**Cards:**

- Conjurer's Closet
- Eternal Witness
- Time Walk

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {1}{U}, MV: 2, Colors: GU, Popularity: 0**

**Steps:**

Cast Time Walk by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Eternal Witness.
Eternal Witness enters the battlefield, returning Time Walk from your graveyard to your hand.
Repeat.

---

# 864-933-4377

**Cards:**

- Conjurer's Closet
- Eternal Witness
- Walk the Aeons

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {4}{U}{U}, MV: 6, Colors: GU, Popularity: 90**

**Steps:**

Cast Walk the Aeons by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Eternal Witness.
Eternal Witness enters the battlefield, returning Walk the Aeons from your graveyard to your hand.
Repeat.

---

# 864-933-4872

**Cards:**

- Conjurer's Closet
- Eternal Witness
- Time Warp

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {3}{U}{U}, MV: 5, Colors: GU, Popularity: 398**

**Steps:**

Cast Time Warp by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Eternal Witness.
Eternal Witness enters the battlefield, returning Time Warp from your graveyard to your hand.
Repeat.

---

# 864-933-957

**Cards:**

- Conjurer's Closet
- Eternal Witness
- Time Stretch

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {8}{U}{U}, MV: 10, Colors: GU, Popularity: 60**

**Steps:**

Cast Time Stretch by paying {8}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Eternal Witness.
Eternal Witness enters the battlefield, returning Time Stretch from your graveyard to your hand.
Repeat.

---

# 864-957-2334

**Cards:**

- Soulherder
- Eternal Witness
- Time Stretch

**Produces:** Infinite turns, Lock

**Mana: {8}{U}{U} every other turn, MV: 10, Colors: GWU, Popularity: 48**

**Steps:**

With Soulherder and a creature based spell recursion effect on the battlefield, cast the extra turn spell.
Move to end step and target the creature with Soulherder's ability.
When creature re-enters the battlefield, target the extra turn spell in your graveyard and return it to your hand, then pass to yourself.
Repeat

---

# 864-957-4428

**Cards:**

- Thassa, Deep-Dwelling
- Eternal Witness
- Time Stretch

**Produces:** Infinite turns, Lock

**Mana: {8}{U}{U} every other turn, MV: 10, Colors: GU, Popularity: 76**

**Steps:**

Cast Time Stretch by paying {8}{U}{U}, getting two extra turns after this one.
At the beginning of your end step, Thassa triggers, blinking Eternal Witness.
Eternal Witness enters the battlefield, returning Time Stretch from your graveyard to your hand.
Repeat every other turn.

---

# 867-1640

**Cards:**

- Jackal Pup
- Pariah's Shield

**Produces:** Draw the game

**Mana: , MV: 0, Colors: R, Popularity: 40**

**Steps:**

Deal damage to Jackal Pup.
Jackal Pup triggers, attempting to deal damage to you, but dealing damage to Jackal Pup instead due to Pariah's Shield.
Repeat step 2 in an infinite loop, causing the game to end in a draw.

---

# 867-4090

**Cards:**

- Jackal Pup
- Pariah

**Produces:** Draw the game

**Mana: , MV: 0, Colors: RW, Popularity: 30**

**Steps:**

Deal damage to Jackal Pup.
Jackal Pup triggers, attempting to deal damage to you, but dealing damage to Jackal Pup instead due to Pariah.
Repeat step 2 in an infinite loop, causing the game to end in a draw.

---

# 868-2670-2713-5261

**Cards:**

- Isochron Scepter
- Psychic Puppetry
- Desperate Ritual
- Zirda, the Dawnwaker

**Produces:** Infinite storm count

**Mana: {2}{R}, MV: 3, Colors: URW, Popularity: 0**

**Steps:**

Activate Isochron Scepter for {1}.
Splice Desperate Ritual onto Psychic Puppetry for {1}{R}, and have Psychic Puppetry target Isochron Scepter.
Resolve the spell, untapping Isochron Scepter and adding {R}{R}{R}.
Repeat as necessary, using {R} to pay for the Isochron Scepter activation and {R}{R} for Desperate Ritual.

---

# 868-2670-5149-5261

**Cards:**

- Isochron Scepter
- Psychic Puppetry
- Desperate Ritual
- Power Artifact

**Produces:** Infinite storm count

**Mana: {2}{R}, MV: 3, Colors: UR, Popularity: 1**

**Steps:**

Activate Isochron Scepter for {1}.
Splice Desperate Ritual onto Psychic Puppetry for {1}{R}, and have Psychic Puppetry target Isochron Scepter.
Resolve the spell, untapping Isochron Scepter and adding {R}{R}{R}.
Repeat as necessary, using {R} to pay for the Isochron Scepter activation and {R}{R} for Desperate Ritual.

---

# 868-3075-3368

**Cards:**

- Mizzix of the Izmagnus
- Desperate Ritual
- Reiterate

**Produces:** Infinite copies of instant and sorcery spells on the stack, Infinite magecraft triggers, Infinite red mana, Infinite storm count

**Mana: {R}{R}{R}, MV: 3, Colors: UR, Popularity: 936**

**Steps:**

Cast Desperate Ritual by paying {R}.
In response, cast Reiterate with buyback by paying {R}{R}, copying Desparate Ritual and putting Reiterate into your hand.
Resolve the Desperate Ritual copy, adding {R}{R}{R}.
Repeat from step 2.
Once you have infinite mana, you may cast Reiterate with buyback any number of times, targeting anything.

---

# 873-3584-5261

**Cards:**

- Isochron Scepter
- Twiddle
- Thousand-Year Storm

**Produces:** Infinite magecraft triggers, Infinite mana lands, artifacts, and creatures you control can produce, Infinite storm count, Infinite untap of lands, creatures, and artifacts you control, Tap all lands, creatures, and artifacts opponents control

**Mana: {5}, MV: 5, Colors: UR, Popularity: 110**

**Steps:**

Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Twiddle.
Thousand-Year Storm triggers, copying Twiddle for each other instant or sorcery you've cast before it this turn.
Resolve a copy of Twiddle, untapping Isochron Scepter.
If there is a remaining copy of Twiddle on the stack, resolve it, untapping a mana-producing land.
Activate that land by tapping it, adding {1}.
Repeat steps 4 and 5 until there are no more copies of Twiddle.
Repeat from step 1.

---

# 874-2882-4675-4694

**Cards:**

- Cavalier of Dawn
- Infinite Reflection
- March of the Machines
- Delif's Cone

**Produces:** Infinite creature tokens, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: , MV: 0, Colors: WU, Popularity: 0**

**Steps:**

Cast Delif's Cone by paying {0}.
Delif's Cone enters the battlefield as a copy of Cavalier of Dawn.
Copy of Cavalier of Dawn enter-the-battlefield ability triggers, destroying itself and creating you a 3/3 Golem token.
Copy of Cavalier of Dawn dies, triggering itself, returning Delif's Cone from your graveyard to your hand.
Repeat.

---

# 876-2703-2713-4659

**Cards:**

- Zirda, the Dawnwaker
- Myr Propagator
- Krark-Clan Ironworks
- Lightning Greaves

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: {1}, MV: 1, Colors: RW, Popularity: 7**

**Steps:**

Equip Lightning Greaves to Myr Propagator by paying {0}.
Activate Myr Propagator by paying {1} and tapping it, creating a token copy of itself.
Activate Krark-Clan Ironworks by sacrificing the tapped Myr Propagator, adding {2}.
Repeat.

---

# 877-1099-1374-2452

**Cards:**

- Morophon, the Boundless
- Rooftop Storm
- Sling-Gang Lieutenant
- Haakon, Stromgald Scourge

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: WUBRG, Popularity: 3**

**Steps:**

Sacrifice Morophon to Sling-Gang Lieutenant, losing target player to lose 1 life and gaining you 1 life.
Cast Morophon from your graveyard by paying {0}.
Repeat.

---

# 880-1659-3470

**Cards:**

- Perilous Forays
- Lotus Cobra
- Seed the Land

**Produces:** Put all lands with a basic land type from your library onto the battlefield tapped

**Mana: {1}, MV: 1, Colors: G, Popularity: 75**

**Steps:**

Activate Perilous Forays by paying {1} and sacrificing a creature, causing you to search your library for a land card with a basic land type and put it onto the battlefield tapped.
When the land enters the battlefield Lotus Cobra and Seed the Land trigger.
Resolve the Lotus Cobra trigger, adding {1}.
Resolve the Seed the Land trigger, creating a creature token.
Repeat.

---

# 880-2783-3470

**Cards:**

- Perilous Forays
- Lotus Cobra
- Nesting Dragon

**Produces:** Put all lands with a basic land type from your library onto the battlefield tapped

**Mana: {1}, MV: 1, Colors: RG, Popularity: 246**

**Steps:**

Activate Perilous Forays by paying {1} and sacrificing a creature.
If the creature was a Dragon Egg, it triggers, creating a 2/2 Dragon creature token.
Resolve the Perilous Forays ability, causing you to search your library for a land card with a basic land type and put it onto the battlefield tapped.
When the land enters the battlefield Lotus Cobra and Nesting Dragon trigger.
Resolve the Lotus Cobra trigger, adding {1}.
Resolve the Nesting Dragon trigger, creating a creature token.
Repeat.

---

# 880-3470-3703

**Cards:**

- Perilous Forays
- Lotus Cobra
- Sporemound

**Produces:** Put all lands with a basic land type from your library onto the battlefield tapped

**Mana: {1}, MV: 1, Colors: G, Popularity: 465**

**Steps:**

Activate Perilous Forays by paying {1} and sacrificing a creature, causing you to search your library for a land card with a basic land type and put it onto the battlefield tapped.
When the land enters the battlefield Lotus Cobra and Sporemound trigger.
Resolve the Lotus Cobra trigger, adding {1}.
Resolve the Sporemound trigger, creating a creature token.
Repeat.

---

# 880-3470-4488

**Cards:**

- Perilous Forays
- Lotus Cobra
- Rampaging Baloths

**Produces:** Put all lands with a basic land type from your library onto the battlefield tapped

**Mana: {1}, MV: 1, Colors: G, Popularity: 3065**

**Steps:**

Activate Perilous Forays by paying {1} and sacrificing a creature, causing you to search your library for a land card with a basic land type and put it onto the battlefield tapped.
When the land enters the battlefield Lotus Cobra and Rampaging Baloths trigger.
Resolve the Lotus Cobra trigger, adding {1}.
Resolve the Rampaging Baloths trigger, creating a creature token.
Repeat.

---

# 880-3470-4677

**Cards:**

- Perilous Forays
- Lotus Cobra
- Zendikar's Roil

**Produces:** Put all lands with a basic land type from your library onto the battlefield tapped

**Mana: {1}, MV: 1, Colors: G, Popularity: 2052**

**Steps:**

Activate Perilous Forays by paying {1} and sacrificing a creature, causing you to search your library for a land card with a basic land type and put it onto the battlefield tapped.
When the land enters the battlefield Lotus Cobra and Zendikar's Roil trigger.
Resolve the Lotus Cobra trigger, adding {1}.
Resolve the Zendikar's Roil trigger, creating a creature token.
Repeat.

---

# 880-3470-4862

**Cards:**

- Perilous Forays
- Omnath, Locus of Rage
- Lotus Cobra

**Produces:** Near-infinite damage, Put all lands with a basic land type from your library onto the battlefield tapped

**Mana: {1}, MV: 1, Colors: RG, Popularity: 2537**

**Steps:**

Activate Perilous Forays by paying {1} and sacrificing a creature.
If the creature was an Elemental, Omnath triggers, dealing 3 damage to any target.
Resolve the Perilous Forays ability, causing you to search your library for a land card with a basic land type and put it onto the battlefield tapped.
When the land enters the battlefield Lotus Cobra and Omnath trigger.
Resolve the Lotus Cobra trigger, adding {1}.
Resolve the Omnath trigger, creating a creature token.
Repeat.

---

# 884-2232-3260-4740

**Cards:**

- K'rrik, Son of Yawgmoth
- Ayara, First of Locthwain
- Cloudstone Curio
- Aetherflux Reservoir

**Produces:** Infinite +1/+1 counters on a creature, Infinite damage, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite lifeloss, Infinite LTB, Infinite storm count

**Mana: , MV: 0, Colors: B, Popularity: 39**

**Steps:**

Cast any creature card in your hand with mana cost {B} by paying 2 life.
Aetherflux Reservoir and K'rrik trigger.
Resolve the Aetherflux Reservoir trigger, causing you to gain 1 life for each spell you've cast this turn.
Resolve the K'rrik trigger, putting a +1/+1 counter on it.
The creature enters the battlefield, triggering Ayara and Cloudstone Curio.
Resolve the Ayara trigger, causing each opponent to lose 1 life and you to gain 1 life.
Resolve the Cloudstone Curio trigger, returning Ayara from the battlefield to your hand.
Cast Ayara by paying 6 life.
Aetherflux Reservoir and K'rrik trigger.
Resolve the Aetherflux Reservoir trigger, causing you to gain 1 life for each spell you've cast this turn.
Resolve the K'rrik trigger, putting a +1/+1 counter on it.
Ayara enters the battlefield, triggering itself and Cloudstone Curio.
Resolve the Ayara trigger, causing each opponent to lose 1 life and you to gain 1 life.
Resolve the Cloudstone Curio trigger, returning the creature with mana cost {B} from the battlefield to your hand.
Repeat.
Once you have an arbitrarily large lifetotal, you may activate Aetherflux Reservoir's ability infinite times to deal infinite damage to any target(s).

---

# 884-5035

**Cards:**

- Ayara, First of Locthwain
- Plague of Vermin

**Produces:** Near-infinite creature tokens for all players, Near-infinite ETB, Near-infinite lifegain, Near-infinite lifegain triggers, Near-infinite lifeloss

**Mana: {6}{B}, MV: 7, Colors: B, Popularity: 8152**

**Steps:**

Cast Plague of Vermin by paying {6}{B}.
Resolve Plague of Vermin, choosing to pay all but one life and create that many black Rat tokens.
For each Rat tokens that enters the battlefield, Ayara triggers, causing you to gain that many life and each opponent to lose that many life.

---

# 885-4747-5200

**Cards:**

- Alena, Kessig Trapper
- Sword of the Paruns
- Phyrexian Soulgorger

**Produces:** Infinite untap of creatures you control, Infinite mana creatures you control can produce, Infinite red mana

**Mana: , MV: 0, Colors: R, Popularity: 21**

**Steps:**

Activate Alena by tapping it, adding at least {R}{R}{R}{R}.
Activate Sword of the Paruns by paying {3}, untapping Alena.
Repeat.

---

# 890-1247-1656

**Cards:**

- Necrotic Ooze
- Pili-Pala
- Palladium Myr

**Produces:** Infinite colored mana, Infinite colorless mana

**Mana: , MV: 0, Colors: B, Popularity: 1484**

**Steps:**

Activate Necrotic Ooze using Palladium Myr's ability by tapping it, adding {C}{C}.
Activate Necrotic Ooze using Pili-Pala's ability by paying {2} and untapping it, adding one mana of any color.
Repeat.

---

# 890-1978-2713

**Cards:**

- Voltaic Construct
- Palladium Myr
- Zirda, the Dawnwaker

**Produces:** Infinite untap of artifact creatures you control

**Mana: , MV: 0, Colors: RW, Popularity: 277**

**Steps:**

Activate Palladium Myr by tapping it, adding {C}{C}.
Activate Voltaic Construct by paying {1}, untapping Palladium Myr.
Repeat.

---

# 890-1978-4893

**Cards:**

- Voltaic Construct
- Palladium Myr
- Training Grounds

**Produces:** Infinite untap of artifact creatures you control

**Mana: , MV: 0, Colors: U, Popularity: 230**

**Steps:**

Activate Palladium Myr by tapping it, adding {C}{C}.
Activate Voltaic Construct by paying {1}, untapping Palladium Myr.
Repeat.

---

# 890-2451-3069-4050

**Cards:**

- Sedris, the Traitor King
- Void Maw
- Phyrexian Altar
- Palladium Myr

**Produces:** Infinite ETB, Infinite LTB, Infinitely large creature until end of turn, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: {2}, MV: 2, Colors: UBR, Popularity: 0**

**Steps:**

Activate Phyrexian Altar by sacrificing Palladium Myr, adding {B}.
Activate Palladium Myr's unearth ability by paying {2}{B}, returning it from your graveyard to the battlefield, giving it haste and exiling it at end of turn or when it leaves the battlefield.
Activate Palladium Myr by tapping it, adding {C}{C}.
Activate Phyrexian Altar by sacrificing Palladium Myr, adding {B}.
Both Palladium Myr's undying ability and Void Maw attempt to exile Palladium Myr when it would be put into your graveyard.
Choose to apply the Void Maw replacement effect, exiling Palladium Myr.
Activate Void Maw by putting Palladium Myr from exile into your graveyard, giving Void Maw +2/+2 until end of turn.
Repeat from step 2.

---

# 890-2713-5200

**Cards:**

- Zirda, the Dawnwaker
- Sword of the Paruns
- Palladium Myr

**Produces:** Infinite colorless mana, Infinite untap of creatures you control, Infinite mana creatures you control can produce

**Mana: , MV: 0, Colors: RW, Popularity: 177**

**Steps:**

Activate Palladium Myr by tapping it, adding {C}{C}.
Activate Sword of the Paruns by paying {1}, untapping Palladium Myr.
Repeat.

---

# 892-1061-1953

**Cards:**

- Brudiclad, Telchor Engineer
- Timestream Navigator
- Sublime Epiphany

**Produces:** Infinite turns, Lock

**Mana: {6}{U}{U}{U}{U} on your first turn, with {2}{U}{U} available on each extra turn, MV: 10, Colors: UR, Popularity: 62**

**Steps:**

Cast Sublime Epiphany by paying {4}{U}{U}, creating a token copy of Timestream Navigator.
At the beginning of your combat phase, Brudiclad triggers, creating a 2/1 Phyrexian Myr creature token, then choosing to have all tokens you control become copies of the Timestream Navigator token.
Activate Timestream Navigator by paying {2}{U}{U} and tapping it and putting it onto the bottom of your library, causing you to take an extra turn after this one.
Move to your next turn.
Repeat from step 2.

---

# 892-1953-2105

**Cards:**

- Brudiclad, Telchor Engineer
- Combat Celebrant
- Sublime Epiphany

**Produces:** Infinite combat phases, Infinite damage

**Mana: {4}{U}{U}, MV: 6, Colors: UR, Popularity: 159**

**Steps:**

Cast Sublime Epiphany by paying {4}{U}{U}, creating a token copy of Combat Celebrant.
At the beginning of your combat phase, Brudiclad triggers, creating a 2/1 Phyrexian Myr creature token, then choosing to have all tokens you control become copies of the Combat Celebrant token.
Declare one of the Combat Celebrant copy as an attacker, choosing to exert it as it attacks.
The Combat Celebrant copy triggers, untapping all other creatures you control and causing you to get an additional combat phase after this one.
Repeat from step 2.

---

# 893-1014-1636-4694

**Cards:**

- Arcum Dagsson
- March of the Machines
- Myr Turbine
- Intruder Alarm

**Produces:** Put all noncreature artifact cards from your library onto the battlefield

**Mana: , MV: 0, Colors: U, Popularity: 18**

**Steps:**

Activate Arcum Dagsson, sacrificing the extra artifact creature to tutor any noncreature artifact to play.
The tutored card ETBs as a creature due to March of the Machines, triggering Intruder Alarm.
Untap Arcum Dagsson and Myr Turbine (also a creature due to March of the Machines) with Intruder Alarm.
Activate Myr Turbine to create a 1/1 Myr artifact creature token.
Repeat the loop, sacrificing the newly generated Myr, to tutor all noncreature artifacts from your library to play.

---

# 893-2034-4853

**Cards:**

- Dross Scorpion
- Myr Turbine
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: C, Popularity: 427**

**Steps:**

Activate Myr Turbine by tapping it, creating a 1/1 Myr artifact creature token.
Activate Ashnod's Altar by sacrificing the Myr.
When the Myr dies, Dross Scorpion triggers, untapping Myr Turbine.
Repeat.

---

# 893-3698-4853

**Cards:**

- Dross Scorpion
- Myr Turbine
- Grinding Station

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: C, Popularity: 295**

**Steps:**

Activate Myr Turbine by tapping it, creating a 1/1 Myr artifact creature token.
When the Myr enters, Grinding Station triggers, untapping Grinding Station.
Activate Grinding Station by tapping it and sacrificing the Myr.
When the Myr dies, Dross Scorpion triggers, untapping Myr Turbine.
Resolve the Grinding Station ability.
Repeat.

---

# 893-4050-4853

**Cards:**

- Dross Scorpion
- Myr Turbine
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: C, Popularity: 106**

**Steps:**

Activate Myr Turbine by tapping it, creating a 1/1 Myr artifact creature token.
Activate Phyrexian Altar by sacrificing the Myr.
When the Myr dies, Dross Scorpion triggers, untapping Myr Turbine.
Repeat.

---

# 893-4659-4853

**Cards:**

- Dross Scorpion
- Myr Turbine
- Krark-Clan Ironworks

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: C, Popularity: 511**

**Steps:**

Activate Myr Turbine by tapping it, creating a 1/1 Myr artifact creature token.
Activate Krark-Clan Ironworks by sacrificing the Myr.
When the Myr dies, Dross Scorpion triggers, untapping Myr Turbine.
Repeat.

---

# 900-2914-4992

**Cards:**

- Stormtide Leviathan
- Choke
- Sword of Feast and Famine

**Produces:** Lands do not untap, Lands your opponents control do not untap, Lock, Mass Land Denial

**Mana: , MV: 0, Colors: GU, Popularity: 7**

**Steps:**

Stormtide makes everything an island, choke prevents them from untapping.
Sword of Feast and Famine can untap your lands.

---

# 900-3750

**Cards:**

- Sword of Feast and Famine
- Aggravated Assault

**Produces:** Infinite combat phases

**Mana: , MV: 0, Colors: R, Popularity: 28678**

**Steps:**

Deal combat damage to an opponent with the creature that has Sword of Feast and Famine attached.
Sword of Feast and Famine triggers, causing that opponent to discard a card, and you to untap all lands you control.
Proceed to your postcombat main phase.
Activate all mana producing lands you control by tapping them, adding at least {3}{R}{R}.
Activate Aggravated Assault by paying {3}{R}{R}, untapping all creatures you control and causing you to get an additional combat and main phase after this phase.
Repeat.

---

# 901-2024-5168

**Cards:**

- Seedcradle Witch
- Bloom Tender
- Govern the Guildless

**Produces:** Infinite black mana, Infinite blue mana, Infinitely large creature until end of turn, Infinite red mana, Infinite mana of colors among permanents you control

**Mana: {1}{U}, MV: 2, Colors: GWU, Popularity: 0**

**Steps:**

During your upkeep, activate Govern the Guildless by paying {1}{U} and revealing it from your hand, making a creature you control all colors until end of turn.
Activate Bloom Tender by tapping it, adding {W}{U}{B}{R}{G}.
Activate Seedcradle Witch by paying {2}{W}{G}, giving Bloom Tender +3/+3 until end of turn and untapping it.
Repeat from step 2.

---

# 91-1242-4050-5112

**Cards:**

- Mairsil, the Pretender
- Cinderhaze Wretch
- Endling
- Phyrexian Altar

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: {B}, MV: 1, Colors: UBR, Popularity: 10**

**Steps:**

Activate Mairsil using Endling's third ability by paying {B}, gaining Mairsil undying.
Activate Mairsil using Phyrexian Altar's ability by sacrificing Mairsil, adding {B}.
Mairsil's undying ability triggers, returning it to the battlefield.
Activate Mairsil using Cinderhaze Wretch's ability, putting -1/-1 on itself.
Repeat.

---

# 9-1308-1645-3581

**Cards:**

- Kykar, Wind's Fury
- Anointed Procession
- Crown of Flames
- Grapeshot

**Produces:** Infinite storm count, Near-infinite damage to one opponent, Infinite LTB, Infinite ETB, Infinite sacrifice triggers, Infinite death triggers

**Mana: {R}, MV: 1, Colors: URW, Popularity: 18**

**Steps:**

Cast Crown of Flames on Kykar, Wind's Fury.
Kykar Wind's Fury triggers creating 2 spirits with Anointed Procession.
Sacrifice both spirits adding {R}{R} to your mana pool with Kykar, Wind's Fury.
Return Crown of Flames to your hand with its ability.
Repeat for an arbitrarily large storm count.
Cast Grapeshot instead of Crown of Flames.

---

# 913-1385-1864-2034

**Cards:**

- Prossh, Skyraider of Kher
- Signpost Scarecrow
- Ashnod's Altar
- Zulaport Cutthroat

**Produces:** Infinite colored mana, Infinite creature tokens, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite death triggers, Infinite colorless mana

**Mana: , MV: 0, Colors: BRG, Popularity: 7**

**Steps:**

Cast Prossh, creating 6 kobold tokens.Sacrifice6 tokens to Altar to produce {12}.
Use {6} to produce {B}{R}{G} with Scarecrow.SacrificeProssh to Altar to put him back into the command zone.
(also producing {2})
Floating {8}{B}{R}{G}, recast Prossh for {5}{B}{R}{G}, producing 8 tokens.Sacrifice them all to Altar producing {20}, filter again, and repeat.
For eachsacrificeed creature, Cutthroat drains an opponent for 1 life.

---

# 913-1864-2034

**Cards:**

- Prossh, Skyraider of Kher
- Signpost Scarecrow
- Ashnod's Altar

**Produces:** Infinite colored mana, Infinite creature tokens, Infinite LTB, Infinite sacrifice triggers, Infinite death triggers, Infinite colorless mana

**Mana: , MV: 0, Colors: BRG, Popularity: 7**

**Steps:**

Cast Prossh, creating 6 kobold tokens.Sacrifice6 tokens to Altar to produce {12}.
Use {6} to produce {B}{R}{G} with Scarecrow.SacrificeProssh to Altar to put him back into the command zone.
(also producing {2})
Floating {8}{B}{R}{G}, recast Prossh for {5}{B}{R}{G}, producing 8 tokens.Sacrifice them all to Altar producing {20}, filter again, and repeat.

---

# 913-1864-2034-2842

**Cards:**

- Prossh, Skyraider of Kher
- Signpost Scarecrow
- Ashnod's Altar
- Blood Artist

**Produces:** Infinite colored mana, Infinite creature tokens, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite death triggers, Infinite colorless mana

**Mana: , MV: 0, Colors: BRG, Popularity: 6**

**Steps:**

Cast Prossh, creating 6 kobold tokens.Sacrifice6 tokens to Altar to produce {12}.
Use {6} to produce {B}{R}{G} with Scarecrow.SacrificeProssh to Altar to put him back into the command zone.
(also producing {2})
Floating {8}{B}{R}{G}, recast Prossh for {5}{B}{R}{G}, producing 8 tokens.Sacrifice them all to Altar producing {20}, filter again, and repeat.
For eachsacrificeed creature, Artist drains an opponent for 1 life.

---

# 913-2440-2714-5105

**Cards:**

- Sigil of the New Dawn
- Mana Echoes
- Siege-Gang Commander
- Signpost Scarecrow

**Produces:** Infinite colored mana, Infinite colorless mana, Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {3}{R}{R}, MV: 5, Colors: RW, Popularity: 0**

**Steps:**

Cast Siege-Gang Commander by paying {3}{R}{R}.
When Siege-Gang Commander enters the battlefield, it and Mana Echoes trigger.
Resolve the Siege-Gang Commander trigger, creating three 1/1 Goblin creature tokens.
When the Goblin tokens enter the battlefield, Mana Echoes triggers three times.
Resolve all four Mana Echoes triggers, adding at least {16}.
Activate Signpost Scarecrow four times by paying {8}, adding {W}{R}{R}{R}.
Activate Siege-Gang Commander by paying {C}{R} and sacrificing itself.
Sigil of the New Dawn triggers, causing you to pay {C}{W} to return Siege-Gang Commander from your graveyard to your hand.
Resolve the Siege-Gang Commander activated ability, dealing 2 damage to any target.
Repeat.

---

# 914-1099-1799-2048

**Cards:**

- Grenzo, Dungeon Warden
- Epitaph Golem
- Dockside Extortionist
- Sling-Gang Lieutenant

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite Treasure tokens

**Mana: {1}{R}, MV: 2, Colors: BR, Popularity: 58**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least five Treasure tokens.
Activate four Treasure tokens by tapping and sacrificing them, adding {4}.
Activate Sling-Gang Lieutenant by sacrificing Dockside Extortionist, causing an opponent to lose 1 life and you to gain 1 life.
Activate Epitaph Golem by paying {2}, putting Dockside Extortionist on the bottom of your library from your graveyard.
Activate Grenzo by paying {2}, putting Dockside Extortionist into your graveyard from the bottom of your library, and then putting it onto the battlefield.
Repeat from step 2.

---

# 914-1214-3198

**Cards:**

- Dockside Extortionist
- Silent Departure
- Lore Drakkis

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {1}{R}, MV: 2, Colors: UR, Popularity: 0**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Cast Lore Drakkis for its mutate cost by paying {U/R}{U/R}, targeting Dockside Extortionist.
Lore Drakkis's mutate ability triggers, returning Silent Departure from your graveyard to hand.
Cast Silent Departure by paying {U}, returning Dockside Extortionist and Lore Drakkis to your hand.
Activate five Treasure tokens by tapping and sacrificing those, adding {1}{U}{U/R}{U/R}{R}.
Repeat.

---

# 914-1409

**Cards:**

- Dockside Extortionist
- Deadeye Navigator

**Produces:** Infinite blinking, Infinite colored mana, Infinite ETB, Infinite LTB, Infinite Treasure tokens

**Mana: {1}{U}, MV: 2, Colors: UR, Popularity: 1017**

**Steps:**

Activate Dockside Extortionist by paying {1}{U}, blinking it.
When Dockside Extortionist enters the battlefield, it and Deadeye Navigator's soulbond ability trigger.
Resolve the Dockside Extortionist trigger, creating at least two Treasure artifact tokens.
Resolve the Deadeye Navigator trigger, repairing it and Dockside Extortionist.
Activate two Treasures by tapping and sacrificing them, adding {1}{U}.
Repeat.

---

# 914-1458-2617

**Cards:**

- Midnight Guard
- Banishing Knack
- Dockside Extortionist

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite storm count, Infinite Treasure tokens

**Mana: {1}{R}, MV: 2, Colors: URW, Popularity: 0**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, triggering itself and Midnight Guard.
Resolve the Dockside Extortionist trigger, creating at least 3 Treasure tokens.
Resolve the Midnight Guard trigger, untapping it.
Activate a Treasure token by tapping and sacrificing it, adding {U}.
Cast Banishing Knack by paying {U} targeting Midnight Guard.
Activate Midnight Guard by tapping it, returning Dockside Extortionist from the battlefield to your hand.
Activate two Treasure tokens by tapping and sacrificing them, adding {1}{R}.
Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, triggering itself and Midnight Guard.
Resolve the Dockside Extortionist trigger, creating at least 3 Treasure tokens.
Resolve the Midnight Guard trigger, untapping it.
Repeat from step 7.

---

# 914-1639-2649

**Cards:**

- Vadrok, Apex of Thunder
- Dockside Extortionist
- Winds of Rebuke

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite mill, Infinite self-mill, Infinite storm count, Infinite Treasure tokens

**Mana: {1}{R} plus enough mana to pay for commander tax, if applicable, MV: 2, Colors: URW, Popularity: 37**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Activate six Treasure tokens by tapping and sacrificing them, adding {2}{W/U}{R}{R}{R}.
Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R} plus commander tax if applicable, putting it on top of Dockside Extortionist.
The Vadrok mutated creature triggers, allowing you to cast Winds of Rebuke from your graveyard without paying its mana cost.
Resolve Winds of Rebuke, returning Vadrok and Dockside Extortionist from the battlefield to your hand and causing each player to mill two cards.
Repeat.
If your opponents control at least seven artifacts and/or enchantments, this combo produces infinite Treasure tokens.

---

# 914-1792-2617

**Cards:**

- Midnight Guard
- Retraction Helix
- Dockside Extortionist

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite storm count, Infinite Treasure tokens

**Mana: {1}{R}, MV: 2, Colors: URW, Popularity: 0**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, triggering itself and Midnight Guard.
Resolve the Dockside Extortionist trigger, creating at least three Treasure tokens.
Resolve the Midnight Guard trigger, untapping it.
Activate three Treasure tokens by tapping and sacrificing them, adding {1}{U}{R}.
Cast Retraction Helix by paying {U}, targeting Midnight Guard.
Activate Midnight Guard by tapping it, returning Dockside Extortionist from the battlefield to your hand.
Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, triggering itself and Midnight Guard.
Resolve the Dockside Extortionist trigger, creating at least three Treasure tokens.
Resolve the Midnight Guard trigger, untapping it.
Activate two Treasure tokens by tapping and sacrificing them, adding {1}{R}.
Repeat from step 7.

---

# 914-1801-3198

**Cards:**

- Dockside Extortionist
- String of Disappearances
- Lore Drakkis

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {1}{R}, MV: 2, Colors: UR, Popularity: 4**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Cast Lore Drakkis for its mutate cost by paying {U/R}{U/R}, targeting Dockside Extortionist.
Lore Drakkis's mutate ability triggers, returning String of Disappearances from your graveyard to hand.
Cast String of Disappearances by paying {U}, returning Dockside Extortionist and Lore Drakkis to your hand.
Activate five Treasure tokens by tapping and sacrificing those, adding {1}{U}{U/R}{U/R}{R}.
Repeat.

---

# 914-2034-5003

**Cards:**

- Dockside Extortionist
- Nim Deathmantle
- Ashnod's Altar

**Produces:** Infinite colored mana, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite Treasure tokens

**Mana: {2}, MV: 2, Colors: R, Popularity: 554**

**Steps:**

Activate Ashnod's Altar by sacrificing Dockside Extortionist, adding {C}{C}.
Dockside Extortionist dies, triggering Nim Deathmantle, causing you to pay {4} to return Dockside Extortionist from your graveyard to the battlefield, and attach Nim Deathmantle to it.
Dockside Extortionist enters the battlefield, creating at least two Treasure tokens.
Activate two Treasure tokens by tapping and sacrificing them, adding two mana of any color.
Repeat.

---

# 914-2232

**Cards:**

- Dockside Extortionist
- Cloudstone Curio

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count, Infinite Treasure tokens

**Mana: {1}{R}, MV: 2, Colors: R, Popularity: 7730**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, triggering itself and Cloudstone Curio.
Resolve the Dockside Extortionist trigger, creating a number of Treasure tokens equal to the number of artifacts and/or enchantments your opponent control.
Resolve the Cloudstone Curio trigger, returning the additional nontoken nonartifact creature from the battlefield to your hand.
Activate a Treasure token by tapping and sacrificing it, adding one mana of any color.
Repeat step 5 until you have enough mana to cast the additional creature card.
Cast the additional creature by paying its mana cost.
The creature enters the battlefield, triggering Cloudstone Curio, returning Dockside Extortionist from the battlefield to your hand.
Activate two Treasure tokens by tapping and sacrificing them, adding {1}{R}.
Repeat.

---

# 914-2451-3069-5256

**Cards:**

- Sedris, the Traitor King
- Void Maw
- Altar of Dementia
- Dockside Extortionist

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinitely large creature until end of turn, Infinite mill, Infinite sacrifice triggers, Infinite self-mill, Infinite Treasure tokens

**Mana: {2}{B}, MV: 3, Colors: UBR, Popularity: 0**

**Steps:**

Activate Altar of Dementia by sacrificing Dockside Extortionist, causing target player to mill cards equal to Dockside Extortionist's power.
Activate Dockside Extortionist's unearth ability by paying {2}{B}, returning it from your graveyard to the battlefield, giving it haste and exiling it at end of turn or when it leaves the battlefield.
Dockside Extortionist enters the battlefield, creating at least four Treasure tokens.
Activate three of the Treasure tokens by tapping and sacrificing them, adding {2}{B}.
Activate Altar of Dementia by sacrificing Dockside Extortionist.
Both Dockside Extortionist's undying ability and Void Maw attempt to exile Dockside Extortionist when it would be put into your graveyard.
Choose to apply the Void Maw replacement effect, exiling Dockside Extortionist.
Resolve the Altar of Dementia ability, causing target player to mill cards equal to Dockside Extortionist's power.
Activate Void Maw by putting Dockside Extortionist from exile into your graveyard, giving Void Maw +2/+2 until end of turn.
Repeat from step 2.

---

# 914-2461-3198

**Cards:**

- Dockside Extortionist
- Saving Grasp
- Lore Drakkis

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {1}{R}, MV: 2, Colors: URW, Popularity: 0**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Cast Lore Drakkis for its mutate cost by paying {U/R}{U/R}, targeting Dockside Extortionist.
Lore Drakkis's mutate ability triggers, returning Saving Grasp from your graveyard to hand.
Cast Saving Grasp by paying {U}, returning Dockside Extortionist and Lore Drakkis to your hand.
Activate five Treasure tokens by tapping and sacrificing those, adding {1}{U}{U/R}{U/R}{R}.
Repeat.

---

# 914-2504-2649

**Cards:**

- Vadrok, Apex of Thunder
- Dockside Extortionist
- Unexplained Disappearance

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite self-mill, Infinite storm count, Infinite surveil, Infinite Treasure tokens

**Mana: {1}{R} plus enough mana to pay for commander tax, if applicable, MV: 2, Colors: URW, Popularity: 1**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Activate six Treasure tokens by tapping and sacrificing them, adding {2}{W/U}{R}{R}{R}.
Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R} plus commander tax if applicable, putting it on top of Dockside Extortionist.
The Vadrok mutated creature triggers, allowing you to cast Unexplained Disappearance from your graveyard without paying its mana cost.
Resolve Unexplained Disappearance, returning Vadrok and Dockside Extortionist from the battlefield to your hand and causing you to surveil 1.
Repeat.
If your opponents control at least seven artifacts and/or enchantments, this combo produces infinite Treasure tokens.

---

# 914-2807-3198

**Cards:**

- Dockside Extortionist
- Clutch of Currents
- Lore Drakkis

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {1}{R}, MV: 2, Colors: UR, Popularity: 0**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Cast Lore Drakkis for its mutate cost by paying {U/R}{U/R}, targeting Dockside Extortionist.
Lore Drakkis's mutate ability triggers, returning Clutch of Currents from your graveyard to hand.
Cast Clutch of Currents by paying {U}, returning Dockside Extortionist and Lore Drakkis to your hand.
Activate five Treasure tokens by tapping and sacrificing those, adding {1}{U}{U/R}{U/R}{R}.
Repeat.

---

# 914-3089

**Cards:**

- Dockside Extortionist
- Barrin, Master Wizard

**Produces:** Infinite colored mana, Infinite ETB, Infinite sacrifice triggers, Infinite storm count, Infinite Treasure tokens

**Mana: {1}{R}, MV: 2, Colors: UR, Popularity: 1378**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Activate four Treasure tokens by tapping and sacrificing those, adding {R} and three mana of any color.
Activate Barrin by paying {2} and sacrificing a Treasure token, returning Dockside Extortionist to hand.
Repeat.

---

# 914-3198-3636

**Cards:**

- Dockside Extortionist
- Rescue
- Lore Drakkis

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {1}{R}, MV: 2, Colors: UR, Popularity: 2**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Cast Lore Drakkis for its mutate cost by paying {U/R}{U/R}, targeting Dockside Extortionist.
Lore Drakkis's mutate ability triggers, returning Rescue from your graveyard to hand.
Cast Rescue by paying {U}, returning Dockside Extortionist and Lore Drakkis to your hand.
Activate five Treasure tokens by tapping and sacrificing those, adding {1}{U}{U/R}{U/R}{R}.
Repeat.

---

# 914-3198-3648

**Cards:**

- Dockside Extortionist
- Word of Undoing
- Lore Drakkis

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {1}{R}, MV: 2, Colors: UR, Popularity: 0**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Cast Lore Drakkis for its mutate cost by paying {U/R}{U/R}, targeting Dockside Extortionist.
Lore Drakkis's mutate ability triggers, returning Word of Undoing from your graveyard to hand.
Cast Word of Undoing by paying {U}, returning Dockside Extortionist and Lore Drakkis to your hand.
Activate five Treasure tokens by tapping and sacrificing those, adding {1}{U}{U/R}{U/R}{R}.
Repeat.

---

# 914-3198-4263

**Cards:**

- Dockside Extortionist
- Unsummon
- Lore Drakkis

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {1}{R}, MV: 2, Colors: UR, Popularity: 3**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Cast Lore Drakkis for its mutate cost by paying {U/R}{U/R}, targeting Dockside Extortionist.
Lore Drakkis's mutate ability triggers, returning Unsummon from your graveyard to hand.
Cast Unsummon by paying {U}, returning Dockside Extortionist and Lore Drakkis to your hand.
Activate five Treasure tokens by tapping and sacrificing those, adding {1}{U}{U/R}{U/R}{R}.
Repeat.

---

# 914-3198-4643

**Cards:**

- Dockside Extortionist
- Void Snare
- Lore Drakkis

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {1}{R}, MV: 2, Colors: UR, Popularity: 3**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Cast Lore Drakkis for its mutate cost by paying {U/R}{U/R}, targeting Dockside Extortionist.
Lore Drakkis's mutate ability triggers, returning Void Snare from your graveyard to hand.
Cast Void Snare by paying {U}, returning Dockside Extortionist and Lore Drakkis to your hand.
Activate five Treasure tokens by tapping and sacrificing those, adding {1}{U}{U/R}{U/R}{R}.
Repeat.

---

# 914-3198-4953

**Cards:**

- Dockside Extortionist
- Chain of Vapor
- Lore Drakkis

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Infinite Treasure tokens

**Mana: {1}{R}, MV: 2, Colors: UR, Popularity: 136**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Activate five Treasure tokens by tapping and sacrificing them, adding {1}{U/R}{U/R}{U}{R}.
Cast Lore Drakkis for its mutate cost by paying {U/R}{U/R}, mutating it on top of Dockside Extortionist.
Lore Drakkis triggers, returning Chain of Vapor from your graveyard to your hand.
Cast Chain of Vapor by paying {U}, returning Lore Drakkis and Dockside Extortionist to your hand and choosing not to copy Chain of Vapor.
Repeat.

---

# 914-3423

**Cards:**

- Aegis Automaton
- Dockside Extortionist

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite storm count, Infinite Treasure tokens

**Mana: {1}{R}, MV: 2, Colors: RW, Popularity: 7**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least eight Treasure tokens.
Activate seven of the Treasure tokens by tapping and sacrificing them, adding {5}{W}{R}.
Activate Aegis Automaton by paying {4}{W}, returning Dockside Extortionist from the battlefield to your hand.
Repeat.

---

# 914-3593-4359-5147

**Cards:**

- Garna, the Bloodflame
- Sneak Attack
- Dockside Extortionist
- Goblin Bombardment

**Produces:** Infinite colored mana, Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite Treasure tokens

**Mana: {R}, MV: 1, Colors: BR, Popularity: 9**

**Steps:**

Activate Sneak Attack by paying {R}, putting Dockside Extortionist onto the battlefield.
Dockside Extortionist triggers, creating at least three Treasure tokens.
Activate two Treasure tokens by tapping and sacrificing those, adding {R}{R}.
Activate Goblin Bombardment by sacrificing Dockside Extortionist, dealing 1 damage to any target.
Activate Sneak Attack by paying {R}, putting Garna onto the battlefield.
Garna's enter the battlefield ability triggers.
Holding priority, activate Goblin Bombardment by sacrificing Garna, dealing 1 damage to any target.
Resolve the Garna ability, returning all creature cards put in your graveyard this turn to your hand.
Repeat.

---

# 914-4013-4659

**Cards:**

- Dockside Extortionist
- Eldrazi Displacer
- Krark-Clan Ironworks

**Produces:** Infinite blinking, Infinite colored mana, Infinite colorless mana, Infinite ETB, Infinite LTB, Infinite Treasure tokens, Infinite blinking of most creatures

**Mana: {2}{C}, MV: 3, Colors: RW, Popularity: 176**

**Steps:**

Activate Eldrazi Displacer by paying {2}{C}, blinking Dockside Extortionist.
Dockside Extortionsit enters the battlefield, creating at least three Treasure tokens.
Activate Krark-Clan Ironworks by sacrificing two Treasure tokens, adding {C}{C}{C}{C}.
Repeat.

---

# 914-5105-5147

**Cards:**

- Sigil of the New Dawn
- Dockside Extortionist
- Goblin Bombardment

**Produces:** Infinite colored mana, Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count, Infinite Treasure tokens

**Mana: {1}{R}, MV: 2, Colors: RW, Popularity: 8**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least five Treasure tokens.
Activate four of the Treasure tokens by tapping and sacrificing them, adding {2}{W}{R}.
Activate Goblin Bombardment by sacrificing Dockside Extortionist.
Sigil of the New Dawn triggers, causing you to pay {1}{W} to return Dockside Extortionist from your graveyard to your hand.
Resolve the Goblin Bombardment ability, dealing 1 damage to any target.
Repeat.

---

# 914-5105-5256

**Cards:**

- Sigil of the New Dawn
- Dockside Extortionist
- Altar of Dementia

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill, Infinite storm count, Infinite Treasure tokens

**Mana: {1}{R}, MV: 2, Colors: RW, Popularity: 6**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least five Treasure tokens.
Activate four of the Treasure tokens by tapping and sacrificing them, adding {2}{W}{R}.
Activate Altar of Dementia by sacrificing Dockside Extortionist.
Sigil of the New Dawn triggers, causing you to pay {1}{W} to return Dockside Extortionist from your graveyard to your hand.
Resolve the Altar of Dementia ability, causing target player to mill cards equal to Dockside Extortionist's power.
Repeat.

---

# 914-990-1678

**Cards:**

- Dockside Extortionist
- Recurring Nightmare
- Mayhem Devil

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite storm count, Infinite Treasure tokens

**Mana: {1}{R}, MV: 2, Colors: BR, Popularity: 0**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Activate Recurring Nightmare by sacrificing Dockside Extortionist and returning itself to hand, return Mayhem Devil to the battlefield.
Activate five Treasure tokens by tapping and sacrificing those, adding {4}{B}{B}.
Mayhem Devil triggers six times each.
Resolve the first Mayhem Devil trigger, dealing 1 damage to any target.
Repeat step 6 for each remaining Mayhem Devil trigger.
Cast Recurring Nightmare by paying {2}{B}.
Activate Recurring Nightmare by sacrificing Mayhem Devil.
Mayhem Devil trigger, dealing 1 damage to any target.
Resolve the Recurring Nightmare by returning itself to hand, return Dockside Extortionist to the battlefield.
Repeat from step 2.

---

# 92-1839-2298

**Cards:**

- Kuro, Pitlord
- Vizkopa Guildmage
- Oketra's Last Mercy

**Produces:** Each opponent loses the game

**Mana: {2}{W}{W}{W}{B}, MV: 6, Colors: WB, Popularity: 4**

**Steps:**

Activate Vizkopa Guildmage by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Activate Kuro by paying 1 life, targeting any creature.
Repeat step 2 until you have one life.
Resolve all Kuro abilities, giving the creature -1/-1 for each ability.
Cast Oketra's Last Mercy by paying {1}{W}{W}, causing your life total to become forty.
Vizkopa Guildmage triggers, causing each opponent to lose thirty-nine life.
Each opponent loses the game due to having zero or less life.

---

# 92-2063-2298

**Cards:**

- Mischievous Poltergeist
- Vizkopa Guildmage
- Oketra's Last Mercy

**Produces:** Each opponent loses the game

**Mana: {2}{W}{W}{W}{B}, MV: 6, Colors: WB, Popularity: 88**

**Steps:**

Activate Vizkopa Guildmage by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Activate Mischievous Poltergeist by paying 1 life, regenerating it.
Repeat step 2 until you have one life.
Cast Oketra's Last Mercy by paying {1}{W}{W}, causing your life total to become forty.
Vizkopa Guildmage triggers, causing each opponent to lose thirty-nine life.
Each opponent loses the game due to having zero or less life.

---

# 922-1656-3121-3866-4283

**Cards:**

- Necrotic Ooze
- Whisper, Blood Liturgist
- Altar Golem
- Abhorrent Overlord
- Marionette Master

**Produces:** Infinite tapped creature tokens, Infinite death triggers, Infinite ETB, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: B, Popularity: 1**

**Steps:**

Tap Necrotic Ooze using Whisper, Blood Liturgist's ability to sacrifice two creatures and return Abhorrent Overlord to battlefield.
Abhorrent Overlord's ETB triggers, creating at least 5 creature tokens.
Using Altar Golem's ability, tap Abhorrent Overlord and 4 tokens to untap Necrotic Ooze.
Tap Necrotic Ooze and sacrifice Abhorrent Overlord and a tapped token to Whisper's ability to return Marionetter Master to the battlefield, creating 3 Servo tokens.
Tap Marionette Master and the 4 untapped tokens to untap Necrotic Ooze.
Sacrifice Marionetter Master and a Servo token, causing target opponent to lose 1 life and reanimating Abhorrent Overlord.
Repeat from step 2 for infinite life loss.

---

# 92-2298-2358

**Cards:**

- Blood Celebrant
- Vizkopa Guildmage
- Oketra's Last Mercy

**Produces:** Each opponent loses the game

**Mana: {2}{W}{W}{W}{B}, MV: 6, Colors: WB, Popularity: 183**

**Steps:**

Activate Blood Celebrant by paying {B} and one life, adding {B}.
Repeat step 1 until you have one life.
Activate Vizkopa Guildmage by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Cast Oketra's Last Mercy by paying {1}{W}{W}, causing your life total to become forty.
Vizkopa Guildmage triggers, causing each opponent to lose thirty-nine life.
Each opponent loses the game due to having zero or less life.

---

# 92-2298-2749

**Cards:**

- Wall of Blood
- Vizkopa Guildmage
- Oketra's Last Mercy

**Produces:** Each opponent loses the game

**Mana: {2}{W}{W}{W}{B}, MV: 6, Colors: WB, Popularity: 377**

**Steps:**

Activate Vizkopa Guildmage by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Activate Wall of Blood by paying 1 life, giving it +1/+1 until end of turn.
Repeat step 2 until you have one life.
Cast Oketra's Last Mercy by paying {1}{W}{W}, causing your life total to become forty.
Vizkopa Guildmage triggers, causing each opponent to lose thirty-nine life.
Each opponent loses the game due to having zero or less life.

---

# 92-2298-2935

**Cards:**

- Ethereal Champion
- Vizkopa Guildmage
- Oketra's Last Mercy

**Produces:** Each opponent loses the game

**Mana: {2}{W}{W}{W}{B}, MV: 6, Colors: WB, Popularity: 6**

**Steps:**

Activate Vizkopa Guildmage by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Activate Ethereal Champion by paying 1 life, preventing the next one damage dealt to it this turn.
Repeat step 2 until you have one life.
Cast Oketra's Last Mercy by paying {1}{W}{W}, causing your life total to become forty.
Vizkopa Guildmage triggers, causing each opponent to lose thirty-nine life.
Each opponent loses the game due to having zero or less life.

---

# 92-2298-3527

**Cards:**

- Spatial Binding
- Vizkopa Guildmage
- Oketra's Last Mercy

**Produces:** Each opponent loses the game

**Mana: {2}{W}{W}{W}{B}, MV: 6, Colors: WUB, Popularity: 3**

**Steps:**

Activate Vizkopa Guildmage by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Activate Spatial Binding by paying 1 life, preventing it from phasing out during your next upkeep.
Repeat step 2 until you have one life.
Cast Oketra's Last Mercy by paying {1}{W}{W}, causing your life total to become forty.
Vizkopa Guildmage triggers, causing each opponent to lose thirty-nine life.
Each opponent loses the game due to having zero or less life.

---

# 92-2298-3591

**Cards:**

- Necropotence
- Vizkopa Guildmage
- Oketra's Last Mercy

**Produces:** Each opponent loses the game

**Mana: {2}{W}{W}{W}{B}, MV: 6, Colors: WB, Popularity: 242**

**Steps:**

Activate Vizkopa Guildmage by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Activate Necropotence by paying 1 life, exiling the top card of your library.
Repeat step 2 until you have one life.
Cast Oketra's Last Mercy by paying {1}{W}{W}, causing your life total to become forty.
Vizkopa Guildmage triggers, causing each opponent to lose thirty-nine life.
Each opponent loses the game due to having zero or less life.

---

# 92-2298-3859

**Cards:**

- Cavern Harpy
- Vizkopa Guildmage
- Oketra's Last Mercy

**Produces:** Each opponent loses the game

**Mana: {2}{W}{W}{W}{B}, MV: 6, Colors: WUB, Popularity: 2**

**Steps:**

Activate Vizkopa Guildmage by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Activate Cavern Harpy by paying 1 life, targeting any creature.
Repeat step 2 until you have one life.
Resolve all Cavern Harpy abilities, returning it from the battlefield to your hand.
Cast Oketra's Last Mercy by paying {1}{W}{W}, causing your life total to become forty.
Vizkopa Guildmage triggers, causing each opponent to lose thirty-nine life.
Each opponent loses the game due to having zero or less life.

---

# 92-2749-3779

**Cards:**

- Wall of Blood
- Vizkopa Guildmage
- Swords to Plowshares

**Produces:** Infinite lifeloss, Near-infinite lifegain

**Mana: {1}{W}{W}{B}, MV: 4, Colors: WB, Popularity: 1792**

**Steps:**

Activate Vizkopa Guildmage's second ability by paying {1}{W}{B}, creating a delayed triggered ability.
Activate Wall of Blood's ability multiple times by paying 1 life each time until you are at 1 life, giving Wall of Blood +1/+1 until end of turn for each activation.
Cast Swords to Plowshares by paying {W}, exiling Wall of Blood and gaining life equal to its power.
The delayed triggered ability from Vizkopa Guildmage triggers, causing each opponent to lose that much life.

---

# 92-2927-3392

**Cards:**

- Children of Korlis
- Vizkopa Guildmage
- Plunge into Darkness

**Produces:** Each opponent loses the game, Near-infinite lifeloss

**Mana: {2}{W}{B}{B}, MV: 5, Colors: WB, Popularity: 222**

**Steps:**

Activate Vizkopa Guildmage's second ability by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Cast Plunge into Darkness by paying {1}{B}, choosing to pay an amount of life equal to the greatest lifetotal among opponent, then look at that many cards from the top of your library, putting one into your hand and exiling the rest.
Activate Children of Korils by sacrificing it, causing you to gain life equal to the amount of life you've lost this turn.
Vizkopa Guildmage triggers, causing each opponent to lose life equal to the amount of life you gained.
Each opponent loses the game due to having zero or less life.

---

# 923-2615-5112

**Cards:**

- Mairsil, the Pretender
- Spikeshot Elder
- Tree of Perdition

**Produces:** Target opponent loses the game

**Mana: {1}{R}{R}, MV: 3, Colors: UBR, Popularity: 269**

**Steps:**

Activate Mairsil using Tree of Perdition's ability by tapping it, exchanging target opponent's life total with Mairsil's toughness.
Activate Mairsil using Spikeshot Elder's ability by paying {1}{R}{R}, dealing damage equal to Mairsil's power to the opponent.
The opponent loses the game due to having zero or less life.

---

# 92-3966

**Cards:**

- Exquisite Blood
- Vizkopa Guildmage

**Produces:** Infinite lifegain triggers, Infinite lifeloss, Infinite lifegain

**Mana: {1}{W}{B}, MV: 3, Colors: WB, Popularity: 11872**

**Steps:**

Activate Vizkopa Guildmage's second ability by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Gain life.
Vizkopa Guildmage triggers, causing each opponent to lose 1 life.
Exquisite Blood triggers for each opponent that lost life.
Resolve a Exquisite Blood trigger, gaining 1 life.
Repeat from step 3.

---

# 924-2452-2577

**Cards:**

- Gravecrawler
- Rooftop Storm
- Phyrexian Ghoul

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinitely large creature until end of turn, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: UB, Popularity: 846**

**Steps:**

Activate Phyrexian Ghoul's ability by sacrificing Gravecrawler, giving Phyrexian Ghoul +2/+2 until end of turn.
Cast Gravecrawler from your graveyard by paying {0}.
Repeat.

---

# 92-4624

**Cards:**

- Vizkopa Guildmage
- Revival // Revenge

**Produces:** Near-infinite lifeloss

**Mana: {5}{W}{W}{B}{B}, MV: 9, Colors: WB, Popularity: 6253**

**Steps:**

Activate Vizkopa Guildmage's second ability by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Cast Revenge by paying {4}{W}{B}, doubling your life total and causing target opponent to lose half their life, rounded up.
Vizkopa Guildmage triggers, causing each opponent to lose life equal to the life you gained.
Each opponent loses the game due to having zero or less life.

---

# 92-4996

**Cards:**

- Vizkopa Guildmage
- Beacon of Immortality

**Produces:** Near-infinite lifeloss

**Mana: {6}{W}{W}{B}, MV: 9, Colors: WB, Popularity: 5579**

**Steps:**

Activate Vizkopa Guildmage's second ability by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Cast Beacon of Immortality by paying {5}{W}, doubling your life total.
Vizkopa Guildmage triggers, causing each opponent to lose life equal to the life you gained.
Each opponent loses the game due to having zero or less life.

---

# 92-558-2298

**Cards:**

- Carrion Howler
- Vizkopa Guildmage
- Oketra's Last Mercy

**Produces:** Each opponent loses the game

**Mana: {2}{W}{W}{W}{B}, MV: 6, Colors: WB, Popularity: 10**

**Steps:**

Activate Vizkopa Guildmage by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Activate Carrion Howler by paying 1 life.
Repeat step 2 until you have one life.
Resolve all Carrion Howler abilities, giving itself +2/-1 for each ability.
Cast Oketra's Last Mercy by paying {1}{W}{W}, causing your life total to become forty.
Vizkopa Guildmage triggers, causing each opponent to lose thirty-nine life.
Each opponent loses the game due to having zero or less life.

---

# 926-1462

**Cards:**

- Enchanted Evening
- Aura Thief

**Produces:** Gain control of all permanents, Mass Land Denial

**Mana: , MV: 0, Colors: WU, Popularity: 3649**

**Steps:**

Kill Aura Thief.
Aura Thief triggers, causing you to gain control of all permanents.

---

# 933-1061-1869

**Cards:**

- Inalla, Archmage Ritualist
- Timestream Navigator
- Conjurer's Closet

**Produces:** Infinite turns, Lock

**Mana: {3}{U}{U} each turn, MV: 5, Colors: UBR, Popularity: 1230**

**Steps:**

At the beginning of your end step, Conjurer's Closet triggers, blinking Timestream Navigator.
If you don't have the city's blessing, Timestream Navigator's Ascend ability gives you the city's blessing.
When Timestream Navigator enters the battlefield, triggering Inalla, causing you to pay {1} to create a token copy of Timestream Navigator with haste.
Activate the Timestream Navigator token by paying {2}{U}{U}, tapping it, and putting it on the bottom of your library, causing you to take an extra turn after this one.
Repeat each turn.

---

# 933-1061-2506

**Cards:**

- Molten Echoes
- Timestream Navigator
- Conjurer's Closet

**Produces:** Infinite turns, Lock

**Mana: {2}{U}{U} each turn, MV: 4, Colors: UR, Popularity: 781**

**Steps:**

At the beginning of your end step, Conjurer's Closet triggers, blinking Timestream Navigator.
Timestream Navigator enters the battlefield, triggering Molten Echoes, creating a token copy of Timestream Navigator with haste.
Activate the token Timestream Navigator by paying {2}{U}{U}, tapping it and putting it on the bottom of your library, causing you to take an extra turn after this one.
Repeat each turn.

---

# 933-2103-2493

**Cards:**

- Conjurer's Closet
- Archaeomancer
- Capture of Jingzhou

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {3}{U}{U}, MV: 5, Colors: U, Popularity: 362**

**Steps:**

Cast Capture of Jingzhou by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Archaeomancer.
Archaeomancer enters the battlefield, returning Capture of Jingzhou from your graveyard to your hand.
Repeat.

---

# 933-2103-2556

**Cards:**

- Conjurer's Closet
- Mnemonic Wall
- Capture of Jingzhou

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {3}{U}{U}, MV: 5, Colors: U, Popularity: 76**

**Steps:**

Cast Capture of Jingzhou by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Mnemonic Wall.
Mnemonic Wall enters the battlefield, returning Capture of Jingzhou from your graveyard to your hand.
Repeat.

---

# 933-2104-2493

**Cards:**

- Conjurer's Closet
- Archaeomancer
- Temporal Manipulation

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {3}{U}{U}, MV: 5, Colors: U, Popularity: 916**

**Steps:**

Cast Temporal Manipulation by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Archaeomancer.
Archaeomancer enters the battlefield, returning Temporal Manipulation from your graveyard to your hand.
Repeat.

---

# 933-2104-2556

**Cards:**

- Conjurer's Closet
- Mnemonic Wall
- Temporal Manipulation

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {3}{U}{U}, MV: 5, Colors: U, Popularity: 153**

**Steps:**

Cast Temporal Manipulation by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Mnemonic Wall.
Mnemonic Wall enters the battlefield, returning Temporal Manipulation from your graveyard to your hand.
Repeat.

---

# 933-2493-3617

**Cards:**

- Conjurer's Closet
- Archaeomancer
- Time Walk

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {1}{U}, MV: 2, Colors: U, Popularity: 0**

**Steps:**

Cast Time Walk by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Archaeomancer.
Archaeomancer enters the battlefield, returning Time Walk from your graveyard to your hand.
Repeat.

---

# 933-2493-4377

**Cards:**

- Conjurer's Closet
- Archaeomancer
- Walk the Aeons

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {4}{U}{U}, MV: 6, Colors: U, Popularity: 279**

**Steps:**

Cast Walk the Aeons by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Archaeomancer.
Archaeomancer enters the battlefield, returning Walk the Aeons from your graveyard to your hand.
Repeat.

---

# 933-2493-4872

**Cards:**

- Conjurer's Closet
- Archaeomancer
- Time Warp

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {3}{U}{U}, MV: 5, Colors: U, Popularity: 1567**

**Steps:**

Cast Time Warp by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Archaeomancer.
Archaeomancer enters the battlefield, returning Time Warp from your graveyard to your hand.
Repeat.

---

# 933-2556-3617

**Cards:**

- Conjurer's Closet
- Mnemonic Wall
- Time Walk

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {1}{U}, MV: 2, Colors: U, Popularity: 0**

**Steps:**

Cast Time Walk by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Mnemonic Wall.
Mnemonic Wall enters the battlefield, returning Time Walk from your graveyard to your hand.
Repeat.

---

# 933-2556-4377

**Cards:**

- Conjurer's Closet
- Mnemonic Wall
- Walk the Aeons

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {4}{U}{U}, MV: 6, Colors: U, Popularity: 87**

**Steps:**

Cast Walk the Aeons by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Mnemonic Wall.
Mnemonic Wall enters the battlefield, returning Walk the Aeons from your graveyard to your hand.
Repeat.

---

# 933-2556-4872

**Cards:**

- Conjurer's Closet
- Mnemonic Wall
- Time Warp

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {3}{U}{U}, MV: 5, Colors: U, Popularity: 220**

**Steps:**

Cast Time Warp by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Mnemonic Wall.
Mnemonic Wall enters the battlefield, returning Time Warp from your graveyard to your hand.
Repeat.

---

# 933-2724-3194

**Cards:**

- Wormfang Manta
- Hushwing Gryff
- Conjurer's Closet

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: WU, Popularity: 37**

**Steps:**

At the beginning of your end step Conjurer's Closet triggers, exiling Wormfang Manta and returns it to the battlefield.
On LTB Wormfang Manta triggers, giving you an extra turn.
On ETB Hushwing Gryff prevents Wormfang Manta's trigger, so you do not skip your next turn.
Take your extra turn.

---

# 933-2724-3987

**Cards:**

- Wormfang Manta
- Torpor Orb
- Conjurer's Closet

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: U, Popularity: 24**

**Steps:**

At the beginning of your end step Conjurer's Closet triggers, exiling Wormfang Manta and returns it to the battlefield.
On LTB Wormfang Manta triggers, giving you an extra turn.
On ETB Torpor Orb prevents Wormfang Manta's trigger, so you do not skip your next turn.
Take your extra turn.

---

# 933-2724-4006

**Cards:**

- Wormfang Manta
- Hushbringer
- Conjurer's Closet

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: WU, Popularity: 13**

**Steps:**

At the beginning of your end step Conjurer's Closet triggers, exiling Wormfang Manta and returns it to the battlefield.
On LTB Wormfang Manta triggers, giving you an extra turn.
On ETB Hushbringer prevents Wormfang Manta's trigger, so you do not skip your next turn.
Take your extra turn.

---

# 933-957-2493

**Cards:**

- Conjurer's Closet
- Archaeomancer
- Time Stretch

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {8}{U}{U}, MV: 10, Colors: U, Popularity: 424**

**Steps:**

Cast Time Stretch by paying {8}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Archaeomancer.
Archaeomancer enters the battlefield, returning Time Stretch from your graveyard to your hand.
Repeat.

---

# 933-957-2556

**Cards:**

- Conjurer's Closet
- Mnemonic Wall
- Time Stretch

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {8}{U}{U}, MV: 10, Colors: U, Popularity: 47**

**Steps:**

Cast Time Stretch by paying {8}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Mnemonic Wall.
Mnemonic Wall enters the battlefield, returning Time Stretch from your graveyard to your hand.
Repeat.

---

# 936-1290

**Cards:**

- Bloodchief Ascension
- Mindcrank

**Produces:** Infinite mill, Near-infinite lifegain, Near-infinite lifegain triggers, Near-infinite lifeloss

**Mana: , MV: 0, Colors: B, Popularity: 53134**

**Steps:**

Cause one or more opponents to lose life.
Mindcrank triggers once for each life loss event, causing that player to mill cards equal to the amount of life lost.
Bloodchief Ascension triggers once for each card milled, causing that player to lose 2 life and you to gain 2 life for each trigger.
Repeat from step 2.

---

# 936-5069

**Cards:**

- Duskmantle Guildmage
- Mindcrank

**Produces:** Each opponent loses the game, Infinite mill, Near-infinite lifeloss

**Mana: {1}{U}{B} plus an additional {2}{U}{B} for each opponent you have, MV: 3, Colors: UB, Popularity: 17061**

**Steps:**

Activate Duskmantle Guildmage's first ability by paying {1}{U}{B}, causing your opponent to lose life whenever a card is put into their graveyard this turn.
Activate Duskmantle Guildmage's second ability by paying {2}{U}{B}, causing an opponent to mill two cards.
Duskmantle Guildmage triggers twice.
Resolve the first trigger, causing the opponent to lose 1 life.
Mindcrank triggers, causing the opponent to mill a card.
Duskmantle Guildmage triggers, causing the opponent to lose 1 life.
Repeat from step 5 until the opponent has a life total of zero, causing them to lose the game.
Repeat from step 2 for each other opponent.

---

# 937-2358-4551

**Cards:**

- Phyrexian Unlife
- Magus of the Mirror
- Blood Celebrant

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WB, Popularity: 318**

**Steps:**

During your upkeep, activate Blood Celebrant by paying {B} and one life, adding {B}.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-2358-4591

**Cards:**

- Platinum Angel
- Magus of the Mirror
- Blood Celebrant

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: B, Popularity: 371**

**Steps:**

During your upkeep, activate Blood Celebrant by paying {B} and one life, adding {B}.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-2358-4695

**Cards:**

- Soul Echo
- Magus of the Mirror
- Blood Celebrant

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WB, Popularity: 51**

**Steps:**

During your upkeep, activate Blood Celebrant by paying {B} and one life, adding {B}.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-2749-4551

**Cards:**

- Phyrexian Unlife
- Magus of the Mirror
- Wall of Blood

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WB, Popularity: 631**

**Steps:**

During your upkeep, activate Wall of Blood by paying 1 life, giving Wall of Blood +1/+1 until end of turn.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-2749-4591

**Cards:**

- Platinum Angel
- Magus of the Mirror
- Wall of Blood

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: B, Popularity: 986**

**Steps:**

During your upkeep, activate Wall of Blood by paying 1 life, giving Wall of Blood +1/+1 until end of turn.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-2749-4695

**Cards:**

- Soul Echo
- Magus of the Mirror
- Wall of Blood

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WB, Popularity: 66**

**Steps:**

During your upkeep, activate Wall of Blood by paying 1 life, giving Wall of Blood +1/+1 until end of turn.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-2935-4551

**Cards:**

- Phyrexian Unlife
- Magus of the Mirror
- Ethereal Champion

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WB, Popularity: 12**

**Steps:**

During your upkeep, activate Ethereal Champion by paying 1 life, preventing the next one damage that will be dealt to Ethereal Champion this turn.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-2935-4591

**Cards:**

- Platinum Angel
- Magus of the Mirror
- Ethereal Champion

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WB, Popularity: 17**

**Steps:**

During your upkeep, activate Ethereal Champion by paying 1 life, preventing the next one damage that will be dealt to Ethereal Champion this turn.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-2935-4695

**Cards:**

- Soul Echo
- Magus of the Mirror
- Ethereal Champion

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WB, Popularity: 5**

**Steps:**

During your upkeep, activate Ethereal Champion by paying 1 life, preventing the next one damage that will be dealt to Ethereal Champion this turn.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-3591-4551

**Cards:**

- Phyrexian Unlife
- Magus of the Mirror
- Necropotence

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WB, Popularity: 377**

**Steps:**

During your upkeep, activate Necropotence by paying 1 life, exiling the top card of your library face down.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-3591-4591

**Cards:**

- Platinum Angel
- Magus of the Mirror
- Necropotence

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: B, Popularity: 543**

**Steps:**

During your upkeep, activate Necropotence by paying 1 life, exiling the top card of your library face down.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-3591-4695

**Cards:**

- Soul Echo
- Magus of the Mirror
- Necropotence

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WB, Popularity: 50**

**Steps:**

During your upkeep, activate Necropotence by paying 1 life, exiling the top card of your library face down.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-3859-4551

**Cards:**

- Phyrexian Unlife
- Magus of the Mirror
- Cavern Harpy

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WUB, Popularity: 3**

**Steps:**

During your upkeep, activate Cavern Harpy by paying 1 life.
Repeat step 1 until you have zero life.
Resolve the last Cavern Harpy trigger, returning it to your hand.
The remaining Cavern Harpy triggers fizzle.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-3859-4591

**Cards:**

- Platinum Angel
- Magus of the Mirror
- Cavern Harpy

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: UB, Popularity: 5**

**Steps:**

During your upkeep, activate Cavern Harpy by paying 1 life.
Repeat step 1 until you have zero life.
Resolve the last Cavern Harpy trigger, returning it to your hand.
The remaining Cavern Harpy triggers fizzle.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-3859-4695

**Cards:**

- Soul Echo
- Magus of the Mirror
- Cavern Harpy

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WUB, Popularity: 1**

**Steps:**

During your upkeep, activate Cavern Harpy by paying 1 life.
Repeat step 1 until you have zero life.
Resolve the last Cavern Harpy trigger, returning it to your hand.
The remaining Cavern Harpy triggers fizzle.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 940-2178-3500

**Cards:**

- Thornbite Staff
- Arcane Teachings
- Basilisk Collar

**Produces:** Destroy all creatures opponents control, Destroy all creatures opponents control whenever a creature enters the battlefield, Lock

**Mana: , MV: 0, Colors: R, Popularity: 51**

**Steps:**

Activate the creature by tapping it, dealing 1 damage to any opponent's creature and causing you to gain 1 life.
The opponent's creature dies due to deathtouch, triggering Thornbite Staff, untapping your creature.
Repeat.

---

# 9-411-1283-2500-4600

**Cards:**

- Chromatic Orrery
- Grinning Ignus
- Mirage Mirror
- Grapeshot
- Mirror Gallery

**Produces:** Infinite damage, Infinite storm count

**Mana: , MV: 0, Colors: R, Popularity: 3**

**Steps:**

Tap Orrery for 5 mana.
Tap 2 mana to activate mirror, targeting grinning ignus.
In response, activate mirror again targeting orrery.
tap mirror for 5 mana before letting it become an ignus.
Use one mana to return mirror to your hand using ignus's ability.
this adds 3 to your mana pool.
8 floating.
cast mirror from your hand, 5 floating.
Repeat.
Cast grapeshot for Infinite damage.

---

# 9-411-2500-2604-5116

**Cards:**

- Ugin, the Ineffable
- Grinning Ignus
- Mirage Mirror
- Gilded Lotus
- Grapeshot

**Produces:** Infinite damage, Infinite magecraft triggers, Infinite storm count

**Mana: {1}, MV: 1, Colors: R, Popularity: 5**

**Steps:**

Activate Gilded Lotus by tapping it, adding {3}.
Activate Mirage Mirror twice by paying {4}, targeting Grinning Ignus and Gilded Lotus.
Resolve the first Mirage Mirror ability, causing it to become a copy of Gilded Lotus until end of turn.
Activate Mirage Mirror by tapping it, adding {R}{R}{R}.
Resolve the second Mirage Mirror ability, causing it to become a copy of Grinning Ignus until end of turn.
Activate Mirage Mirror by paying {R} and returning it to your hand, adding {C}{C}{R}.
Cast Mirage Mirror by paying {1}.
Repeat from step 2 until you have a very large storm count.
Cast Grapeshot by paying {1}{R}.
Grapeshot's storm ability triggers, creating a copy of Grapeshot for each spell you've cast this turn.
Resolve all Grapeshots, dealing infinite damage to any target(s).

---

# 943-1556-4235

**Cards:**

- Rings of Brighthearth
- Deserted Temple
- Scorched Ruins

**Produces:** Infinite colorless mana, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: , MV: 0, Colors: C, Popularity: 3004**

**Steps:**

Activate Scorched Ruins by tapping it, adding {C}{C}{C}{C}.
Activate Deserted Temple's second ability by paying {1} and tapping it, targeting Scorched Ruins.
Rings of Brighthearth triggers, causing you to pay {2} to copy Deserted Temple's ability, targeting Deserted Temple.
Resolve both Deserted Temple abilities, untapping Deserted Temple and Scorched Ruins.
Repeat an arbitrarily large number of times.
Once you have a large amount of {C}, you may untap any other lands you control in place of Scorched Ruins.

---

# 944-4050-4242-5105

**Cards:**

- Sigil of the New Dawn
- Phyrexian Altar
- Su-Chi
- Planar Gate

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: W, Popularity: 2**

**Steps:**

Activate Phyrexian Altar by sacrificing Su-Chi, adding {W}.
Su-Chi dies, triggering itself and Sigil of New Dawn.
Resolve the Su-Chi trigger, adding {C}{C}{C}{C}.
Resolve the Sigil of New Dawn trigger, causing you to pay {1}{W} to return Su-Chi from your graveyard to your hand.
Cast Su-Chi by paying {1}.
Repeat.

---

# 944-4050-5004-5105

**Cards:**

- Sigil of the New Dawn
- Phyrexian Altar
- Cathodion
- Planar Gate

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: W, Popularity: 0**

**Steps:**

Activate Phyrexian Altar by sacrificing Cathodion, adding {W}.
Cathodion dies, triggering itself and Sigil of New Dawn.
Resolve the Cathodion trigger, adding {C}{C}{C}.
Resolve the Sigil of New Dawn trigger, causing you to pay {1}{W} to return Cathodion from your graveyard to your hand.
Cast Cathodion by paying {1}.
Repeat.

---

# 949-1343-2686

**Cards:**

- Kaervek's Spite
- Academy Rector
- Barren Glory

**Produces:** Win the game

**Mana: {B}{B}{B}, MV: 3, Colors: WB, Popularity: 258**

**Steps:**

During the end step before your turn, cast Kaervek's Spite by paying {B}{B}{B}, discarding your hand, and sacrificing all permanents.
Academy Rector triggers, exiling itself and searching your library for Barren Glory, putting it onto the battlefield, and shuffling your library.
Resolve Kaervek's Spite, causing target player to lose five life.
At the beginning of your upkeep, Barren Glory triggers, causing you to win the game.

---

# 950-1584-3525

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Teferi's Isle

**Produces:** Infinite blue mana, Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: U, Popularity: 39**

**Steps:**

Activate Teferi's Isle by tapping it, adding {U}{U}.
Activate Fatestitcher by tapping it, untapping Teferi's Isle.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-1584-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Teferi's Isle

**Produces:** Infinite blue mana, Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: U, Popularity: 41**

**Steps:**

Activate Teferi's Isle by tapping it, adding {U}{U}.
Activate Fatestitcher by tapping it, untapping Teferi's Isle.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-1671-3525

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Simic Growth Chamber

**Produces:** Infinite green mana, Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: GU, Popularity: 377**

**Steps:**

Activate Simic Growth Chamber by tapping it, adding {U}{G}.
Activate Fatestitcher by tapping it, untapping Simic Growth Chamber.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-1671-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Simic Growth Chamber

**Produces:** Infinite green mana, Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: GU, Popularity: 568**

**Steps:**

Activate Simic Growth Chamber by tapping it, adding {U}{G}.
Activate Fatestitcher by tapping it, untapping Simic Growth Chamber.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-2605-3525

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Lotus Vale

**Produces:** Infinite colored mana

**Mana: , MV: 0, Colors: U, Popularity: 220**

**Steps:**

Activate Lotus Vale by tapping it, adding {U}{U}{U}.
Activate Fatestitcher by tapping it, untapping Lotus Vale.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.
Repeat steps with a different color for infinite mana of any color.

---

# 950-2605-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Lotus Vale

**Produces:** Infinite colored mana

**Mana: , MV: 0, Colors: U, Popularity: 222**

**Steps:**

Activate Lotus Vale by tapping it, adding {U}{U}{U}.
Activate Fatestitcher by tapping it, untapping Lotus Vale.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.
Repeat steps with a different color for infinite mana of any color.

---

# 950-3078-3525

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Soldevi Excavations

**Produces:** Infinite colorless mana

**Mana: , MV: 0, Colors: U, Popularity: 109**

**Steps:**

Activate Soldevi Excavations by tapping it, adding {C}{U}.
Activate Fatestitcher by tapping it, untapping Soldevi Excavations.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3078-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Soldevi Excavations

**Produces:** Infinite colorless mana

**Mana: , MV: 0, Colors: U, Popularity: 115**

**Steps:**

Activate Soldevi Excavations by tapping it, adding {C}{U}.
Activate Fatestitcher by tapping it, untapping Soldevi Excavations.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3147-3525

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Azorius Chancery

**Produces:** Infinite white mana, Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: WU, Popularity: 571**

**Steps:**

Activate Azorius Chancery by tapping it, adding {W}{U}.
Activate Fatestitcher by tapping it, untapping Azorius Chancery.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3147-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Azorius Chancery

**Produces:** Infinite white mana, Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: WU, Popularity: 815**

**Steps:**

Activate Azorius Chancery by tapping it, adding {W}{U}.
Activate Fatestitcher by tapping it, untapping Azorius Chancery.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3201-3525

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Arixmethes, Slumbering Isle

**Produces:** Infinite green mana

**Mana: , MV: 0, Colors: GU, Popularity: 89**

**Steps:**

Activate Arixmethes by tapping it, adding {U}{G}.
Activate Fatestitcher by tapping it, untapping Arixmethes.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3201-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Arixmethes, Slumbering Isle

**Produces:** Infinite green mana

**Mana: , MV: 0, Colors: GU, Popularity: 123**

**Steps:**

Activate Arixmethes by tapping it, adding {U}{G}.
Activate Fatestitcher by tapping it, untapping Arixmethes.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3230-3525

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Coral Atoll

**Produces:** Infinite colorless mana, Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: U, Popularity: 290**

**Steps:**

Activate Coral Atoll by tapping it, adding {C}{U}.
Activate Fatestitcher by tapping it, untapping Coral Atoll.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3230-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Coral Atoll

**Produces:** Infinite colorless mana, Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: U, Popularity: 351**

**Steps:**

Activate Coral Atoll by tapping it, adding {C}{U}.
Activate Fatestitcher by tapping it, untapping Coral Atoll.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3478-3525

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Dimir Aqueduct

**Produces:** Infinite black mana, Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: UB, Popularity: 734**

**Steps:**

Activate Dimir Aqueduct by tapping it, adding {U}{B}.
Activate Fatestitcher by tapping it, untapping Dimir Aqueduct.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3478-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Dimir Aqueduct

**Produces:** Infinite black mana, Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: UB, Popularity: 921**

**Steps:**

Activate Dimir Aqueduct by tapping it, adding {U}{B}.
Activate Fatestitcher by tapping it, untapping Dimir Aqueduct.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3525-3573

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Tolarian Academy

**Produces:** Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: U, Popularity: 0**

**Steps:**

Activate Tolarian Academy by tapping it, adding at least {U}{U}.
Activate Fatestitcher by tapping it, untapping Tolarian Academy.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3525-3664

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Lotus Field

**Produces:** Infinite colored mana, Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: U, Popularity: 573**

**Steps:**

Activate Lotus Field by tapping it, adding {U}{U}{U}.
Activate Fatestitcher by tapping it, untapping Lotus Field.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.
Repeat steps with a different color for infinite mana of any color.

---

# 950-3525-3756

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Izzet Boilerworks

**Produces:** Infinite red mana, Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: UR, Popularity: 310**

**Steps:**

Activate Izzet Boilerworks by tapping it, adding {U}{R}.
Activate Fatestitcher by tapping it, untapping Izzet Boilerworks.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3573-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Tolarian Academy

**Produces:** Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: U, Popularity: 0**

**Steps:**

Activate Tolarian Academy by tapping it, adding at least {U}{U}.
Activate Fatestitcher by tapping it, untapping Tolarian Academy.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3664-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Lotus Field

**Produces:** Infinite colored mana, Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: U, Popularity: 665**

**Steps:**

Activate Lotus Field by tapping it, adding {U}{U}{U}.
Activate Fatestitcher by tapping it, untapping Lotus Field.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.
Repeat steps with a different color for infinite mana of any color.

---

# 950-3756-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Izzet Boilerworks

**Produces:** Infinite red mana, Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: UR, Popularity: 547**

**Steps:**

Activate Izzet Boilerworks by tapping it, adding {U}{R}.
Activate Fatestitcher by tapping it, untapping Izzet Boilerworks.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 95-1848

**Cards:**

- Bruvac the Grandiloquent
- Fleet Swallower

**Produces:** Infinite mill for target opponent, Near-infinite self-mill

**Mana: , MV: 0, Colors: U, Popularity: 14066**

**Steps:**

Declare Fleet Swallower as an attacker, triggering its ability, causing an opponent to mill their library due to Bruvac.

---

# 953-1139-1371

**Cards:**

- Hive Mind
- Enter the Infinite
- Howling Mine

**Produces:** Each opponent loses the game, Infinite card draw, Infinite card draw for each opponent, Infinite draw triggers, Infinite draw triggers for each opponent

**Mana: {8}{U}{U}{U}{U}, MV: 12, Colors: U, Popularity: 333**

**Steps:**

Cast Enter the Infinite by paying {8}{U}{U}{U}{U}.
Hive Mind triggers, causing each opponent to create a copy of Enter the Infinite.
Resolve each Enter the Infinite, causing each player to draw their entire library, put a card from their hand on top of their library, and have no maximum hand size until their next turn.
At the beginning of each opponent's draw step, Howling Mine triggers, causing them to draw an additional card and lose the game due to drawing from an empty library.

---

# 953-1371-2065

**Cards:**

- Hive Mind
- Enter the Infinite
- Dictate of Kruphix

**Produces:** Each opponent loses the game, Infinite card draw, Infinite card draw for each opponent, Infinite draw triggers, Infinite draw triggers for each opponent

**Mana: {8}{U}{U}{U}{U}, MV: 12, Colors: U, Popularity: 270**

**Steps:**

Cast Enter the Infinite by paying {8}{U}{U}{U}{U}.
Hive Mind triggers, causing each opponent to create a copy of Enter the Infinite.
Resolve each Enter the Infinite, causing each player to draw their entire library, put a card from their hand on top of their library, and have no maximum hand size until their next turn.
At the beginning of each opponent's draw step, Dictate of Kruphix triggers, causing them to draw an additional card and lose the game due to drawing from an empty library.

---

# 953-1371-2870

**Cards:**

- Hive Mind
- Enter the Infinite
- Anvil of Bogardan

**Produces:** Each opponent loses the game, Infinite card draw, Infinite card draw for each opponent, Infinite draw triggers, Infinite draw triggers for each opponent

**Mana: {8}{U}{U}{U}{U}, MV: 12, Colors: U, Popularity: 76**

**Steps:**

Cast Enter the Infinite by paying {8}{U}{U}{U}{U}.
Hive Mind triggers, causing each opponent to create a copy of Enter the Infinite.
Resolve each Enter the Infinite, causing each player to draw their entire library, put a card from their hand on top of their library, and have no maximum hand size until their next turn.
At the beginning of each opponent's draw step, Anvil of Bogardan triggers, causing them to draw an additional card, discard a card and lose the game due to drawing from an empty library.

---

# 953-1371-3032

**Cards:**

- Hive Mind
- Enter the Infinite
- Kami of the Crescent Moon

**Produces:** Each opponent loses the game, Infinite card draw, Infinite card draw for each opponent, Infinite draw triggers, Infinite draw triggers for each opponent

**Mana: {8}{U}{U}{U}{U}, MV: 12, Colors: U, Popularity: 293**

**Steps:**

Cast Enter the Infinite by paying {8}{U}{U}{U}{U}.
Hive Mind triggers, causing each opponent to create a copy of Enter the Infinite.
Resolve each Enter the Infinite, causing each player to draw their entire library, put a card from their hand on top of their library, and have no maximum hand size until their next turn.
At the beginning of each opponent's draw step, Kami triggers, causing them to draw an additional card and lose the game due to drawing from an empty library.

---

# 954-2034-2302-4215

**Cards:**

- Verdant Succession
- Angel of Fury
- Ashnod's Altar
- Painter's Servant

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: GW, Popularity: 1**

**Steps:**

Activate Ashnod's Altar by sacrificing Angel of Fury, adding {C}{C}.
Angel of Fury and Verdant Succession trigger.
Resolve the Angel of Fury trigger, shuffling it into your library.
Resolve the Verdant Succession trigger, searching your library for Angel of Fury, putting it onto the battlefield and shuffling your library.
Repeat.

---

# 954-2302-4050-4215

**Cards:**

- Verdant Succession
- Angel of Fury
- Phyrexian Altar
- Painter's Servant

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: GW, Popularity: 1**

**Steps:**

Activate Phyrexian Altar by sacrificing Angel of Fury, adding one mana of any color.
Angel of Fury and Verdant Succession trigger.
Resolve the Angel of Fury trigger, shuffling it into your library.
Resolve the Verdant Succession trigger, searching your library for Angel of Fury, putting it onto the battlefield and shuffling your library.
Repeat.

---

# 954-2302-4215-5256

**Cards:**

- Verdant Succession
- Angel of Fury
- Altar of Dementia
- Painter's Servant

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: GW, Popularity: 0**

**Steps:**

Activate Altar of Dementia by sacrificing Angel of Fury.
Angel of Fury and Verdant Succession trigger.
Resolve the Angel of Fury trigger, shuffling it into your library.
Resolve the Verdant Succession trigger, searching your library for Angel of Fury, putting it onto the battlefield and shuffling your library.
Resolve the Altar of Dementia ability from step 1, causing target player to mill cards equal to Angel of Fury's power.
Repeat.

---

# 95-5080

**Cards:**

- Bruvac the Grandiloquent
- Maddening Cacophony

**Produces:** Infinite mill

**Mana: {4}{U}{U}, MV: 6, Colors: U, Popularity: 46331**

**Steps:**

Cast Maddening Cacophony with kicker by paying {4}{U}{U}, causing each opponent to mill their library due to Bruvac.

---

# 957-1271-3212

**Cards:**

- God-Eternal Kefnet
- Scroll Rack
- Time Stretch

**Produces:** Infinite turns, Lock

**Mana: {7}{U}{U} each turn, MV: 9, Colors: U, Popularity: 201**

**Steps:**

Tap Scroll Rack and pay {1} to activate it, putting Time Stretch on top of your library.
Pass the turn.
On your next draw step, when you draw Time Stretch, reveal it due to Kefnet's ability, making a copy that costs {2} less to cast.
Cast the copy for {6}{U}{U}, granting you two extra turns.

---

# 957-1702-3212

**Cards:**

- God-Eternal Kefnet
- Jace, the Mind Sculptor
- Time Stretch

**Produces:** Infinite turns, Lock

**Mana: {6}{U}{U} each turn, MV: 8, Colors: U, Popularity: 133**

**Steps:**

Activate Jace's zero loyalty ability, putting Time Stretch on top of your library.
Move to your next turn.
On your next draw step, when you draw Time Stretch, reveal it due to Kefnet's ability, making a copy that costs {2} less to cast.
Cast the copy for {6}{U}{U}, granting you two extra turns.

---

# 957-2334-2493

**Cards:**

- Soulherder
- Archaeomancer
- Time Stretch

**Produces:** Infinite turns, Lock

**Mana: {8}{U}{U} every other turn, MV: 10, Colors: WU, Popularity: 113**

**Steps:**

With Soulherder and a creature based spell recursion effect on the battlefield, cast the extra turn spell.
Move to end step and target the creature with Soulherder's ability.
When creature re-enters the battlefield, target the extra turn spell in your graveyard and return it to your hand, then pass to yourself.
Repeat

---

# 957-2334-2556

**Cards:**

- Soulherder
- Mnemonic Wall
- Time Stretch

**Produces:** Infinite turns, Lock

**Mana: {8}{U}{U} every other turn, MV: 10, Colors: WU, Popularity: 15**

**Steps:**

With Soulherder and a creature based spell recursion effect on the battlefield, cast the extra turn spell.
Move to end step and target the creature with Soulherder's ability.
When creature re-enters the battlefield, target the extra turn spell in your graveyard and return it to your hand, then pass to yourself.
Repeat

---

# 957-2493-4428

**Cards:**

- Thassa, Deep-Dwelling
- Archaeomancer
- Time Stretch

**Produces:** Infinite turns, Lock

**Mana: {8}{U}{U} every other turn, MV: 10, Colors: U, Popularity: 717**

**Steps:**

Cast Time Stretch by paying {8}{U}{U}, getting two extra turns after this one.
At the beginning of your end step, Thassa triggers, blinking Archaeomancer.
Archaeomancer enters the battlefield, returning Time Stretch from your graveyard to your hand.
Repeat every other turn.

---

# 957-2556-4305

**Cards:**

- Mnemonic Wall
- Followed Footsteps
- Time Stretch

**Produces:** Infinite turns, Lock

**Mana: {8}{U}{U} each turn, MV: 10, Colors: U, Popularity: 4**

**Steps:**

Cast Time Stretch by paying {8}{U}{U}, taking two extra turns after this one.
At the beginning of your upkeep on your next extra turn, Followed Footsteps triggers, creating a token copy of Mnemonic Wall.
Mnemonic Wall enters the battlefield, returning Time Stretch from your graveyard to your hand.
Repeat each turn.

---

# 957-2556-4428

**Cards:**

- Thassa, Deep-Dwelling
- Mnemonic Wall
- Time Stretch

**Produces:** Infinite turns, Lock

**Mana: {8}{U}{U} every other turn, MV: 10, Colors: U, Popularity: 53**

**Steps:**

Cast Time Stretch by paying {8}{U}{U}, getting two extra turns after this one.
At the beginning of your end step, Thassa triggers, blinking Mnemonic Wall.
Mnemonic Wall enters the battlefield, returning Time Stretch from your graveyard to your hand.
Repeat every other turn.

---

# 958-1750-2365-5261

**Cards:**

- Isochron Scepter
- Pull from Eternity
- Dralnu, Lich Lord
- Expropriate

**Produces:** Infinite turns, Lock

**Mana: {9}{U}{U} each turn, MV: 11, Colors: WUB, Popularity: 0**

**Steps:**

Cast Expropriate by paying {7}{U}{U}, causing you to take at least one extra turn after this one and exile Expropriate.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Pull from Eternity without paying its mana cost.
Resolve Pull from Eternity, putting Expropriate into your graveyard from exile.
Move to your next turn.
Activate Dralnu by tapping it, giving Expropriate flashback until end of turn.
Cast Expropriate from your graveyard by paying {7}{U}{U}, causing you to take an extra turn after this one and exile Expropriate.
Repeat from step 2.

---

# 958-1750-2575-5261

**Cards:**

- Isochron Scepter
- Pull from Eternity
- Dralnu, Lich Lord
- Temporal Mastery

**Produces:** Infinite turns, Lock

**Mana: {7}{U}{U} each turn, MV: 9, Colors: WUB, Popularity: 0**

**Steps:**

Cast Temporal Mastery by paying {5}{U}{U}, causing you to take an extra turn after this one and exile Temporal Mastery.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Pull from Eternity without paying its mana cost.
Resolve Pull from Eternity, putting Temporal Mastery into your graveyard from exile.
Move to your next turn.
Activate Dralnu by tapping it, giving Temporal Mastery flashback until end of turn.
Cast Temporal Mastery from your graveyard by paying {5}{U}{U}, causing you to take an extra turn after this one and exile Temporal Mastery.
Repeat from step 2.

---

# 958-1750-4084-5261

**Cards:**

- Isochron Scepter
- Pull from Eternity
- Dralnu, Lich Lord
- Part the Waterveil

**Produces:** Lock, Infinite turns

**Mana: {6}{U}{U} each turn, MV: 8, Colors: WUB, Popularity: 0**

**Steps:**

Cast Part the Waterveil by paying {4}{U}{U}, causing you to take an extra turn after this one and exile Part the Waterveil.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Pull from Eternity without paying its mana cost.
Resolve Pull from Eternity, putting Part the Waterveil into your graveyard from exile.
Move to your next turn.
Activate Dralnu by tapping it, giving Part the Waterveil flashback until end of turn.
Cast Part the Waterveil from your graveyard by paying {4}{U}{U}, causing you to take an extra turn after this one and exile Part the Waterveil.
Repeat from step 2.

---

# 968-2660-4772

**Cards:**

- Jace, Architect of Thought
- Wheel of Sun and Moon
- Doubling Season

**Produces:** Cast any number of spells from opponents' libraries, Infinite storm count

**Mana: {2}{U}{U}, MV: 4, Colors: GWU, Popularity: 63**

**Steps:**

Cast Jace, Architect of Thought for {2}{U}{U} which enters with 8 loyalty counters due to Doubling Season.
Activate Jace's -8, putting it on the bottom of your library.
Search you library for Jace and exile it, and exile a nonland card of your choice.
Cast Jace along with any of the nonland cards you wish to cast.
Repeat from step 2.

---

# 969-1991-3259

**Cards:**

- Tana, the Bloodsower
- Breath of Fury
- Fervor

**Produces:** Infinite combat damage, Infinite combat phases, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mana creatures you control can produce, Infinite sacrifice triggers, Infinite untap of creatures you control, Infinite creature tokens with haste

**Mana: , MV: 0, Colors: RG, Popularity: 21**

**Steps:**

Deal combat damage with Tana and the creature that has Breath of Fury attached.
Tana and Breath of Fury triggers.
Resolve the Tana trigger, creating a number of 1/1 Saproling creature tokens equal to the damage Tana dealt.
Resolve the Breath of Fury trigger, causing you to sacrifice the creature it is attached to, attach Breath of Fury to a Saproling token, untap all creatures you control and get an additional combat phase after this one.
Repeat.

---

# 971-2034-3048-5003

**Cards:**

- Roalesk, Apex Hybrid
- Ashnod's Altar
- Nim Deathmantle
- Pentad Prism

**Produces:** Infinite ETB, Infinite LTB, Infinite proliferate

**Mana: , MV: 0, Colors: GU, Popularity: 1**

**Steps:**

Sacrifice Roalesk to Ashnod's Altar generating two colorless, with Roalesk's death you proliferate twice, putting two more counters on Pentad Prism.
Remove those counters for two mana, use the other two mana from Ashnod's to return Roalesk to the battlefield using Nim Deathmantle.
Repeat.

---

# 972-1061-1953

**Cards:**

- Brudiclad, Telchor Engineer
- Timestream Navigator
- Saheeli's Artistry

**Produces:** Lock, Infinite turns

**Mana: {6}{U}{U}{U}{U} on your first turn, with {2}{U}{U} available on each extra turn, MV: 10, Colors: UR, Popularity: 162**

**Steps:**

Cast Saheeli's Artistry by paying {4}{U}{U}, creating a token copy of Timestream Navigator.
At the beginning of your combat phase, Brudiclad triggers, creating a 2/1 Phyrexian Myr creature token, then choosing to have all tokens you control become copies of the Timestream Navigator token.
Activate Timestream Navigator by paying {2}{U}{U} and tapping it and putting it onto the bottom of your library, causing you to take an extra turn after this one.
Move to your next turn.
Repeat from step 2.

---

# 972-1953-2105

**Cards:**

- Brudiclad, Telchor Engineer
- Combat Celebrant
- Saheeli's Artistry

**Produces:** Infinite combat phases, Infinite damage

**Mana: {4}{U}{U}, MV: 6, Colors: UR, Popularity: 470**

**Steps:**

Cast Saheeli's Artistry by paying {4}{U}{U}, creating a token copy of Combat Celebrant.
At the beginning of your combat phase, Brudiclad triggers, creating a 2/1 Phyrexian Myr creature token, then choosing to have all tokens you control become copies of the Combat Celebrant token.
Declare one of the Combat Celebrant copy as an attacker, choosing to exert it as it attacks.
The Combat Celebrant copy triggers, untapping all other creatures you control and causing you to get an additional combat phase after this one.
Repeat from step 2.

---

# 976-1029-2428-3990-4435

**Cards:**

- Greed
- Horizon Chimera
- Alhammarret's Archive
- Incubation Druid
- Tolarian Kraken

**Produces:** Infinite card draw, Infinite draw triggers, Near-infinite colored mana, Near-infinite lifegain, Near-infinite lifegain triggers

**Mana: , MV: 0, Colors: BGU, Popularity: 0**

**Steps:**

Activate Incubation Druid by tapping it, adding {B}{B}{B}.
Activate Greed by paying {B} and two life, causing you to draw two cards.
Horizon Chimera and Tolarian Kraken each trigger twice.
Resolve both Horizon Chimera triggers, causing you to gain four life.
Resolve the first Tolarian Kraken trigger, choosing not to pay.
Resolve the second Tolarian Kraken trigger, causing you to pay {1} to untap Incubation Druid.
Repeat.

---

# 976-1029-2428-3990-5042

**Cards:**

- Greed
- Horizon Chimera
- Teferi's Ageless Insight
- Incubation Druid
- Tolarian Kraken

**Produces:** Infinite card draw, Infinite draw triggers, Near-infinite colored mana

**Mana: , MV: 0, Colors: BGU, Popularity: 0**

**Steps:**

Activate Incubation Druid by tapping it, adding {B}{B}{B}.
Activate Greed by paying {B} and two life, causing you to draw two cards.
Horizon Chimera and Tolarian Kraken each trigger twice.
Resolve both Horizon Chimera triggers, causing you to gain two life.
Resolve the first Tolarian Kraken trigger, choosing not to pay.
Resolve the second Tolarian Kraken trigger, causing you to pay {1} to untap Incubation Druid.
Repeat.

---

# 978-1429-2034

**Cards:**

- Vizier of Remedies
- Lesser Masticore
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: W, Popularity: 313**

**Steps:**

Activate Ashnod's Altar by sacrificing Lesser Manticore, adding {C}{C}.
Lesser Manticore's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Repeat.

---

# 978-1429-4050

**Cards:**

- Vizier of Remedies
- Lesser Masticore
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: W, Popularity: 233**

**Steps:**

Activate Phyrexian Altar by sacrificing Lesser Manticore, adding one mana of any color.
Lesser Manticore's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Repeat.

---

# 978-1429-5256

**Cards:**

- Vizier of Remedies
- Lesser Masticore
- Altar of Dementia

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: W, Popularity: 377**

**Steps:**

Activate Altar of Dementia by sacrificing Lesser Manticore.
Lesser Manticore's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Resolve the Altar of Dementia ability, causing target player to mill cards equal to Lesser Manticore's power.
Repeat.

---

# 978-2034-2086

**Cards:**

- Vizier of Remedies
- Kitchen Finks
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: GW, Popularity: 571**

**Steps:**

Activate Ashnod's Altar by sacrificing Kitchen Finks, adding {C}{C}.
Kitchen Finks' persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Kitchen Finks enters the battlefield, causing you to gain two life.
Repeat.

---

# 978-2034-2111

**Cards:**

- Vizier of Remedies
- Wingrattle Scarecrow
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: W, Popularity: 76**

**Steps:**

Activate Ashnod's Altar by sacrificing Wingrattle Scarecrow, adding {C}{C}.
Wingrattle Scarecrow's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Repeat.

---

# 978-2034-2620

**Cards:**

- Vizier of Remedies
- Safehold Elite
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: GW, Popularity: 327**

**Steps:**

Activate Ashnod's Altar by sacrificing Safehold Elite, adding {C}{C}.
Safehold Elite's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Repeat.

---

# 978-2034-3607

**Cards:**

- River Kelpie
- Vizier of Remedies
- Ashnod's Altar

**Produces:** Infinite card draw, Near-infinite colorless mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers

**Mana: , MV: 0, Colors: WU, Popularity: 37**

**Steps:**

Activate Ashnod's Altar by sacrificing River Kelpie, adding {C}{C}.
River Kelpie's persist triggers, returning it from your graveyard to the battlefield.
River Kelpie enters the battlefield, causing you to draw.
Repeat.

---

# 978-2086-4050

**Cards:**

- Vizier of Remedies
- Kitchen Finks
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: GW, Popularity: 341**

**Steps:**

Activate Phyrexian Altar by sacrificing Kitchen Finks, adding one mana of any color.
Kitchen Finks' persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Kitchen Finks enters the battlefield, causing you to gain two life.
Repeat.

---

# 978-2086-5256

**Cards:**

- Vizier of Remedies
- Kitchen Finks
- Altar of Dementia

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: GW, Popularity: 433**

**Steps:**

Activate Altar of Dementia by sacrificing Kitchen Finks.
Kitchen Finks' persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Kitchen Finks enters the battlefield, causing you to gain two life.
Resolve the Altar of Dementia ability, causing target player to mill cards equal to Kitchen Finks' power.
Repeat.

---

# 978-2111-4050

**Cards:**

- Vizier of Remedies
- Wingrattle Scarecrow
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: W, Popularity: 48**

**Steps:**

Activate Phyrexian Altar by sacrificing Wingrattle Scarecrow, adding one mana of any color.
Wingrattle Scarecrow's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Repeat.

---

# 978-2111-5256

**Cards:**

- Vizier of Remedies
- Wingrattle Scarecrow
- Altar of Dementia

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: W, Popularity: 76**

**Steps:**

Activate Altar of Dementia by sacrificing Wingrattle Scarecrow.
Wingrattle Scarecrow's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Resolve the Altar of Dementia ability, causing target player to mill cards equal to Wingrattle Scarecrow's power.
Repeat.

---

# 978-2292-3607

**Cards:**

- River Kelpie
- Vizier of Remedies
- Viscera Seer

**Produces:** Infinite card draw, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers

**Mana: , MV: 0, Colors: WUB, Popularity: 17**

**Steps:**

Activate Viscera Seer by sacrificing River Kelpie.
River Kelpie's persist triggers, returning it from your graveyard to the battlefield.
River Kelpie enters the battlefield, causing you to draw.
Resolve the Viscera Seer trigger, scrying 1.
Repeat.

---

# 978-2438-3607

**Cards:**

- River Kelpie
- Vizier of Remedies
- Carrion Feeder

**Produces:** Infinite card draw, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinitely large creature, Near-infinite sacrifice triggers

**Mana: , MV: 0, Colors: WUB, Popularity: 10**

**Steps:**

Activate Carrion Feeder by sacrificing River Kelpie.
River Kelpie's persist triggers, returning it from your graveyard to the battlefield.
River Kelpie enters the battlefield, causing you to draw.
Resolve the Carrion Feeder trigger, putting a +1/+1 counter on it.
Repeat.

---

# 978-2620-4050

**Cards:**

- Vizier of Remedies
- Safehold Elite
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: GW, Popularity: 197**

**Steps:**

Activate Phyrexian Altar by sacrificing Safehold Elite, adding one mana of any color.
Safehold Elite's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Repeat.

---

# 978-2620-5256

**Cards:**

- Vizier of Remedies
- Safehold Elite
- Altar of Dementia

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: GW, Popularity: 255**

**Steps:**

Activate Altar of Dementia by sacrificing Safehold Elite.
Safehold Elite's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Resolve the Altar of Dementia ability, causing target player to mill cards equal to Safehold Elite's power.
Repeat.

---

# 978-3607-3899

**Cards:**

- River Kelpie
- Vizier of Remedies
- Spawning Pit

**Produces:** Infinite card draw, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers

**Mana: , MV: 0, Colors: WU, Popularity: 7**

**Steps:**

Activate Spawning Pit by sacrificing River Kelpie.
River Kelpie's persist triggers, returning it from your graveyard to the battlefield.
River Kelpie enters the battlefield, causing you to draw.
Resolve the Spawning Pit trigger, putting a charge counter on it.
Repeat.

---

# 978-3607-4050

**Cards:**

- River Kelpie
- Vizier of Remedies
- Phyrexian Altar

**Produces:** Infinite card draw, Near-infinite colored mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers

**Mana: , MV: 0, Colors: WU, Popularity: 24**

**Steps:**

Activate Phyrexian Altar by sacrificing River Kelpie, adding {1}.
River Kelpie's persist triggers, returning it from your graveyard to the battlefield.
River Kelpie enters the battlefield, causing you to draw.
Repeat.

---

# 978-3607-5256

**Cards:**

- River Kelpie
- Vizier of Remedies
- Altar of Dementia

**Produces:** Infinite card draw, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite mill, Near-infinite sacrifice triggers

**Mana: , MV: 0, Colors: WU, Popularity: 19**

**Steps:**

Activate Altar of Dementia by sacrificing River Kelpie.
River Kelpie's persist triggers, returning it from your graveyard to the battlefield.
River Kelpie enters the battlefield, causing you to draw.
Resolve the Altar of Dementia trigger, causing target player to mill three cards.
Repeat.

---

# 978-4762

**Cards:**

- Devoted Druid
- Vizier of Remedies

**Produces:** Infinite green mana

**Mana: , MV: 0, Colors: GW, Popularity: 4354**

**Steps:**

Activate Devoted Druid by tapping it, adding {G}.
Activate Devoted Druid by putting a zero -1/-1 counter on it due to Vizier of Remedies, untapping it.
Repeat.

---

# 981-1517-1532-2104

**Cards:**

- The Mirari Conjecture
- Faith's Reward
- Temporal Manipulation
- Cursecatcher

**Produces:** Infinite turns, Lock

**Mana: {6}{W}{U}{U} every other turn, MV: 9, Colors: WU, Popularity: 0**

**Steps:**

At the beginning of your precombat main phase, The Mirari Conjecture triggers, putting a lore counter on itself, sacrificing itself and copying all instant and sorcery spells you cast this turn.
Cast Temporal Manipulation by paying {3}{U}{U}.
The Mirari Conjecture triggers, creating a copy of Temporal Manipulation.
Resolve both Temporal Manipulations, getting two extra turns after this one.
Cast Faith's Reward by paying {3}{W}.
The Mirari Conjecture triggers, copying Faith's Reward.
Holding priority, activate Cursecatcher by sacrificing it, countering the original Faith's Reward.
Resolve the Faith's Reward copy, returning The Mirari Conjecture and Cursecatcher from your graveyard to the battlefield.
The Mirari Conjecture triggers, putting a lore counter on itself and returning Faith's Reward from your graveyard to your hand.
Proceed to your next turn.
At the beginning of your precombat main phase, The Mirari Conjecture triggers, putting a lore counter on itself and returning Temporal Manipulation from your graveyard to your hand.
Proceed to your next turn.
Repeat.

---

# 981-1517-1532-4377

**Cards:**

- The Mirari Conjecture
- Faith's Reward
- Walk the Aeons
- Cursecatcher

**Produces:** Infinite turns, Lock

**Mana: {7}{W}{U}{U} every other turn, MV: 10, Colors: WU, Popularity: 0**

**Steps:**

At the beginning of your precombat main phase, The Mirari Conjecture triggers, putting a lore counter on itself, sacrificing itself and copying all instant and sorcery spells you cast this turn.
Cast Walk the Aeons by paying {4}{U}{U}.
The Mirari Conjecture triggers, creating a copy of Walk the Aeons.
Resolve both Walk the Aeonss, getting two extra turns after this one.
Cast Faith's Reward by paying {3}{W}.
The Mirari Conjecture triggers, copying Faith's Reward.
Holding priority, activate Cursecatcher by sacrificing it, countering the original Faith's Reward.
Resolve the Faith's Reward copy, returning The Mirari Conjecture and Cursecatcher from your graveyard to the battlefield.
The Mirari Conjecture triggers, putting a lore counter on itself and returning Faith's Reward from your graveyard to your hand.
Proceed to your next turn.
At the beginning of your precombat main phase, The Mirari Conjecture triggers, putting a lore counter on itself and returning Walk the Aeons from your graveyard to your hand.
Proceed to your next turn.
Repeat.

---

# 981-1517-2104-3505

**Cards:**

- The Mirari Conjecture
- Second Sunrise
- Temporal Manipulation
- Cursecatcher

**Produces:** Infinite turns, Lock

**Mana: {4}{W}{W}{U}{U} every other turn, MV: 8, Colors: WU, Popularity: 0**

**Steps:**

At the beginning of your precombat main phase, The Mirari Conjecture triggers, putting a lore counter on itself, sacrificing itself and copying all instant and sorcery spells you cast this turn.
Cast Temporal Manipulation by paying {3}{U}{U}.
The Mirari Conjecture triggers, creating a copy of Temporal Manipulation.
Resolve both Temporal Manipulations, getting two extra turns after this one.
Cast Second Sunrise by paying {1}{W}{W}.
The Mirari Conjecture triggers, copying Second Sunrise.
Holding priority, activate Cursecatcher by sacrificing it, countering the original Second Sunrise.
Resolve the Second Sunrise copy, returning The Mirari Conjecture and Cursecatcher from your graveyard to the battlefield.
The Mirari Conjecture triggers, putting a lore counter on itself and returning Second Sunrise from your graveyard to your hand.
Proceed to your next turn.
At the beginning of your precombat main phase, The Mirari Conjecture triggers, putting a lore counter on itself and returning Temporal Manipulation from your graveyard to your hand.
Proceed to your next turn.
Repeat.

---

# 981-1517-3505-4377

**Cards:**

- The Mirari Conjecture
- Second Sunrise
- Walk the Aeons
- Cursecatcher

**Produces:** Infinite turns, Lock

**Mana: {5}{W}{W}{U}{U} every other turn, MV: 9, Colors: WU, Popularity: 0**

**Steps:**

At the beginning of your precombat main phase, The Mirari Conjecture triggers, putting a lore counter on itself, sacrificing itself and copying all instant and sorcery spells you cast this turn.
Cast Walk the Aeons by paying {4}{U}{U}.
The Mirari Conjecture triggers, creating a copy of Walk the Aeons.
Resolve both Walk the Aeonss, getting two extra turns after this one.
Cast Second Sunrise by paying {1}{W}{W}.
The Mirari Conjecture triggers, copying Second Sunrise.
Holding priority, activate Cursecatcher by sacrificing it, countering the original Second Sunrise.
Resolve the Second Sunrise copy, returning The Mirari Conjecture and Cursecatcher from your graveyard to the battlefield.
The Mirari Conjecture triggers, putting a lore counter on itself and returning Second Sunrise from your graveyard to your hand.
Proceed to your next turn.
At the beginning of your precombat main phase, The Mirari Conjecture triggers, putting a lore counter on itself and returning Walk the Aeons from your graveyard to your hand.
Proceed to your next turn.
Repeat.

---

# 985-1594-5078

**Cards:**

- Sensei's Divining Top
- Helm of Awakening
- Mystic Forge

**Produces:** Infinite draw triggers, Infinite card draw, Near-infinite storm count

**Mana: , MV: 0, Colors: C, Popularity: 7789**

**Steps:**

Activate Sensei's Divining Top by tapping it, causing you to draw a card and put Sensei's Divining Top on top of your library.
Cast Sensei's Divining Top from the top of your library by paying {0}.
Repeat

---

# 985-1976-5078

**Cards:**

- Sensei's Divining Top
- Etherium Sculptor
- Mystic Forge

**Produces:** Infinite card draw, Near-infinite storm count, Infinite draw triggers

**Mana: , MV: 0, Colors: U, Popularity: 31762**

**Steps:**

Activate Sensei's Divining Top by tapping it, causing you to draw a card and put Sensei's Divining Top on top of your library.
Cast Sensei's Divining Top from the top of your library by paying {0}.
Repeat

---

# 985-2146-5078

**Cards:**

- Sensei's Divining Top
- Cloud Key
- Mystic Forge

**Produces:** Infinite card draw, Near-infinite storm count, Infinite draw triggers

**Mana: , MV: 0, Colors: C, Popularity: 27962**

**Steps:**

Activate Sensei's Divining Top by tapping it, causing you to draw a card and put Sensei's Divining Top on top of your library.
Cast Sensei's Divining Top from the top of your library by paying {0}.
Repeat

---

# 985-4985-5078

**Cards:**

- Sensei's Divining Top
- Jhoira's Familiar
- Mystic Forge

**Produces:** Infinite draw triggers, Infinite card draw, Near-infinite storm count

**Mana: , MV: 0, Colors: C, Popularity: 19616**

**Steps:**

Activate Sensei's Divining Top by tapping it, causing you to draw a card and put Sensei's Divining Top on top of your library.
Cast Sensei's Divining Top from the top of your library by paying {0}.
Repeat

---

# 989-5125-5218

**Cards:**

- Dream Halls
- Verdant Eidolon
- Sparkcaster

**Produces:** Infinite damage, Infinite ETB, Infinite LTB, Infinite self-discard triggers, Infinite storm count

**Mana: , MV: 0, Colors: GUR, Popularity: 2**

**Steps:**

Cast Sparkcaster by discarding Verdant Eidolon.
Verdant Eidolon triggers from your graveyard, returning from your graveyard to your hand.
Sparkcaster enters the battlefield, triggering twice.
Resolve the first Sparkcaster trigger, dealing 1 damage to target player or planeswalker.
Resolve the second Sparkcaster trigger, returning Sparkcaster from the battlefield to your hand.
Repeat.

---

# 992-2702

**Cards:**

- Archetype of Imagination
- Moat

**Produces:** Opponents can't attack, Lock

**Mana: , MV: 0, Colors: WU, Popularity: 258**

**Steps:**

All creatures your opponent control lose flying.
Moat prevents things without flying from attacking.
Creatures your opponent can not fulfill the conditions necessary to attack.

---

# 992-4468

**Cards:**

- Moat
- Mystic Decree

**Produces:** Creatures can't attack, Lock

**Mana: , MV: 0, Colors: WU, Popularity: 40**

**Steps:**

All creatures lose flying and Islandwalk.
Moat prevents things without flying from attacking.
Creatures can not fulfill the conditions nessasary to attack.

---

# 998-1080-1494-5261

**Cards:**

- Scute Mob
- Bioshift
- Sage of Hours
- Isochron Scepter

**Produces:** Infinite turns, Lock

**Mana: {2}, MV: 2, Colors: GU, Popularity: 2**

**Steps:**

Activate Isochron Scepter by tapping it and paying {2}, casting a copy of Bioshift without paying its mana cost, targeting Scute Mob and Sage of Hours.
Sage of Hours triggers, putting a +1/+1 counter on itself.
Resolve the Bioshift copy, moving four +1/+1 counters from Scute Mob onto Sage of Hours.
Activate Sage of Hours by removing all +1/+1 counters from it, generating an extra turn after this one.
At the beginning of your extra turn's upkeep, Scute Mob triggers, putting four +1/+1 counters on itself.
Repeat.

---


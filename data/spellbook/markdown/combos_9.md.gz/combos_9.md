# 757-2402-4353

**Cards:**

- Magosi, the Waterveil
- Nesting Grounds
- Atraxa, Praetors' Voice

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: GWUB, Popularity: 230**

**Steps:**

Activate Nesting Grounds's last ability by paying {1} and tapping it, moving an eon counter from Magosi to Nesting Grounds.
Activate Magosi's last ability by tapping it, removing an eon counter from it, and returning it from the battlefield to your hand, taking an extra turn after this one.
Play Magosi.
At the beginning of your end step, Atraxa triggers, causing you to proliferate, putting an additional eon counter on Nesting Grounds.
On your next extra turn, activate Nesting Grounds's last ability by paying {1} and tapping it, moving an eon counter from Nesting Grounds to Magosi.
Repeat from step 2.

---

# 757-2402-4883

**Cards:**

- Magosi, the Waterveil
- Nesting Grounds
- Contagion Clasp

**Produces:** Infinite turns, Lock

**Mana: {5} each turn, MV: 5, Colors: U, Popularity: 284**

**Steps:**

Activate Contagion Clasp by paying {4} and tapping it, putting an eon counter on Magosi.
Activate Nesting Grounds's last ability by paying {1} and tapping it, moving an eon counter from Magosi to Nesting Grounds.
Activate Magosi's last ability by tapping it, removing an eon counter from it and returning it to your hand, taking an extra turn after this one.
Play Magosi from your hand.
Move to your next turn.
Activate Contagion Clasp by paying {4} and tapping it, putting an eon counter on Nesting Grounds.
Activate Nesting Grounds's last ability by paying {1} and tapping it, moving an eon counter from Nesting Grounds to Magosi.
Repeat from step 3.

---

# 757-943-4235

**Cards:**

- Magosi, the Waterveil
- Rings of Brighthearth
- Deserted Temple

**Produces:** Infinite turns, Lock

**Mana: {3}{U} each turn, MV: 4, Colors: U, Popularity: 231**

**Steps:**

Activate Magosi's second ability by paying {U} and tapping it.
Rings of Brighthearth triggers, choose not to pay.
Resolve the Magosi ability, putting an eon counter on it and causing you to skip your next turn.
Activate Deserted Temple's second ability by paying {1} and tapping it, untapping Magosi.
Activate Magosi's third ability by tapping it, removing an eon counter from it and returning it from the battlefield to your hand.
Rings of Brighthearth triggers, causing you to pay {2} to copy Magosi's ability.
Resolve both Magosi abilities, causing you to take two extra turns after this one.
Play Magosi.
Move to your first extra turn, which is skipped due to Magosi's ability which resolved in step 3.
Move to your second extra turn.
Repeat.

---

# 759-4996

**Cards:**

- Beacon of Immortality
- Tainted Remedy

**Produces:** Target opponent loses the game

**Mana: {5}{W}, MV: 6, Colors: WB, Popularity: 2407**

**Steps:**

Cast Beacon of Immortality by paying {5}{W}, causing target opponent to lose life equal to their life total due to Tainted Remedy.
The opponent loses the game due to having zero or less life.

---

# 763-1274-4929

**Cards:**

- Heliod, Sun-Crowned
- Cryptic Trilobite
- Juju Bubble

**Produces:** Infinite lifegain, Infinite lifegain triggers

**Mana: {2}, MV: 2, Colors: W, Popularity: 27**

**Steps:**

Activate Juju Bubble by paying {2}, causing you to gain 1 life.
Heliod triggers, putting a +1/+1 counter on Cryptic Trilobite.
Activate Cryptic Trilobite by removing a +1/+1 counter from it, adding {C}{C} that can only be spent to activate abilities.
Repeat.

---

# 763-4017-4929

**Cards:**

- Sunbond
- Cryptic Trilobite
- Juju Bubble

**Produces:** Infinite lifegain, Infinite lifegain triggers

**Mana: {2}, MV: 2, Colors: W, Popularity: 23**

**Steps:**

Activate Juju Bubble by paying {2}, causing you to gain 1 life.
Sunbond triggers, putting a +1/+1 counter on Cryptic Trilobite.
Activate Cryptic Trilobite by removing a +1/+1 counter from it, adding {C}{C} that can only be spent to activate abilities.
Repeat.

---

# 767-2011

**Cards:**

- Najeela, the Blade-Blossom
- Druids' Repository

**Produces:** Infinite combat phases, Infinite creature tokens, Infinite ETB, Infinite lifegain, Infinite lifegain triggers

**Mana: , MV: 0, Colors: WUBRG, Popularity: 6163**

**Steps:**

Declare Najeela and four other creature as attackers.
Najeela triggers, creating a 1/1 Warrior creature token that is tapped and attacking.
Druids' Repository triggers five times, putting five charge counters on it.
Activate Druids' Repository five times by removing five charge counters from it, adding {W}{U}{B}{R}{G}.
Activate Najeela by paying {W}{U}{B}{R}{G}, untapping all attacking creatures, giving them trample, lifelink, and haste, and gaining an additional combat phase after this one.
Repeat each combat phase.

---

# 770-1636

**Cards:**

- Intruder Alarm
- Man-o'-War

**Produces:** Infinite ETB, Infinite LTB, Infinite mana creatures you control can produce, Infinite storm count, Infinite untap of creatures

**Mana: , MV: 0, Colors: U, Popularity: 548**

**Steps:**

Activate all mana-producing creatures you control by tapping them, adding at least {2}{U}.
Cast Man-o'-War by paying {2}{U}.
Man-o'-War enters the battlefield, triggering Intruder Alarm and Man-o'-War.
Resolve the Intruder Alarm's trigger, untapping all creatures you control.
Resolve the Man-o'-War's trigger, returning it to your hand.
Repeat.

---

# 770-2397-3821

**Cards:**

- Peregrine Drake
- Man-o'-War
- Panharmonicon

**Produces:** Infinite LTB, Infinite mana lands you control can produce, Infinite storm count, Infinite ETB

**Mana: {4}{U}, MV: 5, Colors: U, Popularity: 4034**

**Steps:**

Cast Peregrine Drake by paying {4}{U}.
When Peregrine Drake enters the battlefield, it triggers itself twice due to Panharmonicon.
Resolve one Peregrine Drake trigger, untapping five lands.
Activate those lands by tapping them to add at least {3}{U}.
Resolve the remaining Peregrine Drake trigger, untapping five lands.
Activate those lands by tapping them to add at least {3}{U}.
Cast Man-o'-War by paying {2}{U}.
When Man-o'-War enters the battlefield, it triggers itself twice due to Panharmonicon, returning itself and Peregrine Drake from the battlefield to your hand.
Repeat.
If you can produce at least one additional mana in step 4, this combo produces infinite mana.

---

# 770-2499-3821

**Cards:**

- Peregrine Drake
- Man-o'-War
- Yarok, the Desecrated

**Produces:** Infinite ETB, Infinite LTB, Infinite mana lands you control can produce, Infinite storm count

**Mana: {4}{U}, MV: 5, Colors: BGU, Popularity: 847**

**Steps:**

Cast Peregrine Drake by paying {4}{U}.
When Peregrine Drake enters the battlefield, it triggers itself twice due to Yarok.
Resolve one Peregrine Drake trigger, untapping five lands.
Activate those lands by tapping them to add at least {3}{U}.
Resolve the remaining Peregrine Drake trigger, untapping five lands.
Activate those lands by tapping them to add at least {3}{U}.
Cast Man-o'-War by paying {2}{U}.
When Man-o'-War enters the battlefield, it triggers itself twice due to Yarokg, returning itself and Peregrine Drake from the battlefield to your hand.
Repeat.
If you can produce at least one additional mana in step 4, this combo produces infinite mana.

---

# 770-2506-4191

**Cards:**

- Aluren
- Molten Echoes
- Man-o'-War

**Produces:** Infinite creature tokens with haste, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: , MV: 0, Colors: GUR, Popularity: 1**

**Steps:**

Cast Man-o'-War without paying its mana cost.
Man-o'-War enters the battlefield, targeting itself.
Molten Echoes triggers, creating a token copy of Man-o'-War.
Token copy of Man-o'-War enters the battlefield, returning original Man-o'-War to hand.
Resolve the original Man-o'-War triggers, fails to resolve due to having no legal targets.
Repeat.

---

# 771-1328

**Cards:**

- Spellbinder
- Savage Beating

**Produces:** Infinite combat phases, Infinite damage, Infinite magecraft triggers, Infinite storm count

**Mana: , MV: 0, Colors: R, Popularity: 905**

**Steps:**

Declare the creature with Spellbinder equipped as an attacker, attacking an opponent unable to block it.
Deal combat damage with the creature, triggering Spellbinder, casting a copy of Savage Beating without paying its mana cost.
Resolve Savage Beating, untapping all creatures you control and getting an additional combat phase after this one.
Repeat.

---

# 772-2034-3175

**Cards:**

- Sun Titan
- Ashnod's Altar
- Shade's Form

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite colorless mana

**Mana: , MV: 0, Colors: WB, Popularity: 26**

**Steps:**

Activate Ashnod's Altar by sacrificing Sun Titan.
When Sun Titan dies, Shade's Form triggers, returning Sun Titan from your graveyard to the battlefield.
When Sun Titan enters, it triggers, returning Shade's Form from your graveyard to the battlefield attached to Sun Titan.
Repeat.

---

# 772-3175-4050

**Cards:**

- Sun Titan
- Phyrexian Altar
- Shade's Form

**Produces:** Infinite LTB, Infinite sacrifice triggers, Infinite colored mana, Infinite death triggers, Infinite ETB

**Mana: , MV: 0, Colors: WB, Popularity: 17**

**Steps:**

Activate Phyrexian Altar by sacrificing Sun Titan.
When Sun Titan dies, Shade's Form triggers, returning Sun Titan from your graveyard to the battlefield.
When Sun Titan enters, it triggers, returning Shade's Form from your graveyard to the battlefield attached to Sun Titan.
Repeat.

---

# 772-3175-5256

**Cards:**

- Sun Titan
- Altar of Dementia
- Shade's Form

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: WB, Popularity: 17**

**Steps:**

Activate Altar of Dementia by sacrificing Sun Titan.
When Sun Titan dies, Shade's Form triggers, returning Sun Titan from your graveyard to the battlefield.
When Sun Titan enters, it triggers, returning Shade's Form from your graveyard to the battlefield attached to Sun Titan.
Resolve the Altar of Dementia ability.
Repeat.

---

# 776-1329-1414

**Cards:**

- Jeskai Ascendancy
- Emry, Lurker of the Loch
- Lotus Petal

**Produces:** Infinite colored mana, Infinite ETB, Infinite looting, Infinite LTB, Infinitely large creatures, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: URW, Popularity: 442**

**Steps:**

Activate Lotus Petal by tapping and sacrificing it, adding one mana of of any color.
Activate Emry by tapping it, targeting Lotus Petal.
Cast Lotus Petal from your graveyard by paying {0}.
Jeskai Ascendacy first and second abilities trigger.
Resolve the first Jeskai Ascendancy trigger, giving creatures you control +1/+1 until end of turn and untapping them.
Resolve the second Jeskai Ascendancy trigger, allowing you to loot.


---

# 776-1329-2478

**Cards:**

- Jeskai Ascendancy
- Emry, Lurker of the Loch
- Mishra's Bauble

**Produces:** Infinite ETB, Infinite card draw, Infinite looting, Infinite LTB, Infinitely large creatures, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: URW, Popularity: 332**

**Steps:**

Activate Mishra's Bauble by tapping and sacrificing it, looking at the top card of a player's library and drawing a card at the beginning of the next turn's upkeep.
Activate Emry by tapping it, targeting Mishra's Bauble.
Cast Mishra's Bauble from your graveyard by paying {0}.
Jeskai Ascendacy first and second abilities trigger.
Resolve the first Jeskai Ascendancy trigger, giving creatures you control +1/+1 until end of turn and untapping them.
Resolve the second Jeskai Ascendancy trigger, allowing you to loot.


---

# 776-1792-3682

**Cards:**

- Jeskai Ascendancy
- Mox Amber
- Retraction Helix

**Produces:** Infinite colored mana, Infinite looting, Infinite mana creatures you control can produce, Infinite storm count, Infinite untap of creatures you control

**Mana: {U}, MV: 1, Colors: URW, Popularity: 341**

**Steps:**

Cast Retraction Helix by paying {U}, targeting a creature you control without summoning sickness.
Jeskai Ascendacy first and second abilities trigger.
Resolve the first Jeskai Ascendancy trigger, giving creatures you control +1/+1 until end of turn and untapping them.
Resolve the second Jeskai Ascendancy trigger, allowing you to loot.
Activate Mox Amber by tapping it, adding one mana of any color you can produce among legendary creatures and planeswalkers you control.
Activate the creature by tapping it, returning Mox Amber to your hand.
Cast Mox Amber by paying {0}.
Repeat from step 2.


---

# 776-3209

**Cards:**

- Jeskai Ascendancy
- Sprout Swarm

**Produces:** Infinite creature tokens, Infinite draw triggers, Infinite ETB, Infinite looting, Infinitely large creatures you control until end of turn, Infinite magecraft triggers, Infinite mana creatures you control can produce, Infinite storm count, Infinite untap of creatures you control

**Mana: , MV: 0, Colors: RGWU, Popularity: 64**

**Steps:**

Cast Sprout Swarm with buyback by tapping five untapped creatures you control.
Jeskai Ascendancy's first and second ability triggers.
Resolve Jeskai Ascendancy's first trigger, untapping all creatures you control and giving them +1/+1 until end of turn.
Resolve Jeskai Ascendancy's second trigger, allowing you to loot.
Resolve Sprout Swarm, creating a 1/1 Saproling creature token and returning Sprout Swarm to your hand.
Repeat.

---

# 776-3690-3923

**Cards:**

- Jeskai Ascendancy
- Sylvan Awakening
- Mystic Speculation

**Produces:** Infinite looting, Infinitely large creatures, Infinite magecraft triggers, Infinite mana lands you control can produce, Infinite storm count

**Mana: {2}{G}, MV: 3, Colors: RGWU, Popularity: 4**

**Steps:**

Cast Sylvan Awakening by paying {2}{G}, causing all lands you control to become 2/2 Elemental creatures that are still lands until end of turn.
Jeskai Ascendacy first and second abilities trigger.
Resolve the first Jeskai Ascendancy trigger, giving creatures you control +1/+1 until end of turn and untapping them.
Resolve the second Jeskai Ascendancy trigger, allowing you to loot.
Activate all of your lands by tapping those, adding at least {3}{U}.
Cast Mystic Speculation with buyback by paying {2}{U}.
Jeskai Ascendacy first and second abilities trigger.
Resolve the first Jeskai Ascendancy trigger, giving creatures you control +1/+1 until end of turn and untapping them.
Resolve the second Jeskai Ascendancy trigger, allowing you to loot.
Repeat from step 5.

---

# 777-1395-5078

**Cards:**

- Sensei's Divining Top
- Foundry Inspector
- Elsha of the Infinite

**Produces:** Infinite card draw, Near-infinite storm count, Infinite draw triggers, Near-infinitely large creature until end of turn

**Mana: , MV: 0, Colors: URW, Popularity: 673**

**Steps:**

Activate Sensei's Divining Top by tapping it, causing you to draw a card and put Sensei's Divining Top on top of your library.
Cast Sensei's Divining Top from the top of your library by paying {0}.
Elsha's prowess ability triggers, giving it +1/+1 until end of turn.
Repeat

---

# 777-1661-5078

**Cards:**

- Sensei's Divining Top
- Foundry Inspector
- Magus of the Future

**Produces:** Infinite draw triggers, Infinite card draw, Near-infinite storm count

**Mana: , MV: 0, Colors: U, Popularity: 220**

**Steps:**

Activate Sensei's Divining Top by tapping it, causing you to draw a card and put Sensei's Divining Top on top of your library.
Cast Sensei's Divining Top from the top of your library by paying {0}.
Repeat

---

# 777-4311-5078

**Cards:**

- Sensei's Divining Top
- Foundry Inspector
- Future Sight

**Produces:** Infinite card draw, Near-infinite storm count, Infinite draw triggers

**Mana: , MV: 0, Colors: U, Popularity: 804**

**Steps:**

Activate Sensei's Divining Top by tapping it, causing you to draw a card and put Sensei's Divining Top on top of your library.
Cast Sensei's Divining Top from the top of your library by paying {0}.
Repeat

---

# 777-985-5078

**Cards:**

- Sensei's Divining Top
- Foundry Inspector
- Mystic Forge

**Produces:** Infinite card draw, Near-infinite storm count, Infinite draw triggers

**Mana: , MV: 0, Colors: C, Popularity: 45177**

**Steps:**

Activate Sensei's Divining Top by tapping it, causing you to draw a card and put Sensei's Divining Top on top of your library.
Cast Sensei's Divining Top from the top of your library by paying {0}.
Repeat

---

# 780-864-4050

**Cards:**

- Eternal Witness
- Phyrexian Altar
- Supernatural Stamina

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {B}, MV: 1, Colors: BG, Popularity: 155**

**Steps:**

Cast Supernatural Stamina by paying {B}, giving Eternal Witness +2/+0 and a new triggered ability until end of turn.
Activate Phyrexian Altar by sacrificing Eternal Witness, adding {B}.
When Eternal Witness dies, it triggers its own ability from Supernatural Stamina, returning Eternal Witness from your graveyard to the battlefield tapped.
When Eternal Witness enters the battlefield, it triggers, returning Supernatural Stamina from your graveyard to your hand.
Repeat.

---

# 782-2580-5141

**Cards:**

- Lethal Vapors
- Teferi's Protection
- Grand Abolisher

**Produces:** Skip all your future turns, causing your opponents to eventually draw from an empty library and lose the game, You have protection from everything, Your life total can't change, Lock

**Mana: {4}{W}{B}{B}, MV: 7, Colors: WB, Popularity: 586**

**Steps:**

Cast Lethal Vapors by paying {2}{B}{B}.
Activate Lethal Vapors an arbitrarily large number of times.
Cast Teferi's Protection by paying {2}{W}: until your next turn your life total can't change and you have protection from everything.
Allow all the activated abilities from Lethal Vapors to resolve, skipping an arbitrarily large number of turns.

---

# 783-1399-3814

**Cards:**

- Argothian Elder
- Jungle Basin
- Wirewood Lodge

**Produces:** Infinite colorless mana

**Mana: , MV: 0, Colors: G, Popularity: 103**

**Steps:**

Activate Jungle Basin by tapping it, adding {1}{G}.
Activate Argothian Elder by tapping it, untapping Jungle Basin and Wirewood Lodge.
Activate Wirewood Lodge's second ability by paying {G} and tapping it, untap Argothian Elder.
Repeat.

---

# 787-1124

**Cards:**

- Teferi, Temporal Archmage
- The Chain Veil

**Produces:** Infinite card draw, Infinite colored mana, Infinite colorless mana, Infinite planeswalker activations

**Mana: , MV: 0, Colors: U, Popularity: 19287**

**Steps:**

Activate The Chain Veil by paying {4} and tapping it, allowing all planeswalkers you control to activate their loyalty abilities and additional time this turn.
Activate Teferi's second loyalty ability by removing a loyalty counter from it, untapping the Chain Veil and the three mana-producing permanents.
Repeat from step 1 until Teferi dies due to having zero loyalty.
Cast Teferi from your command zone.
Activate Teferi's first loyalty ability by adding a loyalty counter to it, looking at the top two cards of your library and putting one card from the top of your library into your hand and the other onto the bottom of your library.
Do this x times, where x is equal to one half times the number of times you activated The Chain Veil this turn minus four, rounded down.
Activate Teferi's second loyalty ability, untapping the Chain Veil and the three mana-producing permanents.
Repeat step 7 an additional time.
Activate Teferi's second loyalty ability by untapping the three mana producing permanents and the additional mana producing permanent, adding {4}{U}.
Repeat step 9 until Teferi dies due to having zero loyalty.
Repeat from step 4.

---

# 787-3094

**Cards:**

- Teferi, Temporal Archmage
- Lithoform Engine

**Produces:** Infinite mana lands you control can produce, Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: U, Popularity: 1949**

**Steps:**

Activate Teferi, Temporal Archmage's second ability by removing a loyalty counter from it.
In resopnse, activate Lithoform Engine's first ability by paying {2} and tapping it, copying Teferi's activated ability.
Let the copied ability resolve, untapping three lands and Lithoform Engine.
Activate those lands by tapping them, adding at least {3}.
Repeat from step 2.
Once you have infinite mana, you may untap any permanents in step 3.

---

# 790-1218-1972

**Cards:**

- Windfall
- Tainted Strike
- Nekusar, the Mindrazer

**Produces:** Each opponent loses the game

**Mana: {2}{U}{B}, MV: 4, Colors: UBR, Popularity: 1863**

**Steps:**

Cast Tainted Strike by paying {B}, giving Nekusar infect until end of turn.
Cast Windfall by paying {2}{U}, causing each player to discard their hand and then draw a number of cards equal to the greatest number of cards a player discarded this way.
Nekusar triggers for each card drawn this way, giving each opponent a poison counter for each card they drew.
Each opponent loses the game due to having ten or more poison counters

---

# 790-1368-4682

**Cards:**

- Smothering Tithe
- Underworld Breach
- Windfall

**Produces:** Infinite draw triggers for all players, Infinite looting for all players, Infinite self-discard triggers for all players, Near-infinite colored mana, Near-infinite Treasure tokens

**Mana: {2}{U}, MV: 3, Colors: URW, Popularity: 8280**

**Steps:**

Cast Windfall from your graveyard for its escape cost by paying {2}{U} and exiling three cards from your graveyard, causing each player to discard at least three cards and draw at least three cards.
Smothering Tithe triggers for each card drawn by your opponents, creating that many Treasure tokens.
Activate three of the Treasure tokens by tapping and sacrificing them, adding {2}{U}.
Repeat.

---

# 790-1972-3681

**Cards:**

- Windfall
- Grafted Exoskeleton
- Nekusar, the Mindrazer

**Produces:** Each opponent loses the game

**Mana: {2}{U}, MV: 3, Colors: UBR, Popularity: 1494**

**Steps:**

Cast Windfall by paying {2}{U}, causing each player to discard their hand and then draw a number of cards equal to the greatest number of cards a player discarded this way.
Nekusar triggers for each card drawn this way, giving each opponent a poison counter for each card they drew.
Each opponent loses the game due to having ten or more poison counters

---

# 790-1972-4651

**Cards:**

- Windfall
- Phyresis
- Nekusar, the Mindrazer

**Produces:** Each opponent loses the game

**Mana: {2}{U}, MV: 3, Colors: UBR, Popularity: 4490**

**Steps:**

Cast Windfall by paying {2}{U}, causing each player to discard their hand and then draw a number of cards equal to the greatest number of cards a player discarded this way.
Nekusar triggers for each card drawn this way, giving each opponent a poison counter for each card they drew.
Each opponent loses the game due to having ten or more poison counters

---

# 79-1912-4013

**Cards:**

- Biomancer's Familiar
- Eldrazi Displacer
- Birthing Hulk

**Produces:** Infinite colorless mana, Infinite creature tokens, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite blinking of most creatures

**Mana: {C}, MV: 1, Colors: GWU, Popularity: 7**

**Steps:**

Activate Eldrazi Displacer by paying {C}, blinking Birthing Hulk.
Birthing Hulk enters the battlefield, creating two 1/1 colorless Eldrazi Scion tokens.
Activate Eldrazi Scion by sacrificing it, adding {C}.
Repeat.

---

# 79-2713-4013

**Cards:**

- Zirda, the Dawnwaker
- Eldrazi Displacer
- Birthing Hulk

**Produces:** Infinite blinking, Infinite colorless mana, Infinite creature tokens, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite blinking of most creatures

**Mana: {C}, MV: 1, Colors: RGW, Popularity: 8**

**Steps:**

Activate Eldrazi Displacer by paying {C}, blinking Birthing Hulk.
Birthing Hulk enters the battlefield, creating two 1/1 Eldrazi Scion creature tokens.
Activate an Eldrazi Scion by sacrificing it, adding {C}.
Repeat.

---

# 79-4013-4893

**Cards:**

- Training Grounds
- Eldrazi Displacer
- Birthing Hulk

**Produces:** Infinite blinking, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite blinking of most creatures

**Mana: {C}, MV: 1, Colors: GWU, Popularity: 15**

**Steps:**

Activate Eldrazi Displacer's ability by paying {C}, blinking Birthing Hulk.
Birthing Hulk enters the battlefield tapped, triggering itself, creating two 1/1 Eldrazi Scion tokens.
Activate an Eldrazi Scion by sacrificing it, adding {C}.
Repeat.
Once you have infinite Eldrazi Scion tokens, you may activate any number of them.

---

# 797-1061-1953

**Cards:**

- Brudiclad, Telchor Engineer
- Timestream Navigator
- Stolen Identity

**Produces:** Infinite turns, Lock

**Mana: {6}{U}{U}{U}{U} on your first turn, with {2}{U}{U} available on each extra turn, MV: 10, Colors: UR, Popularity: 93**

**Steps:**

Cast Stolen Identity by paying {4}{U}{U}, creating a token copy of Timestream Navigator.
At the beginning of your combat phase, Brudiclad triggers, creating a 2/1 Phyrexian Myr creature token, then choosing to have all tokens you control become copies of the Timestream Navigator token.
Activate Timestream Navigator by paying {2}{U}{U} and tapping it and putting it onto the bottom of your library, causing you to take an extra turn after this one.
Move to your next turn.
Repeat from step 2.

---

# 797-1953-2105

**Cards:**

- Brudiclad, Telchor Engineer
- Combat Celebrant
- Stolen Identity

**Produces:** Infinite combat phases, Infinite damage

**Mana: {4}{U}{U}, MV: 6, Colors: UR, Popularity: 258**

**Steps:**

Cast Stolen Identity by paying {4}{U}{U}, creating a token copy of Combat Celebrant.
At the beginning of your combat phase, Brudiclad triggers, creating a 2/1 Phyrexian Myr creature token, then choosing to have all tokens you control become copies of the Combat Celebrant token.
Declare one of the Combat Celebrant copy as an attacker, choosing to exert it as it attacks.
The Combat Celebrant copy triggers, untapping all other creatures you control and causing you to get an additional combat phase after this one.
Repeat from step 2.

---

# 799-1164-5131

**Cards:**

- Muldrotha, the Gravetide
- Mirror of Fate
- Karn's Temporal Sundering

**Produces:** Infinite turns, Lock

**Mana: {9}{U}{U} each turn, MV: 11, Colors: BGU, Popularity: 7**

**Steps:**

Cast Karn's Temporal Sundering by paying {4}{U}{U}, taking an extra turn after this one.
Activate Mirror of Fate by tapping and sacrificing it, choosing Karn's Temporal Sundering from exile and putting it on the top of your library.
Cast Mirror of Fate from your graveyard by paying {5}.
Move to your next turn.
Repeat.

---

# 799-1271-3212

**Cards:**

- God-Eternal Kefnet
- Scroll Rack
- Karn's Temporal Sundering

**Produces:** Infinite turns, Skip your draw steps, Lock

**Mana: {3}{U}{U} each turn, MV: 5, Colors: U, Popularity: 235**

**Steps:**

Tap Scroll Rack and pay {1} to activate it, putting Karn's Temporal Sundering on top of your library.
Pass the turn.
On your next draw step, when you draw Karn's Temporal Sundering, reveal it due to Kefnet's ability, making a copy that costs {2} less to cast.
Cast the copy for {2}{U}{U}, granting you an extra turn and returning up to one nonland permanent to its owner's hand.

---

# 799-1702-3212

**Cards:**

- God-Eternal Kefnet
- Jace, the Mind Sculptor
- Karn's Temporal Sundering

**Produces:** Infinite turns, Lock

**Mana: {2}{U}{U} each turn, MV: 4, Colors: U, Popularity: 167**

**Steps:**

Activate Jace's zero loyalty ability, putting Karn's Temporal Sundering on top of your library.
Pass the turn.
On your next draw step, when you draw Karn's Temporal Sundering, reveal it due to Kefnet's ability, making a copy that costs {2} less to cast.
Cast the copy for {2}{U}{U}, granting you an extra turn and returning up to one nonland permanent to its owner's hand.

---

# 799-1750-4861-5261

**Cards:**

- Isochron Scepter
- Pull from Eternity
- Kess, Dissident Mage
- Karn's Temporal Sundering

**Produces:** Infinite turns, Lock

**Mana: {6}{U}{U} each turn, MV: 8, Colors: WUBR, Popularity: 0**

**Steps:**

Cast Karn's Temporal Sundering by paying {4}{U}{U}, causing you to take an extra turn after this one and exile Karn's Temporal Sundering.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Pull from Eternity without paying its mana cost.
Resolve Pull from Eternity, putting Karn's Temporal Sundering into your graveyard from exile.
Move to your next turn.
Cast Karn's Temporal Sundering from your graveyard by paying {4}{U}{U}, causing you to take an extra turn after this one and exile Karn's Temporal Sundering.
Repeat from step 2.

---

# 799-1750-4903-5261

**Cards:**

- Isochron Scepter
- Pull from Eternity
- Backdraft Hellkite
- Karn's Temporal Sundering

**Produces:** Infinite turns, Lock

**Mana: {6}{U}{U}, MV: 8, Colors: URW, Popularity: 1**

**Steps:**

Cast the extra turn spell and move to your extra turn.
Activate Isochron Sceptre to cast Pull from Eternity, putting the extra turn spell from exile to your graveyard.
Attack with Backdraft Hellkite to give your extra turn flashback, then cast it.
Repeat for infinite turns.

---

# 799-958-1750-5261

**Cards:**

- Isochron Scepter
- Pull from Eternity
- Dralnu, Lich Lord
- Karn's Temporal Sundering

**Produces:** Infinite turns, Lock

**Mana: {6}{U}{U} each turn, MV: 8, Colors: WUB, Popularity: 0**

**Steps:**

Cast Karn's Temporal Sundering by paying {4}{U}{U}, causing you to take an extra turn after this one and exile Karn's Temporal Sundering.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Pull from Eternity without paying its mana cost.
Resolve Pull from Eternity, putting Karn's Temporal Sundering into your graveyard from exile.
Move to your next turn.
Activate Dralnu by tapping it, giving Karn's Temporal Sundering flashback until end of turn.
Cast Karn's Temporal Sundering from your graveyard by paying {4}{U}{U}, causing you to take an extra turn after this one and exile Karn's Temporal Sundering.
Repeat from step 2.

---

# 800-1656-3181

**Cards:**

- Necrotic Ooze
- Knacksaw Clique
- Krosan Restorer

**Produces:** Exile each opponent's library, Infinite colored mana

**Mana: , MV: 0, Colors: BGU, Popularity: 22**

**Steps:**

Activate Krosan Restorer threshold ability with Necrotic Ooze to untap up to three lands.
Activate Knacksaw Qlique with Nectrotic Ooze to untap it, and have target opponent remove the top card of their library from the game.
Until end of turn you may play that card.
Continue looping as long as needed, generating infinite mana among lands you control.
From here, you could either cast every card from your opponent' libraries, or Move to your next turn and win from them decking out.

---

# 800-1912-4474

**Cards:**

- Knacksaw Clique
- Paradise Mantle
- Biomancer's Familiar

**Produces:** Exile each opponent's library

**Mana: , MV: 0, Colors: GU, Popularity: 43**

**Steps:**

Activate Knacksaw Clique by tapping it, adding {U}.
Activate Knacksaw Clique by paying {U} and untap it, exiling the top card of target opponent's library.
Repeat.

---

# 800-4474-4893

**Cards:**

- Knacksaw Clique
- Paradise Mantle
- Training Grounds

**Produces:** Exile each opponent's library

**Mana: , MV: 0, Colors: U, Popularity: 100**

**Steps:**

Activate Knacksaw Clique by tapping it, adding {U}.
Activate Knacksaw Clique by paying {U} and untap it, exiling the top card of target opponent's library.
Repeat.

---

# 802-1003-1846-3198

**Cards:**

- High Tide
- Lore Drakkis
- Phyrexian Walker
- Snap

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: {U}{U}, MV: 2, Colors: UR, Popularity: 6**

**Steps:**

Cast High Tide by paying {U}.
Cast Lore Drakkis for its Mutate cost by paying {U}{U}, targeting Phyrexian Walker.
Lore Drakkis's mutate ability triggers, causing you to return Snap from your graveyard to your hand.
Cast Snap by paying {1}{U}, returning the mutated creature that contains the nontoken Lore Drakkis from the battlefield to your hand and untapping two Islands.
Cast Phyrexian Walker by paying {0}.
Repeat from step 2.

---

# 802-1235-1741-2649

**Cards:**

- Vadrok, Apex of Thunder
- Cloud of Faeries
- Twinflame
- Snap

**Produces:** Cast a subset of spells in your graveyard, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: {2}{W/U}{R}{R}{R}, plus commander tax if applicable, MV: 6, Colors: URW, Popularity: 145**

**Steps:**

Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under Cloud of Faeries.
The Cloud of Faeries mutated creature's ability from Vadrok triggers, casting Twinflame from your graveyard without paying its mana cost.
Resolve Twinflame, creating a token copy of the Cloud of Faeries mutated creature with haste.
The token copy of the Cloud of Faeries mutated creature triggers, untapping two lands you control.
Cast Snap by paying {1}{U}, returning the nontoken Cloud of Faeries and Vadrok from the battlefield to your hand and untapping two lands you control.
Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under the token Cloud of Faeries mutated creature.
The token Cloud of Faeries mutated creature triggers once for each of its Vadrok abilities.
Resolve one of these triggers, casting Twinflame from your graveyard without paying its mana cost.
Resolve Twinflame, creating a token copy of the Cloud of Faeries mutated creature with haste.
The token copy of the Cloud of Faeries mutated creature triggers, untapping two lands you control.
Resolve a second trigger from step 7, casting Snap from your graveyard without paying its mana cost, targeting the mutated creature that includes the nontoken Vadrok.
Resolve Snap, returning Vadrok from the battlefield to your hand as well as multiple token creatures which cease to exist, and untapping two lands you control.
Resolve any remaining triggers from step 7, casting any noncreature cards with mana value 3 or less that were not already cast since step 7 from your graveyard without paying their casting costs.
Repeat from step 6, adding one additional token Vadrok to each new iteration of the Cloud of Faeries mutated creature token.

---

# 802-1235-2649-3821

**Cards:**

- Vadrok, Apex of Thunder
- Peregrine Drake
- Twinflame
- Snap

**Produces:** Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Infinite mana lands you control can produce, Infinite untap of lands you control, Cast a subset of spells in your graveyard

**Mana: {1}{W/U}{R}{R}{R}, plus commander tax if applicable, MV: 5, Colors: URW, Popularity: 84**

**Steps:**

Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under Peregrine Drake.
The Peregrine Drake mutated creature's ability from Vadrok triggers, casting Twinflame from your graveyard without paying its mana cost.
Resolve Twinflame, creating a token copy of the Peregrine Drake mutated creature with haste.
The token copy of the Peregrine Drake mutated creature triggers, untapping five lands you control.
Cast Snap by paying {1}{U}, returning the nontoken Peregrine Drake and Vadrok from the battlefield to your hand and untapping two lands you control.
Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under the token Peregrine Drake mutated creature.
The token Peregrine Drake mutated creature triggers once for each of its Vadrok abilities.
Resolve one of these triggers, casting Twinflame from your graveyard without paying its mana cost.
Resolve Twinflame, creating a token copy of the Peregrine Drake mutated creature with haste.
The token copy of the Peregrine Drake mutated creature triggers, untapping five lands you control.
Resolve a second trigger from step 7, casting Snap from your graveyard without paying its mana cost, targeting the mutated creature that includes the nontoken Vadrok.
Resolve Snap, returning Vadrok from the battlefield to your hand as well as multiple token creatures which cease to exist, and untapping two lands you control.
Resolve any remaining triggers from step 7, casting any noncreature cards with mana value 3 or less that were not already cast since step 7 from your graveyard without paying their casting costs.
Repeat from step 6, adding one additional token Vadrok to each new iteration of the Peregrine Drake mutated creature token.

---

# 802-1741-2649-2959

**Cards:**

- Vadrok, Apex of Thunder
- Cloud of Faeries
- Heat Shimmer
- Snap

**Produces:** Cast a subset of spells in your graveyard, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: {2}{W/U}{R}{R}{R}, plus commander tax if applicable, MV: 6, Colors: URW, Popularity: 57**

**Steps:**

Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under Cloud of Faeries.
The Cloud of Faeries mutated creature's ability from Vadrok triggers, casting Heat Shimmer from your graveyard without paying its mana cost.
Resolve Heat Shimmer, creating a token copy of the Cloud of Faeries mutated creature with haste.
The token copy of the Cloud of Faeries mutated creature triggers, untapping two lands you control.
Cast Snap by paying {1}{U}, returning the nontoken Cloud of Faeries and Vadrok from the battlefield to your hand and untapping two lands you control.
Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under the token Cloud of Faeries mutated creature.
The token Cloud of Faeries mutated creature triggers once for each of its Vadrok abilities.
Resolve one of these triggers, casting Heat Shimmer from your graveyard without paying its mana cost.
Resolve Heat Shimmer, creating a token copy of the Cloud of Faeries mutated creature with haste.
The token copy of the Cloud of Faeries mutated creature triggers, untapping two lands you control.
Resolve a second trigger from step 7, casting Snap from your graveyard without paying its mana cost, targeting the mutated creature that includes the nontoken Vadrok.
Resolve Snap, returning Vadrok from the battlefield to your hand as well as multiple token creatures which cease to exist, and untapping two lands you control.
Resolve any remaining triggers from step 7, casting any noncreature cards with mana value 3 or less that were not already cast since step 7 from your graveyard without paying their casting costs.
Repeat from step 6, adding one additional token Vadrok to each new iteration of the Cloud of Faeries mutated creature token.

---

# 802-1741-2649-4615

**Cards:**

- Vadrok, Apex of Thunder
- Cloud of Faeries
- Quasiduplicate
- Snap

**Produces:** Cast a subset of spells in your graveyard, Infinite ETB, Infinite magecraft triggers, Infinite storm count, Infinite mana lands you control can produce, Infinite untap of lands you control, Infinite LTB

**Mana: {2}{W/U}{R}{R}{R}, plus commander tax if applicable, MV: 6, Colors: URW, Popularity: 171**

**Steps:**

Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under Cloud of Faeries.
The Cloud of Faeries mutated creature's ability from Vadrok triggers, casting Quasiduplicate from your graveyard without paying its mana cost.
Resolve Quasiduplicate, creating a token copy of the Cloud of Faeries mutated creature with haste.
The token copy of the Cloud of Faeries mutated creature triggers, untapping two lands you control.
Cast Snap by paying {1}{U}, returning the nontoken Cloud of Faeries and Vadrok from the battlefield to your hand and untapping two lands you control.
Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under the token Cloud of Faeries mutated creature.
The token Cloud of Faeries mutated creature triggers once for each of its Vadrok abilities.
Resolve one of these triggers, casting Quasiduplicate from your graveyard without paying its mana cost.
Resolve Quasiduplicate, creating a token copy of the Cloud of Faeries mutated creature with haste.
The token copy of the Cloud of Faeries mutated creature triggers, untapping two lands you control.
Resolve a second trigger from step 7, casting Snap from your graveyard without paying its mana cost, targeting the mutated creature that includes the nontoken Vadrok.
Resolve Snap, returning Vadrok from the battlefield to your hand as well as multiple token creatures which cease to exist, and untapping two lands you control.
Resolve any remaining triggers from step 7, casting any noncreature cards with mana value 3 or less that were not already cast since step 7 from your graveyard without paying their casting costs.
Repeat from step 6, adding one additional token Vadrok to each new iteration of the Cloud of Faeries mutated creature token.

---

# 802-1846-2493

**Cards:**

- High Tide
- Archaeomancer
- Snap

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count

**Mana: {U}, MV: 1, Colors: U, Popularity: 12557**

**Steps:**

Cast High Tide by paying {U}, causing Islands to add an additional {U} this turn.
Activate two Islands by tapping them, adding {U}{U}{U}{U}.
Cast Archaeomancer by paying {2}{U}{U}.
Archaeomancer enters the battlefield, returning High Tide from your graveyard to your hand.
Activate an Island by tapping it, adding {U}{U}.
Cast High Tide by paying {U}, causing Islands to add an additional {U} this turn.
Activate an Island by tapping it, adding {U}{U}{U}.
Cast Snap by paying {1}{U}, returning Archaeomancer from the battlefield to your hand and untapping two Islands.
Activate two Islands by tapping them, adding six {U}.
Cast Archaeomancer by paying {2}{U}{U}.
Archaeomancer enters the battlefield, returning Snap from your graveyard to your hand.
Repeat from step 8.

---

# 802-1846-3198-3652

**Cards:**

- High Tide
- Lore Drakkis
- Ornithopter
- Snap

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: {U}{U}, MV: 2, Colors: UR, Popularity: 27**

**Steps:**

Cast High Tide by paying {U}.
Cast Lore Drakkis for its Mutate cost by paying {U}{U}, targeting Ornithopter.
Lore Drakkis's mutate ability triggers, causing you to return Snap from your graveyard to your hand.
Cast Snap by paying {1}{U}, returning the mutated creature that contains the nontoken Lore Drakkis from the battlefield to your hand and untapping two Islands.
Cast Ornithopter by paying {0}.
Repeat from step 2.

---

# 802-2649-2959-3821

**Cards:**

- Vadrok, Apex of Thunder
- Peregrine Drake
- Heat Shimmer
- Snap

**Produces:** Cast a subset of spells in your graveyard, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: {1}{W/U}{R}{R}{R}, plus commander tax if applicable, MV: 5, Colors: URW, Popularity: 41**

**Steps:**

Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under Peregrine Drake.
The Peregrine Drake mutated creature's ability from Vadrok triggers, casting Heat Shimmer from your graveyard without paying its mana cost.
Resolve Heat Shimmer, creating a token copy of the Peregrine Drake mutated creature with haste.
The token copy of the Peregrine Drake mutated creature triggers, untapping five lands you control.
Cast Snap by paying {1}{U}, returning the nontoken Peregrine Drake and Vadrok from the battlefield to your hand and untapping two lands you control.
Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under the token Peregrine Drake mutated creature.
The token Peregrine Drake mutated creature triggers once for each of its Vadrok abilities.
Resolve one of these triggers, casting Heat Shimmer from your graveyard without paying its mana cost.
Resolve Heat Shimmer, creating a token copy of the Peregrine Drake mutated creature with haste.
The token copy of the Peregrine Drake mutated creature triggers, untapping five lands you control.
Resolve a second trigger from step 7, casting Snap from your graveyard without paying its mana cost, targeting the mutated creature that includes the nontoken Vadrok.
Resolve Snap, returning Vadrok from the battlefield to your hand as well as multiple token creatures which cease to exist, and untapping two lands you control.
Resolve any remaining triggers from step 7, casting any noncreature cards with mana value 3 or less that were not already cast since step 7 from your graveyard without paying their casting costs.
Repeat from step 6, adding one additional token Vadrok to each new iteration of the Peregrine Drake mutated creature token.

---

# 802-2649-3147-3664

**Cards:**

- Vadrok, Apex of Thunder
- Lotus Field
- Snap
- Azorius Chancery

**Produces:** Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Infinite colored mana, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: {1}{U} plus enough mana to pay for commander tax, if applicable, MV: 2, Colors: URW, Popularity: 66**

**Steps:**

Cast Snap by paying {1}{U}, returning the additional creature to your hand and untapping Lotus Field and Azorius Chancery.
Activate Lotus Field and the land by tapping them, adding at least {1}{W/U}{R}{R}{R}.
Cast the additional creature by paying {0}.
Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R} plus commander tax if applicable, mutating it under the additional creature.
The mutated creature's ability from Vadrok triggers, casting Snap from your graveyard without paying its mana cost.
Resolve Snap, returning both cards that compose the mutated creature from the battlefield to your hand and untapping Lotus Field and Azorius Chancery.
Repeat from step 2.

---

# 802-2649-3821-4615

**Cards:**

- Vadrok, Apex of Thunder
- Peregrine Drake
- Quasiduplicate
- Snap

**Produces:** Cast a subset of spells in your graveyard, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: {1}{W/U}{R}{R}{R}, plus commander tax if applicable, MV: 5, Colors: URW, Popularity: 122**

**Steps:**

Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under Peregrine Drake.
The Peregrine Drake mutated creature's ability from Vadrok triggers, casting Quasiduplicate from your graveyard without paying its mana cost.
Resolve Quasiduplicate, creating a token copy of the Peregrine Drake mutated creature with haste.
The token copy of the Peregrine Drake mutated creature triggers, untapping five lands you control.
Cast Snap by paying {1}{U}, returning the nontoken Peregrine Drake and Vadrok from the battlefield to your hand and untapping two lands you control.
Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under the token Peregrine Drake mutated creature.
The token Peregrine Drake mutated creature triggers once for each of its Vadrok abilities.
Resolve one of these triggers, casting Quasiduplicate from your graveyard without paying its mana cost.
Resolve Quasiduplicate, creating a token copy of the Peregrine Drake mutated creature with haste.
The token copy of the Peregrine Drake mutated creature triggers, untapping five lands you control.
Resolve a second trigger from step 7, casting Snap from your graveyard without paying its mana cost, targeting the mutated creature that includes the nontoken Vadrok.
Resolve Snap, returning Vadrok from the battlefield to your hand as well as multiple token creatures which cease to exist, and untapping two lands you control.
Resolve any remaining triggers from step 7, casting any noncreature cards with mana value 3 or less that were not already cast since step 7 from your graveyard without paying their casting costs.
Repeat from step 6, adding one additional token Vadrok to each new iteration of the Peregrine Drake mutated creature token.

---

# 802-864-914-5257

**Cards:**

- Riku of Two Reflections
- Dockside Extortionist
- Eternal Witness
- Snap

**Produces:** Infinite colored mana, Infinite creature tokens, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {1}{R}, MV: 2, Colors: GUR, Popularity: 12**

**Steps:**

Cast Dockside Extortionist for {1}{R}.
When Dockside Extortionist enters the battlefield, its own ETB triggers and Riku of Two Reflections triggers.
Stack the triggers such that Dockside Extortionist's trigger resolves first, creating 5 Treasure tokens.
Pay for the Riku of Two Reflections trigger using 2 Treasures, creating a token copy of Dockside Extortionist that creates another 5 Treasure tokens.
Cast Snap using two of your 8 Treasures, returning Dockside Extortionist to your hand and untapping two lands, leaving you with 6 Treasure tokens and two untapped lands.
Cast Eternal Witness with an untapped land and two Treasure tokens, leaving an untapped land and four Treasure tokens.
When it enters the battlefield, Eternal Witness and Riku of Two Reflections trigger.
Stack the triggers such that Eternal Witness resolves first, returning Snap to your hand.
Before the Riku trigger resolves, cast Snap using an untapped land and a Treasure, returning Dockside Extortionist to your hand and leaving you with 2 untapped lands and 3 Treasure tokens.
Pay for the Riku of Two Reflectons trigger with 2 Treasure tokens, creating a token copy of Eternal Witness that returns Snap to your hand on ETB.
You are now back where you started, but with an extra Treasure token, an Eternal Witness token, and a Dockside Extortionist token, and with 2 untapped lands instead of {1}{R}.
Repeat for infinite Treasure tokens and creature tokens.

---

# 802-914-1235-2649

**Cards:**

- Vadrok, Apex of Thunder
- Dockside Extortionist
- Twinflame
- Snap

**Produces:** Cast a subset of spells in your graveyard, Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Infinite Treasure tokens, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: {1}{W/U}{R}{R}, plus commander tax if applicable, plus one additional red, white, or blue mana if opponents control exactly three artifacts and/or enchantments, MV: 4, Colors: URW, Popularity: 23**

**Steps:**

Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under Dockside Extortionist.
The Dockside Extortionist mutated creature's ability from Vadrok triggers, casting Twinflame from your graveyard without paying its mana cost.
Resolve Twinflame, creating a token copy of the Dockside Extortionist mutated creature with haste.
The token copy of the Dockside Extortionist mutated creature triggers, creating at least three Treasure tokens.
Activate three Treasure tokens by tapping and sacrificing them, adding {U}{R}{R}.
Cast Snap by paying {1}{U}, returning the nontoken Dockside Extortionist and Vadrok from the battlefield to your hand and untapping two lands you control.
Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under the token Dockside Extortionist mutated creature.
The token Dockside Extortionist mutated creature triggers once for each of its Vadrok abilities.
Resolve one of these triggers, casting Twinflame from your graveyard without paying its mana cost.
Resolve Twinflame, creating a token copy of the Dockside Extortionist mutated creature with haste.
The token copy of the Dockside Extortionist mutated creature triggers, creating at least three Treasure tokens.
Activate three Treasure tokens by tapping and sacrificing them, adding {U}{R}{R}.
Resolve a second trigger from step 8, casting Snap from your graveyard without paying its mana cost, targeting the mutated creature that includes the nontoken Vadrok.
Resolve Snap, returning Vadrok from the battlefield to your hand as well as multiple token creatures which cease to exist, and untapping two lands you control.
Resolve any remaining triggers from step 8, casting any noncreature cards with mana value 3 or less that were not already cast since step 8 from your graveyard without paying their casting costs.
Repeat from step 7, adding one additional token Vadrok to each new iteration of the Dockside Extortionist mutated creature token.

---

# 802-914-2649-2959

**Cards:**

- Vadrok, Apex of Thunder
- Dockside Extortionist
- Heat Shimmer
- Snap

**Produces:** Cast a subset of spells in your graveyard, Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Infinite Treasure tokens, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: {1}{W/U}{R}{R}, plus commander tax if applicable, plus one additional red, white, or blue mana if opponents control exactly three artifacts and/or enchantments, MV: 4, Colors: URW, Popularity: 10**

**Steps:**

Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under Dockside Extortionist.
The Dockside Extortionist mutated creature's ability from Vadrok triggers, casting Heat Shimmer from your graveyard without paying its mana cost.
Resolve Heat Shimmer, creating a token copy of the Dockside Extortionist mutated creature with haste.
The token copy of the Dockside Extortionist mutated creature triggers, creating at least three Treasure tokens.
Activate three Treasure tokens by tapping and sacrificing them, adding {U}{R}{R}.
Cast Snap by paying {1}{U}, returning the nontoken Dockside Extortionist and Vadrok from the battlefield to your hand and untapping two lands you control.
Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under the token Dockside Extortionist mutated creature.
The token Dockside Extortionist mutated creature triggers once for each of its Vadrok abilities.
Resolve one of these triggers, casting Heat Shimmer from your graveyard without paying its mana cost.
Resolve Heat Shimmer, creating a token copy of the Dockside Extortionist mutated creature with haste.
The token copy of the Dockside Extortionist mutated creature triggers, creating at least three Treasure tokens.
Activate three Treasure tokens by tapping and sacrificing them, adding {U}{R}{R}.
Resolve a second trigger from step 8, casting Snap from your graveyard without paying its mana cost, targeting the mutated creature that includes the nontoken Vadrok.
Resolve Snap, returning Vadrok from the battlefield to your hand as well as multiple token creatures which cease to exist, and untapping two lands you control.
Resolve any remaining triggers from step 8, casting any noncreature cards with mana value 3 or less that were not already cast since step 8 from your graveyard without paying their casting costs.
Repeat from step 7, adding one additional token Vadrok to each new iteration of the Dockside Extortionist mutated creature token.

---

# 802-914-2649-4615

**Cards:**

- Vadrok, Apex of Thunder
- Dockside Extortionist
- Quasiduplicate
- Snap

**Produces:** Cast a subset of spells in your graveyard, Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Infinite Treasure tokens, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: {1}{W/U}{R}{R}, plus commander tax if applicable, plus one additional red, white, or blue mana if opponents control exactly three artifacts and/or enchantments, MV: 4, Colors: URW, Popularity: 12**

**Steps:**

Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under Dockside Extortionist.
The Dockside Extortionist mutated creature's ability from Vadrok triggers, casting Quasiduplicate from your graveyard without paying its mana cost.
Resolve Quasiduplicate, creating a token copy of the Dockside Extortionist mutated creature with haste.
The token copy of the Dockside Extortionist mutated creature triggers, creating at least three Treasure tokens.
Activate three Treasure tokens by tapping and sacrificing them, adding {U}{R}{R}.
Cast Snap by paying {1}{U}, returning the nontoken Dockside Extortionist and Vadrok from the battlefield to your hand and untapping two lands you control.
Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R}, merging it under the token Dockside Extortionist mutated creature.
The token Dockside Extortionist mutated creature triggers once for each of its Vadrok abilities.
Resolve one of these triggers, casting Quasiduplicate from your graveyard without paying its mana cost.
Resolve Quasiduplicate, creating a token copy of the Dockside Extortionist mutated creature with haste.
The token copy of the Dockside Extortionist mutated creature triggers, creating at least three Treasure tokens.
Activate three Treasure tokens by tapping and sacrificing them, adding {U}{R}{R}.
Resolve a second trigger from step 8, casting Snap from your graveyard without paying its mana cost, targeting the mutated creature that includes the nontoken Vadrok.
Resolve Snap, returning Vadrok from the battlefield to your hand as well as multiple token creatures which cease to exist, and untapping two lands you control.
Resolve any remaining triggers from step 8, casting any noncreature cards with mana value 3 or less that were not already cast since step 8 from your graveyard without paying their casting costs.
Repeat from step 7, adding one additional token Vadrok to each new iteration of the Dockside Extortionist mutated creature token.

---

# 803-1134-1267-3395

**Cards:**

- Medomai the Ageless
- Preeminent Captain
- Arcane Adaptation
- Crystal Shard

**Produces:** Infinite turns, Lock

**Mana: {U} each turn, MV: 1, Colors: WU, Popularity: 3**

**Steps:**

Declare Preeminent Captain as an attacker.
Preeminent Captain triggers, putting Medomai from your hand onto the battlefield tapped and attacking.
Deal combat damage with Medomai, causing you to take an extra turn after this one.
Activate Crystal Shard by paying {U} and tapping it, returning Medomai to your hand.
Pass the turn.
Repeat.

---

# 803-1134-1267-3632

**Cards:**

- Medomai the Ageless
- Preeminent Captain
- Arcane Adaptation
- Erratic Portal

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: WU, Popularity: 1**

**Steps:**

Declare Preeminent Captain as an attacker.
Preeminent Captain triggers, putting Medomai from your hand onto the battlefield tapped and attacking.
Deal combat damage with Medomai, causing you to take an extra turn after this one.
Activate Erratic Portal by paying {1} and tapping it, returning Medomai to your hand.
Pass the turn.
Repeat.

---

# 803-1322-3638

**Cards:**

- Arcane Adaptation
- Turntimber Ranger
- Concordant Crossroads

**Produces:** Infinite creature tokens with haste, Infinite ETB, Infinitely large creature

**Mana: {3}{G}{G}, MV: 5, Colors: GU, Popularity: 22**

**Steps:**

Cast Turntimber Ranger by paying {3}{G}{G}.
Turntimber Ranger enters the battlefield, creating a 2/2 Wolf creature token and putting a +1/+1 counter on Turntimber Ranger.
2/2 Wolf creature token enters the battlefield triggering Turntimber Ranger, creating a 2/2 Wolf creature token and putting a +1/+1 counter on Turntimber Ranger.
Repeat from step 2.

---

# 803-1424-4620

**Cards:**

- Arcane Adaptation
- Captain of the Mists
- Presence of Gond

**Produces:** Infinite ETB, Infinite creature tokens

**Mana: , MV: 0, Colors: GU, Popularity: 2**

**Steps:**

Tap Captain of the Mists to activate Presence of Gond, creating a human elf token.
On ETB, the token triggers Captain of the Mists, untapping it.

---

# 803-2034-3413

**Cards:**

- Xathrid Necromancer
- Arcane Adaptation
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: UB, Popularity: 23**

**Steps:**

Activate Ashnod's Altar by sacrificing any other creature, adding {C}{C}.
Xathrid Necromancer triggers, creating a 2/2 Zombie creature token.
Repeat.

---

# 803-3413-4050

**Cards:**

- Xathrid Necromancer
- Arcane Adaptation
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: UB, Popularity: 18**

**Steps:**

Activate Phyrexian Altar by sacrificing any other creature, adding one mana of any color.
Xathrid Necromancer triggers, creating a 2/2 Zombie creature token.
Repeat.

---

# 803-3413-5256

**Cards:**

- Xathrid Necromancer
- Arcane Adaptation
- Altar of Dementia

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: UB, Popularity: 16**

**Steps:**

Activate Altar of Dementia by sacrificing any other creature.
Xathrid Necromancer triggers, creating a 2/2 Zombie creature token.
Resolve the Altar of Dementia ability, causing target player to mill cards equal to the sacrificed creature's power.
Repeat.

---

# 803-3581-4302

**Cards:**

- Kykar, Wind's Fury
- Bishop of Wings
- Arcane Adaptation

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite red mana, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: URW, Popularity: 41**

**Steps:**

Sacrifice a Spirit to Kykar's ability, gaining {R}.
Bishop of Wings triggers, creating a 1/1 Spirit token.
When the token ETB, Bishop of Wings triggers again, gaining you 4 life.
Repeat.

---

# 803-3638

**Cards:**

- Arcane Adaptation
- Turntimber Ranger

**Produces:** Infinite creature tokens, Infinite ETB, Infinitely large creature

**Mana: {3}{G}{G}, MV: 5, Colors: GU, Popularity: 724**

**Steps:**

Cast Turntimber Ranger by paying {3}{G}{G}.
Turntimber Ranger enters the battlefield, creating a 2/2 Wolf creature token and putting a +1/+1 counter on Turntimber Ranger.
2/2 Wolf creature token enters the battlefield triggering Turntimber Ranger, creating a 2/2 Wolf creature token and putting a +1/+1 counter on Turntimber Ranger.
Repeat from step 2.

---

# 804-2034-2533-3175

**Cards:**

- Sun Titan
- Sakashima the Impostor
- Loyal Retainers
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: {4}{W}{W}, MV: 6, Colors: WU, Popularity: 2**

**Steps:**

Cast Sun Titan.
When Sun Titan enters the battlefield you may, return Loyal Retainers to the battlefield.
Activate Loyal Retainers, targeting Sakashima the Impostor.
Have Sakashima the Impostor enter as a copy of Sun Titan.
With Sakashima's enter the battlefield ability, return Loyal Retainers to the battlefield.
Sacrifice Sakashima to Ashnod's Altar.
Activate Loyal Retainers, targeting Sakashima the Impostor.
Repeat.

---

# 804-2533-3175-4050

**Cards:**

- Sun Titan
- Sakashima the Impostor
- Loyal Retainers
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: {4}{W}{W}, MV: 6, Colors: WU, Popularity: 2**

**Steps:**

Cast Sun Titan.
When Sun Titan enters the battlefield you may, return Loyal Retainers to the battlefield.
Activate Loyal Retainers, targeting Sakashima the Impostor.
Have Sakashima the Impostor enter as a copy of Sun Titan.
With Sakashima's enter the battlefield ability, return Loyal Retainers to the battlefield.
Sacrifice Sakashima to Phyrexian Altar.
Activate Loyal Retainers, targeting Sakashima the Impostor.
Repeat.

---

# 804-2533-3175-5256

**Cards:**

- Sun Titan
- Sakashima the Impostor
- Loyal Retainers
- Altar of Dementia

**Produces:** Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers

**Mana: {4}{W}{W}, MV: 6, Colors: WU, Popularity: 6**

**Steps:**

Cast Sun Titan.
When Sun Titan enters the battlefield you may, return Loyal Retainers to the battlefield.
Activate Loyal Retainers, targeting Sakashima the Impostor.
Have Sakashima the Impostor enter as a copy of Sun Titan.
With Sakashima's enter the battlefield ability, return Loyal Retainers to the battlefield.
Sacrifice Sakashima to Altar of Dementia.
Activate Loyal Retainers, targeting Sakashima the Impostor.
Repeat.

---

# 809-893-4853

**Cards:**

- Dross Scorpion
- Myr Turbine
- Fanatical Devotion

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: W, Popularity: 4**

**Steps:**

Activate Myr Turbine by tapping it, creating a 1/1 Myr artifact creature token.
Activate Fanatical Devotion by sacrificing a Myr token.
Dross Scorpion triggers, untapping Myr Turbine.
Resolve the Fanatical Devotion's ability, regenerate target creature.
Repeat.

---

# 813-1193-4095

**Cards:**

- Mythos of Illuna
- Radiate
- Scholar of the Ages

**Produces:** Infinite copies of all permanents, Infinite magecraft triggers, Infinite mana permanents on the battlefield can produce, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: {5}{U}{U}{R}{R}, MV: 9, Colors: GUR, Popularity: 2**

**Steps:**

Cast Mythos of Illuna by paying {2}{U}{U}, targeting anything but Scholar of the Ages.
In response, cast Radiate by paying {3}{R}{R}, creating copies of Mythos of Illuna that target each permanent besides the original target.
Resolve all copies of Mythos of Illuna besides the original, creating token copies of each permanent besides the original target.
The token copy of Scholar of the Ages enters the battlefield, triggering itself, returning Radiate from your graveyard to your hand.
Activate the token lands or other mana-producing permanents created in step 3 by tapping them, adding at least {3}{R}{R}.
Repeat from step 2, doubling the number of copies created in step 3 each repetition.

---

# 813-1283-1518-1987

**Cards:**

- Ghostly Flicker
- Will Kenrith
- Scholar of the Ages
- Chromatic Orrery

**Produces:** Infinite card draw, Infinite colored mana, Infinite colorless mana, Infinite draw triggers, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 6**

**Steps:**

Activate Will Kenrith's -2 ability targeting yourself, reducing the cost of your instant, sorcery, and planeswalker spells by {2} until end of turn and drawing you 2 cards.
Activate Chromatic Orrery's first activated ability by tapping it, adding {C}{C}{C}{C}{C}.
Cast Ghostly Flicker by paying {C}, targeting Chromatic Orrery and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
Repeat.
Once you have infinite mana, you may activate Chromatic Orrery's last ability any number of times.

---

# 813-1283-1987

**Cards:**

- Ghostly Flicker
- Scholar of the Ages
- Chromatic Orrery

**Produces:** Infinite card draw, Infinite colored mana, Infinite colorless mana, Infinite draw triggers, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 59**

**Steps:**

Activate Chromatic Orrery's first activated ability by tapping it, adding {C}{C}{C}{C}{C}.
Cast Ghostly Flicker for {3} targeting Chromatic Orrery and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
Repeat.
Once you have infinite mana, you may activate Chromatic Orrery's last ability any number of times.

---

# 813-1283-1987-2427

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Scholar of the Ages
- Chromatic Orrery

**Produces:** Infinite card draw, Infinite colored mana, Infinite colorless mana, Infinite draw triggers, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 4**

**Steps:**

Activate Chromatic Orrery's first activated ability by tapping it, adding {C}{C}{C}{C}{C}.
Cast Ghostly Flicker by paying {C}, targeting Chromatic Orrery and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
Repeat.
Once you have infinite mana, you may activate Chromatic Orrery's last ability any number of times.

---

# 813-1283-1987-3075

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Scholar of the Ages
- Chromatic Orrery

**Produces:** Infinite card draw, Infinite colored mana, Infinite colorless mana, Infinite draw triggers, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: UR, Popularity: 4**

**Steps:**

Activate Chromatic Orrery's first activated ability by tapping it, adding {C}{C}{C}{C}{C}.
Cast Ghostly Flicker by paying {C}, targeting Chromatic Orrery and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
Repeat.
Once you have infinite mana, you may activate Chromatic Orrery's last ability any number of times.

---

# 813-1518-1964-1987

**Cards:**

- Ghostly Flicker
- Will Kenrith
- Scholar of the Ages
- Meteorite

**Produces:** Infinite damage, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 5**

**Steps:**

Activate Will Kenrith's -2 ability targeting yourself, reducing the cost of your instant, sorcery, and planeswalker spells by {2} until end of turn and drawing you 2 cards.
Activate Meteorite by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Meteorite and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Meteorite enters the battlefield, deal 2 damage to any target.
Repeat.

---

# 813-1518-1987

**Cards:**

- Will Kenrith
- Ghostly Flicker
- Scholar of the Ages

**Produces:** Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 32**

**Steps:**

Activate Will's second ability by removing two loyalty counters from it, causing target player to draw two cards and causing all instant, sorcery and planeswalker spells you cast to cost {2} less this turn.
Activate the aritfact and/or land by tapping it, adding at least {U}.
Cast Ghostly Flicker by paying {U}, blinking Scholar of the Ages and the artifact and/or land.
Scholar of the Ages enters the battlefield, returning Ghostly Flicker from the graveyard to your hand.
Repeat.

---

# 813-1518-1987-3448

**Cards:**

- Ghostly Flicker
- Will Kenrith
- Scholar of the Ages
- Stadium Vendors

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: {U}, MV: 1, Colors: UR, Popularity: 4**

**Steps:**

Cast Ghostly Flicker by paying {U}, targeting Stadium Vendors and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Stadium Vendors enters the battlefield, add {U}{U}.
Repeat.

---

# 813-1518-1987-3573

**Cards:**

- Ghostly Flicker
- Will Kenrith
- Scholar of the Ages
- Tolarian Academy

**Produces:** Infinite blue mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 0**

**Steps:**

Activate Will Kenrith's -2 ability targeting yourself, reducing the cost of your instant, sorcery, and planeswalker spells by {2} until end of turn and drawing you 2 cards.
Activate Tolarian Academy by tapping it, adding at least {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Tolarian Academy and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
Repeat.

---

# 813-1518-1987-3941

**Cards:**

- Ghostly Flicker
- Will Kenrith
- Scholar of the Ages
- Coveted Jewel

**Produces:** Infinite card draw, Infinite draw triggers, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Near-infinite colored mana, Near-infinite ETB, Near-infinite LTB, Near-infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 14**

**Steps:**

Activate Will Kenrith's -2 ability targeting yourself, reducing the cost of your instant, sorcery, and planeswalker spells by {2} until end of turn and drawing you 2 cards.
Activate Coveted Jewel by tapping it, adding {U}{U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Coveted Jewel and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Coveted Jewel enters the battlefield, draw three cards.
Repeat.

---

# 813-1518-1987-4714

**Cards:**

- Ghostly Flicker
- Will Kenrith
- Scholar of the Ages
- Mana Geode

**Produces:** Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite scry 1, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 6**

**Steps:**

Activate Will Kenrith's -2 ability targeting yourself, reducing the cost of your instant, sorcery, and planeswalker spells by {2} until end of turn and drawing you 2 cards.
Activate Mana Geode by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Mana Geode and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Mana Geode enters the battlefield, scry 1.
Repeat.

---

# 813-1518-1987-4792

**Cards:**

- Ghostly Flicker
- Will Kenrith
- Scholar of the Ages
- Paradise Plume

**Produces:** Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 7**

**Steps:**

Activate Will Kenrith's -2 ability targeting yourself, reducing the cost of your instant, sorcery, and planeswalker spells by {2} until end of turn and drawing you 2 cards.
Activate Paradise Plume by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Paradise Plume and Scholar of the Ages, blinking them as well as triggering Paradise Plume to gain you 1 life.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Paradise Plume enters the battlefield, choose "blue".
Repeat.

---

# 813-1518-1987-5116

**Cards:**

- Ghostly Flicker
- Will Kenrith
- Scholar of the Ages
- Gilded Lotus

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 19**

**Steps:**

Activate Will Kenrith's -2 ability targeting yourself, reducing the cost of your instant, sorcery, and planeswalker spells by {2} until end of turn and drawing you 2 cards.
Activate Gilded Lotus by tapping it, adding {U}{U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Gilded Lotus and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
Repeat.

---

# 813-1846-1987

**Cards:**

- High Tide
- Scholar of the Ages
- Ghostly Flicker

**Produces:** Infinite blinking of artifacts, creatures, and lands, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite mana lands you control can produce, Infinite storm count, Infinite landfall triggers, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 997**

**Steps:**

Activate an Island by tapping it, adding {U}.
Cast High Tide by paying {U}, creating a delayed triggered ability that adds {U} whenever an Island is tapped for mana this turn.
Activate four Islands by tapping them, adding {U}{U}{U}{U}.
High Tide's delayed trigger triggers four times, adding an additional {U}{U}{U}{U}.
Cast Scholar of the Ages by paying {5}{U}{U}.
Scholar of the Ages enters the battlefield, triggering itself, returning High Tide from your graveyard to your hand.
Cast High Tide by paying {U}, creating a second delayed triggered ability.
Activate two Islands by tapping them, adding {U}{U}.
High Tide delayed triggers trigger a combined total of four times, adding an additional {U}{U}{U}{U}{U}{U}.
Cast Ghostly Flicker by paying {2}{U}, blinking an Island and Scholar of the Ages.
Scholar of the Ages enters the battlefield, triggering itself, returning High Tide and Ghostly Flicker from your graveyard to your hand.
Repeat from step 7, except that you activate only one Island in step 8 and trigger an increasing number of High Tide delayed triggered abilities in step 9.

---

# 813-1964-1987-2427

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Scholar of the Ages
- Meteorite

**Produces:** Infinite damage, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 5**

**Steps:**

Activate Meteorite by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Meteorite and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Meteorite enters the battlefield, deal 2 damage to any target.
Repeat.

---

# 813-1964-1987-2510

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Scholar of the Ages
- Meteorite

**Produces:** Infinite damage, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 4**

**Steps:**

Activate Meteorite by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Meteorite and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Meteorite enters the battlefield, deal 2 damage to any target.
Repeat.

---

# 813-1964-1987-3075

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Scholar of the Ages
- Meteorite

**Produces:** Infinite damage, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: UR, Popularity: 5**

**Steps:**

Activate Meteorite by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Meteorite and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Meteorite enters the battlefield, deal 2 damage to any target.
Repeat.

---

# 813-1987-2427

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Scholar of the Ages

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: {U}, MV: 1, Colors: U, Popularity: 8**

**Steps:**

Cast Ghostly Flicker by paying {U}, targeting Scholar of the Ages and your untapped source, blinking them both.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to your hand.
Tap your untapped blue source for {U}.
Repeat.

---

# 813-1987-2427-3448

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Scholar of the Ages
- Stadium Vendors

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: {U}, MV: 1, Colors: UR, Popularity: 3**

**Steps:**

Cast Ghostly Flicker by paying {U}, targeting Stadium Vendors and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Stadium Vendors enters the battlefield, add {U}{U}.
Repeat.

---

# 813-1987-2427-3573

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Scholar of the Ages
- Tolarian Academy

**Produces:** Infinite blue mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 0**

**Steps:**

Activate Tolarian Academy by tapping it, adding at least {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Tolarian Academy and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
Repeat.

---

# 813-1987-2427-3941

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Scholar of the Ages
- Coveted Jewel

**Produces:** Infinite card draw, Infinite draw triggers, Infinite ETB, Infinite LTB, Infinite storm count, Near-infinite colored mana, Near-infinite ETB, Near-infinite LTB, Near-infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 3**

**Steps:**

Activate Coveted Jewel by tapping it, adding {U}{U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Coveted Jewel and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Coveted Jewel enters the battlefield, draw three cards.
Repeat.

---

# 813-1987-2427-4714

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Scholar of the Ages
- Mana Geode

**Produces:** Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite scry 1, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 3**

**Steps:**

Activate Mana Geode by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Mana Geode and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Mana Geode enters the battlefield, scry 1.
Repeat.

---

# 813-1987-2427-4792

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Scholar of the Ages
- Paradise Plume

**Produces:** Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 2**

**Steps:**

Activate Paradise Plume by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Paradise Plume and Scholar of the Ages, blinking them as well as triggering Paradise Plume to gain you 1 life.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Paradise Plume enters the battlefield, choose "blue".
Repeat.

---

# 813-1987-2427-5116

**Cards:**

- Ghostly Flicker
- Mana Matrix
- Scholar of the Ages
- Gilded Lotus

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 4**

**Steps:**

Activate Gilded Lotus by tapping it, adding {U}{U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Gilded Lotus and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
Repeat.

---

# 813-1987-2510

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Scholar of the Ages

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: {U}, MV: 1, Colors: U, Popularity: 23**

**Steps:**

Cast Ghostly Flicker by paying {U}, targeting Scholar of the Ages and your untapped source, blinking them both.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to your hand.
Tap your untapped blue source for {U}.
Repeat.

---

# 813-1987-2510-3448

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Scholar of the Ages
- Stadium Vendors

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: {U}, MV: 1, Colors: UR, Popularity: 2**

**Steps:**

Cast Ghostly Flicker by paying {U}, targeting Stadium Vendors and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Stadium Vendors enters the battlefield, add {U}{U}.
Repeat.

---

# 813-1987-2510-3573

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Scholar of the Ages
- Tolarian Academy

**Produces:** Infinite blue mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 0**

**Steps:**

Activate Tolarian Academy by tapping it, adding at least {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Tolarian Academy and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
Repeat.

---

# 813-1987-2510-3941

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Scholar of the Ages
- Coveted Jewel

**Produces:** Infinite card draw, Infinite draw triggers, Infinite ETB, Infinite LTB, Infinite storm count, Near-infinite colored mana, Near-infinite ETB, Near-infinite LTB, Near-infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 9**

**Steps:**

Activate Coveted Jewel by tapping it, adding {U}{U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Coveted Jewel and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Coveted Jewel enters the battlefield, draw three cards.
Repeat.

---

# 813-1987-2510-4714

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Scholar of the Ages
- Mana Geode

**Produces:** Infinite LTB, Infinite magecraft triggers, Infinite scry 1, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand, Infinite ETB

**Mana: , MV: 0, Colors: U, Popularity: 4**

**Steps:**

Activate Mana Geode by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Mana Geode and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Mana Geode enters the battlefield, scry 1.
Repeat.

---

# 813-1987-2510-4792

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Scholar of the Ages
- Paradise Plume

**Produces:** Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 5**

**Steps:**

Activate Paradise Plume by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Paradise Plume and Scholar of the Ages, blinking them as well as triggering Paradise Plume to gain you 1 life.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Paradise Plume enters the battlefield, choose "blue".
Repeat.

---

# 813-1987-2510-5116

**Cards:**

- Ghostly Flicker
- Semblance Anvil
- Scholar of the Ages
- Gilded Lotus

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 10**

**Steps:**

Activate Gilded Lotus by tapping it, adding {U}{U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Gilded Lotus and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
Repeat.

---

# 813-1987-3075

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Scholar of the Ages

**Produces:** Infinite ETB, Infinite LTB, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: {U}, MV: 1, Colors: UR, Popularity: 23**

**Steps:**

Cast Ghostly Flicker by paying {U}, targeting Scholar of the Ages and your untapped source, blinking them both.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to your hand.
Tap your untapped blue source for {U}.
Repeat.

---

# 813-1987-3075-3448

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Scholar of the Ages
- Stadium Vendors

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: {U}, MV: 1, Colors: UR, Popularity: 4**

**Steps:**

Cast Ghostly Flicker by paying {U}, targeting Stadium Vendors and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Stadium Vendors enters the battlefield, add {U}{U}.
Repeat.

---

# 813-1987-3075-3573

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Scholar of the Ages
- Tolarian Academy

**Produces:** Infinite blue mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: UR, Popularity: 0**

**Steps:**

Activate Tolarian Academy by tapping it, adding at least {U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Tolarian Academy and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
Repeat.

---

# 813-1987-3075-3941

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Scholar of the Ages
- Coveted Jewel

**Produces:** Infinite card draw, Infinite draw triggers, Infinite ETB, Infinite LTB, Infinite storm count, Near-infinite colored mana, Near-infinite ETB, Near-infinite LTB, Near-infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: UR, Popularity: 5**

**Steps:**

Activate Coveted Jewel by tapping it, adding {U}{U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Coveted Jewel and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Coveted Jewel enters the battlefield, draw three cards.
Repeat.

---

# 813-1987-3075-4714

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Scholar of the Ages
- Mana Geode

**Produces:** Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite scry 1, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: UR, Popularity: 4**

**Steps:**

Activate Mana Geode by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Mana Geode and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Mana Geode enters the battlefield, scry 1.
Repeat.

---

# 813-1987-3075-4792

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Scholar of the Ages
- Paradise Plume

**Produces:** Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: UR, Popularity: 2**

**Steps:**

Activate Paradise Plume by tapping it, adding {U}.
Cast Ghostly Flicker by paying {U}, targeting Paradise Plume and Scholar of the Ages, blinking them as well as triggering Paradise Plume to gain you 1 life.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
When Paradise Plume enters the battlefield, choose "blue".
Repeat.

---

# 813-1987-3075-5116

**Cards:**

- Ghostly Flicker
- Mizzix of the Izmagnus
- Scholar of the Ages
- Gilded Lotus

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: UR, Popularity: 6**

**Steps:**

Activate Gilded Lotus by tapping it, adding {U}{U}{U}.
Cast Ghostly Flicker by paying {U}, targeting Gilded Lotus and Scholar of the Ages, blinking them.
When Scholar of the Ages enters the battlefield, return Ghostly Flicker to you hand.
Repeat.

---

# 813-2103-2628

**Cards:**

- Escape Protocol
- Scholar of the Ages
- Capture of Jingzhou

**Produces:** Infinite turns, Lock

**Mana: {4}{U}{U} plus enough mana to cycle the instant/sorcery each turn, MV: 6, Colors: U, Popularity: 1**

**Steps:**

Cast Capture of Jingzhou by paying {3}{U}{U}, causing you to take an extra turn after this one.
Activate any instant/sorcery card in your hand's cycling ability by paying its cycling cost and discarding it.
Escape Protocol triggers, causing you to pay {1} to blink Scholar of the Ages.
Scholar of the Ages enters the battlefield, returning Capture of Jingzhou and the card with cycling from your graveyard to your hand.
Resolve the cycling ability from step 2, causing you to draw a card.
Repeat each turn.

---

# 813-2103-2665

**Cards:**

- Progenitor Mimic
- Capture of Jingzhou
- Scholar of the Ages

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: GU, Popularity: 0**

**Steps:**

Cast Capture of Jingzhou by paying its mana cost, taking an extra turn after this one.
At the beginning of your next upkeep, Progenitor Mimic triggers, creating a token copy of Scholar of the Ages.
When the token Scholar of the Ages enters the battlefield, it triggers itself, returning Capture of Jingzhou and up to one additional target instant or sorcery card from your graveyard to your hand.
Repeat.

---

# 813-2103-4305

**Cards:**

- Scholar of the Ages
- Followed Footsteps
- Capture of Jingzhou

**Produces:** Infinite creature tokens, Infinite turns, Lock

**Mana: {3}{U}{U} each turn, MV: 5, Colors: U, Popularity: 5**

**Steps:**

Cast Capture of Jingzhou by paying {3}{U}{U}, taking an extra turn after this one.
Move to your next turn.
At the beginning of your upkeep, Followed Footsteps triggers, creating a copy of Scholar of the Ages.
Scholar of the Ages enters the battlefield, returning Capture of Jingzhou to your hand.
Repeat.

---

# 813-2104-2628

**Cards:**

- Escape Protocol
- Scholar of the Ages
- Temporal Manipulation

**Produces:** Infinite turns, Lock

**Mana: {4}{U}{U} plus enough mana to cycle the instant/sorcery each turn, MV: 6, Colors: U, Popularity: 5**

**Steps:**

Cast Temporal Manipulation by paying {3}{U}{U}, causing you to take an extra turn after this one.
Activate any instant/sorcery card in your hand's cycling ability by paying its cycling cost and discarding it.
Escape Protocol triggers, causing you to pay {1} to blink Scholar of the Ages.
Scholar of the Ages enters the battlefield, returning Temporal Manipulation and the card with cycling from your graveyard to your hand.
Resolve the cycling ability from step 2, causing you to draw a card.
Repeat each turn.

---

# 813-2104-2665

**Cards:**

- Progenitor Mimic
- Temporal Manipulation
- Scholar of the Ages

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: GU, Popularity: 2**

**Steps:**

Cast Temporal Manipulation by paying its mana cost, taking an extra turn after this one.
At the beginning of your next upkeep, Progenitor Mimic triggers, creating a token copy of Scholar of the Ages.
When the token Scholar of the Ages enters the battlefield, it triggers itself, returning Temporal Manipulation and up to one additional target instant or sorcery card from your graveyard to your hand.
Repeat.

---

# 813-2104-4305

**Cards:**

- Scholar of the Ages
- Followed Footsteps
- Temporal Manipulation

**Produces:** Infinite turns, Lock, Infinite creature tokens

**Mana: {3}{U}{U} each turn, MV: 5, Colors: U, Popularity: 9**

**Steps:**

Cast Temporal Manipulation by paying {3}{U}{U}, taking an extra turn after this one.
Move to your next turn.
At the beginning of your upkeep, Followed Footsteps triggers, creating a copy of Scholar of the Ages.
Scholar of the Ages enters the battlefield, returning Temporal Manipulation to your hand.
Repeat.

---

# 813-2628-4276

**Cards:**

- Escape Protocol
- Scholar of the Ages
- Turnabout

**Produces:** Infinite card draw, Infinite draw triggers, Infinite self-discard triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite magecraft triggers, Near-infinite mana lands you control can produce, Near-infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 19**

**Steps:**

Activate all mana-producing lands you control by tapping them, adding at least {3}{U}{U} plus enough mana to pay for the cycling cost of an instant/sorcery card in your hand.
Cast Turnabout by paying {2}{U}{U}, untapping all lands you control.
Activate any instant/sorcery card in your hand's cycling ability by paying its cycling cost and discarding it.
Escape Protocol triggers, causing you to pay {1} to blink Scholar of the Ages.
Scholar of the Ages enters the battlefield, returning Turnabout and the card with cycling from your graveyard to your hand.
Resolve the cycling ability from step 2, causing you to draw a card.
Repeat.

---

# 813-2628-4377

**Cards:**

- Escape Protocol
- Scholar of the Ages
- Walk the Aeons

**Produces:** Infinite turns, Lock

**Mana: {5}{U}{U} plus enough mana to cycle the instant/sorcery each turn, MV: 7, Colors: U, Popularity: 1**

**Steps:**

Cast Walk the Aeons by paying {5}{U}{U}, causing you to take an extra turn after this one.
Activate any instant/sorcery card in your hand's cycling ability by paying its cycling cost and discarding it.
Escape Protocol triggers, causing you to pay {1} to blink Scholar of the Ages.
Scholar of the Ages enters the battlefield, returning Walk the Aeons and the card with cycling from your graveyard to your hand.
Resolve the cycling ability from step 2, causing you to draw a card.
Repeat each turn.

---

# 813-2628-4821

**Cards:**

- Escape Protocol
- Scholar of the Ages
- Dramatic Reversal

**Produces:** Infinite card draw, Infinite draw triggers, Infinite self-discard triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite magecraft triggers, Near-infinite mana nonland permanents you control can produce, Near-infinite storm count, Return all instant and sorcery cards from your graveyard to your hand

**Mana: , MV: 0, Colors: U, Popularity: 2**

**Steps:**

Activate all nonland mana-producing permanents you control by tapping them, adding at least {3}{U} plus enough mana to pay for the cycling cost of an instant/sorcery card in your hand.
Cast Dramatic Reversal by paying {1}{U}, untapping all nonland permanents you control.
Activate any instant/sorcery card in your hand's cycling ability by paying its cycling cost and discarding it.
Escape Protocol triggers, causing you to pay {1} to blink Scholar of the Ages.
Scholar of the Ages enters the battlefield, returning Dramatic Reversal and the card with cycling from your graveyard to your hand.
Resolve the cycling ability from step 2, causing you to draw a card.
Repeat.

---

# 813-2628-4872

**Cards:**

- Escape Protocol
- Scholar of the Ages
- Time Warp

**Produces:** Infinite turns, Lock

**Mana: {4}{U}{U} plus enough mana to cycle the instant/sorcery each turn, MV: 6, Colors: U, Popularity: 9**

**Steps:**

Cast Time Warp by paying {3}{U}{U}, causing you to take an extra turn after this one.
Activate any instant/sorcery card in your hand's cycling ability by paying its cycling cost and discarding it.
Escape Protocol triggers, causing you to pay {1} to blink Scholar of the Ages.
Scholar of the Ages enters the battlefield, returning Time Warp and the card with cycling from your graveyard to your hand.
Resolve the cycling ability from step 2, causing you to draw a card.
Repeat each turn.

---

# 813-2665-3617

**Cards:**

- Progenitor Mimic
- Time Walk
- Scholar of the Ages

**Produces:** Infinite turns, Lock

**Mana: {1}{U} each turn, MV: 2, Colors: GU, Popularity: 0**

**Steps:**

Cast Time Walk by paying {1}{U}, taking an extra turn after this one.
At the beginning of your next upkeep, Progenitor Mimic triggers, creating a token copy of Scholar of the Ages.
When the token Scholar of the Ages enters the battlefield, it triggers, returning Time Walk from your graveyard to your hand.
Repeat.

---

# 813-2665-4377

**Cards:**

- Progenitor Mimic
- Walk the Aeons
- Scholar of the Ages

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: GU, Popularity: 2**

**Steps:**

Cast Walk the Aeons by paying its mana cost, taking an extra turn after this one.
At the beginning of your next upkeep, Progenitor Mimic triggers, creating a token copy of Scholar of the Ages.
When the token Scholar of the Ages enters the battlefield, it triggers itself, returning Walk the Aeons and up to one additional target instant or sorcery card from your graveyard to your hand.
Repeat.

---

# 813-2665-4872

**Cards:**

- Progenitor Mimic
- Time Warp
- Scholar of the Ages

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: GU, Popularity: 3**

**Steps:**

Cast Time Warp by paying its mana cost, taking an extra turn after this one.
At the beginning of your next upkeep, Progenitor Mimic triggers, creating a token copy of Scholar of the Ages.
When the token Scholar of the Ages enters the battlefield, it triggers itself, returning Time Warp and up to one additional target instant or sorcery card from your graveyard to your hand.
Repeat.

---

# 813-3617-4305

**Cards:**

- Scholar of the Ages
- Followed Footsteps
- Time Walk

**Produces:** Infinite creature tokens, Infinite turns, Lock

**Mana: {1}{U} each turn, MV: 2, Colors: U, Popularity: 0**

**Steps:**

Cast Time Walk by paying {1}{U}, taking an extra turn after this one.
Move to your next turn.
At the beginning of your upkeep, Followed Footsteps triggers, creating a copy of Scholar of the Ages.
Scholar of the Ages enters the battlefield, returning Time Walk to your hand.
Repeat.

---

# 813-4305-4377

**Cards:**

- Scholar of the Ages
- Followed Footsteps
- Walk the Aeons

**Produces:** Infinite creature tokens, Infinite turns, Lock

**Mana: {3}{U}{U} each turn, MV: 5, Colors: U, Popularity: 6**

**Steps:**

Cast Walk the Aeons by paying {3}{U}{U}, taking an extra turn after this one.
Move to your next turn.
At the beginning of your upkeep, Followed Footsteps triggers, creating a copy of Scholar of the Ages.
Scholar of the Ages enters the battlefield, returning Walk the Aeons to your hand.
Repeat.

---

# 813-4305-4872

**Cards:**

- Scholar of the Ages
- Followed Footsteps
- Time Warp

**Produces:** Infinite creature tokens, Infinite turns, Lock

**Mana: {4}{U}{U} each turn, MV: 6, Colors: U, Popularity: 12**

**Steps:**

Cast Time Warp by paying {3}{U}{U}, taking an extra turn after this one.
Move to your next turn.
At the beginning of your upkeep, Followed Footsteps triggers, creating a copy of Scholar of the Ages.
Scholar of the Ages enters the battlefield, returning Time Warp to your hand.
Repeat.

---

# 816-3111

**Cards:**

- Rune-Tail, Kitsune Ascendant // Rune-Tail's Essence
- Protector of the Crown

**Produces:** Creatures you control can't be dealt damage, You can't be dealt damage, Lock

**Mana: {2}{W}, MV: 3, Colors: W, Popularity: 1293**

**Steps:**

Cast Rune-Tail, Kitsune Ascendant.
Rune-Tail, Kitsune Ascendant flips due to having 30 or more life.
Since creatures can not take damage and Protector of the Crown prevents you from taking damage, you are unable to take damage.

---

# 821-2018-4053

**Cards:**

- Solemnity
- Luminous Broodmoth
- Mogg Fanatic

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite damage, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: RW, Popularity: 6**

**Steps:**

Activate Mogg Fanatic by sacrificing it.
When Mogg Fanatic dies, Luminous Broodmoth triggers, returning Mogg Fanatic from your graveyard to the battlefield without a flying counter on it due to Solemnity.
Resolve the Mogg Fanatic ability.
Repeat.

---

# 822-1310-5261

**Cards:**

- Isochron Scepter
- Roar of the Kha
- Karn's Touch

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: {U}{U}, MV: 2, Colors: WU, Popularity: 0**

**Steps:**

Cast Karn's Touch by paying {U}{U}, targeting Isochron Scepter, causing it to become an artifact creature until end of turn.
Activate creatures you control by tapping those, adding {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Roar of the Kha without paying its mana cost, untapping all creatures.
Repeat from step 2.


---

# 822-1358-5261

**Cards:**

- Isochron Scepter
- Roar of the Kha
- Sydri, Galvanic Genius

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: {U}, MV: 1, Colors: WUB, Popularity: 3**

**Steps:**

Activate Sydri's first ability by paying {U}, causing Isochron Scepter to become an artifact creature until end of turn.
Activate creatures you control by tapping those, adding {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Roar of the Kha without paying its mana cost, untapping all creatures.
Repeat from step 2.


---

# 822-2064-5261

**Cards:**

- Isochron Scepter
- Roar of the Kha
- Tezzeret's Touch

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: , MV: 0, Colors: WUB, Popularity: 1**

**Steps:**

Activate creatures you control by tapping those, adding {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Roar of the Kha without paying its mana cost, untapping all creatures.
Repeat

---

# 822-3007-5261

**Cards:**

- Isochron Scepter
- Roar of the Kha
- Toymaker

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: {1}, MV: 1, Colors: W, Popularity: 2**

**Steps:**

Activate Toymaker's first ability by paying {1}, tapping it and discarding a card, causing Isochron Scepter to become an artifact creature until end of turn.
Activate creatures you control by tapping those, adding {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Roar of the Kha without paying its mana cost, untapping all creatures.
Repeat from step 2.


---

# 822-3088-5261

**Cards:**

- Isochron Scepter
- Roar of the Kha
- Xenic Poltergeist

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: {1}, MV: 1, Colors: WB, Popularity: 1**

**Steps:**

Activate Xenic Poltergeist's first ability by paying {1} and tapping it, causing Isochron Scepter to become an artifact creature until your next upkeep.
Activate creatures you control by tapping those, adding {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Roar of the Kha without paying its mana cost, untapping all creatures.
Repeat from step 2.


---

# 822-4104-5261

**Cards:**

- Isochron Scepter
- Roar of the Kha
- Tezzeret, Agent of Bolas

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: , MV: 0, Colors: WUB, Popularity: 2**

**Steps:**

Activate Tezzeret's second loyalty ability by removing a loyalty counter on it, causing Isochron Scepter to become an artifact creature until end of turn.
Activate creatures you control by tapping those, adding at least {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Roar of the Kha without paying its mana cost, untapping all creatures.
Repeat from step 2.


---

# 822-4241-5261

**Cards:**

- Isochron Scepter
- Roar of the Kha
- Karn, Silver Golem

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: {1}, MV: 1, Colors: W, Popularity: 4**

**Steps:**

Activate Karn by paying {1}, causing Isochron Scepter to become an artifact creature until end of turn.
Activate creatures you control by tapping those, adding {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Roar of the Kha without paying its mana cost, untapping all creatures.
Repeat from step 2.


---

# 822-4694-5261

**Cards:**

- Isochron Scepter
- Roar of the Kha
- March of the Machines

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: , MV: 0, Colors: WU, Popularity: 2**

**Steps:**

Activate creatures you control by tapping those, adding {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Roar of the Kha without paying its mana cost, untapping all creatures.
Repeat

---

# 822-4832-5261

**Cards:**

- Isochron Scepter
- Roar of the Kha
- Ensoul Artifact

**Produces:** Infinite mana creatures you control can produce, Infinite storm count

**Mana: , MV: 0, Colors: WU, Popularity: 2**

**Steps:**

Activate creatures you control by tapping those, adding {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Roar of the Kha without paying its mana cost, untapping all creatures.
Repeat

---

# 822-4916-5261

**Cards:**

- Isochron Scepter
- Roar of the Kha
- Animate Artifact

**Produces:** Infinite storm count, Infinite mana creatures you control can produce

**Mana: , MV: 0, Colors: WU, Popularity: 0**

**Steps:**

Activate creatures you control by tapping those, adding {3}.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Roar of the Kha without paying its mana cost, untapping all creatures.
Repeat.

---

# 824-2228-2464

**Cards:**

- Leech Bonder
- Song of Freyalise
- Hapatra, Vizier of Poisons

**Produces:** Infinite creature tokens, Infinite ETB

**Mana: , MV: 0, Colors: BGU, Popularity: 3**

**Steps:**

Activate Leech Bonder by tapping it, adding {U}.
Activate Leech Bonder by paying {U} and untapping it, moving a -1/-1 counter from a creature you control to any other creature you control.
Haptra triggers, creating a 1/1 Snake creature token.
Repeat.

---

# 824-2464-2760

**Cards:**

- Leech Bonder
- Song of Freyalise
- Nest of Scarabs

**Produces:** Infinite creature tokens, Infinite ETB

**Mana: , MV: 0, Colors: BGU, Popularity: 2**

**Steps:**

Activate Leech Bonder by tapping it, adding {U}.
Activate Leech Bonder by paying {U} and untapping it, moving a -1/-1 counter from a creature you control to any other creature you control.
Nest of Scarabs triggers, creating a 1/1 Insect creature token.
Repeat.

---

# 83-301-687-2034

**Cards:**

- Tayam, Luminous Enigma
- Mortician Beetle
- Ashnod's Altar
- Putrid Goblin

**Produces:** Infinite +1/+1 counters on a creature, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite self-mill, Put a selection of permanant cards from your library and graveyard onto the battlefield

**Mana: {1}, MV: 1, Colors: WBG, Popularity: 35**

**Steps:**

Activate Ashnod's Altar by sacrificing Putrid Goblin, adding {C}{C}.
Putrid Goblin's persist ability and Mortician Beetle trigger.
Resolve the Putrid Goblin trigger, returning it from your graveyard to the battlefield with a -1/-1 and a vigilance counter.
Resolve the Mortician Beetle trigger, putting a +1/+1 counter on it.
Activate Tayam by paying {3}, removing a +1/+1 counter from Mortician Beetle and removing both counters from Putrid Goblin.
Holding priority, activate Ashnod's Altar by sacrificing Putrid Goblin, adding {C}{C}.
Putrid Goblin's persist ability and Mortician Beetle trigger.
Resolve the Putrid Goblin trigger, returning it from your graveyard to the battlefield with a -1/-1 and a vigilance counter.
Resolve the Mortician Beetle trigger, putting a +1/+1 counter on it.
Activate Ashnod's Altar by sacrificing Putrid Goblin, adding {C}{C}.
Mortician Beetle triggers, putting a +1/+1 counter on itself.
Resolve the Tayam ability from step 5, causing yourself to mill three cards and return Putrid Goblin from your graveyard to the battlefield.
Repeat.

---

# 83-687-2012-2034

**Cards:**

- Tayam, Luminous Enigma
- Mortician Beetle
- Ashnod's Altar
- Strangleroot Geist

**Produces:** Infinite +1/+1 counters on a creature, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite self-mill, Put a selection of permanant cards from your library and graveyard onto the battlefield

**Mana: {1}, MV: 1, Colors: WBG, Popularity: 45**

**Steps:**

Activate Ashnod's Altar by sacrificing Strangleroot Geist, adding {C}{C}.
Strangleroot Geist's undying ability and Mortician Beetle trigger.
Resolve the Strangleroot Geist trigger, returning it from your graveyard to the battlefield with a +1/+1 and a vigilance counter.
Resolve the Mortician Beetle trigger, putting a +1/+1 counter on it.
Activate Tayam by paying {3}, removing a +1/+1 counter from Mortician Beetle and removing both counters from Strangleroot Geist.
Holding priority, activate Ashnod's Altar by sacrificing Strangleroot Geist, adding {C}{C}.
Strangleroot Geist's undying ability and Mortician Beetle trigger.
Resolve the Strangleroot Geist trigger, returning it from your graveyard to the battlefield with a +1/+1 and a vigilance counter.
Resolve the Mortician Beetle trigger, putting a +1/+1 counter on it.
Activate Ashnod's Altar by sacrificing Strangleroot Geist, adding {C}{C}.
Mortician Beetle triggers, putting a +1/+1 counter on itself.
Resolve the Tayam ability from step 5, causing yourself to mill three cards and return Strangleroot Geist from your graveyard to the battlefield.
Repeat.

---

# 83-687-2034-2086

**Cards:**

- Tayam, Luminous Enigma
- Mortician Beetle
- Ashnod's Altar
- Kitchen Finks

**Produces:** Infinite +1/+1 counters on a creature, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite sacrifice triggers, Infinite self-mill, Put a selection of permanant cards from your library and graveyard onto the battlefield

**Mana: {1}, MV: 1, Colors: WBG, Popularity: 45**

**Steps:**

Activate Ashnod's Altar by sacrificing Kitchen Finks, adding {C}{C}.
Kitchen Finks's persist ability and Mortician Beetle trigger.
Resolve the Kitchen Finks trigger, returning it from your graveyard to the battlefield with a -1/-1 and a vigilance counter.
Kitchen Finks enters the battlefield, causing you to gain two life.
Resolve the Mortician Beetle trigger, putting a +1/+1 counter on it.
Activate Tayam by paying {3}, removing a +1/+1 counter from Mortician Beetle and removing both counters from Kitchen Finks.
Holding priority, activate Ashnod's Altar by sacrificing Kitchen Finks, adding {C}{C}.
Kitchen Finks's persist ability and Mortician Beetle trigger.
Resolve the Kitchen Finks trigger, returning it from your graveyard to the battlefield with a -1/-1 and a vigilance counter.
Kitchen Finks enters the battlefield, causing you to gain two life.
Resolve the Mortician Beetle trigger, putting a +1/+1 counter on it.
Activate Ashnod's Altar by sacrificing Kitchen Finks, adding {C}{C}.
Mortician Beetle triggers, putting a +1/+1 counter on itself.
Resolve the Tayam ability from step 6, causing yourself to mill three cards and return Kitchen Finks from your graveyard to the battlefield.
Kitchen Finks enters the battlefield, causing you to gain two life.
Repeat.

---

# 83-687-2034-2620

**Cards:**

- Tayam, Luminous Enigma
- Mortician Beetle
- Ashnod's Altar
- Safehold Elite

**Produces:** Infinite +1/+1 counters on a creature, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite self-mill, Put a selection of permanant cards from your library and graveyard onto the battlefield

**Mana: {1}, MV: 1, Colors: WBG, Popularity: 46**

**Steps:**

Activate Ashnod's Altar by sacrificing Safehold Elite, adding {C}{C}.
Safehold Elite's persist ability and Mortician Beetle trigger.
Resolve the Safehold Elite trigger, returning it from your graveyard to the battlefield with a -1/-1 and a vigilance counter.
Resolve the Mortician Beetle trigger, putting a +1/+1 counter on it.
Activate Tayam by paying {3}, removing a +1/+1 counter from Mortician Beetle and removing both counters from Safehold Elite.
Holding priority, activate Ashnod's Altar by sacrificing Safehold Elite, adding {C}{C}.
Safehold Elite's persist ability and Mortician Beetle trigger.
Resolve the Safehold Elite trigger, returning it from your graveyard to the battlefield with a -1/-1 and a vigilance counter.
Resolve the Mortician Beetle trigger, putting a +1/+1 counter on it.
Activate Ashnod's Altar by sacrificing Safehold Elite, adding {C}{C}.
Mortician Beetle triggers, putting a +1/+1 counter on itself.
Resolve the Tayam ability from step 5, causing yourself to mill three cards and return Safehold Elite from your graveyard to the battlefield.
Repeat.

---

# 83-687-2034-3644

**Cards:**

- Tayam, Luminous Enigma
- Mortician Beetle
- Ashnod's Altar
- Young Wolf

**Produces:** Infinite +1/+1 counters on a creature, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite self-mill, Put a selection of permanant cards from your library and graveyard onto the battlefield

**Mana: {1}, MV: 1, Colors: WBG, Popularity: 48**

**Steps:**

Activate Ashnod's Altar by sacrificing Young Wolf, adding {C}{C}.
Young Wolf's undying ability and Mortician Beetle trigger.
Resolve the Young Wolf trigger, returning it from your graveyard to the battlefield with a +1/+1 and a vigilance counter.
Resolve the Mortician Beetle trigger, putting a +1/+1 counter on it.
Activate Tayam by paying {3}, removing a +1/+1 counter from Mortician Beetle and removing both counters from Young Wolf.
Holding priority, activate Ashnod's Altar by sacrificing Young Wolf, adding {C}{C}.
Young Wolf's undying ability and Mortician Beetle trigger.
Resolve the Young Wolf trigger, returning it from your graveyard to the battlefield with a +1/+1 and a vigilance counter.
Resolve the Mortician Beetle trigger, putting a +1/+1 counter on it.
Activate Ashnod's Altar by sacrificing Young Wolf, adding {C}{C}.
Mortician Beetle triggers, putting a +1/+1 counter on itself.
Resolve the Tayam ability from step 5, causing yourself to mill three cards and return Young Wolf from your graveyard to the battlefield.
Repeat.

---

# 83-687-2034-4350

**Cards:**

- Tayam, Luminous Enigma
- Mortician Beetle
- Ashnod's Altar
- Butcher Ghoul

**Produces:** Infinite +1/+1 counters on a creature, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite self-mill, Put a selection of permanant cards from your library and graveyard onto the battlefield

**Mana: {1}, MV: 1, Colors: WBG, Popularity: 19**

**Steps:**

Activate Ashnod's Altar by sacrificing Butcher Ghoul, adding {C}{C}.
Butcher Ghoul's undying ability and Mortician Beetle trigger.
Resolve the Butcher Ghoul trigger, returning it from your graveyard to the battlefield with a +1/+1 and a vigilance counter.
Resolve the Mortician Beetle trigger, putting a +1/+1 counter on it.
Activate Tayam by paying {3}, removing a +1/+1 counter from Mortician Beetle and removing both counters from Butcher Ghoul.
Holding priority, activate Ashnod's Altar by sacrificing Butcher Ghoul, adding {C}{C}.
Butcher Ghoul's undying ability and Mortician Beetle trigger.
Resolve the Butcher Ghoul trigger, returning it from your graveyard to the battlefield with a +1/+1 and a vigilance counter.
Resolve the Mortician Beetle trigger, putting a +1/+1 counter on it.
Activate Ashnod's Altar by sacrificing Butcher Ghoul, adding {C}{C}.
Mortician Beetle triggers, putting a +1/+1 counter on itself.
Resolve the Tayam ability from step 5, causing yourself to mill three cards and return Butcher Ghoul from your graveyard to the battlefield.
Repeat.

---

# 83-687-2034-5319

**Cards:**

- Tayam, Luminous Enigma
- Mortician Beetle
- Ashnod's Altar
- Geralf's Messenger

**Produces:** Infinite +1/+1 counters on a creature, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite self-mill, Put a selection of permanant cards from your library and graveyard onto the battlefield

**Mana: {1}, MV: 1, Colors: WBG, Popularity: 21**

**Steps:**

Activate Ashnod's Altar by sacrificing Geralf's Messenger, adding {C}{C}.
Geralf's Messenger's undying ability and Mortician Beetle trigger.
Resolve the Geralf's Messenger trigger, returning it from your graveyard to the battlefield with a +1/+1 and a vigilance counter.
Geralf's Messenger enters the battlefield, causing target opponent to lose 2 life.
Resolve the Mortician Beetle trigger, putting a +1/+1 counter on it.
Activate Tayam by paying {3}, removing a +1/+1 counter from Mortician Beetle and removing both counters from Geralf's Messenger.
Holding priority, activate Ashnod's Altar by sacrificing Geralf's Messenger, adding {C}{C}.
Geralf's Messenger's undying ability and Mortician Beetle trigger.
Resolve the Geralf's Messenger trigger, returning it from your graveyard to the battlefield with a +1/+1 and a vigilance counter.
Geralf's Messenger enters the battlefield, causing target opponent to lose 2 life.
Resolve the Mortician Beetle trigger, putting a +1/+1 counter on it.
Activate Ashnod's Altar by sacrificing Geralf's Messenger, adding {C}{C}.
Mortician Beetle triggers, putting a +1/+1 counter on itself.
Resolve the Tayam ability from step 6, causing yourself to mill three cards and return Geralf's Messenger from your graveyard to the battlefield.
Geralf's Messenger enters the battlefield, causing target opponent to lose 2 life.
Repeat.

---

# 849-1812-2034-2577

**Cards:**

- Gravecrawler
- Ashnod's Altar
- Anax, Hardened in the Forge
- Prismite

**Produces:** Infinite colored mana, Infinite colorless mana, Infinite creature tokens, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: BR, Popularity: 2**

**Steps:**

Activate Ashnod's Altar by sacrificing Gravecrawler, adding {C}{C}.
Anax triggers, creating a 1/1 Satyr creature token.
Activate Prismite by paying {2}, adding {B}.
Cast Gravecrawler from your graveyard by paying {B}.
Repeat any number of times.
Activate Ashnod's Altar any number of times by sacrificing any number of Satyr tokens, adding any amount of colorless mana.
Activate Prismite any number of times by paying any amount of colorless mana, adding any amount of colored mana.

---

# 849-1812-2034-3240

**Cards:**

- Nether Traitor
- Ashnod's Altar
- Anax, Hardened in the Forge
- Prismite

**Produces:** Infinite colored mana, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: BR, Popularity: 0**

**Steps:**

Activate Ashnod's Altar by sacrificing Nether Traitor, adding {C}{C}.
Nether Traitor dies, triggering Anax, crating a 1/1 Satyr creature token.
Activate Prismite by paying {2}, adding {B}.
Activate Ashnod's Altar by sacrificing the Satyr token, adding {C}{C}.
The Satyr dies, triggering Nether Traitor, causing you to pay {B} to return Nether Traitor from your graveyard to the battlefield.
Repeat.

---

# 849-2034-2577-3537

**Cards:**

- Gravecrawler
- Ashnod's Altar
- Anax, Hardened in the Forge
- Bog Initiate

**Produces:** Infinite black mana, Infinite colorless mana, Infinite creature tokens, Infinite death triggers, Infinite ETB, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: BR, Popularity: 2**

**Steps:**

Activate Ashnod's Altar by sacrificing Gravecrawler, adding {C}{C}.
Anax triggers, creating a 1/1 Satyr creature token.
Activate Bog Initiate by paying {1}, adding {B}.
Cast Gravecrawler from your graveyard by paying {B}.
Repeat any number of times.
Activate Ashnod's Altar any number of times by sacrificing any number of Satyr tokens, adding any amount of colorless mana.
Activate Bog Initiate any number of times by paying any amount of colorless mana, adding any amount of black mana.

---

# 849-2034-2577-5115

**Cards:**

- Gravecrawler
- Ashnod's Altar
- Anax, Hardened in the Forge
- Gemstone Array

**Produces:** Infinite creature tokens, Infinite death triggers, Infinite ETB, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite storm count, Infinite colorless mana, Infinite colored mana, Infinite charge counters on a permanent

**Mana: , MV: 0, Colors: BR, Popularity: 1**

**Steps:**

Activate Ashnod's Altar by sacrificing Gravecrawler, adding {C}{C}.
Anax triggers, creating a 1/1 Satyr creature token.
Activate Gemstone Array by paying {2}, putting a charge counter on it.
Activate Gemstone Array by removing a charge counter, adding {B}.
Cast Gravecrawler from your graveyard by paying {B}.
Repeat any number of times.
Activate Ashnod's Altar any number of times by sacrificing any number of Satyr tokens, adding any amount of colorless mana.
Activate Gemstone Array any number of times by paying any amount of colorless mana, adding any number of charge counters.
Activate Gemstone Array any number of times by removing any number of charge counters, adding any amount of colored mana.

---

# 849-2034-3240-3537

**Cards:**

- Nether Traitor
- Ashnod's Altar
- Anax, Hardened in the Forge
- Bog Initiate

**Produces:** Infinite black mana, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: BR, Popularity: 4**

**Steps:**

Activate Ashnod's Altar by sacrificing Nether Traitor, adding {C}{C}.
Nether Traitor dies, triggering Anax, crating a 1/1 Satyr creature token.
Activate Bog Initiate by paying {1}, adding {B}.
Activate Ashnod's Altar by sacrificing the Satyr token, adding {C}{C}.
The Satyr dies, triggering Nether Traitor, causing you to pay {B} to return Nether Traitor from your graveyard to the battlefield.
Repeat.

---

# 849-2034-3240-5115

**Cards:**

- Nether Traitor
- Ashnod's Altar
- Anax, Hardened in the Forge
- Gemstone Array

**Produces:** Infinite charge counters on a permanent, Infinite colored mana, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: BR, Popularity: 0**

**Steps:**

Activate Ashnod's Altar by sacrificing Nether Traitor, adding {C}{C}.
Nether Traitor dies, triggering Anax, crating a 1/1 Satyr creature token.
Activate Gemstone Array's first ability by paying {2}, putting a charge counter on it.
Activate Gemstone Array's second ability by removing a charge counter from it, adding {B}.
Activate Ashnod's Altar by sacrificing the Satyr token, adding {C}{C}.
The Satyr dies, triggering Nether Traitor, causing you to pay {B} to return Nether Traitor from your graveyard to the battlefield.
Repeat.

---

# 849-3240-4050

**Cards:**

- Nether Traitor
- Phyrexian Altar
- Anax, Hardened in the Forge

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: BR, Popularity: 222**

**Steps:**

Activate Phyrexian Altar by sacrificing Nether Traitor, adding {B}.
When Nether Traitor dies, Anax triggers, creating a creature token.
Activate Phyrexian Altar by sacrificing the creature token, adding one mana of any color.
When the creature token dies, Nether Traitor triggers, causing you to pay {B} to return Nether Traitor from your graveyard to the battlefield.
Repeat.

---

# 849-913-2034-2577

**Cards:**

- Gravecrawler
- Ashnod's Altar
- Anax, Hardened in the Forge
- Signpost Scarecrow

**Produces:** Infinite colored mana, Infinite colorless mana, Infinite creature tokens, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: BR, Popularity: 0**

**Steps:**

Activate Ashnod's Altar by sacrificing Gravecrawler, adding {C}{C}.
Anax triggers, creating a 1/1 Satyr creature token.
Activate Signpost Scarecrow by paying {2}, adding {B}.
Cast Gravecrawler from your graveyard by paying {B}.
Repeat any number of times.
Activate Ashnod's Altar any number of times by sacrificing any number of Satyr tokens, adding any amount of colorless mana.
Activate Signpost Scarecrow any number of times by paying any amount of colorless mana, adding any amount of colored mana.

---

# 849-913-2034-3240

**Cards:**

- Nether Traitor
- Ashnod's Altar
- Anax, Hardened in the Forge
- Signpost Scarecrow

**Produces:** Infinite colored mana, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: BR, Popularity: 0**

**Steps:**

Activate Ashnod's Altar by sacrificing Nether Traitor, adding {C}{C}.
Nether Traitor dies, triggering Anax, crating a 1/1 Satyr creature token.
Activate Signpost Scarecrow by paying {2}, adding {B}.
Activate Ashnod's Altar by sacrificing the Satyr token, adding {C}{C}.
The Satyr dies, triggering Nether Traitor, causing you to pay {B} to return Nether Traitor from your graveyard to the battlefield.
Repeat.

---

# 855-4929-5189

**Cards:**

- Ghave, Guru of Spores
- Cryptic Trilobite
- Corpsejack Menace

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: WBG, Popularity: 1686**

**Steps:**

Activate Cryptic Trilobite's first ability by removing a +1/+1 counter from it, adding {C}{C}.
Activate Ghave's first ability by paying {1} and removing a +1/+1 counter from Cryptic Trilobite, creating a 1/1 Saproling creature token.
Activate Ghave's second ability by paying {1} and sacrificing the Saproling token, putting two +1/+1 counters on Cryptic Trilobite.
Repeat.

---

# 856-1201-1308-1651

**Cards:**

- Cauldron Familiar
- Witch's Oven
- Clock of Omens
- Anointed Procession

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite tapped Food tokens

**Mana: , MV: 0, Colors: WB, Popularity: 121**

**Steps:**

Activate Witch's Oven by tapping and sacrificing Cauldron Familiar, creating two Food tokens.
Activate Clock of Omens by tapping two Food tokens, untapping Witch's Oven.
Activate Cauldron Familiar by sacrificing a Food, returning Cauldron Familiar from your graveyard to the battlefield.
When Caludron Familiar enters the battlefield, it triggers, causing each opponent to lose 1 life and you to gain 1 life.
Repeat.

---

# 856-1201-1651-2557

**Cards:**

- Cauldron Familiar
- Witch's Oven
- Clock of Omens
- Parallel Lives

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite tapped Food tokens

**Mana: , MV: 0, Colors: BG, Popularity: 427**

**Steps:**

Activate Witch's Oven by tapping it and sacrificing Cauldron Familiar, creating two Food artifact tokens.
Activate Clock of Omens by tapping two Food tokens, untapping Witch's Oven.
Activate Cauldron Familiar by sacrificing a Food, returning Cauldron Familiar from your graveyard to the battlefield.
When Caludron Familiar enters the battlefield, it triggers, causing each opponent to lose 1 life and you to gain 1 life.
Repeat.

---

# 856-1201-1651-3129

**Cards:**

- Cauldron Familiar
- Witch's Oven
- Clock of Omens
- Primal Vigor

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite tapped Food tokens

**Mana: , MV: 0, Colors: BG, Popularity: 122**

**Steps:**

Activate Witch's Oven by tapping it and sacrificing Cauldron Familiar, creating two Food artifact tokens.
Activate Clock of Omens by tapping two Food tokens, untapping Witch's Oven.
Activate Cauldron Familiar by sacrificing a Food, returning Cauldron Familiar from your graveyard to the battlefield.
When Caludron Familiar enters the battlefield, it triggers, causing each opponent to lose 1 life and you to gain 1 life.
Repeat.

---

# 856-1201-1651-4772

**Cards:**

- Cauldron Familiar
- Witch's Oven
- Clock of Omens
- Doubling Season

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite tapped Food tokens

**Mana: , MV: 0, Colors: BG, Popularity: 415**

**Steps:**

Activate Witch's Oven by tapping and sacrificing Cauldron Familiar, creating two Food tokens.
Activate Clock of Omens by tapping two Food tokens, untapping Witch's Oven.
Activate Cauldron Familiar by sacrificing a Food, returning Cauldron Familiar from your graveyard to the battlefield.
When Caludron Familiar enters the battlefield, it triggers, causing each opponent to lose 1 life and you to gain 1 life.
Repeat.

---

# 856-1201-1651-4871

**Cards:**

- Cauldron Familiar
- Witch's Oven
- Clock of Omens
- Pitiless Plunderer

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite tapped Treasure tokens

**Mana: , MV: 0, Colors: B, Popularity: 1067**

**Steps:**

Activate Witch's Oven by tapping it and sacrificing Cauldron Familiar.
When Cauldron Familar dies, Pitless Plunderer triggers, creating a Treasure artifact token.
Resolve the Witch's Oven ability, creating a Food artifact token.
Activate Clock of Omens by tapping the Treasure and Food, untapping Witch's Oven.
Activate Cauldron Familiar by sacrificing a Food, returning Cauldron Familiar from your graveyard to the battlefield.
When Caludron Familiar enters the battlefield, it triggers, causing each opponent to lose 1 life and you to gain 1 life.
Repeat.

---

# 862-2034-3249

**Cards:**

- Havengul Lich
- Ashnod's Altar
- Crimson Kobolds

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: UBR, Popularity: 3**

**Steps:**

Activate Ashnod's Altar by sacrificing Crimson Kobolds, adding {C}{C}.
Activate Havengul Lich by paying {1}, targeting Crimson Kobolds.
Cast Crimson Kobolds from graveyard by paying {0}.
Repeat.

---

# 862-2232-2459-2624

**Cards:**

- God-Eternal Oketra
- Cloudstone Curio
- Crimson Kobolds
- Rograkh, Son of Rohgahh

**Produces:** Infinite creature tokens, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: , MV: 0, Colors: RW, Popularity: 5**

**Steps:**

Cast Rograkh by paying {0}.
Oketra triggers, creating a 4/4 Zombie creature token.
Cloudstone Curio triggers, returning nothing to your hand.
Rograkh enters the battlefield, triggering Cloudstone Curio, returning nothing to your hand.
Cast Crimson Kobolds by paying {0}.
Oketra triggers, creating a 4/4 Zombie creature token.
Cloudstone Curio triggers, returning Rograkh to your hand.
Crimson Kobolds enters the battlefield, triggering Cloudstone Curio, returning nothing to your hand.
Cast Rograkh by paying {0}.
Oketra triggers, creating a 4/4 Zombie creature token.
Cloudstone Curio triggers, returning Crimson Kobolds to your hand.
Rograkh enters the battlefield, triggering Cloudstone Curio, returning nothing to your hand.
Repeat from step 5.

---

# 862-3249-4050

**Cards:**

- Havengul Lich
- Phyrexian Altar
- Crimson Kobolds

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: UBR, Popularity: 3**

**Steps:**

Activate Phyrexian Altar by sacrificing Crimson Kobolds, adding one mana of any color.
Activate Havengul Lich by paying {1}, targeting Crimson Kobolds.
Cast Crimson Kobolds from graveyard by paying {0}.
Repeat.

---

# 862-3249-5231

**Cards:**

- Havengul Lich
- Thermopod
- Crimson Kobolds

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: UBR, Popularity: 0**

**Steps:**

Activate Thermopod's second ability by sacrificing Crimson Kobolds, adding {R}.
Activate Havengul Lich by paying {1}, targeting Crimson Kobolds.
Cast Crimson Kobolds from graveyard by paying {0}.
Repeat.

---

# 864-1193-4095

**Cards:**

- Mythos of Illuna
- Radiate
- Eternal Witness

**Produces:** Infinite copies of all permanents, Infinite storm count, Infinite recursion of most cards in your graveyard

**Mana: {5}{U}{U}{R}{R}, MV: 9, Colors: GUR, Popularity: 26**

**Steps:**

Cast Mythos of Illuna targeting anything but Eternal Witness, holding priority, and then cast Radiate targeting Mythos of Illuna.
When Radiate resolves you will have Mythos copies targeting every targetable permanent (except what the original Mythos card is targeting).
When each of the copies resolve, target Radiate in your graveyard with the new Eternal Witness token's ability and return Radiate to your hand.
Before the original Mythos of Illuna card resolves, cast Radiate again targeting Mythos by spending mana from the tokens you just created.
Repeat this process, effectively doubling the number of copies created, allowing you to return Radiate and another card with two Witness triggers.
Repeat.

---

# 864-1532-2034-3255-3747

**Cards:**

- Child of Alara
- Faith's Reward
- Commander's Sphere
- Ashnod's Altar
- Eternal Witness

**Produces:** Infinite card draw, Infinite colorless mana, Infinite death triggers, Infinite draw triggers, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: WUBRG, Popularity: 13**

**Steps:**

Activate Commander's Sphere's first ability by tapping it, adding {W}.
Activate Commander's Sphere's second ability by sacrificing it, causing you to draw a card.
Activate Ashnod's Altar by sacrificing Eternal Witness and Child of Alara, adding {C}{C}{C}{C}.
Child of Alara dies, destroying all nonland permanents.
Cast Faith's Reward by paying {3}{W}, returning all permanent cards put into your graveyard this turn to the battlefield under your control.
Eternal Witness enters the battlefield, returning Faith's Reward from your graveyard to your hand.
Repeat.

---

# 864-2034-3622-4766

**Cards:**

- Deathrender
- Gravedigger
- Eternal Witness
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: BG, Popularity: 4**

**Steps:**

Activate Ashnod's Altar by sacrificing Eternal Witness, adding {C}{C}.
Eternal Witness dies, triggering Deathrender, putting Gravedigger from your hand onto the battlefield and attaching Deathrender to it.
Gravedigger enters the battlefield, returning Eternal Witness from your graveyard to your hand.
Activate Ashnod's Altar by sacrificing Gravedigger, adding {C}{C}.
Gravedigger dies, triggering Deathrender, putting Eternal Witness from your hand onto the battlefield and attaching Deathrender to it.
Eternal Witness enters the battlefield, returning Gravedigger from your graveyard to your hand.
Repeat.

---

# 864-2103-2334

**Cards:**

- Soulherder
- Eternal Witness
- Capture of Jingzhou

**Produces:** Infinite turns, Lock

**Mana: {3}{U}{U} each turn, MV: 5, Colors: GWU, Popularity: 86**

**Steps:**

With Soulherder and a creature based spell recursion effect on the battlefield, cast the extra turn spell.
Move to end step and target the creature with Soulherder's ability.
When creature re-enters the battlefield, target the extra turn spell in your graveyard and return it to your hand, then pass to yourself.
Repeat

---

# 864-2103-2665

**Cards:**

- Progenitor Mimic
- Capture of Jingzhou
- Eternal Witness

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: GU, Popularity: 42**

**Steps:**

Cast Capture of Jingzhou by paying its mana cost, taking an extra turn after this one.
At the beginning of your next upkeep, Progenitor Mimic triggers, creating a token copy of Eternal Witness.
When the token Eternal Witness enters the battlefield, it triggers itself, returning Capture of Jingzhou from your graveyard to your hand.
Repeat.

---

# 864-2103-4305

**Cards:**

- Eternal Witness
- Followed Footsteps
- Capture of Jingzhou

**Produces:** Infinite creature tokens, Infinite turns, Lock

**Mana: {3}{U}{U}, MV: 5, Colors: GU, Popularity: 9**

**Steps:**

Cast Capture of Jingzhou by paying {3}{U}{U}, taking an extra turn after this one.
Move to your next turn.
At the beginning of your upkeep, Followed Footsteps triggers, creating a copy of Eternal Witness.
Eternal Witness enters the battlefield, returning Capture of Jingzhou from your graveyard to your hand.
Repeat.

---

# 864-2103-4428

**Cards:**

- Thassa, Deep-Dwelling
- Eternal Witness
- Capture of Jingzhou

**Produces:** Infinite turns, Lock

**Mana: {3}{U}{U} each turn, MV: 5, Colors: GU, Popularity: 129**

**Steps:**

Cast Capture of Jingzhou by paying {3}{U}{U}, getting an extra turn after this one.
At the beginning of your end step, Thassa triggers, blinking Eternal Witness.
Eternal Witness enters the battlefield, returning Capture of Jingzhou from your graveyard to your hand.
Repeat.

---

# 864-2104-2334

**Cards:**

- Soulherder
- Eternal Witness
- Temporal Manipulation

**Produces:** Infinite turns, Lock

**Mana: {3}{U}{U} each turn, MV: 5, Colors: GWU, Popularity: 296**

**Steps:**

With Soulherder and a creature based spell recursion effect on the battlefield, cast the extra turn spell.
Move to end step and target the creature with Soulherder's ability.
When creature re-enters the battlefield, target the extra turn spell in your graveyard and return it to your hand, then pass to yourself.
Repeat

---

# 864-2104-2665

**Cards:**

- Progenitor Mimic
- Temporal Manipulation
- Eternal Witness

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: GU, Popularity: 74**

**Steps:**

Cast Temporal Manipulation by paying its mana cost, taking an extra turn after this one.
At the beginning of your next upkeep, Progenitor Mimic triggers, creating a token copy of Eternal Witness.
When the token Eternal Witness enters the battlefield, it triggers itself, returning Temporal Manipulation from your graveyard to your hand.
Repeat.

---

# 864-2104-4305

**Cards:**

- Eternal Witness
- Followed Footsteps
- Temporal Manipulation

**Produces:** Infinite creature tokens, Infinite turns, Lock

**Mana: {3}{U}{U}, MV: 5, Colors: GU, Popularity: 7**

**Steps:**

Cast Temporal Manipulation by paying {3}{U}{U}, taking an extra turn after this one.
Move to your next turn.
At the beginning of your upkeep, Followed Footsteps triggers, creating a copy of Eternal Witness.
Eternal Witness enters the battlefield, returning Temporal Manipulation from your graveyard to your hand.
Repeat.

---

# 864-2104-4428

**Cards:**

- Thassa, Deep-Dwelling
- Eternal Witness
- Temporal Manipulation

**Produces:** Infinite turns, Lock

**Mana: {3}{U}{U} each turn, MV: 5, Colors: GU, Popularity: 355**

**Steps:**

Cast Temporal Manipulation by paying {3}{U}{U}, getting an extra turn after this one.
At the beginning of your end step, Thassa triggers, blinking Eternal Witness.
Eternal Witness enters the battlefield, returning Temporal Manipulation from your graveyard to your hand.
Repeat.

---

# 864-2292-3622-4766

**Cards:**

- Deathrender
- Gravedigger
- Eternal Witness
- Viscera Seer

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite scry 1

**Mana: , MV: 0, Colors: BG, Popularity: 2**

**Steps:**

Activate Viscera Seer by sacrificing Eternal Witness.
Eternal Witness dies, triggering Deathrender, putting Gravedigger from your hand onto the battlefield and attaching Deathrender to it.
Gravedigger enters the battlefield, returning Eternal Witness from your graveyard to your hand.
Resolve the Viscera Seer ability from step 1, causing you to scry 1.
Activate Viscera Seer by sacrificing Gravedigger.
Gravedigger dies, triggering Deathrender, putting Eternal Witness from your hand onto the battlefield and attaching Deathrender to it.
Eternal Witness enters the battlefield, returning Gravedigger from your graveyard to your hand.
Resolve the Viscera Seer ability from step 5, causing you to scry 1.
Repeat.

---

# 864-2334-3617

**Cards:**

- Soulherder
- Eternal Witness
- Time Walk

**Produces:** Lock, Infinite turns

**Mana: {1}{U} each turn, MV: 2, Colors: GWU, Popularity: 0**

**Steps:**

With Soulherder and a creature based spell recursion effect on the battlefield, cast the extra turn spell.
Move to end step and target the creature with Soulherder's ability.
When creature re-enters the battlefield, target the extra turn spell in your graveyard and return it to your hand, then pass to yourself.
Repeat

---

# 864-2334-4377

**Cards:**

- Soulherder
- Eternal Witness
- Walk the Aeons

**Produces:** Infinite turns, Lock

**Mana: {4}{U}{U} each turn, MV: 6, Colors: GWU, Popularity: 56**

**Steps:**

With Soulherder and a creature based spell recursion effect on the battlefield, cast the extra turn spell.
Move to end step and target the creature with Soulherder's ability.
When creature re-enters the battlefield, target the extra turn spell in your graveyard and return it to your hand, then pass to yourself.
Repeat

---

# 864-2334-4872

**Cards:**

- Soulherder
- Eternal Witness
- Time Warp

**Produces:** Infinite turns, Lock

**Mana: {3}{U}{U} each turn, MV: 5, Colors: GWU, Popularity: 508**

**Steps:**

With Soulherder and a creature based spell recursion effect on the battlefield, cast the extra turn spell.
Move to end step and target the creature with Soulherder's ability.
When creature re-enters the battlefield, target the extra turn spell in your graveyard and return it to your hand, then pass to yourself.
Repeat

---

# 864-2665-3617

**Cards:**

- Progenitor Mimic
- Time Walk
- Eternal Witness

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: GU, Popularity: 0**

**Steps:**

Cast Time Walk by paying its mana cost, taking an extra turn after this one.
At the beginning of your next upkeep, Progenitor Mimic triggers, creating a token copy of Eternal Witness.
When the token Eternal Witness enters the battlefield, it triggers itself, returning Time Walk from your graveyard to your hand.
Repeat.

---

# 864-2665-4377

**Cards:**

- Progenitor Mimic
- Walk the Aeons
- Eternal Witness

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: GU, Popularity: 84**

**Steps:**

Cast Walk the Aeons by paying its mana cost, taking an extra turn after this one.
At the beginning of your next upkeep, Progenitor Mimic triggers, creating a token copy of Eternal Witness.
When the token Eternal Witness enters the battlefield, it triggers itself, returning Walk the Aeons from your graveyard to your hand.
Repeat.

---

# 864-2665-4872

**Cards:**

- Progenitor Mimic
- Time Warp
- Eternal Witness

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: GU, Popularity: 211**

**Steps:**

Cast Time Warp by paying its mana cost, taking an extra turn after this one.
At the beginning of your next upkeep, Progenitor Mimic triggers, creating a token copy of Eternal Witness.
When the token Eternal Witness enters the battlefield, it triggers itself, returning Time Warp from your graveyard to your hand.
Repeat.

---

# 864-2730-4050

**Cards:**

- Kaya's Ghostform
- Phyrexian Altar
- Eternal Witness

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: BG, Popularity: 1972**

**Steps:**

Activate Phyrexian Altar by sacrificing Eternal Witness, adding {B}.
When Eternal Witness dies, Kaya's Ghostform triggers, returning Eternal Witness from your graveyard to the battlefield.
When Eternal Witness enters the battlefield, it triggers, returning Kaya's Ghostform from your graveyard to your hand.
Cast Kaya's Ghostform by paying {B}, attaching it to Eternal Witness.
Repeat.

---

# 864-3617-4305

**Cards:**

- Eternal Witness
- Followed Footsteps
- Time Walk

**Produces:** Infinite creature tokens, Infinite turns, Lock

**Mana: {1}{U}, MV: 2, Colors: GU, Popularity: 0**

**Steps:**

Cast Time Walk by paying {1}{U}, taking an extra turn after this one.
Move to your next turn.
At the beginning of your upkeep, Followed Footsteps triggers, creating a copy of Eternal Witness.
Eternal Witness enters the battlefield, returning Time Walk from your graveyard to your hand.
Repeat.

---

# 864-3617-4428

**Cards:**

- Thassa, Deep-Dwelling
- Eternal Witness
- Time Walk

**Produces:** Infinite turns, Lock

**Mana: {1}{U} each turn, MV: 2, Colors: GU, Popularity: 0**

**Steps:**

Cast Time Walk by paying {1}{U}, getting an extra turn after this one.
At the beginning of your end step, Thassa triggers, blinking Eternal Witness.
Eternal Witness enters the battlefield, returning Time Walk from your graveyard to your hand.
Repeat.

---

# 864-3622-4050-4766

**Cards:**

- Deathrender
- Gravedigger
- Eternal Witness
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: BG, Popularity: 4**

**Steps:**

Activate Phyrexian Altar by sacrificing Eternal Witness, adding one mana of any color.
Eternal Witness dies, triggering Deathrender, putting Gravedigger from your hand onto the battlefield and attaching Deathrender to it.
Gravedigger enters the battlefield, returning Eternal Witness from your graveyard to your hand.
Activate Phyrexian Altar by sacrificing Gravedigger, adding one mana of any color.
Gravedigger dies, triggering Deathrender, putting Eternal Witness from your hand onto the battlefield and attaching Deathrender to it.
Eternal Witness enters the battlefield, returning Gravedigger from your graveyard to your hand.
Repeat.

---

# 864-3622-4766-5256

**Cards:**

- Deathrender
- Gravedigger
- Eternal Witness
- Altar of Dementia

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: BG, Popularity: 5**

**Steps:**

Activate Altar of Dementia by sacrificing Eternal Witness.
Eternal Witness dies, triggering Deathrender, putting Gravedigger from your hand onto the battlefield and attaching Deathrender to it.
Gravedigger enters the battlefield, returning Eternal Witness from your graveyard to your hand.
Resolve the Altar of Dementia ability from step 1, causing target player to mill cards equal to Eternal Witness' power.
Activate Altar of Dementia by sacrificing Gravedigger.
Gravedigger dies, triggering Deathrender, putting Eternal Witness from your hand onto the battlefield and attaching Deathrender to it.
Eternal Witness enters the battlefield, returning Gravedigger from your graveyard to your hand.
Resolve the Altar of Dementia ability from step 5, causing target player to mill cards equal to Gravedigger's power.
Repeat.

---

# 864-3890-4050

**Cards:**

- Eternal Witness
- Phyrexian Altar
- Unearth

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count, Infinite magecraft triggers

**Mana: , MV: 0, Colors: BG, Popularity: 2385**

**Steps:**

Sacrifice Eternal Witness to Phyrexian Altar, for {B}.
Cast Unearth, returning Eternal Witness from your graveyard to the battlefield.
Eternal Witness enters, returning Unearth from your graveyard to your hand.
Repeat.

---

# 864-4305-4377

**Cards:**

- Eternal Witness
- Followed Footsteps
- Walk the Aeons

**Produces:** Infinite creature tokens, Infinite turns, Lock

**Mana: {4}{U}{U}, MV: 6, Colors: GU, Popularity: 11**

**Steps:**

Cast Walk the Aeons by paying {4}{U}{U}, taking an extra turn after this one.
Move to your next turn.
At the beginning of your upkeep, Followed Footsteps triggers, creating a copy of Eternal Witness.
Eternal Witness enters the battlefield, returning Walk the Aeons from your graveyard to your hand.
Repeat.

---

# 864-4305-4872

**Cards:**

- Eternal Witness
- Followed Footsteps
- Time Warp

**Produces:** Infinite creature tokens, Infinite turns, Lock

**Mana: {3}{U}{U}, MV: 5, Colors: GU, Popularity: 20**

**Steps:**

Cast Time Warp by paying {3}{U}{U}, taking an extra turn after this one.
Move to your next turn.
At the beginning of your upkeep, Followed Footsteps triggers, creating a copy of Eternal Witness.
Eternal Witness enters the battlefield, returning Time Warp from your graveyard to your hand.
Repeat.

---

# 864-4377-4428

**Cards:**

- Thassa, Deep-Dwelling
- Eternal Witness
- Walk the Aeons

**Produces:** Infinite turns, Lock

**Mana: {4}{U}{U} each turn, MV: 6, Colors: GU, Popularity: 105**

**Steps:**

Cast Walk the Aeons by paying {4}{U}{U}, getting an extra turn after this one.
At the beginning of your end step, Thassa triggers, blinking Eternal Witness.
Eternal Witness enters the battlefield, returning Walk the Aeons from your graveyard to your hand.
Repeat.

---

# 864-4428-4872

**Cards:**

- Thassa, Deep-Dwelling
- Eternal Witness
- Time Warp

**Produces:** Infinite turns, Lock

**Mana: {3}{U}{U} each turn, MV: 5, Colors: GU, Popularity: 621**

**Steps:**

Cast Time Warp by paying {3}{U}{U}, getting an extra turn after this one.
At the beginning of your end step, Thassa triggers, blinking Eternal Witness.
Eternal Witness enters the battlefield, returning Time Warp from your graveyard to your hand.
Repeat.

---

# 864-933-2103

**Cards:**

- Conjurer's Closet
- Eternal Witness
- Capture of Jingzhou

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {3}{U}{U}, MV: 5, Colors: GU, Popularity: 81**

**Steps:**

Cast Capture of Jingzhou by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Eternal Witness.
Eternal Witness enters the battlefield, returning Capture of Jingzhou from your graveyard to your hand.
Repeat.

---

# 864-933-2104

**Cards:**

- Conjurer's Closet
- Eternal Witness
- Temporal Manipulation

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {3}{U}{U}, MV: 5, Colors: GU, Popularity: 216**

**Steps:**

Cast Temporal Manipulation by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Eternal Witness.
Eternal Witness enters the battlefield, returning Temporal Manipulation from your graveyard to your hand.
Repeat.

---

# 864-933-3617

**Cards:**

- Conjurer's Closet
- Eternal Witness
- Time Walk

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {1}{U}, MV: 2, Colors: GU, Popularity: 0**

**Steps:**

Cast Time Walk by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Eternal Witness.
Eternal Witness enters the battlefield, returning Time Walk from your graveyard to your hand.
Repeat.

---

# 864-933-4377

**Cards:**

- Conjurer's Closet
- Eternal Witness
- Walk the Aeons

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {4}{U}{U}, MV: 6, Colors: GU, Popularity: 88**

**Steps:**

Cast Walk the Aeons by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Eternal Witness.
Eternal Witness enters the battlefield, returning Walk the Aeons from your graveyard to your hand.
Repeat.

---

# 864-933-4872

**Cards:**

- Conjurer's Closet
- Eternal Witness
- Time Warp

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {3}{U}{U}, MV: 5, Colors: GU, Popularity: 399**

**Steps:**

Cast Time Warp by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Eternal Witness.
Eternal Witness enters the battlefield, returning Time Warp from your graveyard to your hand.
Repeat.

---

# 864-933-957

**Cards:**

- Conjurer's Closet
- Eternal Witness
- Time Stretch

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {8}{U}{U}, MV: 10, Colors: GU, Popularity: 60**

**Steps:**

Cast Time Stretch by paying {8}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Eternal Witness.
Eternal Witness enters the battlefield, returning Time Stretch from your graveyard to your hand.
Repeat.

---

# 864-957-2334

**Cards:**

- Soulherder
- Eternal Witness
- Time Stretch

**Produces:** Infinite turns, Lock

**Mana: {8}{U}{U} every other turn, MV: 10, Colors: GWU, Popularity: 48**

**Steps:**

With Soulherder and a creature based spell recursion effect on the battlefield, cast the extra turn spell.
Move to end step and target the creature with Soulherder's ability.
When creature re-enters the battlefield, target the extra turn spell in your graveyard and return it to your hand, then pass to yourself.
Repeat

---

# 864-957-4428

**Cards:**

- Thassa, Deep-Dwelling
- Eternal Witness
- Time Stretch

**Produces:** Infinite turns, Lock

**Mana: {8}{U}{U} every other turn, MV: 10, Colors: GU, Popularity: 76**

**Steps:**

Cast Time Stretch by paying {8}{U}{U}, getting two extra turns after this one.
At the beginning of your end step, Thassa triggers, blinking Eternal Witness.
Eternal Witness enters the battlefield, returning Time Stretch from your graveyard to your hand.
Repeat every other turn.

---

# 867-1640

**Cards:**

- Jackal Pup
- Pariah's Shield

**Produces:** Draw the game

**Mana: , MV: 0, Colors: R, Popularity: 40**

**Steps:**

Deal damage to Jackal Pup.
Jackal Pup triggers, attempting to deal damage to you, but dealing damage to Jackal Pup instead due to Pariah's Shield.
Repeat step 2 in an infinite loop, causing the game to end in a draw.

---

# 867-4090

**Cards:**

- Jackal Pup
- Pariah

**Produces:** Draw the game

**Mana: , MV: 0, Colors: RW, Popularity: 30**

**Steps:**

Deal damage to Jackal Pup.
Jackal Pup triggers, attempting to deal damage to you, but dealing damage to Jackal Pup instead due to Pariah.
Repeat step 2 in an infinite loop, causing the game to end in a draw.

---

# 868-2670-2713-5261

**Cards:**

- Isochron Scepter
- Psychic Puppetry
- Desperate Ritual
- Zirda, the Dawnwaker

**Produces:** Infinite storm count

**Mana: {2}{R}, MV: 3, Colors: URW, Popularity: 0**

**Steps:**

Activate Isochron Scepter for {1}.
Splice Desperate Ritual onto Psychic Puppetry for {1}{R}, and have Psychic Puppetry target Isochron Scepter.
Resolve the spell, untapping Isochron Scepter and adding {R}{R}{R}.
Repeat as necessary, using {R} to pay for the Isochron Scepter activation and {R}{R} for Desperate Ritual.

---

# 868-2670-5149-5261

**Cards:**

- Isochron Scepter
- Psychic Puppetry
- Desperate Ritual
- Power Artifact

**Produces:** Infinite storm count

**Mana: {2}{R}, MV: 3, Colors: UR, Popularity: 1**

**Steps:**

Activate Isochron Scepter for {1}.
Splice Desperate Ritual onto Psychic Puppetry for {1}{R}, and have Psychic Puppetry target Isochron Scepter.
Resolve the spell, untapping Isochron Scepter and adding {R}{R}{R}.
Repeat as necessary, using {R} to pay for the Isochron Scepter activation and {R}{R} for Desperate Ritual.

---

# 868-3075-3368

**Cards:**

- Mizzix of the Izmagnus
- Desperate Ritual
- Reiterate

**Produces:** Infinite copies of instant and sorcery spells on the stack, Infinite magecraft triggers, Infinite red mana, Infinite storm count

**Mana: {R}{R}{R}, MV: 3, Colors: UR, Popularity: 939**

**Steps:**

Cast Desperate Ritual by paying {R}.
In response, cast Reiterate with buyback by paying {R}{R}, copying Desparate Ritual and putting Reiterate into your hand.
Resolve the Desperate Ritual copy, adding {R}{R}{R}.
Repeat from step 2.
Once you have infinite mana, you may cast Reiterate with buyback any number of times, targeting anything.

---

# 873-3584-5261

**Cards:**

- Isochron Scepter
- Twiddle
- Thousand-Year Storm

**Produces:** Infinite magecraft triggers, Infinite mana lands, artifacts, and creatures you control can produce, Infinite storm count, Infinite untap of lands, creatures, and artifacts you control, Tap all lands, creatures, and artifacts opponents control

**Mana: {5}, MV: 5, Colors: UR, Popularity: 111**

**Steps:**

Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Twiddle.
Thousand-Year Storm triggers, copying Twiddle for each other instant or sorcery you've cast before it this turn.
Resolve a copy of Twiddle, untapping Isochron Scepter.
If there is a remaining copy of Twiddle on the stack, resolve it, untapping a mana-producing land.
Activate that land by tapping it, adding {1}.
Repeat steps 4 and 5 until there are no more copies of Twiddle.
Repeat from step 1.

---

# 874-2882-4675-4694

**Cards:**

- Cavalier of Dawn
- Infinite Reflection
- March of the Machines
- Delif's Cone

**Produces:** Infinite creature tokens, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite storm count

**Mana: , MV: 0, Colors: WU, Popularity: 0**

**Steps:**

Cast Delif's Cone by paying {0}.
Delif's Cone enters the battlefield as a copy of Cavalier of Dawn.
Copy of Cavalier of Dawn enter-the-battlefield ability triggers, destroying itself and creating you a 3/3 Golem token.
Copy of Cavalier of Dawn dies, triggering itself, returning Delif's Cone from your graveyard to your hand.
Repeat.

---

# 876-2703-2713-4659

**Cards:**

- Zirda, the Dawnwaker
- Myr Propagator
- Krark-Clan Ironworks
- Lightning Greaves

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: {1}, MV: 1, Colors: RW, Popularity: 7**

**Steps:**

Equip Lightning Greaves to Myr Propagator by paying {0}.
Activate Myr Propagator by paying {1} and tapping it, creating a token copy of itself.
Activate Krark-Clan Ironworks by sacrificing the tapped Myr Propagator, adding {2}.
Repeat.

---

# 877-1099-1374-2452

**Cards:**

- Morophon, the Boundless
- Rooftop Storm
- Sling-Gang Lieutenant
- Haakon, Stromgald Scourge

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: WUBRG, Popularity: 3**

**Steps:**

Sacrifice Morophon to Sling-Gang Lieutenant, losing target player to lose 1 life and gaining you 1 life.
Cast Morophon from your graveyard by paying {0}.
Repeat.

---

# 880-1659-3470

**Cards:**

- Perilous Forays
- Lotus Cobra
- Seed the Land

**Produces:** Put all lands with a basic land type from your library onto the battlefield tapped

**Mana: {1}, MV: 1, Colors: G, Popularity: 75**

**Steps:**

Activate Perilous Forays by paying {1} and sacrificing a creature, causing you to search your library for a land card with a basic land type and put it onto the battlefield tapped.
When the land enters the battlefield Lotus Cobra and Seed the Land trigger.
Resolve the Lotus Cobra trigger, adding {1}.
Resolve the Seed the Land trigger, creating a creature token.
Repeat.

---

# 880-2783-3470

**Cards:**

- Perilous Forays
- Lotus Cobra
- Nesting Dragon

**Produces:** Put all lands with a basic land type from your library onto the battlefield tapped

**Mana: {1}, MV: 1, Colors: RG, Popularity: 247**

**Steps:**

Activate Perilous Forays by paying {1} and sacrificing a creature.
If the creature was a Dragon Egg, it triggers, creating a 2/2 Dragon creature token.
Resolve the Perilous Forays ability, causing you to search your library for a land card with a basic land type and put it onto the battlefield tapped.
When the land enters the battlefield Lotus Cobra and Nesting Dragon trigger.
Resolve the Lotus Cobra trigger, adding {1}.
Resolve the Nesting Dragon trigger, creating a creature token.
Repeat.

---

# 880-3470-3703

**Cards:**

- Perilous Forays
- Lotus Cobra
- Sporemound

**Produces:** Put all lands with a basic land type from your library onto the battlefield tapped

**Mana: {1}, MV: 1, Colors: G, Popularity: 465**

**Steps:**

Activate Perilous Forays by paying {1} and sacrificing a creature, causing you to search your library for a land card with a basic land type and put it onto the battlefield tapped.
When the land enters the battlefield Lotus Cobra and Sporemound trigger.
Resolve the Lotus Cobra trigger, adding {1}.
Resolve the Sporemound trigger, creating a creature token.
Repeat.

---

# 880-3470-4488

**Cards:**

- Perilous Forays
- Lotus Cobra
- Rampaging Baloths

**Produces:** Put all lands with a basic land type from your library onto the battlefield tapped

**Mana: {1}, MV: 1, Colors: G, Popularity: 3067**

**Steps:**

Activate Perilous Forays by paying {1} and sacrificing a creature, causing you to search your library for a land card with a basic land type and put it onto the battlefield tapped.
When the land enters the battlefield Lotus Cobra and Rampaging Baloths trigger.
Resolve the Lotus Cobra trigger, adding {1}.
Resolve the Rampaging Baloths trigger, creating a creature token.
Repeat.

---

# 880-3470-4677

**Cards:**

- Perilous Forays
- Lotus Cobra
- Zendikar's Roil

**Produces:** Put all lands with a basic land type from your library onto the battlefield tapped

**Mana: {1}, MV: 1, Colors: G, Popularity: 2055**

**Steps:**

Activate Perilous Forays by paying {1} and sacrificing a creature, causing you to search your library for a land card with a basic land type and put it onto the battlefield tapped.
When the land enters the battlefield Lotus Cobra and Zendikar's Roil trigger.
Resolve the Lotus Cobra trigger, adding {1}.
Resolve the Zendikar's Roil trigger, creating a creature token.
Repeat.

---

# 880-3470-4862

**Cards:**

- Perilous Forays
- Omnath, Locus of Rage
- Lotus Cobra

**Produces:** Near-infinite damage, Put all lands with a basic land type from your library onto the battlefield tapped

**Mana: {1}, MV: 1, Colors: RG, Popularity: 2537**

**Steps:**

Activate Perilous Forays by paying {1} and sacrificing a creature.
If the creature was an Elemental, Omnath triggers, dealing 3 damage to any target.
Resolve the Perilous Forays ability, causing you to search your library for a land card with a basic land type and put it onto the battlefield tapped.
When the land enters the battlefield Lotus Cobra and Omnath trigger.
Resolve the Lotus Cobra trigger, adding {1}.
Resolve the Omnath trigger, creating a creature token.
Repeat.

---

# 884-2232-3260-4740

**Cards:**

- K'rrik, Son of Yawgmoth
- Ayara, First of Locthwain
- Cloudstone Curio
- Aetherflux Reservoir

**Produces:** Infinite +1/+1 counters on a creature, Infinite damage, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite lifeloss, Infinite LTB, Infinite storm count

**Mana: , MV: 0, Colors: B, Popularity: 39**

**Steps:**

Cast any creature card in your hand with mana cost {B} by paying 2 life.
Aetherflux Reservoir and K'rrik trigger.
Resolve the Aetherflux Reservoir trigger, causing you to gain 1 life for each spell you've cast this turn.
Resolve the K'rrik trigger, putting a +1/+1 counter on it.
The creature enters the battlefield, triggering Ayara and Cloudstone Curio.
Resolve the Ayara trigger, causing each opponent to lose 1 life and you to gain 1 life.
Resolve the Cloudstone Curio trigger, returning Ayara from the battlefield to your hand.
Cast Ayara by paying 6 life.
Aetherflux Reservoir and K'rrik trigger.
Resolve the Aetherflux Reservoir trigger, causing you to gain 1 life for each spell you've cast this turn.
Resolve the K'rrik trigger, putting a +1/+1 counter on it.
Ayara enters the battlefield, triggering itself and Cloudstone Curio.
Resolve the Ayara trigger, causing each opponent to lose 1 life and you to gain 1 life.
Resolve the Cloudstone Curio trigger, returning the creature with mana cost {B} from the battlefield to your hand.
Repeat.
Once you have an arbitrarily large lifetotal, you may activate Aetherflux Reservoir's ability infinite times to deal infinite damage to any target(s).

---

# 884-5035

**Cards:**

- Ayara, First of Locthwain
- Plague of Vermin

**Produces:** Near-infinite creature tokens for all players, Near-infinite ETB, Near-infinite lifegain, Near-infinite lifegain triggers, Near-infinite lifeloss

**Mana: {6}{B}, MV: 7, Colors: B, Popularity: 8110**

**Steps:**

Cast Plague of Vermin by paying {6}{B}.
Resolve Plague of Vermin, choosing to pay all but one life and create that many black Rat tokens.
For each Rat tokens that enters the battlefield, Ayara triggers, causing you to gain that many life and each opponent to lose that many life.

---

# 885-4747-5200

**Cards:**

- Alena, Kessig Trapper
- Sword of the Paruns
- Phyrexian Soulgorger

**Produces:** Infinite untap of creatures you control, Infinite mana creatures you control can produce, Infinite red mana

**Mana: , MV: 0, Colors: R, Popularity: 21**

**Steps:**

Activate Alena by tapping it, adding at least {R}{R}{R}{R}.
Activate Sword of the Paruns by paying {3}, untapping Alena.
Repeat.

---

# 890-1247-1656

**Cards:**

- Necrotic Ooze
- Pili-Pala
- Palladium Myr

**Produces:** Infinite colored mana, Infinite colorless mana

**Mana: , MV: 0, Colors: B, Popularity: 1482**

**Steps:**

Activate Necrotic Ooze using Palladium Myr's ability by tapping it, adding {C}{C}.
Activate Necrotic Ooze using Pili-Pala's ability by paying {2} and untapping it, adding one mana of any color.
Repeat.

---

# 890-1978-2713

**Cards:**

- Voltaic Construct
- Palladium Myr
- Zirda, the Dawnwaker

**Produces:** Infinite untap of artifact creatures you control

**Mana: , MV: 0, Colors: RW, Popularity: 276**

**Steps:**

Activate Palladium Myr by tapping it, adding {C}{C}.
Activate Voltaic Construct by paying {1}, untapping Palladium Myr.
Repeat.

---

# 890-1978-4893

**Cards:**

- Voltaic Construct
- Palladium Myr
- Training Grounds

**Produces:** Infinite untap of artifact creatures you control

**Mana: , MV: 0, Colors: U, Popularity: 230**

**Steps:**

Activate Palladium Myr by tapping it, adding {C}{C}.
Activate Voltaic Construct by paying {1}, untapping Palladium Myr.
Repeat.

---

# 890-2451-3069-4050

**Cards:**

- Sedris, the Traitor King
- Void Maw
- Phyrexian Altar
- Palladium Myr

**Produces:** Infinite ETB, Infinite LTB, Infinitely large creature until end of turn, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: {2}, MV: 2, Colors: UBR, Popularity: 0**

**Steps:**

Activate Phyrexian Altar by sacrificing Palladium Myr, adding {B}.
Activate Palladium Myr's unearth ability by paying {2}{B}, returning it from your graveyard to the battlefield, giving it haste and exiling it at end of turn or when it leaves the battlefield.
Activate Palladium Myr by tapping it, adding {C}{C}.
Activate Phyrexian Altar by sacrificing Palladium Myr, adding {B}.
Both Palladium Myr's undying ability and Void Maw attempt to exile Palladium Myr when it would be put into your graveyard.
Choose to apply the Void Maw replacement effect, exiling Palladium Myr.
Activate Void Maw by putting Palladium Myr from exile into your graveyard, giving Void Maw +2/+2 until end of turn.
Repeat from step 2.

---

# 890-2713-5200

**Cards:**

- Zirda, the Dawnwaker
- Sword of the Paruns
- Palladium Myr

**Produces:** Infinite colorless mana, Infinite untap of creatures you control, Infinite mana creatures you control can produce

**Mana: , MV: 0, Colors: RW, Popularity: 177**

**Steps:**

Activate Palladium Myr by tapping it, adding {C}{C}.
Activate Sword of the Paruns by paying {1}, untapping Palladium Myr.
Repeat.

---

# 892-1061-1953

**Cards:**

- Brudiclad, Telchor Engineer
- Timestream Navigator
- Sublime Epiphany

**Produces:** Infinite turns, Lock

**Mana: {6}{U}{U}{U}{U} on your first turn, with {2}{U}{U} available on each extra turn, MV: 10, Colors: UR, Popularity: 62**

**Steps:**

Cast Sublime Epiphany by paying {4}{U}{U}, creating a token copy of Timestream Navigator.
At the beginning of your combat phase, Brudiclad triggers, creating a 2/1 Phyrexian Myr creature token, then choosing to have all tokens you control become copies of the Timestream Navigator token.
Activate Timestream Navigator by paying {2}{U}{U} and tapping it and putting it onto the bottom of your library, causing you to take an extra turn after this one.
Move to your next turn.
Repeat from step 2.

---

# 892-1953-2105

**Cards:**

- Brudiclad, Telchor Engineer
- Combat Celebrant
- Sublime Epiphany

**Produces:** Infinite combat phases, Infinite damage

**Mana: {4}{U}{U}, MV: 6, Colors: UR, Popularity: 159**

**Steps:**

Cast Sublime Epiphany by paying {4}{U}{U}, creating a token copy of Combat Celebrant.
At the beginning of your combat phase, Brudiclad triggers, creating a 2/1 Phyrexian Myr creature token, then choosing to have all tokens you control become copies of the Combat Celebrant token.
Declare one of the Combat Celebrant copy as an attacker, choosing to exert it as it attacks.
The Combat Celebrant copy triggers, untapping all other creatures you control and causing you to get an additional combat phase after this one.
Repeat from step 2.

---

# 893-1014-1636-4694

**Cards:**

- Arcum Dagsson
- March of the Machines
- Myr Turbine
- Intruder Alarm

**Produces:** Put all noncreature artifact cards from your library onto the battlefield

**Mana: , MV: 0, Colors: U, Popularity: 18**

**Steps:**

Activate Arcum Dagsson, sacrificing the extra artifact creature to tutor any noncreature artifact to play.
The tutored card ETBs as a creature due to March of the Machines, triggering Intruder Alarm.
Untap Arcum Dagsson and Myr Turbine (also a creature due to March of the Machines) with Intruder Alarm.
Activate Myr Turbine to create a 1/1 Myr artifact creature token.
Repeat the loop, sacrificing the newly generated Myr, to tutor all noncreature artifacts from your library to play.

---

# 893-2034-4853

**Cards:**

- Dross Scorpion
- Myr Turbine
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: C, Popularity: 429**

**Steps:**

Activate Myr Turbine by tapping it, creating a 1/1 Myr artifact creature token.
Activate Ashnod's Altar by sacrificing the Myr.
When the Myr dies, Dross Scorpion triggers, untapping Myr Turbine.
Repeat.

---

# 893-3698-4853

**Cards:**

- Dross Scorpion
- Myr Turbine
- Grinding Station

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: C, Popularity: 297**

**Steps:**

Activate Myr Turbine by tapping it, creating a 1/1 Myr artifact creature token.
When the Myr enters, Grinding Station triggers, untapping Grinding Station.
Activate Grinding Station by tapping it and sacrificing the Myr.
When the Myr dies, Dross Scorpion triggers, untapping Myr Turbine.
Resolve the Grinding Station ability.
Repeat.

---

# 893-4050-4853

**Cards:**

- Dross Scorpion
- Myr Turbine
- Phyrexian Altar

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite colored mana

**Mana: , MV: 0, Colors: C, Popularity: 107**

**Steps:**

Activate Myr Turbine by tapping it, creating a 1/1 Myr artifact creature token.
Activate Phyrexian Altar by sacrificing the Myr.
When the Myr dies, Dross Scorpion triggers, untapping Myr Turbine.
Repeat.

---

# 893-4659-4853

**Cards:**

- Dross Scorpion
- Myr Turbine
- Krark-Clan Ironworks

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: C, Popularity: 511**

**Steps:**

Activate Myr Turbine by tapping it, creating a 1/1 Myr artifact creature token.
Activate Krark-Clan Ironworks by sacrificing the Myr.
When the Myr dies, Dross Scorpion triggers, untapping Myr Turbine.
Repeat.

---

# 900-2914-4992

**Cards:**

- Stormtide Leviathan
- Choke
- Sword of Feast and Famine

**Produces:** Lands do not untap, Lands your opponents control do not untap, Lock, Mass Land Denial

**Mana: , MV: 0, Colors: GU, Popularity: 7**

**Steps:**

Stormtide makes everything an island, choke prevents them from untapping.
Sword of Feast and Famine can untap your lands.

---

# 900-3750

**Cards:**

- Sword of Feast and Famine
- Aggravated Assault

**Produces:** Infinite combat phases

**Mana: , MV: 0, Colors: R, Popularity: 28559**

**Steps:**

Deal combat damage to an opponent with the creature that has Sword of Feast and Famine attached.
Sword of Feast and Famine triggers, causing that opponent to discard a card, and you to untap all lands you control.
Proceed to your postcombat main phase.
Activate all mana producing lands you control by tapping them, adding at least {3}{R}{R}.
Activate Aggravated Assault by paying {3}{R}{R}, untapping all creatures you control and causing you to get an additional combat and main phase after this phase.
Repeat.

---

# 901-2024-5168

**Cards:**

- Seedcradle Witch
- Bloom Tender
- Govern the Guildless

**Produces:** Infinite black mana, Infinite blue mana, Infinitely large creature until end of turn, Infinite red mana, Infinite mana of colors among permanents you control

**Mana: {1}{U}, MV: 2, Colors: GWU, Popularity: 0**

**Steps:**

During your upkeep, activate Govern the Guildless by paying {1}{U} and revealing it from your hand, making a creature you control all colors until end of turn.
Activate Bloom Tender by tapping it, adding {W}{U}{B}{R}{G}.
Activate Seedcradle Witch by paying {2}{W}{G}, giving Bloom Tender +3/+3 until end of turn and untapping it.
Repeat from step 2.

---

# 91-1242-4050-5112

**Cards:**

- Mairsil, the Pretender
- Cinderhaze Wretch
- Endling
- Phyrexian Altar

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: {B}, MV: 1, Colors: UBR, Popularity: 10**

**Steps:**

Activate Mairsil using Endling's third ability by paying {B}, gaining Mairsil undying.
Activate Mairsil using Phyrexian Altar's ability by sacrificing Mairsil, adding {B}.
Mairsil's undying ability triggers, returning it to the battlefield.
Activate Mairsil using Cinderhaze Wretch's ability, putting -1/-1 on itself.
Repeat.

---

# 9-1308-1645-3581

**Cards:**

- Kykar, Wind's Fury
- Anointed Procession
- Crown of Flames
- Grapeshot

**Produces:** Infinite storm count, Near-infinite damage to one opponent, Infinite LTB, Infinite ETB, Infinite sacrifice triggers, Infinite death triggers

**Mana: {R}, MV: 1, Colors: URW, Popularity: 18**

**Steps:**

Cast Crown of Flames on Kykar, Wind's Fury.
Kykar Wind's Fury triggers creating 2 spirits with Anointed Procession.
Sacrifice both spirits adding {R}{R} to your mana pool with Kykar, Wind's Fury.
Return Crown of Flames to your hand with its ability.
Repeat for an arbitrarily large storm count.
Cast Grapeshot instead of Crown of Flames.

---

# 913-1385-1864-2034

**Cards:**

- Prossh, Skyraider of Kher
- Signpost Scarecrow
- Ashnod's Altar
- Zulaport Cutthroat

**Produces:** Infinite colored mana, Infinite creature tokens, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite death triggers, Infinite colorless mana

**Mana: , MV: 0, Colors: BRG, Popularity: 7**

**Steps:**

Cast Prossh, creating 6 kobold tokens.Sacrifice6 tokens to Altar to produce {12}.
Use {6} to produce {B}{R}{G} with Scarecrow.SacrificeProssh to Altar to put him back into the command zone.
(also producing {2})
Floating {8}{B}{R}{G}, recast Prossh for {5}{B}{R}{G}, producing 8 tokens.Sacrifice them all to Altar producing {20}, filter again, and repeat.
For eachsacrificeed creature, Cutthroat drains an opponent for 1 life.

---

# 913-1864-2034

**Cards:**

- Prossh, Skyraider of Kher
- Signpost Scarecrow
- Ashnod's Altar

**Produces:** Infinite colored mana, Infinite creature tokens, Infinite LTB, Infinite sacrifice triggers, Infinite death triggers, Infinite colorless mana

**Mana: , MV: 0, Colors: BRG, Popularity: 7**

**Steps:**

Cast Prossh, creating 6 kobold tokens.Sacrifice6 tokens to Altar to produce {12}.
Use {6} to produce {B}{R}{G} with Scarecrow.SacrificeProssh to Altar to put him back into the command zone.
(also producing {2})
Floating {8}{B}{R}{G}, recast Prossh for {5}{B}{R}{G}, producing 8 tokens.Sacrifice them all to Altar producing {20}, filter again, and repeat.

---

# 913-1864-2034-2842

**Cards:**

- Prossh, Skyraider of Kher
- Signpost Scarecrow
- Ashnod's Altar
- Blood Artist

**Produces:** Infinite LTB, Infinite sacrifice triggers, Infinite death triggers, Infinite colorless mana, Infinite colored mana, Infinite creature tokens, Infinite lifeloss

**Mana: , MV: 0, Colors: BRG, Popularity: 6**

**Steps:**

Cast Prossh, creating 6 kobold tokens.Sacrifice6 tokens to Altar to produce {12}.
Use {6} to produce {B}{R}{G} with Scarecrow.SacrificeProssh to Altar to put him back into the command zone.
(also producing {2})
Floating {8}{B}{R}{G}, recast Prossh for {5}{B}{R}{G}, producing 8 tokens.Sacrifice them all to Altar producing {20}, filter again, and repeat.
For eachsacrificeed creature, Artist drains an opponent for 1 life.

---

# 913-2440-2714-5105

**Cards:**

- Sigil of the New Dawn
- Mana Echoes
- Siege-Gang Commander
- Signpost Scarecrow

**Produces:** Infinite colored mana, Infinite colorless mana, Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {3}{R}{R}, MV: 5, Colors: RW, Popularity: 0**

**Steps:**

Cast Siege-Gang Commander by paying {3}{R}{R}.
When Siege-Gang Commander enters the battlefield, it and Mana Echoes trigger.
Resolve the Siege-Gang Commander trigger, creating three 1/1 Goblin creature tokens.
When the Goblin tokens enter the battlefield, Mana Echoes triggers three times.
Resolve all four Mana Echoes triggers, adding at least {16}.
Activate Signpost Scarecrow four times by paying {8}, adding {W}{R}{R}{R}.
Activate Siege-Gang Commander by paying {C}{R} and sacrificing itself.
Sigil of the New Dawn triggers, causing you to pay {C}{W} to return Siege-Gang Commander from your graveyard to your hand.
Resolve the Siege-Gang Commander activated ability, dealing 2 damage to any target.
Repeat.

---

# 914-1099-1799-2048

**Cards:**

- Grenzo, Dungeon Warden
- Epitaph Golem
- Dockside Extortionist
- Sling-Gang Lieutenant

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite Treasure tokens

**Mana: {1}{R}, MV: 2, Colors: BR, Popularity: 58**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least five Treasure tokens.
Activate four Treasure tokens by tapping and sacrificing them, adding {4}.
Activate Sling-Gang Lieutenant by sacrificing Dockside Extortionist, causing an opponent to lose 1 life and you to gain 1 life.
Activate Epitaph Golem by paying {2}, putting Dockside Extortionist on the bottom of your library from your graveyard.
Activate Grenzo by paying {2}, putting Dockside Extortionist into your graveyard from the bottom of your library, and then putting it onto the battlefield.
Repeat from step 2.

---

# 914-1214-3198

**Cards:**

- Dockside Extortionist
- Silent Departure
- Lore Drakkis

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {1}{R}, MV: 2, Colors: UR, Popularity: 0**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Cast Lore Drakkis for its mutate cost by paying {U/R}{U/R}, targeting Dockside Extortionist.
Lore Drakkis's mutate ability triggers, returning Silent Departure from your graveyard to hand.
Cast Silent Departure by paying {U}, returning Dockside Extortionist and Lore Drakkis to your hand.
Activate five Treasure tokens by tapping and sacrificing those, adding {1}{U}{U/R}{U/R}{R}.
Repeat.

---

# 914-1409

**Cards:**

- Dockside Extortionist
- Deadeye Navigator

**Produces:** Infinite blinking, Infinite colored mana, Infinite ETB, Infinite LTB, Infinite Treasure tokens

**Mana: {1}{U}, MV: 2, Colors: UR, Popularity: 1028**

**Steps:**

Activate Dockside Extortionist by paying {1}{U}, blinking it.
When Dockside Extortionist enters the battlefield, it and Deadeye Navigator's soulbond ability trigger.
Resolve the Dockside Extortionist trigger, creating at least two Treasure artifact tokens.
Resolve the Deadeye Navigator trigger, repairing it and Dockside Extortionist.
Activate two Treasures by tapping and sacrificing them, adding {1}{U}.
Repeat.

---

# 914-1458-2617

**Cards:**

- Midnight Guard
- Banishing Knack
- Dockside Extortionist

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite storm count, Infinite Treasure tokens

**Mana: {1}{R}, MV: 2, Colors: URW, Popularity: 0**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, triggering itself and Midnight Guard.
Resolve the Dockside Extortionist trigger, creating at least 3 Treasure tokens.
Resolve the Midnight Guard trigger, untapping it.
Activate a Treasure token by tapping and sacrificing it, adding {U}.
Cast Banishing Knack by paying {U} targeting Midnight Guard.
Activate Midnight Guard by tapping it, returning Dockside Extortionist from the battlefield to your hand.
Activate two Treasure tokens by tapping and sacrificing them, adding {1}{R}.
Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, triggering itself and Midnight Guard.
Resolve the Dockside Extortionist trigger, creating at least 3 Treasure tokens.
Resolve the Midnight Guard trigger, untapping it.
Repeat from step 7.

---

# 914-1639-2649

**Cards:**

- Vadrok, Apex of Thunder
- Dockside Extortionist
- Winds of Rebuke

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite mill, Infinite self-mill, Infinite storm count, Infinite Treasure tokens

**Mana: {1}{R} plus enough mana to pay for commander tax, if applicable, MV: 2, Colors: URW, Popularity: 37**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Activate six Treasure tokens by tapping and sacrificing them, adding {2}{W/U}{R}{R}{R}.
Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R} plus commander tax if applicable, putting it on top of Dockside Extortionist.
The Vadrok mutated creature triggers, allowing you to cast Winds of Rebuke from your graveyard without paying its mana cost.
Resolve Winds of Rebuke, returning Vadrok and Dockside Extortionist from the battlefield to your hand and causing each player to mill two cards.
Repeat.
If your opponents control at least seven artifacts and/or enchantments, this combo produces infinite Treasure tokens.

---

# 914-1792-2617

**Cards:**

- Midnight Guard
- Retraction Helix
- Dockside Extortionist

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite storm count, Infinite Treasure tokens

**Mana: {1}{R}, MV: 2, Colors: URW, Popularity: 0**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, triggering itself and Midnight Guard.
Resolve the Dockside Extortionist trigger, creating at least three Treasure tokens.
Resolve the Midnight Guard trigger, untapping it.
Activate three Treasure tokens by tapping and sacrificing them, adding {1}{U}{R}.
Cast Retraction Helix by paying {U}, targeting Midnight Guard.
Activate Midnight Guard by tapping it, returning Dockside Extortionist from the battlefield to your hand.
Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, triggering itself and Midnight Guard.
Resolve the Dockside Extortionist trigger, creating at least three Treasure tokens.
Resolve the Midnight Guard trigger, untapping it.
Activate two Treasure tokens by tapping and sacrificing them, adding {1}{R}.
Repeat from step 7.

---

# 914-1801-3198

**Cards:**

- Dockside Extortionist
- String of Disappearances
- Lore Drakkis

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {1}{R}, MV: 2, Colors: UR, Popularity: 4**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Cast Lore Drakkis for its mutate cost by paying {U/R}{U/R}, targeting Dockside Extortionist.
Lore Drakkis's mutate ability triggers, returning String of Disappearances from your graveyard to hand.
Cast String of Disappearances by paying {U}, returning Dockside Extortionist and Lore Drakkis to your hand.
Activate five Treasure tokens by tapping and sacrificing those, adding {1}{U}{U/R}{U/R}{R}.
Repeat.

---

# 914-2034-5003

**Cards:**

- Dockside Extortionist
- Nim Deathmantle
- Ashnod's Altar

**Produces:** Infinite colored mana, Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite Treasure tokens

**Mana: {2}, MV: 2, Colors: R, Popularity: 559**

**Steps:**

Activate Ashnod's Altar by sacrificing Dockside Extortionist, adding {C}{C}.
Dockside Extortionist dies, triggering Nim Deathmantle, causing you to pay {4} to return Dockside Extortionist from your graveyard to the battlefield, and attach Nim Deathmantle to it.
Dockside Extortionist enters the battlefield, creating at least two Treasure tokens.
Activate two Treasure tokens by tapping and sacrificing them, adding two mana of any color.
Repeat.

---

# 914-2232

**Cards:**

- Dockside Extortionist
- Cloudstone Curio

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count, Infinite Treasure tokens

**Mana: {1}{R}, MV: 2, Colors: R, Popularity: 7812**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, triggering itself and Cloudstone Curio.
Resolve the Dockside Extortionist trigger, creating a number of Treasure tokens equal to the number of artifacts and/or enchantments your opponent control.
Resolve the Cloudstone Curio trigger, returning the additional nontoken nonartifact creature from the battlefield to your hand.
Activate a Treasure token by tapping and sacrificing it, adding one mana of any color.
Repeat step 5 until you have enough mana to cast the additional creature card.
Cast the additional creature by paying its mana cost.
The creature enters the battlefield, triggering Cloudstone Curio, returning Dockside Extortionist from the battlefield to your hand.
Activate two Treasure tokens by tapping and sacrificing them, adding {1}{R}.
Repeat.

---

# 914-2451-3069-5256

**Cards:**

- Sedris, the Traitor King
- Void Maw
- Altar of Dementia
- Dockside Extortionist

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinitely large creature until end of turn, Infinite mill, Infinite sacrifice triggers, Infinite self-mill, Infinite Treasure tokens

**Mana: {2}{B}, MV: 3, Colors: UBR, Popularity: 0**

**Steps:**

Activate Altar of Dementia by sacrificing Dockside Extortionist, causing target player to mill cards equal to Dockside Extortionist's power.
Activate Dockside Extortionist's unearth ability by paying {2}{B}, returning it from your graveyard to the battlefield, giving it haste and exiling it at end of turn or when it leaves the battlefield.
Dockside Extortionist enters the battlefield, creating at least four Treasure tokens.
Activate three of the Treasure tokens by tapping and sacrificing them, adding {2}{B}.
Activate Altar of Dementia by sacrificing Dockside Extortionist.
Both Dockside Extortionist's undying ability and Void Maw attempt to exile Dockside Extortionist when it would be put into your graveyard.
Choose to apply the Void Maw replacement effect, exiling Dockside Extortionist.
Resolve the Altar of Dementia ability, causing target player to mill cards equal to Dockside Extortionist's power.
Activate Void Maw by putting Dockside Extortionist from exile into your graveyard, giving Void Maw +2/+2 until end of turn.
Repeat from step 2.

---

# 914-2461-3198

**Cards:**

- Dockside Extortionist
- Saving Grasp
- Lore Drakkis

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {1}{R}, MV: 2, Colors: URW, Popularity: 0**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Cast Lore Drakkis for its mutate cost by paying {U/R}{U/R}, targeting Dockside Extortionist.
Lore Drakkis's mutate ability triggers, returning Saving Grasp from your graveyard to hand.
Cast Saving Grasp by paying {U}, returning Dockside Extortionist and Lore Drakkis to your hand.
Activate five Treasure tokens by tapping and sacrificing those, adding {1}{U}{U/R}{U/R}{R}.
Repeat.

---

# 914-2504-2649

**Cards:**

- Vadrok, Apex of Thunder
- Dockside Extortionist
- Unexplained Disappearance

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite self-mill, Infinite storm count, Infinite surveil, Infinite Treasure tokens

**Mana: {1}{R} plus enough mana to pay for commander tax, if applicable, MV: 2, Colors: URW, Popularity: 1**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Activate six Treasure tokens by tapping and sacrificing them, adding {2}{W/U}{R}{R}{R}.
Cast Vadrok for its mutate cost by paying {1}{W/U}{R}{R} plus commander tax if applicable, putting it on top of Dockside Extortionist.
The Vadrok mutated creature triggers, allowing you to cast Unexplained Disappearance from your graveyard without paying its mana cost.
Resolve Unexplained Disappearance, returning Vadrok and Dockside Extortionist from the battlefield to your hand and causing you to surveil 1.
Repeat.
If your opponents control at least seven artifacts and/or enchantments, this combo produces infinite Treasure tokens.

---

# 914-2807-3198

**Cards:**

- Dockside Extortionist
- Clutch of Currents
- Lore Drakkis

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {1}{R}, MV: 2, Colors: UR, Popularity: 0**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Cast Lore Drakkis for its mutate cost by paying {U/R}{U/R}, targeting Dockside Extortionist.
Lore Drakkis's mutate ability triggers, returning Clutch of Currents from your graveyard to hand.
Cast Clutch of Currents by paying {U}, returning Dockside Extortionist and Lore Drakkis to your hand.
Activate five Treasure tokens by tapping and sacrificing those, adding {1}{U}{U/R}{U/R}{R}.
Repeat.

---

# 914-3089

**Cards:**

- Dockside Extortionist
- Barrin, Master Wizard

**Produces:** Infinite colored mana, Infinite ETB, Infinite sacrifice triggers, Infinite storm count, Infinite Treasure tokens

**Mana: {1}{R}, MV: 2, Colors: UR, Popularity: 1390**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Activate four Treasure tokens by tapping and sacrificing those, adding {R} and three mana of any color.
Activate Barrin by paying {2} and sacrificing a Treasure token, returning Dockside Extortionist to hand.
Repeat.

---

# 914-3198-3636

**Cards:**

- Dockside Extortionist
- Rescue
- Lore Drakkis

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {1}{R}, MV: 2, Colors: UR, Popularity: 2**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Cast Lore Drakkis for its mutate cost by paying {U/R}{U/R}, targeting Dockside Extortionist.
Lore Drakkis's mutate ability triggers, returning Rescue from your graveyard to hand.
Cast Rescue by paying {U}, returning Dockside Extortionist and Lore Drakkis to your hand.
Activate five Treasure tokens by tapping and sacrificing those, adding {1}{U}{U/R}{U/R}{R}.
Repeat.

---

# 914-3198-3648

**Cards:**

- Dockside Extortionist
- Word of Undoing
- Lore Drakkis

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {1}{R}, MV: 2, Colors: UR, Popularity: 0**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Cast Lore Drakkis for its mutate cost by paying {U/R}{U/R}, targeting Dockside Extortionist.
Lore Drakkis's mutate ability triggers, returning Word of Undoing from your graveyard to hand.
Cast Word of Undoing by paying {U}, returning Dockside Extortionist and Lore Drakkis to your hand.
Activate five Treasure tokens by tapping and sacrificing those, adding {1}{U}{U/R}{U/R}{R}.
Repeat.

---

# 914-3198-4263

**Cards:**

- Dockside Extortionist
- Unsummon
- Lore Drakkis

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {1}{R}, MV: 2, Colors: UR, Popularity: 3**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Cast Lore Drakkis for its mutate cost by paying {U/R}{U/R}, targeting Dockside Extortionist.
Lore Drakkis's mutate ability triggers, returning Unsummon from your graveyard to hand.
Cast Unsummon by paying {U}, returning Dockside Extortionist and Lore Drakkis to your hand.
Activate five Treasure tokens by tapping and sacrificing those, adding {1}{U}{U/R}{U/R}{R}.
Repeat.

---

# 914-3198-4643

**Cards:**

- Dockside Extortionist
- Void Snare
- Lore Drakkis

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: {1}{R}, MV: 2, Colors: UR, Popularity: 3**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Cast Lore Drakkis for its mutate cost by paying {U/R}{U/R}, targeting Dockside Extortionist.
Lore Drakkis's mutate ability triggers, returning Void Snare from your graveyard to hand.
Cast Void Snare by paying {U}, returning Dockside Extortionist and Lore Drakkis to your hand.
Activate five Treasure tokens by tapping and sacrificing those, adding {1}{U}{U/R}{U/R}{R}.
Repeat.

---

# 914-3198-4953

**Cards:**

- Dockside Extortionist
- Chain of Vapor
- Lore Drakkis

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite magecraft triggers, Infinite storm count, Infinite Treasure tokens

**Mana: {1}{R}, MV: 2, Colors: UR, Popularity: 136**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Activate five Treasure tokens by tapping and sacrificing them, adding {1}{U/R}{U/R}{U}{R}.
Cast Lore Drakkis for its mutate cost by paying {U/R}{U/R}, mutating it on top of Dockside Extortionist.
Lore Drakkis triggers, returning Chain of Vapor from your graveyard to your hand.
Cast Chain of Vapor by paying {U}, returning Lore Drakkis and Dockside Extortionist to your hand and choosing not to copy Chain of Vapor.
Repeat.

---

# 914-3423

**Cards:**

- Aegis Automaton
- Dockside Extortionist

**Produces:** Infinite colored mana, Infinite ETB, Infinite LTB, Infinite storm count, Infinite Treasure tokens

**Mana: {1}{R}, MV: 2, Colors: RW, Popularity: 7**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least eight Treasure tokens.
Activate seven of the Treasure tokens by tapping and sacrificing them, adding {5}{W}{R}.
Activate Aegis Automaton by paying {4}{W}, returning Dockside Extortionist from the battlefield to your hand.
Repeat.

---

# 914-3593-4359-5147

**Cards:**

- Garna, the Bloodflame
- Sneak Attack
- Dockside Extortionist
- Goblin Bombardment

**Produces:** Infinite colored mana, Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite Treasure tokens

**Mana: {R}, MV: 1, Colors: BR, Popularity: 10**

**Steps:**

Activate Sneak Attack by paying {R}, putting Dockside Extortionist onto the battlefield.
Dockside Extortionist triggers, creating at least three Treasure tokens.
Activate two Treasure tokens by tapping and sacrificing those, adding {R}{R}.
Activate Goblin Bombardment by sacrificing Dockside Extortionist, dealing 1 damage to any target.
Activate Sneak Attack by paying {R}, putting Garna onto the battlefield.
Garna's enter the battlefield ability triggers.
Holding priority, activate Goblin Bombardment by sacrificing Garna, dealing 1 damage to any target.
Resolve the Garna ability, returning all creature cards put in your graveyard this turn to your hand.
Repeat.

---

# 914-4013-4659

**Cards:**

- Dockside Extortionist
- Eldrazi Displacer
- Krark-Clan Ironworks

**Produces:** Infinite blinking, Infinite colored mana, Infinite colorless mana, Infinite ETB, Infinite LTB, Infinite Treasure tokens, Infinite blinking of most creatures

**Mana: {2}{C}, MV: 3, Colors: RW, Popularity: 178**

**Steps:**

Activate Eldrazi Displacer by paying {2}{C}, blinking Dockside Extortionist.
Dockside Extortionsit enters the battlefield, creating at least three Treasure tokens.
Activate Krark-Clan Ironworks by sacrificing two Treasure tokens, adding {C}{C}{C}{C}.
Repeat.

---

# 914-5105-5147

**Cards:**

- Sigil of the New Dawn
- Dockside Extortionist
- Goblin Bombardment

**Produces:** Infinite colored mana, Infinite damage, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count, Infinite Treasure tokens

**Mana: {1}{R}, MV: 2, Colors: RW, Popularity: 8**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least five Treasure tokens.
Activate four of the Treasure tokens by tapping and sacrificing them, adding {2}{W}{R}.
Activate Goblin Bombardment by sacrificing Dockside Extortionist.
Sigil of the New Dawn triggers, causing you to pay {1}{W} to return Dockside Extortionist from your graveyard to your hand.
Resolve the Goblin Bombardment ability, dealing 1 damage to any target.
Repeat.

---

# 914-5105-5256

**Cards:**

- Sigil of the New Dawn
- Dockside Extortionist
- Altar of Dementia

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite self-mill, Infinite storm count, Infinite Treasure tokens, Infinite sacrifice triggers

**Mana: {1}{R}, MV: 2, Colors: RW, Popularity: 6**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least five Treasure tokens.
Activate four of the Treasure tokens by tapping and sacrificing them, adding {2}{W}{R}.
Activate Altar of Dementia by sacrificing Dockside Extortionist.
Sigil of the New Dawn triggers, causing you to pay {1}{W} to return Dockside Extortionist from your graveyard to your hand.
Resolve the Altar of Dementia ability, causing target player to mill cards equal to Dockside Extortionist's power.
Repeat.

---

# 914-990-1678

**Cards:**

- Dockside Extortionist
- Recurring Nightmare
- Mayhem Devil

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite storm count, Infinite Treasure tokens

**Mana: {1}{R}, MV: 2, Colors: BR, Popularity: 0**

**Steps:**

Cast Dockside Extortionist by paying {1}{R}.
Dockside Extortionist enters the battlefield, creating at least six Treasure tokens.
Activate Recurring Nightmare by sacrificing Dockside Extortionist and returning itself to hand, return Mayhem Devil to the battlefield.
Activate five Treasure tokens by tapping and sacrificing those, adding {4}{B}{B}.
Mayhem Devil triggers six times each.
Resolve the first Mayhem Devil trigger, dealing 1 damage to any target.
Repeat step 6 for each remaining Mayhem Devil trigger.
Cast Recurring Nightmare by paying {2}{B}.
Activate Recurring Nightmare by sacrificing Mayhem Devil.
Mayhem Devil trigger, dealing 1 damage to any target.
Resolve the Recurring Nightmare by returning itself to hand, return Dockside Extortionist to the battlefield.
Repeat from step 2.

---

# 92-1839-2298

**Cards:**

- Kuro, Pitlord
- Vizkopa Guildmage
- Oketra's Last Mercy

**Produces:** Each opponent loses the game

**Mana: {2}{W}{W}{W}{B}, MV: 6, Colors: WB, Popularity: 4**

**Steps:**

Activate Vizkopa Guildmage by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Activate Kuro by paying 1 life, targeting any creature.
Repeat step 2 until you have one life.
Resolve all Kuro abilities, giving the creature -1/-1 for each ability.
Cast Oketra's Last Mercy by paying {1}{W}{W}, causing your life total to become forty.
Vizkopa Guildmage triggers, causing each opponent to lose thirty-nine life.
Each opponent loses the game due to having zero or less life.

---

# 92-2063-2298

**Cards:**

- Mischievous Poltergeist
- Vizkopa Guildmage
- Oketra's Last Mercy

**Produces:** Each opponent loses the game

**Mana: {2}{W}{W}{W}{B}, MV: 6, Colors: WB, Popularity: 87**

**Steps:**

Activate Vizkopa Guildmage by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Activate Mischievous Poltergeist by paying 1 life, regenerating it.
Repeat step 2 until you have one life.
Cast Oketra's Last Mercy by paying {1}{W}{W}, causing your life total to become forty.
Vizkopa Guildmage triggers, causing each opponent to lose thirty-nine life.
Each opponent loses the game due to having zero or less life.

---

# 922-1656-3121-3866-4283

**Cards:**

- Necrotic Ooze
- Whisper, Blood Liturgist
- Altar Golem
- Abhorrent Overlord
- Marionette Master

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifeloss, Infinite LTB, Infinite sacrifice triggers, Infinite tapped creature tokens

**Mana: , MV: 0, Colors: B, Popularity: 1**

**Steps:**

Tap Necrotic Ooze using Whisper, Blood Liturgist's ability to sacrifice two creatures and return Abhorrent Overlord to battlefield.
Abhorrent Overlord's ETB triggers, creating at least 5 creature tokens.
Using Altar Golem's ability, tap Abhorrent Overlord and 4 tokens to untap Necrotic Ooze.
Tap Necrotic Ooze and sacrifice Abhorrent Overlord and a tapped token to Whisper's ability to return Marionetter Master to the battlefield, creating 3 Servo tokens.
Tap Marionette Master and the 4 untapped tokens to untap Necrotic Ooze.
Sacrifice Marionetter Master and a Servo token, causing target opponent to lose 1 life and reanimating Abhorrent Overlord.
Repeat from step 2 for infinite life loss.

---

# 92-2298-2358

**Cards:**

- Blood Celebrant
- Vizkopa Guildmage
- Oketra's Last Mercy

**Produces:** Each opponent loses the game

**Mana: {2}{W}{W}{W}{B}, MV: 6, Colors: WB, Popularity: 183**

**Steps:**

Activate Blood Celebrant by paying {B} and one life, adding {B}.
Repeat step 1 until you have one life.
Activate Vizkopa Guildmage by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Cast Oketra's Last Mercy by paying {1}{W}{W}, causing your life total to become forty.
Vizkopa Guildmage triggers, causing each opponent to lose thirty-nine life.
Each opponent loses the game due to having zero or less life.

---

# 92-2298-2749

**Cards:**

- Wall of Blood
- Vizkopa Guildmage
- Oketra's Last Mercy

**Produces:** Each opponent loses the game

**Mana: {2}{W}{W}{W}{B}, MV: 6, Colors: WB, Popularity: 374**

**Steps:**

Activate Vizkopa Guildmage by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Activate Wall of Blood by paying 1 life, giving it +1/+1 until end of turn.
Repeat step 2 until you have one life.
Cast Oketra's Last Mercy by paying {1}{W}{W}, causing your life total to become forty.
Vizkopa Guildmage triggers, causing each opponent to lose thirty-nine life.
Each opponent loses the game due to having zero or less life.

---

# 92-2298-2935

**Cards:**

- Ethereal Champion
- Vizkopa Guildmage
- Oketra's Last Mercy

**Produces:** Each opponent loses the game

**Mana: {2}{W}{W}{W}{B}, MV: 6, Colors: WB, Popularity: 6**

**Steps:**

Activate Vizkopa Guildmage by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Activate Ethereal Champion by paying 1 life, preventing the next one damage dealt to it this turn.
Repeat step 2 until you have one life.
Cast Oketra's Last Mercy by paying {1}{W}{W}, causing your life total to become forty.
Vizkopa Guildmage triggers, causing each opponent to lose thirty-nine life.
Each opponent loses the game due to having zero or less life.

---

# 92-2298-3527

**Cards:**

- Spatial Binding
- Vizkopa Guildmage
- Oketra's Last Mercy

**Produces:** Each opponent loses the game

**Mana: {2}{W}{W}{W}{B}, MV: 6, Colors: WUB, Popularity: 3**

**Steps:**

Activate Vizkopa Guildmage by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Activate Spatial Binding by paying 1 life, preventing it from phasing out during your next upkeep.
Repeat step 2 until you have one life.
Cast Oketra's Last Mercy by paying {1}{W}{W}, causing your life total to become forty.
Vizkopa Guildmage triggers, causing each opponent to lose thirty-nine life.
Each opponent loses the game due to having zero or less life.

---

# 92-2298-3591

**Cards:**

- Necropotence
- Vizkopa Guildmage
- Oketra's Last Mercy

**Produces:** Each opponent loses the game

**Mana: {2}{W}{W}{W}{B}, MV: 6, Colors: WB, Popularity: 242**

**Steps:**

Activate Vizkopa Guildmage by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Activate Necropotence by paying 1 life, exiling the top card of your library.
Repeat step 2 until you have one life.
Cast Oketra's Last Mercy by paying {1}{W}{W}, causing your life total to become forty.
Vizkopa Guildmage triggers, causing each opponent to lose thirty-nine life.
Each opponent loses the game due to having zero or less life.

---

# 92-2298-3859

**Cards:**

- Cavern Harpy
- Vizkopa Guildmage
- Oketra's Last Mercy

**Produces:** Each opponent loses the game

**Mana: {2}{W}{W}{W}{B}, MV: 6, Colors: WUB, Popularity: 2**

**Steps:**

Activate Vizkopa Guildmage by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Activate Cavern Harpy by paying 1 life, targeting any creature.
Repeat step 2 until you have one life.
Resolve all Cavern Harpy abilities, returning it from the battlefield to your hand.
Cast Oketra's Last Mercy by paying {1}{W}{W}, causing your life total to become forty.
Vizkopa Guildmage triggers, causing each opponent to lose thirty-nine life.
Each opponent loses the game due to having zero or less life.

---

# 92-2749-3779

**Cards:**

- Wall of Blood
- Vizkopa Guildmage
- Swords to Plowshares

**Produces:** Infinite lifeloss, Near-infinite lifegain

**Mana: {1}{W}{W}{B}, MV: 4, Colors: WB, Popularity: 1786**

**Steps:**

Activate Vizkopa Guildmage's second ability by paying {1}{W}{B}, creating a delayed triggered ability.
Activate Wall of Blood's ability multiple times by paying 1 life each time until you are at 1 life, giving Wall of Blood +1/+1 until end of turn for each activation.
Cast Swords to Plowshares by paying {W}, exiling Wall of Blood and gaining life equal to its power.
The delayed triggered ability from Vizkopa Guildmage triggers, causing each opponent to lose that much life.

---

# 92-2927-3392

**Cards:**

- Children of Korlis
- Vizkopa Guildmage
- Plunge into Darkness

**Produces:** Each opponent loses the game, Near-infinite lifeloss

**Mana: {2}{W}{B}{B}, MV: 5, Colors: WB, Popularity: 222**

**Steps:**

Activate Vizkopa Guildmage's second ability by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Cast Plunge into Darkness by paying {1}{B}, choosing to pay an amount of life equal to the greatest lifetotal among opponent, then look at that many cards from the top of your library, putting one into your hand and exiling the rest.
Activate Children of Korils by sacrificing it, causing you to gain life equal to the amount of life you've lost this turn.
Vizkopa Guildmage triggers, causing each opponent to lose life equal to the amount of life you gained.
Each opponent loses the game due to having zero or less life.

---

# 923-2615-5112

**Cards:**

- Mairsil, the Pretender
- Spikeshot Elder
- Tree of Perdition

**Produces:** Target opponent loses the game

**Mana: {1}{R}{R}, MV: 3, Colors: UBR, Popularity: 269**

**Steps:**

Activate Mairsil using Tree of Perdition's ability by tapping it, exchanging target opponent's life total with Mairsil's toughness.
Activate Mairsil using Spikeshot Elder's ability by paying {1}{R}{R}, dealing damage equal to Mairsil's power to the opponent.
The opponent loses the game due to having zero or less life.

---

# 92-3966

**Cards:**

- Exquisite Blood
- Vizkopa Guildmage

**Produces:** Infinite lifegain triggers, Infinite lifeloss, Infinite lifegain

**Mana: {1}{W}{B}, MV: 3, Colors: WB, Popularity: 11864**

**Steps:**

Activate Vizkopa Guildmage's second ability by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Gain life.
Vizkopa Guildmage triggers, causing each opponent to lose 1 life.
Exquisite Blood triggers for each opponent that lost life.
Resolve a Exquisite Blood trigger, gaining 1 life.
Repeat from step 3.

---

# 924-2452-2577

**Cards:**

- Gravecrawler
- Rooftop Storm
- Phyrexian Ghoul

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinitely large creature until end of turn, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: UB, Popularity: 841**

**Steps:**

Activate Phyrexian Ghoul's ability by sacrificing Gravecrawler, giving Phyrexian Ghoul +2/+2 until end of turn.
Cast Gravecrawler from your graveyard by paying {0}.
Repeat.

---

# 92-4624

**Cards:**

- Vizkopa Guildmage
- Revival // Revenge

**Produces:** Near-infinite lifeloss

**Mana: {5}{W}{W}{B}{B}, MV: 9, Colors: WB, Popularity: 6258**

**Steps:**

Activate Vizkopa Guildmage's second ability by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Cast Revenge by paying {4}{W}{B}, doubling your life total and causing target opponent to lose half their life, rounded up.
Vizkopa Guildmage triggers, causing each opponent to lose life equal to the life you gained.
Each opponent loses the game due to having zero or less life.

---

# 92-4996

**Cards:**

- Vizkopa Guildmage
- Beacon of Immortality

**Produces:** Near-infinite lifeloss

**Mana: {6}{W}{W}{B}, MV: 9, Colors: WB, Popularity: 5581**

**Steps:**

Activate Vizkopa Guildmage's second ability by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Cast Beacon of Immortality by paying {5}{W}, doubling your life total.
Vizkopa Guildmage triggers, causing each opponent to lose life equal to the life you gained.
Each opponent loses the game due to having zero or less life.

---

# 92-558-2298

**Cards:**

- Carrion Howler
- Vizkopa Guildmage
- Oketra's Last Mercy

**Produces:** Each opponent loses the game

**Mana: {2}{W}{W}{W}{B}, MV: 6, Colors: WB, Popularity: 10**

**Steps:**

Activate Vizkopa Guildmage by paying {1}{W}{B}, causing each opponent to lose life whenever you gain life this turn.
Activate Carrion Howler by paying 1 life.
Repeat step 2 until you have one life.
Resolve all Carrion Howler abilities, giving itself +2/-1 for each ability.
Cast Oketra's Last Mercy by paying {1}{W}{W}, causing your life total to become forty.
Vizkopa Guildmage triggers, causing each opponent to lose thirty-nine life.
Each opponent loses the game due to having zero or less life.

---

# 926-1462

**Cards:**

- Enchanted Evening
- Aura Thief

**Produces:** Gain control of all permanents, Mass Land Denial

**Mana: , MV: 0, Colors: WU, Popularity: 3635**

**Steps:**

Kill Aura Thief.
Aura Thief triggers, causing you to gain control of all permanents.

---

# 933-1061-1869

**Cards:**

- Inalla, Archmage Ritualist
- Timestream Navigator
- Conjurer's Closet

**Produces:** Infinite turns, Lock

**Mana: {3}{U}{U} each turn, MV: 5, Colors: UBR, Popularity: 1228**

**Steps:**

At the beginning of your end step, Conjurer's Closet triggers, blinking Timestream Navigator.
If you don't have the city's blessing, Timestream Navigator's Ascend ability gives you the city's blessing.
When Timestream Navigator enters the battlefield, triggering Inalla, causing you to pay {1} to create a token copy of Timestream Navigator with haste.
Activate the Timestream Navigator token by paying {2}{U}{U}, tapping it, and putting it on the bottom of your library, causing you to take an extra turn after this one.
Repeat each turn.

---

# 933-1061-2506

**Cards:**

- Molten Echoes
- Timestream Navigator
- Conjurer's Closet

**Produces:** Infinite turns, Lock

**Mana: {2}{U}{U} each turn, MV: 4, Colors: UR, Popularity: 781**

**Steps:**

At the beginning of your end step, Conjurer's Closet triggers, blinking Timestream Navigator.
Timestream Navigator enters the battlefield, triggering Molten Echoes, creating a token copy of Timestream Navigator with haste.
Activate the token Timestream Navigator by paying {2}{U}{U}, tapping it and putting it on the bottom of your library, causing you to take an extra turn after this one.
Repeat each turn.

---

# 933-2103-2493

**Cards:**

- Conjurer's Closet
- Archaeomancer
- Capture of Jingzhou

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {3}{U}{U}, MV: 5, Colors: U, Popularity: 360**

**Steps:**

Cast Capture of Jingzhou by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Archaeomancer.
Archaeomancer enters the battlefield, returning Capture of Jingzhou from your graveyard to your hand.
Repeat.

---

# 933-2103-2556

**Cards:**

- Conjurer's Closet
- Mnemonic Wall
- Capture of Jingzhou

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {3}{U}{U}, MV: 5, Colors: U, Popularity: 76**

**Steps:**

Cast Capture of Jingzhou by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Mnemonic Wall.
Mnemonic Wall enters the battlefield, returning Capture of Jingzhou from your graveyard to your hand.
Repeat.

---

# 933-2104-2493

**Cards:**

- Conjurer's Closet
- Archaeomancer
- Temporal Manipulation

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {3}{U}{U}, MV: 5, Colors: U, Popularity: 914**

**Steps:**

Cast Temporal Manipulation by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Archaeomancer.
Archaeomancer enters the battlefield, returning Temporal Manipulation from your graveyard to your hand.
Repeat.

---

# 933-2104-2556

**Cards:**

- Conjurer's Closet
- Mnemonic Wall
- Temporal Manipulation

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {3}{U}{U}, MV: 5, Colors: U, Popularity: 153**

**Steps:**

Cast Temporal Manipulation by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Mnemonic Wall.
Mnemonic Wall enters the battlefield, returning Temporal Manipulation from your graveyard to your hand.
Repeat.

---

# 933-2493-3617

**Cards:**

- Conjurer's Closet
- Archaeomancer
- Time Walk

**Produces:** Infinite ETB, Infinite LTB, Lock, Infinite turns

**Mana: {1}{U}, MV: 2, Colors: U, Popularity: 0**

**Steps:**

Cast Time Walk by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Archaeomancer.
Archaeomancer enters the battlefield, returning Time Walk from your graveyard to your hand.
Repeat.

---

# 933-2493-4377

**Cards:**

- Conjurer's Closet
- Archaeomancer
- Walk the Aeons

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {4}{U}{U}, MV: 6, Colors: U, Popularity: 279**

**Steps:**

Cast Walk the Aeons by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Archaeomancer.
Archaeomancer enters the battlefield, returning Walk the Aeons from your graveyard to your hand.
Repeat.

---

# 933-2493-4872

**Cards:**

- Conjurer's Closet
- Archaeomancer
- Time Warp

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {3}{U}{U}, MV: 5, Colors: U, Popularity: 1558**

**Steps:**

Cast Time Warp by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Archaeomancer.
Archaeomancer enters the battlefield, returning Time Warp from your graveyard to your hand.
Repeat.

---

# 933-2556-3617

**Cards:**

- Conjurer's Closet
- Mnemonic Wall
- Time Walk

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {1}{U}, MV: 2, Colors: U, Popularity: 0**

**Steps:**

Cast Time Walk by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Mnemonic Wall.
Mnemonic Wall enters the battlefield, returning Time Walk from your graveyard to your hand.
Repeat.

---

# 933-2556-4377

**Cards:**

- Conjurer's Closet
- Mnemonic Wall
- Walk the Aeons

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {4}{U}{U}, MV: 6, Colors: U, Popularity: 87**

**Steps:**

Cast Walk the Aeons by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Mnemonic Wall.
Mnemonic Wall enters the battlefield, returning Walk the Aeons from your graveyard to your hand.
Repeat.

---

# 933-2556-4872

**Cards:**

- Conjurer's Closet
- Mnemonic Wall
- Time Warp

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {3}{U}{U}, MV: 5, Colors: U, Popularity: 219**

**Steps:**

Cast Time Warp by paying {3}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Mnemonic Wall.
Mnemonic Wall enters the battlefield, returning Time Warp from your graveyard to your hand.
Repeat.

---

# 933-2724-3194

**Cards:**

- Wormfang Manta
- Hushwing Gryff
- Conjurer's Closet

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: WU, Popularity: 37**

**Steps:**

At the beginning of your end step Conjurer's Closet triggers, exiling Wormfang Manta and returns it to the battlefield.
On LTB Wormfang Manta triggers, giving you an extra turn.
On ETB Hushwing Gryff prevents Wormfang Manta's trigger, so you do not skip your next turn.
Take your extra turn.

---

# 933-2724-3987

**Cards:**

- Wormfang Manta
- Torpor Orb
- Conjurer's Closet

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: U, Popularity: 24**

**Steps:**

At the beginning of your end step Conjurer's Closet triggers, exiling Wormfang Manta and returns it to the battlefield.
On LTB Wormfang Manta triggers, giving you an extra turn.
On ETB Torpor Orb prevents Wormfang Manta's trigger, so you do not skip your next turn.
Take your extra turn.

---

# 933-2724-4006

**Cards:**

- Wormfang Manta
- Hushbringer
- Conjurer's Closet

**Produces:** Infinite turns, Lock

**Mana: , MV: 0, Colors: WU, Popularity: 13**

**Steps:**

At the beginning of your end step Conjurer's Closet triggers, exiling Wormfang Manta and returns it to the battlefield.
On LTB Wormfang Manta triggers, giving you an extra turn.
On ETB Hushbringer prevents Wormfang Manta's trigger, so you do not skip your next turn.
Take your extra turn.

---

# 933-957-2493

**Cards:**

- Conjurer's Closet
- Archaeomancer
- Time Stretch

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {8}{U}{U}, MV: 10, Colors: U, Popularity: 422**

**Steps:**

Cast Time Stretch by paying {8}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Archaeomancer.
Archaeomancer enters the battlefield, returning Time Stretch from your graveyard to your hand.
Repeat.

---

# 933-957-2556

**Cards:**

- Conjurer's Closet
- Mnemonic Wall
- Time Stretch

**Produces:** Infinite ETB, Infinite LTB, Infinite turns, Lock

**Mana: {8}{U}{U}, MV: 10, Colors: U, Popularity: 46**

**Steps:**

Cast Time Stretch by paying {8}{U}{U}, taking an extra turn after this one.
At the beginning of your end step, Conjurer's Closet triggers, blinking Mnemonic Wall.
Mnemonic Wall enters the battlefield, returning Time Stretch from your graveyard to your hand.
Repeat.

---

# 936-1290

**Cards:**

- Bloodchief Ascension
- Mindcrank

**Produces:** Infinite mill, Near-infinite lifegain, Near-infinite lifegain triggers, Near-infinite lifeloss

**Mana: , MV: 0, Colors: B, Popularity: 52966**

**Steps:**

Cause one or more opponents to lose life.
Mindcrank triggers once for each life loss event, causing that player to mill cards equal to the amount of life lost.
Bloodchief Ascension triggers once for each card milled, causing that player to lose 2 life and you to gain 2 life for each trigger.
Repeat from step 2.

---

# 936-5069

**Cards:**

- Duskmantle Guildmage
- Mindcrank

**Produces:** Each opponent loses the game, Infinite mill, Near-infinite lifeloss

**Mana: {1}{U}{B} plus an additional {2}{U}{B} for each opponent you have, MV: 3, Colors: UB, Popularity: 17020**

**Steps:**

Activate Duskmantle Guildmage's first ability by paying {1}{U}{B}, causing your opponent to lose life whenever a card is put into their graveyard this turn.
Activate Duskmantle Guildmage's second ability by paying {2}{U}{B}, causing an opponent to mill two cards.
Duskmantle Guildmage triggers twice.
Resolve the first trigger, causing the opponent to lose 1 life.
Mindcrank triggers, causing the opponent to mill a card.
Duskmantle Guildmage triggers, causing the opponent to lose 1 life.
Repeat from step 5 until the opponent has a life total of zero, causing them to lose the game.
Repeat from step 2 for each other opponent.

---

# 937-2358-4551

**Cards:**

- Phyrexian Unlife
- Magus of the Mirror
- Blood Celebrant

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WB, Popularity: 318**

**Steps:**

During your upkeep, activate Blood Celebrant by paying {B} and one life, adding {B}.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-2358-4591

**Cards:**

- Platinum Angel
- Magus of the Mirror
- Blood Celebrant

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: B, Popularity: 367**

**Steps:**

During your upkeep, activate Blood Celebrant by paying {B} and one life, adding {B}.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-2358-4695

**Cards:**

- Soul Echo
- Magus of the Mirror
- Blood Celebrant

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WB, Popularity: 51**

**Steps:**

During your upkeep, activate Blood Celebrant by paying {B} and one life, adding {B}.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-2749-4551

**Cards:**

- Phyrexian Unlife
- Magus of the Mirror
- Wall of Blood

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WB, Popularity: 629**

**Steps:**

During your upkeep, activate Wall of Blood by paying 1 life, giving Wall of Blood +1/+1 until end of turn.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-2749-4591

**Cards:**

- Platinum Angel
- Magus of the Mirror
- Wall of Blood

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: B, Popularity: 982**

**Steps:**

During your upkeep, activate Wall of Blood by paying 1 life, giving Wall of Blood +1/+1 until end of turn.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-2749-4695

**Cards:**

- Soul Echo
- Magus of the Mirror
- Wall of Blood

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WB, Popularity: 66**

**Steps:**

During your upkeep, activate Wall of Blood by paying 1 life, giving Wall of Blood +1/+1 until end of turn.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-2935-4551

**Cards:**

- Phyrexian Unlife
- Magus of the Mirror
- Ethereal Champion

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WB, Popularity: 12**

**Steps:**

During your upkeep, activate Ethereal Champion by paying 1 life, preventing the next one damage that will be dealt to Ethereal Champion this turn.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-2935-4591

**Cards:**

- Platinum Angel
- Magus of the Mirror
- Ethereal Champion

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WB, Popularity: 17**

**Steps:**

During your upkeep, activate Ethereal Champion by paying 1 life, preventing the next one damage that will be dealt to Ethereal Champion this turn.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-2935-4695

**Cards:**

- Soul Echo
- Magus of the Mirror
- Ethereal Champion

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WB, Popularity: 5**

**Steps:**

During your upkeep, activate Ethereal Champion by paying 1 life, preventing the next one damage that will be dealt to Ethereal Champion this turn.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-3591-4551

**Cards:**

- Phyrexian Unlife
- Magus of the Mirror
- Necropotence

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WB, Popularity: 376**

**Steps:**

During your upkeep, activate Necropotence by paying 1 life, exiling the top card of your library face down.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-3591-4591

**Cards:**

- Platinum Angel
- Magus of the Mirror
- Necropotence

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: B, Popularity: 542**

**Steps:**

During your upkeep, activate Necropotence by paying 1 life, exiling the top card of your library face down.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-3591-4695

**Cards:**

- Soul Echo
- Magus of the Mirror
- Necropotence

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WB, Popularity: 50**

**Steps:**

During your upkeep, activate Necropotence by paying 1 life, exiling the top card of your library face down.
Repeat step 1 until you have zero life.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-3859-4551

**Cards:**

- Phyrexian Unlife
- Magus of the Mirror
- Cavern Harpy

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WUB, Popularity: 3**

**Steps:**

During your upkeep, activate Cavern Harpy by paying 1 life.
Repeat step 1 until you have zero life.
Resolve the last Cavern Harpy trigger, returning it to your hand.
The remaining Cavern Harpy triggers fizzle.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-3859-4591

**Cards:**

- Platinum Angel
- Magus of the Mirror
- Cavern Harpy

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: UB, Popularity: 5**

**Steps:**

During your upkeep, activate Cavern Harpy by paying 1 life.
Repeat step 1 until you have zero life.
Resolve the last Cavern Harpy trigger, returning it to your hand.
The remaining Cavern Harpy triggers fizzle.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 937-3859-4695

**Cards:**

- Soul Echo
- Magus of the Mirror
- Cavern Harpy

**Produces:** Target player loses the game

**Mana: , MV: 0, Colors: WUB, Popularity: 1**

**Steps:**

During your upkeep, activate Cavern Harpy by paying 1 life.
Repeat step 1 until you have zero life.
Resolve the last Cavern Harpy trigger, returning it to your hand.
The remaining Cavern Harpy triggers fizzle.
Activate Magus of the Mirror by tapping and sacrificing it, exchanging your life total with an opponent.
The opponent loses the game due to having zero life.

---

# 940-2178-3500

**Cards:**

- Thornbite Staff
- Arcane Teachings
- Basilisk Collar

**Produces:** Destroy all creatures opponents control, Destroy all creatures opponents control whenever a creature enters the battlefield, Lock

**Mana: , MV: 0, Colors: R, Popularity: 51**

**Steps:**

Activate the creature by tapping it, dealing 1 damage to any opponent's creature and causing you to gain 1 life.
The opponent's creature dies due to deathtouch, triggering Thornbite Staff, untapping your creature.
Repeat.

---

# 9-411-1283-2500-4600

**Cards:**

- Chromatic Orrery
- Grinning Ignus
- Mirage Mirror
- Grapeshot
- Mirror Gallery

**Produces:** Infinite damage, Infinite storm count

**Mana: , MV: 0, Colors: R, Popularity: 3**

**Steps:**

Tap Orrery for 5 mana.
Tap 2 mana to activate mirror, targeting grinning ignus.
In response, activate mirror again targeting orrery.
tap mirror for 5 mana before letting it become an ignus.
Use one mana to return mirror to your hand using ignus's ability.
this adds 3 to your mana pool.
8 floating.
cast mirror from your hand, 5 floating.
Repeat.
Cast grapeshot for Infinite damage.

---

# 9-411-2500-2604-5116

**Cards:**

- Ugin, the Ineffable
- Grinning Ignus
- Mirage Mirror
- Gilded Lotus
- Grapeshot

**Produces:** Infinite damage, Infinite magecraft triggers, Infinite storm count

**Mana: {1}, MV: 1, Colors: R, Popularity: 5**

**Steps:**

Activate Gilded Lotus by tapping it, adding {3}.
Activate Mirage Mirror twice by paying {4}, targeting Grinning Ignus and Gilded Lotus.
Resolve the first Mirage Mirror ability, causing it to become a copy of Gilded Lotus until end of turn.
Activate Mirage Mirror by tapping it, adding {R}{R}{R}.
Resolve the second Mirage Mirror ability, causing it to become a copy of Grinning Ignus until end of turn.
Activate Mirage Mirror by paying {R} and returning it to your hand, adding {C}{C}{R}.
Cast Mirage Mirror by paying {1}.
Repeat from step 2 until you have a very large storm count.
Cast Grapeshot by paying {1}{R}.
Grapeshot's storm ability triggers, creating a copy of Grapeshot for each spell you've cast this turn.
Resolve all Grapeshots, dealing infinite damage to any target(s).

---

# 943-1556-4235

**Cards:**

- Rings of Brighthearth
- Deserted Temple
- Scorched Ruins

**Produces:** Infinite colorless mana, Infinite mana lands you control can produce, Infinite untap of lands you control

**Mana: , MV: 0, Colors: C, Popularity: 2992**

**Steps:**

Activate Scorched Ruins by tapping it, adding {C}{C}{C}{C}.
Activate Deserted Temple's second ability by paying {1} and tapping it, targeting Scorched Ruins.
Rings of Brighthearth triggers, causing you to pay {2} to copy Deserted Temple's ability, targeting Deserted Temple.
Resolve both Deserted Temple abilities, untapping Deserted Temple and Scorched Ruins.
Repeat an arbitrarily large number of times.
Once you have a large amount of {C}, you may untap any other lands you control in place of Scorched Ruins.

---

# 944-4050-4242-5105

**Cards:**

- Sigil of the New Dawn
- Phyrexian Altar
- Su-Chi
- Planar Gate

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: W, Popularity: 2**

**Steps:**

Activate Phyrexian Altar by sacrificing Su-Chi, adding {W}.
Su-Chi dies, triggering itself and Sigil of New Dawn.
Resolve the Su-Chi trigger, adding {C}{C}{C}{C}.
Resolve the Sigil of New Dawn trigger, causing you to pay {1}{W} to return Su-Chi from your graveyard to your hand.
Cast Su-Chi by paying {1}.
Repeat.

---

# 944-4050-5004-5105

**Cards:**

- Sigil of the New Dawn
- Phyrexian Altar
- Cathodion
- Planar Gate

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers, Infinite storm count

**Mana: , MV: 0, Colors: W, Popularity: 0**

**Steps:**

Activate Phyrexian Altar by sacrificing Cathodion, adding {W}.
Cathodion dies, triggering itself and Sigil of New Dawn.
Resolve the Cathodion trigger, adding {C}{C}{C}.
Resolve the Sigil of New Dawn trigger, causing you to pay {1}{W} to return Cathodion from your graveyard to your hand.
Cast Cathodion by paying {1}.
Repeat.

---

# 949-1343-2686

**Cards:**

- Kaervek's Spite
- Academy Rector
- Barren Glory

**Produces:** Win the game

**Mana: {B}{B}{B}, MV: 3, Colors: WB, Popularity: 257**

**Steps:**

During the end step before your turn, cast Kaervek's Spite by paying {B}{B}{B}, discarding your hand, and sacrificing all permanents.
Academy Rector triggers, exiling itself and searching your library for Barren Glory, putting it onto the battlefield, and shuffling your library.
Resolve Kaervek's Spite, causing target player to lose five life.
At the beginning of your upkeep, Barren Glory triggers, causing you to win the game.

---

# 950-1584-3525

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Teferi's Isle

**Produces:** Infinite blue mana, Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: U, Popularity: 39**

**Steps:**

Activate Teferi's Isle by tapping it, adding {U}{U}.
Activate Fatestitcher by tapping it, untapping Teferi's Isle.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-1584-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Teferi's Isle

**Produces:** Infinite blue mana, Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: U, Popularity: 41**

**Steps:**

Activate Teferi's Isle by tapping it, adding {U}{U}.
Activate Fatestitcher by tapping it, untapping Teferi's Isle.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-1671-3525

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Simic Growth Chamber

**Produces:** Infinite green mana, Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: GU, Popularity: 374**

**Steps:**

Activate Simic Growth Chamber by tapping it, adding {U}{G}.
Activate Fatestitcher by tapping it, untapping Simic Growth Chamber.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-1671-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Simic Growth Chamber

**Produces:** Infinite green mana, Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: GU, Popularity: 568**

**Steps:**

Activate Simic Growth Chamber by tapping it, adding {U}{G}.
Activate Fatestitcher by tapping it, untapping Simic Growth Chamber.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-2605-3525

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Lotus Vale

**Produces:** Infinite colored mana

**Mana: , MV: 0, Colors: U, Popularity: 222**

**Steps:**

Activate Lotus Vale by tapping it, adding {U}{U}{U}.
Activate Fatestitcher by tapping it, untapping Lotus Vale.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.
Repeat steps with a different color for infinite mana of any color.

---

# 950-2605-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Lotus Vale

**Produces:** Infinite colored mana

**Mana: , MV: 0, Colors: U, Popularity: 224**

**Steps:**

Activate Lotus Vale by tapping it, adding {U}{U}{U}.
Activate Fatestitcher by tapping it, untapping Lotus Vale.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.
Repeat steps with a different color for infinite mana of any color.

---

# 950-3078-3525

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Soldevi Excavations

**Produces:** Infinite colorless mana

**Mana: , MV: 0, Colors: U, Popularity: 108**

**Steps:**

Activate Soldevi Excavations by tapping it, adding {C}{U}.
Activate Fatestitcher by tapping it, untapping Soldevi Excavations.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3078-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Soldevi Excavations

**Produces:** Infinite colorless mana

**Mana: , MV: 0, Colors: U, Popularity: 114**

**Steps:**

Activate Soldevi Excavations by tapping it, adding {C}{U}.
Activate Fatestitcher by tapping it, untapping Soldevi Excavations.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3147-3525

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Azorius Chancery

**Produces:** Infinite white mana, Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: WU, Popularity: 570**

**Steps:**

Activate Azorius Chancery by tapping it, adding {W}{U}.
Activate Fatestitcher by tapping it, untapping Azorius Chancery.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3147-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Azorius Chancery

**Produces:** Infinite white mana, Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: WU, Popularity: 813**

**Steps:**

Activate Azorius Chancery by tapping it, adding {W}{U}.
Activate Fatestitcher by tapping it, untapping Azorius Chancery.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3201-3525

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Arixmethes, Slumbering Isle

**Produces:** Infinite green mana

**Mana: , MV: 0, Colors: GU, Popularity: 87**

**Steps:**

Activate Arixmethes by tapping it, adding {U}{G}.
Activate Fatestitcher by tapping it, untapping Arixmethes.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3201-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Arixmethes, Slumbering Isle

**Produces:** Infinite green mana

**Mana: , MV: 0, Colors: GU, Popularity: 122**

**Steps:**

Activate Arixmethes by tapping it, adding {U}{G}.
Activate Fatestitcher by tapping it, untapping Arixmethes.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3230-3525

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Coral Atoll

**Produces:** Infinite colorless mana, Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: U, Popularity: 288**

**Steps:**

Activate Coral Atoll by tapping it, adding {C}{U}.
Activate Fatestitcher by tapping it, untapping Coral Atoll.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3230-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Coral Atoll

**Produces:** Infinite colorless mana, Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: U, Popularity: 349**

**Steps:**

Activate Coral Atoll by tapping it, adding {C}{U}.
Activate Fatestitcher by tapping it, untapping Coral Atoll.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3478-3525

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Dimir Aqueduct

**Produces:** Infinite black mana, Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: UB, Popularity: 735**

**Steps:**

Activate Dimir Aqueduct by tapping it, adding {U}{B}.
Activate Fatestitcher by tapping it, untapping Dimir Aqueduct.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3478-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Dimir Aqueduct

**Produces:** Infinite black mana, Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: UB, Popularity: 923**

**Steps:**

Activate Dimir Aqueduct by tapping it, adding {U}{B}.
Activate Fatestitcher by tapping it, untapping Dimir Aqueduct.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3525-3573

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Tolarian Academy

**Produces:** Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: U, Popularity: 0**

**Steps:**

Activate Tolarian Academy by tapping it, adding at least {U}{U}.
Activate Fatestitcher by tapping it, untapping Tolarian Academy.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3525-3664

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Lotus Field

**Produces:** Infinite colored mana, Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: U, Popularity: 573**

**Steps:**

Activate Lotus Field by tapping it, adding {U}{U}{U}.
Activate Fatestitcher by tapping it, untapping Lotus Field.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.
Repeat steps with a different color for infinite mana of any color.

---

# 950-3525-3756

**Cards:**

- Pemmin's Aura
- Fatestitcher
- Izzet Boilerworks

**Produces:** Infinite red mana, Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: UR, Popularity: 309**

**Steps:**

Activate Izzet Boilerworks by tapping it, adding {U}{R}.
Activate Fatestitcher by tapping it, untapping Izzet Boilerworks.
Activate Pemmin's Aura's first ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3573-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Tolarian Academy

**Produces:** Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: U, Popularity: 0**

**Steps:**

Activate Tolarian Academy by tapping it, adding at least {U}{U}.
Activate Fatestitcher by tapping it, untapping Tolarian Academy.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 950-3664-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Lotus Field

**Produces:** Infinite colored mana, Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: U, Popularity: 666**

**Steps:**

Activate Lotus Field by tapping it, adding {U}{U}{U}.
Activate Fatestitcher by tapping it, untapping Lotus Field.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.
Repeat steps with a different color for infinite mana of any color.

---

# 950-3756-4222

**Cards:**

- Freed from the Real
- Fatestitcher
- Izzet Boilerworks

**Produces:** Infinite red mana, Infinite mana permanents you control can produce

**Mana: , MV: 0, Colors: UR, Popularity: 547**

**Steps:**

Activate Izzet Boilerworks by tapping it, adding {U}{R}.
Activate Fatestitcher by tapping it, untapping Izzet Boilerworks.
Activate Freed from the Real's last ability by paying {U}, untapping Fatestitcher.
Repeat any number of times.

---

# 95-1848

**Cards:**

- Bruvac the Grandiloquent
- Fleet Swallower

**Produces:** Near-infinite self-mill, Infinite mill for target opponent

**Mana: , MV: 0, Colors: U, Popularity: 14041**

**Steps:**

Declare Fleet Swallower as an attacker, triggering its ability, causing an opponent to mill their library due to Bruvac.

---

# 953-1139-1371

**Cards:**

- Hive Mind
- Enter the Infinite
- Howling Mine

**Produces:** Each opponent loses the game, Infinite card draw, Infinite card draw for each opponent, Infinite draw triggers, Infinite draw triggers for each opponent

**Mana: {8}{U}{U}{U}{U}, MV: 12, Colors: U, Popularity: 329**

**Steps:**

Cast Enter the Infinite by paying {8}{U}{U}{U}{U}.
Hive Mind triggers, causing each opponent to create a copy of Enter the Infinite.
Resolve each Enter the Infinite, causing each player to draw their entire library, put a card from their hand on top of their library, and have no maximum hand size until their next turn.
At the beginning of each opponent's draw step, Howling Mine triggers, causing them to draw an additional card and lose the game due to drawing from an empty library.

---

# 953-1371-2065

**Cards:**

- Hive Mind
- Enter the Infinite
- Dictate of Kruphix

**Produces:** Each opponent loses the game, Infinite card draw, Infinite card draw for each opponent, Infinite draw triggers, Infinite draw triggers for each opponent

**Mana: {8}{U}{U}{U}{U}, MV: 12, Colors: U, Popularity: 266**

**Steps:**

Cast Enter the Infinite by paying {8}{U}{U}{U}{U}.
Hive Mind triggers, causing each opponent to create a copy of Enter the Infinite.
Resolve each Enter the Infinite, causing each player to draw their entire library, put a card from their hand on top of their library, and have no maximum hand size until their next turn.
At the beginning of each opponent's draw step, Dictate of Kruphix triggers, causing them to draw an additional card and lose the game due to drawing from an empty library.

---

# 953-1371-2870

**Cards:**

- Hive Mind
- Enter the Infinite
- Anvil of Bogardan

**Produces:** Each opponent loses the game, Infinite card draw, Infinite card draw for each opponent, Infinite draw triggers, Infinite draw triggers for each opponent

**Mana: {8}{U}{U}{U}{U}, MV: 12, Colors: U, Popularity: 74**

**Steps:**

Cast Enter the Infinite by paying {8}{U}{U}{U}{U}.
Hive Mind triggers, causing each opponent to create a copy of Enter the Infinite.
Resolve each Enter the Infinite, causing each player to draw their entire library, put a card from their hand on top of their library, and have no maximum hand size until their next turn.
At the beginning of each opponent's draw step, Anvil of Bogardan triggers, causing them to draw an additional card, discard a card and lose the game due to drawing from an empty library.

---

# 953-1371-3032

**Cards:**

- Hive Mind
- Enter the Infinite
- Kami of the Crescent Moon

**Produces:** Each opponent loses the game, Infinite card draw, Infinite card draw for each opponent, Infinite draw triggers, Infinite draw triggers for each opponent

**Mana: {8}{U}{U}{U}{U}, MV: 12, Colors: U, Popularity: 289**

**Steps:**

Cast Enter the Infinite by paying {8}{U}{U}{U}{U}.
Hive Mind triggers, causing each opponent to create a copy of Enter the Infinite.
Resolve each Enter the Infinite, causing each player to draw their entire library, put a card from their hand on top of their library, and have no maximum hand size until their next turn.
At the beginning of each opponent's draw step, Kami triggers, causing them to draw an additional card and lose the game due to drawing from an empty library.

---

# 954-2034-2302-4215

**Cards:**

- Verdant Succession
- Angel of Fury
- Ashnod's Altar
- Painter's Servant

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: GW, Popularity: 1**

**Steps:**

Activate Ashnod's Altar by sacrificing Angel of Fury, adding {C}{C}.
Angel of Fury and Verdant Succession trigger.
Resolve the Angel of Fury trigger, shuffling it into your library.
Resolve the Verdant Succession trigger, searching your library for Angel of Fury, putting it onto the battlefield and shuffling your library.
Repeat.

---

# 954-2302-4050-4215

**Cards:**

- Verdant Succession
- Angel of Fury
- Phyrexian Altar
- Painter's Servant

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: GW, Popularity: 1**

**Steps:**

Activate Phyrexian Altar by sacrificing Angel of Fury, adding one mana of any color.
Angel of Fury and Verdant Succession trigger.
Resolve the Angel of Fury trigger, shuffling it into your library.
Resolve the Verdant Succession trigger, searching your library for Angel of Fury, putting it onto the battlefield and shuffling your library.
Repeat.

---

# 954-2302-4215-5256

**Cards:**

- Verdant Succession
- Angel of Fury
- Altar of Dementia
- Painter's Servant

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: GW, Popularity: 0**

**Steps:**

Activate Altar of Dementia by sacrificing Angel of Fury.
Angel of Fury and Verdant Succession trigger.
Resolve the Angel of Fury trigger, shuffling it into your library.
Resolve the Verdant Succession trigger, searching your library for Angel of Fury, putting it onto the battlefield and shuffling your library.
Resolve the Altar of Dementia ability from step 1, causing target player to mill cards equal to Angel of Fury's power.
Repeat.

---

# 95-5080

**Cards:**

- Bruvac the Grandiloquent
- Maddening Cacophony

**Produces:** Infinite mill

**Mana: {4}{U}{U}, MV: 6, Colors: U, Popularity: 46180**

**Steps:**

Cast Maddening Cacophony with kicker by paying {4}{U}{U}, causing each opponent to mill their library due to Bruvac.

---

# 957-1271-3212

**Cards:**

- God-Eternal Kefnet
- Scroll Rack
- Time Stretch

**Produces:** Infinite turns, Lock

**Mana: {7}{U}{U} each turn, MV: 9, Colors: U, Popularity: 201**

**Steps:**

Tap Scroll Rack and pay {1} to activate it, putting Time Stretch on top of your library.
Pass the turn.
On your next draw step, when you draw Time Stretch, reveal it due to Kefnet's ability, making a copy that costs {2} less to cast.
Cast the copy for {6}{U}{U}, granting you two extra turns.

---

# 957-1702-3212

**Cards:**

- God-Eternal Kefnet
- Jace, the Mind Sculptor
- Time Stretch

**Produces:** Infinite turns, Lock

**Mana: {6}{U}{U} each turn, MV: 8, Colors: U, Popularity: 132**

**Steps:**

Activate Jace's zero loyalty ability, putting Time Stretch on top of your library.
Move to your next turn.
On your next draw step, when you draw Time Stretch, reveal it due to Kefnet's ability, making a copy that costs {2} less to cast.
Cast the copy for {6}{U}{U}, granting you two extra turns.

---

# 957-2334-2493

**Cards:**

- Soulherder
- Archaeomancer
- Time Stretch

**Produces:** Infinite turns, Lock

**Mana: {8}{U}{U} every other turn, MV: 10, Colors: WU, Popularity: 112**

**Steps:**

With Soulherder and a creature based spell recursion effect on the battlefield, cast the extra turn spell.
Move to end step and target the creature with Soulherder's ability.
When creature re-enters the battlefield, target the extra turn spell in your graveyard and return it to your hand, then pass to yourself.
Repeat

---

# 957-2334-2556

**Cards:**

- Soulherder
- Mnemonic Wall
- Time Stretch

**Produces:** Infinite turns, Lock

**Mana: {8}{U}{U} every other turn, MV: 10, Colors: WU, Popularity: 15**

**Steps:**

With Soulherder and a creature based spell recursion effect on the battlefield, cast the extra turn spell.
Move to end step and target the creature with Soulherder's ability.
When creature re-enters the battlefield, target the extra turn spell in your graveyard and return it to your hand, then pass to yourself.
Repeat

---

# 957-2493-4428

**Cards:**

- Thassa, Deep-Dwelling
- Archaeomancer
- Time Stretch

**Produces:** Infinite turns, Lock

**Mana: {8}{U}{U} every other turn, MV: 10, Colors: U, Popularity: 715**

**Steps:**

Cast Time Stretch by paying {8}{U}{U}, getting two extra turns after this one.
At the beginning of your end step, Thassa triggers, blinking Archaeomancer.
Archaeomancer enters the battlefield, returning Time Stretch from your graveyard to your hand.
Repeat every other turn.

---

# 957-2556-4305

**Cards:**

- Mnemonic Wall
- Followed Footsteps
- Time Stretch

**Produces:** Infinite turns, Lock

**Mana: {8}{U}{U} each turn, MV: 10, Colors: U, Popularity: 4**

**Steps:**

Cast Time Stretch by paying {8}{U}{U}, taking two extra turns after this one.
At the beginning of your upkeep on your next extra turn, Followed Footsteps triggers, creating a token copy of Mnemonic Wall.
Mnemonic Wall enters the battlefield, returning Time Stretch from your graveyard to your hand.
Repeat each turn.

---

# 957-2556-4428

**Cards:**

- Thassa, Deep-Dwelling
- Mnemonic Wall
- Time Stretch

**Produces:** Infinite turns, Lock

**Mana: {8}{U}{U} every other turn, MV: 10, Colors: U, Popularity: 53**

**Steps:**

Cast Time Stretch by paying {8}{U}{U}, getting two extra turns after this one.
At the beginning of your end step, Thassa triggers, blinking Mnemonic Wall.
Mnemonic Wall enters the battlefield, returning Time Stretch from your graveyard to your hand.
Repeat every other turn.

---

# 958-1750-2365-5261

**Cards:**

- Isochron Scepter
- Pull from Eternity
- Dralnu, Lich Lord
- Expropriate

**Produces:** Infinite turns, Lock

**Mana: {9}{U}{U} each turn, MV: 11, Colors: WUB, Popularity: 0**

**Steps:**

Cast Expropriate by paying {7}{U}{U}, causing you to take at least one extra turn after this one and exile Expropriate.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Pull from Eternity without paying its mana cost.
Resolve Pull from Eternity, putting Expropriate into your graveyard from exile.
Move to your next turn.
Activate Dralnu by tapping it, giving Expropriate flashback until end of turn.
Cast Expropriate from your graveyard by paying {7}{U}{U}, causing you to take an extra turn after this one and exile Expropriate.
Repeat from step 2.

---

# 958-1750-2575-5261

**Cards:**

- Isochron Scepter
- Pull from Eternity
- Dralnu, Lich Lord
- Temporal Mastery

**Produces:** Infinite turns, Lock

**Mana: {7}{U}{U} each turn, MV: 9, Colors: WUB, Popularity: 0**

**Steps:**

Cast Temporal Mastery by paying {5}{U}{U}, causing you to take an extra turn after this one and exile Temporal Mastery.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Pull from Eternity without paying its mana cost.
Resolve Pull from Eternity, putting Temporal Mastery into your graveyard from exile.
Move to your next turn.
Activate Dralnu by tapping it, giving Temporal Mastery flashback until end of turn.
Cast Temporal Mastery from your graveyard by paying {5}{U}{U}, causing you to take an extra turn after this one and exile Temporal Mastery.
Repeat from step 2.

---

# 958-1750-4084-5261

**Cards:**

- Isochron Scepter
- Pull from Eternity
- Dralnu, Lich Lord
- Part the Waterveil

**Produces:** Lock, Infinite turns

**Mana: {6}{U}{U} each turn, MV: 8, Colors: WUB, Popularity: 0**

**Steps:**

Cast Part the Waterveil by paying {4}{U}{U}, causing you to take an extra turn after this one and exile Part the Waterveil.
Activate Isochron Scepter by paying {2} and tapping it, casting a copy of Pull from Eternity without paying its mana cost.
Resolve Pull from Eternity, putting Part the Waterveil into your graveyard from exile.
Move to your next turn.
Activate Dralnu by tapping it, giving Part the Waterveil flashback until end of turn.
Cast Part the Waterveil from your graveyard by paying {4}{U}{U}, causing you to take an extra turn after this one and exile Part the Waterveil.
Repeat from step 2.

---

# 968-2660-4772

**Cards:**

- Jace, Architect of Thought
- Wheel of Sun and Moon
- Doubling Season

**Produces:** Cast any number of spells from opponents' libraries, Infinite storm count

**Mana: {2}{U}{U}, MV: 4, Colors: GWU, Popularity: 63**

**Steps:**

Cast Jace, Architect of Thought for {2}{U}{U} which enters with 8 loyalty counters due to Doubling Season.
Activate Jace's -8, putting it on the bottom of your library.
Search you library for Jace and exile it, and exile a nonland card of your choice.
Cast Jace along with any of the nonland cards you wish to cast.
Repeat from step 2.

---

# 969-1991-3259

**Cards:**

- Tana, the Bloodsower
- Breath of Fury
- Fervor

**Produces:** Infinite combat damage, Infinite combat phases, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mana creatures you control can produce, Infinite sacrifice triggers, Infinite untap of creatures you control, Infinite creature tokens with haste

**Mana: , MV: 0, Colors: RG, Popularity: 21**

**Steps:**

Deal combat damage with Tana and the creature that has Breath of Fury attached.
Tana and Breath of Fury triggers.
Resolve the Tana trigger, creating a number of 1/1 Saproling creature tokens equal to the damage Tana dealt.
Resolve the Breath of Fury trigger, causing you to sacrifice the creature it is attached to, attach Breath of Fury to a Saproling token, untap all creatures you control and get an additional combat phase after this one.
Repeat.

---

# 971-2034-3048-5003

**Cards:**

- Roalesk, Apex Hybrid
- Ashnod's Altar
- Nim Deathmantle
- Pentad Prism

**Produces:** Infinite ETB, Infinite LTB, Infinite proliferate

**Mana: , MV: 0, Colors: GU, Popularity: 1**

**Steps:**

Sacrifice Roalesk to Ashnod's Altar generating two colorless, with Roalesk's death you proliferate twice, putting two more counters on Pentad Prism.
Remove those counters for two mana, use the other two mana from Ashnod's to return Roalesk to the battlefield using Nim Deathmantle.
Repeat.

---

# 972-1061-1953

**Cards:**

- Brudiclad, Telchor Engineer
- Timestream Navigator
- Saheeli's Artistry

**Produces:** Lock, Infinite turns

**Mana: {6}{U}{U}{U}{U} on your first turn, with {2}{U}{U} available on each extra turn, MV: 10, Colors: UR, Popularity: 162**

**Steps:**

Cast Saheeli's Artistry by paying {4}{U}{U}, creating a token copy of Timestream Navigator.
At the beginning of your combat phase, Brudiclad triggers, creating a 2/1 Phyrexian Myr creature token, then choosing to have all tokens you control become copies of the Timestream Navigator token.
Activate Timestream Navigator by paying {2}{U}{U} and tapping it and putting it onto the bottom of your library, causing you to take an extra turn after this one.
Move to your next turn.
Repeat from step 2.

---

# 972-1953-2105

**Cards:**

- Brudiclad, Telchor Engineer
- Combat Celebrant
- Saheeli's Artistry

**Produces:** Infinite combat phases, Infinite damage

**Mana: {4}{U}{U}, MV: 6, Colors: UR, Popularity: 470**

**Steps:**

Cast Saheeli's Artistry by paying {4}{U}{U}, creating a token copy of Combat Celebrant.
At the beginning of your combat phase, Brudiclad triggers, creating a 2/1 Phyrexian Myr creature token, then choosing to have all tokens you control become copies of the Combat Celebrant token.
Declare one of the Combat Celebrant copy as an attacker, choosing to exert it as it attacks.
The Combat Celebrant copy triggers, untapping all other creatures you control and causing you to get an additional combat phase after this one.
Repeat from step 2.

---

# 976-1029-2428-3990-4435

**Cards:**

- Greed
- Horizon Chimera
- Alhammarret's Archive
- Incubation Druid
- Tolarian Kraken

**Produces:** Infinite card draw, Infinite draw triggers, Near-infinite colored mana, Near-infinite lifegain, Near-infinite lifegain triggers

**Mana: , MV: 0, Colors: BGU, Popularity: 0**

**Steps:**

Activate Incubation Druid by tapping it, adding {B}{B}{B}.
Activate Greed by paying {B} and two life, causing you to draw two cards.
Horizon Chimera and Tolarian Kraken each trigger twice.
Resolve both Horizon Chimera triggers, causing you to gain four life.
Resolve the first Tolarian Kraken trigger, choosing not to pay.
Resolve the second Tolarian Kraken trigger, causing you to pay {1} to untap Incubation Druid.
Repeat.

---

# 976-1029-2428-3990-5042

**Cards:**

- Greed
- Horizon Chimera
- Teferi's Ageless Insight
- Incubation Druid
- Tolarian Kraken

**Produces:** Infinite card draw, Infinite draw triggers, Near-infinite colored mana

**Mana: , MV: 0, Colors: BGU, Popularity: 0**

**Steps:**

Activate Incubation Druid by tapping it, adding {B}{B}{B}.
Activate Greed by paying {B} and two life, causing you to draw two cards.
Horizon Chimera and Tolarian Kraken each trigger twice.
Resolve both Horizon Chimera triggers, causing you to gain two life.
Resolve the first Tolarian Kraken trigger, choosing not to pay.
Resolve the second Tolarian Kraken trigger, causing you to pay {1} to untap Incubation Druid.
Repeat.

---

# 978-1429-2034

**Cards:**

- Vizier of Remedies
- Lesser Masticore
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: W, Popularity: 314**

**Steps:**

Activate Ashnod's Altar by sacrificing Lesser Manticore, adding {C}{C}.
Lesser Manticore's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Repeat.

---

# 978-1429-4050

**Cards:**

- Vizier of Remedies
- Lesser Masticore
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: W, Popularity: 233**

**Steps:**

Activate Phyrexian Altar by sacrificing Lesser Manticore, adding one mana of any color.
Lesser Manticore's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Repeat.

---

# 978-1429-5256

**Cards:**

- Vizier of Remedies
- Lesser Masticore
- Altar of Dementia

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: W, Popularity: 379**

**Steps:**

Activate Altar of Dementia by sacrificing Lesser Manticore.
Lesser Manticore's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Resolve the Altar of Dementia ability, causing target player to mill cards equal to Lesser Manticore's power.
Repeat.

---

# 978-2034-2086

**Cards:**

- Vizier of Remedies
- Kitchen Finks
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: GW, Popularity: 576**

**Steps:**

Activate Ashnod's Altar by sacrificing Kitchen Finks, adding {C}{C}.
Kitchen Finks' persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Kitchen Finks enters the battlefield, causing you to gain two life.
Repeat.

---

# 978-2034-2111

**Cards:**

- Vizier of Remedies
- Wingrattle Scarecrow
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: W, Popularity: 76**

**Steps:**

Activate Ashnod's Altar by sacrificing Wingrattle Scarecrow, adding {C}{C}.
Wingrattle Scarecrow's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Repeat.

---

# 978-2034-2620

**Cards:**

- Vizier of Remedies
- Safehold Elite
- Ashnod's Altar

**Produces:** Infinite colorless mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: GW, Popularity: 329**

**Steps:**

Activate Ashnod's Altar by sacrificing Safehold Elite, adding {C}{C}.
Safehold Elite's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Repeat.

---

# 978-2034-3607

**Cards:**

- River Kelpie
- Vizier of Remedies
- Ashnod's Altar

**Produces:** Infinite card draw, Near-infinite colorless mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers

**Mana: , MV: 0, Colors: WU, Popularity: 36**

**Steps:**

Activate Ashnod's Altar by sacrificing River Kelpie, adding {C}{C}.
River Kelpie's persist triggers, returning it from your graveyard to the battlefield.
River Kelpie enters the battlefield, causing you to draw.
Repeat.

---

# 978-2086-4050

**Cards:**

- Vizier of Remedies
- Kitchen Finks
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite lifegain, Infinite lifegain triggers, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: GW, Popularity: 345**

**Steps:**

Activate Phyrexian Altar by sacrificing Kitchen Finks, adding one mana of any color.
Kitchen Finks' persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Kitchen Finks enters the battlefield, causing you to gain two life.
Repeat.

---

# 978-2086-5256

**Cards:**

- Vizier of Remedies
- Kitchen Finks
- Altar of Dementia

**Produces:** Infinite death triggers, Infinite ETB, Infinite lifegain triggers, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill, Infinite lifegain

**Mana: , MV: 0, Colors: GW, Popularity: 437**

**Steps:**

Activate Altar of Dementia by sacrificing Kitchen Finks.
Kitchen Finks' persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Kitchen Finks enters the battlefield, causing you to gain two life.
Resolve the Altar of Dementia ability, causing target player to mill cards equal to Kitchen Finks' power.
Repeat.

---

# 978-2111-4050

**Cards:**

- Vizier of Remedies
- Wingrattle Scarecrow
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: W, Popularity: 48**

**Steps:**

Activate Phyrexian Altar by sacrificing Wingrattle Scarecrow, adding one mana of any color.
Wingrattle Scarecrow's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Repeat.

---

# 978-2111-5256

**Cards:**

- Vizier of Remedies
- Wingrattle Scarecrow
- Altar of Dementia

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: W, Popularity: 77**

**Steps:**

Activate Altar of Dementia by sacrificing Wingrattle Scarecrow.
Wingrattle Scarecrow's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Resolve the Altar of Dementia ability, causing target player to mill cards equal to Wingrattle Scarecrow's power.
Repeat.

---

# 978-2292-3607

**Cards:**

- River Kelpie
- Vizier of Remedies
- Viscera Seer

**Produces:** Infinite card draw, Near-infinite ETB, Near-infinite death triggers, Near-infinite LTB, Near-infinite sacrifice triggers

**Mana: , MV: 0, Colors: WUB, Popularity: 18**

**Steps:**

Activate Viscera Seer by sacrificing River Kelpie.
River Kelpie's persist triggers, returning it from your graveyard to the battlefield.
River Kelpie enters the battlefield, causing you to draw.
Resolve the Viscera Seer trigger, scrying 1.
Repeat.

---

# 978-2438-3607

**Cards:**

- River Kelpie
- Vizier of Remedies
- Carrion Feeder

**Produces:** Infinite card draw, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinitely large creature, Near-infinite sacrifice triggers

**Mana: , MV: 0, Colors: WUB, Popularity: 10**

**Steps:**

Activate Carrion Feeder by sacrificing River Kelpie.
River Kelpie's persist triggers, returning it from your graveyard to the battlefield.
River Kelpie enters the battlefield, causing you to draw.
Resolve the Carrion Feeder trigger, putting a +1/+1 counter on it.
Repeat.

---

# 978-2620-4050

**Cards:**

- Vizier of Remedies
- Safehold Elite
- Phyrexian Altar

**Produces:** Infinite colored mana, Infinite death triggers, Infinite ETB, Infinite LTB, Infinite sacrifice triggers

**Mana: , MV: 0, Colors: GW, Popularity: 199**

**Steps:**

Activate Phyrexian Altar by sacrificing Safehold Elite, adding one mana of any color.
Safehold Elite's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Repeat.

---

# 978-2620-5256

**Cards:**

- Vizier of Remedies
- Safehold Elite
- Altar of Dementia

**Produces:** Infinite death triggers, Infinite ETB, Infinite LTB, Infinite mill, Infinite sacrifice triggers, Infinite self-mill

**Mana: , MV: 0, Colors: GW, Popularity: 258**

**Steps:**

Activate Altar of Dementia by sacrificing Safehold Elite.
Safehold Elite's persist ability triggers, returning it from your graveyard to the battlefield with zero -1/-1 counters due to Vizier of Remedies.
Resolve the Altar of Dementia ability, causing target player to mill cards equal to Safehold Elite's power.
Repeat.

---

# 978-3607-3899

**Cards:**

- River Kelpie
- Vizier of Remedies
- Spawning Pit

**Produces:** Infinite card draw, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers

**Mana: , MV: 0, Colors: WU, Popularity: 7**

**Steps:**

Activate Spawning Pit by sacrificing River Kelpie.
River Kelpie's persist triggers, returning it from your graveyard to the battlefield.
River Kelpie enters the battlefield, causing you to draw.
Resolve the Spawning Pit trigger, putting a charge counter on it.
Repeat.

---

# 978-3607-4050

**Cards:**

- River Kelpie
- Vizier of Remedies
- Phyrexian Altar

**Produces:** Infinite card draw, Near-infinite colored mana, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite sacrifice triggers

**Mana: , MV: 0, Colors: WU, Popularity: 23**

**Steps:**

Activate Phyrexian Altar by sacrificing River Kelpie, adding {1}.
River Kelpie's persist triggers, returning it from your graveyard to the battlefield.
River Kelpie enters the battlefield, causing you to draw.
Repeat.

---

# 978-3607-5256

**Cards:**

- River Kelpie
- Vizier of Remedies
- Altar of Dementia

**Produces:** Infinite card draw, Near-infinite death triggers, Near-infinite ETB, Near-infinite LTB, Near-infinite mill, Near-infinite sacrifice triggers

**Mana: , MV: 0, Colors: WU, Popularity: 19**

**Steps:**

Activate Altar of Dementia by sacrificing River Kelpie.
River Kelpie's persist triggers, returning it from your graveyard to the battlefield.
River Kelpie enters the battlefield, causing you to draw.
Resolve the Altar of Dementia trigger, causing target player to mill three cards.
Repeat.

---

# 978-4762

**Cards:**

- Devoted Druid
- Vizier of Remedies

**Produces:** Infinite green mana

**Mana: , MV: 0, Colors: GW, Popularity: 4349**

**Steps:**

Activate Devoted Druid by tapping it, adding {G}.
Activate Devoted Druid by putting a zero -1/-1 counter on it due to Vizier of Remedies, untapping it.
Repeat.

---

# 981-1517-1532-2104

**Cards:**

- The Mirari Conjecture
- Faith's Reward
- Temporal Manipulation
- Cursecatcher

**Produces:** Infinite turns, Lock

**Mana: {6}{W}{U}{U} every other turn, MV: 9, Colors: WU, Popularity: 0**

**Steps:**

At the beginning of your precombat main phase, The Mirari Conjecture triggers, putting a lore counter on itself, sacrificing itself and copying all instant and sorcery spells you cast this turn.
Cast Temporal Manipulation by paying {3}{U}{U}.
The Mirari Conjecture triggers, creating a copy of Temporal Manipulation.
Resolve both Temporal Manipulations, getting two extra turns after this one.
Cast Faith's Reward by paying {3}{W}.
The Mirari Conjecture triggers, copying Faith's Reward.
Holding priority, activate Cursecatcher by sacrificing it, countering the original Faith's Reward.
Resolve the Faith's Reward copy, returning The Mirari Conjecture and Cursecatcher from your graveyard to the battlefield.
The Mirari Conjecture triggers, putting a lore counter on itself and returning Faith's Reward from your graveyard to your hand.
Proceed to your next turn.
At the beginning of your precombat main phase, The Mirari Conjecture triggers, putting a lore counter on itself and returning Temporal Manipulation from your graveyard to your hand.
Proceed to your next turn.
Repeat.

---

# 981-1517-1532-4377

**Cards:**

- The Mirari Conjecture
- Faith's Reward
- Walk the Aeons
- Cursecatcher

**Produces:** Infinite turns, Lock

**Mana: {7}{W}{U}{U} every other turn, MV: 10, Colors: WU, Popularity: 0**

**Steps:**

At the beginning of your precombat main phase, The Mirari Conjecture triggers, putting a lore counter on itself, sacrificing itself and copying all instant and sorcery spells you cast this turn.
Cast Walk the Aeons by paying {4}{U}{U}.
The Mirari Conjecture triggers, creating a copy of Walk the Aeons.
Resolve both Walk the Aeonss, getting two extra turns after this one.
Cast Faith's Reward by paying {3}{W}.
The Mirari Conjecture triggers, copying Faith's Reward.
Holding priority, activate Cursecatcher by sacrificing it, countering the original Faith's Reward.
Resolve the Faith's Reward copy, returning The Mirari Conjecture and Cursecatcher from your graveyard to the battlefield.
The Mirari Conjecture triggers, putting a lore counter on itself and returning Faith's Reward from your graveyard to your hand.
Proceed to your next turn.
At the beginning of your precombat main phase, The Mirari Conjecture triggers, putting a lore counter on itself and returning Walk the Aeons from your graveyard to your hand.
Proceed to your next turn.
Repeat.

---

# 981-1517-2104-3505

**Cards:**

- The Mirari Conjecture
- Second Sunrise
- Temporal Manipulation
- Cursecatcher

**Produces:** Infinite turns, Lock

**Mana: {4}{W}{W}{U}{U} every other turn, MV: 8, Colors: WU, Popularity: 0**

**Steps:**

At the beginning of your precombat main phase, The Mirari Conjecture triggers, putting a lore counter on itself, sacrificing itself and copying all instant and sorcery spells you cast this turn.
Cast Temporal Manipulation by paying {3}{U}{U}.
The Mirari Conjecture triggers, creating a copy of Temporal Manipulation.
Resolve both Temporal Manipulations, getting two extra turns after this one.
Cast Second Sunrise by paying {1}{W}{W}.
The Mirari Conjecture triggers, copying Second Sunrise.
Holding priority, activate Cursecatcher by sacrificing it, countering the original Second Sunrise.
Resolve the Second Sunrise copy, returning The Mirari Conjecture and Cursecatcher from your graveyard to the battlefield.
The Mirari Conjecture triggers, putting a lore counter on itself and returning Second Sunrise from your graveyard to your hand.
Proceed to your next turn.
At the beginning of your precombat main phase, The Mirari Conjecture triggers, putting a lore counter on itself and returning Temporal Manipulation from your graveyard to your hand.
Proceed to your next turn.
Repeat.

---

# 981-1517-3505-4377

**Cards:**

- The Mirari Conjecture
- Second Sunrise
- Walk the Aeons
- Cursecatcher

**Produces:** Infinite turns, Lock

**Mana: {5}{W}{W}{U}{U} every other turn, MV: 9, Colors: WU, Popularity: 0**

**Steps:**

At the beginning of your precombat main phase, The Mirari Conjecture triggers, putting a lore counter on itself, sacrificing itself and copying all instant and sorcery spells you cast this turn.
Cast Walk the Aeons by paying {4}{U}{U}.
The Mirari Conjecture triggers, creating a copy of Walk the Aeons.
Resolve both Walk the Aeonss, getting two extra turns after this one.
Cast Second Sunrise by paying {1}{W}{W}.
The Mirari Conjecture triggers, copying Second Sunrise.
Holding priority, activate Cursecatcher by sacrificing it, countering the original Second Sunrise.
Resolve the Second Sunrise copy, returning The Mirari Conjecture and Cursecatcher from your graveyard to the battlefield.
The Mirari Conjecture triggers, putting a lore counter on itself and returning Second Sunrise from your graveyard to your hand.
Proceed to your next turn.
At the beginning of your precombat main phase, The Mirari Conjecture triggers, putting a lore counter on itself and returning Walk the Aeons from your graveyard to your hand.
Proceed to your next turn.
Repeat.

---

# 985-1594-5078

**Cards:**

- Sensei's Divining Top
- Helm of Awakening
- Mystic Forge

**Produces:** Infinite draw triggers, Infinite card draw, Near-infinite storm count

**Mana: , MV: 0, Colors: C, Popularity: 7763**

**Steps:**

Activate Sensei's Divining Top by tapping it, causing you to draw a card and put Sensei's Divining Top on top of your library.
Cast Sensei's Divining Top from the top of your library by paying {0}.
Repeat

---

# 985-1976-5078

**Cards:**

- Sensei's Divining Top
- Etherium Sculptor
- Mystic Forge

**Produces:** Infinite card draw, Near-infinite storm count, Infinite draw triggers

**Mana: , MV: 0, Colors: U, Popularity: 31580**

**Steps:**

Activate Sensei's Divining Top by tapping it, causing you to draw a card and put Sensei's Divining Top on top of your library.
Cast Sensei's Divining Top from the top of your library by paying {0}.
Repeat

---

# 985-2146-5078

**Cards:**

- Sensei's Divining Top
- Cloud Key
- Mystic Forge

**Produces:** Infinite card draw, Near-infinite storm count, Infinite draw triggers

**Mana: , MV: 0, Colors: C, Popularity: 27810**

**Steps:**

Activate Sensei's Divining Top by tapping it, causing you to draw a card and put Sensei's Divining Top on top of your library.
Cast Sensei's Divining Top from the top of your library by paying {0}.
Repeat

---

# 985-4985-5078

**Cards:**

- Sensei's Divining Top
- Jhoira's Familiar
- Mystic Forge

**Produces:** Infinite draw triggers, Infinite card draw, Near-infinite storm count

**Mana: , MV: 0, Colors: C, Popularity: 19525**

**Steps:**

Activate Sensei's Divining Top by tapping it, causing you to draw a card and put Sensei's Divining Top on top of your library.
Cast Sensei's Divining Top from the top of your library by paying {0}.
Repeat

---

# 989-5125-5218

**Cards:**

- Dream Halls
- Verdant Eidolon
- Sparkcaster

**Produces:** Infinite damage, Infinite ETB, Infinite LTB, Infinite self-discard triggers, Infinite storm count

**Mana: , MV: 0, Colors: GUR, Popularity: 2**

**Steps:**

Cast Sparkcaster by discarding Verdant Eidolon.
Verdant Eidolon triggers from your graveyard, returning from your graveyard to your hand.
Sparkcaster enters the battlefield, triggering twice.
Resolve the first Sparkcaster trigger, dealing 1 damage to target player or planeswalker.
Resolve the second Sparkcaster trigger, returning Sparkcaster from the battlefield to your hand.
Repeat.

---

# 992-2702

**Cards:**

- Archetype of Imagination
- Moat

**Produces:** Opponents can't attack, Lock

**Mana: , MV: 0, Colors: WU, Popularity: 257**

**Steps:**

All creatures your opponent control lose flying.
Moat prevents things without flying from attacking.
Creatures your opponent can not fulfill the conditions necessary to attack.

---

# 992-4468

**Cards:**

- Moat
- Mystic Decree

**Produces:** Creatures can't attack, Lock

**Mana: , MV: 0, Colors: WU, Popularity: 40**

**Steps:**

All creatures lose flying and Islandwalk.
Moat prevents things without flying from attacking.
Creatures can not fulfill the conditions nessasary to attack.

---

# 998-1080-1494-5261

**Cards:**

- Scute Mob
- Bioshift
- Sage of Hours
- Isochron Scepter

**Produces:** Infinite turns, Lock

**Mana: {2}, MV: 2, Colors: GU, Popularity: 2**

**Steps:**

Activate Isochron Scepter by tapping it and paying {2}, casting a copy of Bioshift without paying its mana cost, targeting Scute Mob and Sage of Hours.
Sage of Hours triggers, putting a +1/+1 counter on itself.
Resolve the Bioshift copy, moving four +1/+1 counters from Scute Mob onto Sage of Hours.
Activate Sage of Hours by removing all +1/+1 counters from it, generating an extra turn after this one.
At the beginning of your extra turn's upkeep, Scute Mob triggers, putting four +1/+1 counters on itself.
Repeat.

---

